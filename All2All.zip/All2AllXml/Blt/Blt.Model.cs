﻿using A2aCommands.Xml;
using A2aTypes.Xml;
using All2All;
using log4net;
using NbTools.SqlGen.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace All2AllXml.Blt
{
    public class BltModel : IDataProvider
    {
        private enum NodeType { Root, Server, Node, Mailbox };

        private const string TypesXml = @"C:\Repo\All2All\All2AllXml\Blt\Types.xml";
        internal static readonly ILog Log = LogManager.GetLogger(nameof(BltModel));

        private readonly A2aT A2aT;
        public A2aT GetTypes() => A2aT; //2
        public string ModelName => nameof(BltModel);    //1

        private readonly IUserInterface Ui;

        public BltModel(IUserInterface ui)
        {
            Ui = ui;
            Log.Info($"Loading {nameof(A2aT)} from '{TypesXml}'");
            A2aT = A2aT.LoadFile(TypesXml);
        }


        public Task GetChildren(string parentIdN, string parentTypeN, IEnumerable<string> typesN, CancellationToken canToken, int requestId)
        {
            if (parentIdN == null && parentTypeN == null)
            {
                Ui.AddSimple(UpdateType.Add, nodeId: nameof(NodeType.Root), nodeType: nameof(NodeType.Root), null, nameof(NodeType.Root), true, requestId);
            }
            else if (parentIdN != null && parentTypeN != null)
            {
                switch (parentTypeN)
                {
                    case nameof(NodeType.Root):
                        foreach(string srvName in new[] { "Srv09", "Srv30", "Srv31" })
                            Ui.AddSimple(UpdateType.Add, nodeId: srvName, nodeType: nameof(NodeType.Server), parentIdN, label: srvName, hasChildren: true, requestId);
                        break;

                    case nameof(NodeType.Server):
                        foreach (int nodeNum in Enumerable.Range(1, 5))
                        {
                            string nodeName = $"{parentIdN}-{nodeNum}";
                            Ui.AddSimple(UpdateType.Add, nodeId: nodeName, nodeType: nameof(NodeType.Node), parentIdN, label: nodeName, hasChildren: false, requestId);
                        }
                        break;

                    case nameof(NodeType.Node): //List of mailboxes here
                        break;

                    default:
                        throw new Exception($"Type '{parentTypeN}' is not supported");
                }
            }
            else
                throw new Exception("Either parentIdN or parentTypeN is not specified");

            return Task.CompletedTask;
        }



        public Task ExecuteCommand(string cmdName, string scrNodeId, string scrNodeType, string scrNodeName, string dstNodeIdN)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsDouble(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsMultiple(string selNodeId, string selNodeType, string selNodeName, IEnumerable<string> nodeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsSingle(string nodeId, string nodeType)
        {
            yield break;
        }

        public IEnumerable<A2aCommandDesc> GetDragCommands(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId)
        {
            throw new NotImplementedException();
        }

        public Task GetList(NbSqlXml request, CancellationToken canToken, int previousRequestId, int requestId)
        {
            return Task.CompletedTask;
        }


        public void Dispose() { }
    }
}
