﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using A2aCommands.Xml;
using A2aTypes.Xml;
using NbTools;
using NbTools.SqlGen.Xml;


namespace All2All.Disk
{
    public class ModelDisk : IDataProvider
    {
        private readonly IUserInterface Ui;
        public string ModelName => "All2AllDisk";
        private const string RootDir = @"D:\Videos";

        internal enum NodeTypes { Dir, File };

        public ModelDisk(IUserInterface ui)
        {
            Ui = ui ?? throw new ArgumentNullException(nameof(ui));
        }

        public A2aT GetTypes()
        {
            throw new NotImplementedException();
        }

        public Task GetChildren(string parentIdN, string parentTypeN, IEnumerable<string> typesN, CancellationToken canToken, int requestId)
        {
            if (parentIdN == null)
            {
                Ui.AddSimple(UpdateType.Add, RootDir, "Dir", null, RootDir, true, requestId);
            }
            else
            {   //THINK: send the type of the parent node into this method?
                DirectoryInfo di = new DirectoryInfo(parentIdN);
                if (di.Exists)
                {
                    foreach (string type in typesN.Safe())
                    {
                        switch (type)
                        {
                            case "Dir":
                                foreach (var d in di.GetDirectories())
                                {
                                    Ui.AddSimple(UpdateType.Add, d.FullName, "Dir", parentIdN, d.Name, false, requestId);
                                }
                                break;
                            case "File":
                                //di.GetFiles().ForEachSafe(f => Ui.AddSimple(UpdateType.Add, f.FullName, parentIdN, f.Name, false, requestId));
                                break;
                            default:
                                throw new NbException($"Unsupported type: '{type}'");
                        }

                    }
                }
            }
            return Task.CompletedTask;
        }

        private readonly List<(string, DisplayStyles)> FileColumns = new List<(string, DisplayStyles)>
        {
            ("Name", DisplayStyles.String),
            ("Size", DisplayStyles.FileSize),
        };

        private static string[] FileColumnValues(FileInfo f) => new string[] { f.Name, f.Length.ToString() };

        //THINK: Get Details requests full details for a parent, maybe 
        // SetColumns() and AddAllFields() 
        public Task GetDetails(string parentId, string parentType, IEnumerable<string> typesN, CancellationToken _, int requestId)
        {
            Ui.SetColumns(FileColumns, requestId);

            DirectoryInfo di = new DirectoryInfo(parentId);
            if (di.Exists)
            {
                foreach (string type in typesN.Safe())
                {
                    switch (type)
                    {
                        case "Dir":
                            //di.GetDirectories().ForEachSafe(d => Ui.AddSimple(UpdateType.Add, d.FullName, parentId, d.Name, false, requestId));
                            break;
                        case "File":
                            foreach (var f in di.GetFiles())
                            {
                                if (f.Name == "desktop.ini")
                                    continue;
                                Ui.AddAllFields(UpdateType.Add, f.FullName, "File", FileColumnValues(f), requestId);
                            }
                            break;
                        default:
                            throw new NbException($"Unsupported type: '{type}'");
                    }
                }
            }
            return Task.CompletedTask;
        }

        enum CmdEnum { Play, Rename, SendUpdate }

        private static readonly A2aCommandDesc CmdPlay = new A2aCommandDesc       { id = nameof(CmdEnum.Play),       label = nameof(CmdEnum.Play), hotkey = "LButton", tooltip = "Play file" };
        private static readonly A2aCommandDesc CmdRename = new A2aCommandDesc     { id = nameof(CmdEnum.Rename),     label = nameof(CmdEnum.Rename), hotkey = "F2", tooltip = "Edit file name" };
        private static readonly A2aCommandDesc CmdSendUpdate = new A2aCommandDesc { id = nameof(CmdEnum.SendUpdate), label = "Send Update", tooltip = "Update selected record for testing purposes" };

        public IEnumerable<A2aCommandDesc> GetCommandsSingle(string nodeId, string nodeType)
        {
            yield return CmdPlay;
            yield return CmdRename;
            yield return CmdSendUpdate;
        }

        private const string MediaPlayer = @"""C:\Program Files (x86)\K-Lite Codec Pack\MPC-HC64\mpc-hc64.exe""";
        public async Task ExecuteCommand(string name, string srcNodeId, string scrNodeType, string scrNodeName, string dstNodeIdN)
        {
            if (!Enum.TryParse(name, out CmdEnum cmdName)) throw new NbExceptionEnum<CmdEnum>(name);
            if (!Enum.TryParse(scrNodeType, out NodeTypes tp)) throw new NbExceptionEnum<NodeTypes>(scrNodeType);

            switch (cmdName)
            {
                case CmdEnum.Play:
                    switch (tp)
                    {
                        case NodeTypes.Dir:
                            break;
                        case NodeTypes.File:
                            if (File.Exists(srcNodeId))
                            {
                                Ui.SetStatus($"Play file '{srcNodeId}'");
                                await NbProcess.RunAsync(MediaPlayer, new SingleSequence<string>(srcNodeId), null);
                                Ui.SetStatus($"Finished playing file '{srcNodeId}'");
                            }
                            break;
                        default:
                            throw new NbExceptionEnum<NodeTypes>(tp);
                    }
                    break;
                case CmdEnum.Rename:
                    break;
                case CmdEnum.SendUpdate:
                    var f = new FileInfo(srcNodeId);
                    Ui.AddAllFields(UpdateType.Update, srcNodeId, scrNodeType, FileColumnValues(f), 0); //Unsolicited request
                    break;
                default:
                    throw new NbExceptionEnum<CmdEnum>(cmdName);
            }
        }

        public IEnumerable<A2aCommandDesc> GetDragCommands(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId)
        {
            throw new NotImplementedException();
        }

        public void Dispose() { }

        public Task GetList(NbSqlXml request, CancellationToken canToken, int requestId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsDouble(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsMultiple(string selNodeId, string selNodeType, string selNodeName, IEnumerable<string> nodeId)
        {
            throw new NotImplementedException();
        }
    }
}
