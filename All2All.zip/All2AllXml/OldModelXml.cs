﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

using NbTools;
using NbTools.SqlGen.Xml;

using A2aCommands.Xml;
using A2aTypes.Xml;

namespace All2All.Xml
{

    internal class RefResolved
    {
        public Node From;
        public Node To;
        public RefType RefType;

        public override string ToString() => $"'{From.id}' -({RefType.id})-> '{To.id}'";
    }


    /// <summary>
    /// Old model, just nodes references and links, no flavours
    /// </summary>
    public class OldModelXml : IDataProvider
    {
        private readonly all2all All2All;
        private readonly NbDictionary<string, Node> Nodes;
        private readonly NbDictionary<string, NbDictionary<string, DisplayStyleXml>> NodeTypes;
        private readonly NbDictionary<string, RefType> RefTypes;

        private readonly List<RefResolved> ForwardReferences;
        private readonly HashSet<Node> Roots; //Keep resolved root nodes, not the Ids;

        private readonly IUserInterface Ui;

        public string ModelName => "All2AllXMl";
        const string IconName = "care-4";

        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public OldModelXml(IUserInterface ui)
        {
            string fileName = "all2all.xml";

            Ui = ui ?? throw new ArgumentNullException(nameof(ui));

            All2All = all2all.LoadXml(fileName);
            Log.Info("Xml loaded: " + fileName);

            Nodes = All2All.nodes.Items.ToNbDictionary(n => n.id, n => n, StringComparer.OrdinalIgnoreCase, 100, "Nodes");
            RefTypes = All2All.ref_types.Items.ToNbDictionary(n => n.id, n => n, StringComparer.OrdinalIgnoreCase, 100, "RefTypes");
            NodeTypes = All2All.node_types.Items.ToNbDictionary(nt => nt.id,
                nt => nt.field_type.ToNbDictionary(ft => ft.field_name, ft => ft.display_style, StringComparer.OrdinalIgnoreCase, 100, $"Node type '{nt.id}' field types"),
                StringComparer.OrdinalIgnoreCase, 100, "Node types");


            ForwardReferences = new List<RefResolved>(All2All.refs.Items.Length);
            var rootIds = new HashSet<string>(All2All.nodes.Items.Select(n => n.id));

            Log.Info($"Nodes: {Nodes.Count}, RefTypes: {RefTypes.Count}, NodeTypes: {NodeTypes.Count}, Roots: {rootIds.Count}");

            foreach (var r in All2All.refs.Items)
            {
                var refRes = new RefResolved();
                if (!Nodes.TryGetValue(r.from, out refRes.From) || !Nodes.TryGetValue(r.to, out refRes.To))
                    throw new Exception($"Referred node '{r.from}' cannot be found: {r}");

                if (!RefTypes.TryGetValue(r.type, out refRes.RefType))
                    throw new Exception($"Reference type '{r.type}' cannot be found: {r}");

                ForwardReferences.Add(refRes);
                rootIds.Remove(r.to);
            }

            Roots = new HashSet<Node>(rootIds.Select(id => Nodes[id]));
            ForwardReferences.Sort((x, y) => String.Compare(x.From.id, y.From.id));
        }

        //TODO: support reference types - i.e. Show all songs, but not the authors
        IEnumerable<Node> GetChildren(string nodeId, string _, HashSet<string> nodeTypesN) =>
            ForwardReferences.Where(r => r.From.id.Equals(nodeId)).Select(r => r.To) //All children of the parent
                    .Where(n => nodeTypesN?.Contains(n.type) ?? true); //Where children are of the specified nodeType

        bool HasChildren(string nodeId, string nodeType, HashSet<string> nodeTypesN) => GetChildren(nodeId, nodeType, nodeTypesN).Any();

        private IEnumerable<(FieldInfo, DisplayStyles)> GetFieldsNode(Node node)
        {
            var ndType = NodeTypes[node.type];

            foreach (var fld in node.GetType().GetFields().Where(f => !f.IsStatic
                && !f.Name.EndsWith("Specified")  //Boolean properties for null
                && !f.Name.EqIC("id") && !f.Name.EqIC("type")))     //Id or type will never be shown on the screen, these are functional fields
            {
                var displayStyleXml = ndType[fld.Name];
                var displayStyle = (DisplayStyles)Enum.Parse(typeof(DisplayStyles), displayStyleXml.ToString()); //DisplayStyle is defined in common interface that doesn't know about the xml schema
                yield return (fld, displayStyle);
            }
        }

        /// <summary>
        /// Request to send the child nodes asynchronously to the IDisplaySimple interface
        /// </summary>
        /// <param name="parentIdN">Id of the parent node in the tree, if null - send all root nodes</param>
        /// <param name="nodeTypesN">The type of references to follow from the parent to the child nodes, if null - send all references</param>
        /// <param name="cnc">Cancellation token</param>
        /// <param name="requestId">Request Id that will be sent back to the requester with IDisplaySimple call</param>
        /// <returns></returns>
        public async Task GetChildren(string parentIdN, string parentTypeN, IEnumerable<string> nodeTypesN, CancellationToken cnc, int requestId)
        {
            await Task.Delay(10);
            var tpHashN = nodeTypesN != null ? new HashSet<string>(nodeTypesN) : null;

            int cntr = 0;
            if (parentIdN == null)
            {
                Log.Debug ($"Request #{requestId} GetChildren for root (no parent), types: {String.Join(" ,", tpHashN)}");

                //await Task.Delay(750);
                foreach (var n in Roots.Where(n => tpHashN?.Contains(n.type) ?? true))
                {
                    Ui.AddSimple(UpdateType.Add, n.id, n.type, nodeIcon: IconName, null, n.label, HasChildren(n.id, n.type, tpHashN), requestId);
                    cntr++;
                }
            }
            else
            {
                Log.Debug($"Request #{requestId} GetChildren for parent '{parentIdN}<{parentTypeN}>', types: {String.Join(" ,", tpHashN)}");
                foreach (Node n in GetChildren(parentIdN, parentTypeN, tpHashN)) //Of the selected type
                {
                    //await Task.Delay(300);
                    Ui.AddSimple(UpdateType.Add, n.id, n.type, nodeIcon: IconName, parentIdN, n.label, HasChildren(n.id, n.type, tpHashN), requestId);
                    cntr++;
                }
            }
            Log.Debug($"Request #{requestId} GetChildren, {cntr} simple records returned");
        }

        //TODO: implement cancel token and cancel if user click too quickly
        public async Task GetDetails(string parentId, string parentType, IEnumerable<string> typesN, CancellationToken _, int requestId)
        {
            if (String.IsNullOrEmpty(parentId)) throw new ArgumentException(nameof(parentId));
            var tpHashN = typesN != null ? new HashSet<string>(typesN) : null;

            bool first = true;
            List<(FieldInfo fi, DisplayStyles ds)> fields = null;
            foreach (Node n in ForwardReferences.Where(r => r.From.id.Equals(parentId)).Select(r => r.To)
                .Where(n => tpHashN?.Contains(n.type) ?? true)) //Of the selected type
            {
                if (first)
                {
                    fields = GetFieldsNode(n).ToList();
                    Ui.SetColumns(fields.Select(f => (f.fi.Name, f.ds)), requestId);
                    first = false;
                }

                await Task.Delay(300);

                var lst = fields.Select(f => f.fi.GetValue(n).ToString()).ToArray();
                Ui.AddAllFields(UpdateType.Add, n.id, n.type, IconName, lst, requestId);
            }
        }

        public async Task GetList(NbSqlXml request, CancellationToken canToken, int prevRequestId, int requestId)
        {
            await Task.Delay(1);
            //Log.Debug($"Request #{requestId} GetList, xml: {request.Serialize()}");

            var andFilters = request?.filter;
            if (andFilters == null || andFilters.Length == 0)
                throw new Exception("No filters provided");

            var typesN = new string[] { "File" }; //TODO: pass with the message
            var tpHashN = typesN != null ? new HashSet<string>(typesN) : null;


            //TODO: support in_subtree in_node properly
            InSubtree subtreeFltN = request?.filter.SafeOfType<InSubtree>().SingleOrDefaultVerbose(who: "in_subtree filter", whats: "request filters");
            IEnumerable<Node> resultNodes = null;


            if (subtreeFltN != null)
            {
                var parentId = subtreeFltN.root_node_id;
                if (String.IsNullOrEmpty(parentId)) throw new ArgumentException(nameof(parentId));
                resultNodes = ForwardReferences.Where(r => r.From.id.Equals(parentId)).Select(r => r.To);
            }
            else //subtreeFltN == null
            {
                resultNodes = Nodes.Values;
            }

            bool first = true;
            List<(FieldInfo fi, DisplayStyles ds)> fields = null;
            foreach (Node n in resultNodes.Where(n => tpHashN?.Contains(n.type) ?? true)) //Of the selected type) 
            {
                if (first) //TODO: Support the request's columns list
                {
                    fields = GetFieldsNode(n).ToList();
                    Ui.SetColumns(fields.Select(f => (f.fi.Name, f.ds)), requestId);
                    first = false;
                }

                await Task.Delay(300);

                var lst = fields.Select(f => f.fi.GetValue(n).ToString()).ToArray();
                Ui.AddAllFields(UpdateType.Add, n.id, n.type, IconName, lst, requestId);
            }
        }

        public IEnumerable<A2aCommandDesc> GetCommandsSingle(string nodeId, string nodeType)
        {
            return NbExt.Yield(new A2aCommandDesc { id = nameof(CommandLabels.Edit), label = nameof(CommandLabels.Edit), hotkey = "F4" },
                new A2aCommandDesc { id = "Cmd1" + nodeId, label = "Cmd1 " + nodeId, tooltip = "Long tool tip message", hotkey = "Enter" },
                new A2aCommandDesc { id = "Cmd2" + nodeId, label = "Cmd2 " + nodeId, tooltip = "Long tool tip message" }
            );
        }

        enum CommandLabels { Edit, Move, Associate };

        /// <summary>
        /// Executes command 'name' on the node 'srcNodeId' in relation to 'dstNodeId', which can be null for some commands
        /// </summary>
        /// <param name="name"></param>
        /// <param name="srcNodeId"></param>
        /// <param name="dstNodeId"></param>
        /// <returns></returns>
        public async Task ExecuteCommand(string name, string srcNodeId, string scrNodeType, string scrNodeName, string dstNodeId)
        {
            await Task.Delay(500);
            if (name == nameof(CommandLabels.Edit))
            {
                //Lock object in the DB?
                var nd = Nodes[srcNodeId];
                var formPar = new A2aFormParameters
                {
                    Properties = Node2Properties(nd).ToList(),
                    FormTitle = $"Edit '{nd.label}'"
                };

                var res = await Ui.EditForm(formPar);

                if (res)
                {
                    Ui.SetStatus($"Save the node '{srcNodeId}'");
                    var updates = Properties2Node(formPar.Properties, nd);
                    if (updates > 0)
                    {
                        //Save object in DB, raise event

                        var lst = new string[] { nd.id, "Extra1 " + nd.id, "Extra2 " + nd.label };
                        Ui.AddAllFields(UpdateType.Update, nd.id, nd.type, IconName, lst, 0);
                        Ui.AddSimple(UpdateType.Update, nd.id, nd.type, IconName, parentId: null, label: nd.label, HasChildren(nd.id, nd.type, null), requestId: 0);
                    }
                }
                else
                    Ui.SetStatus($"Do not save the node '{srcNodeId}'");
                //Unlock the object from the DB
            }
            else if (name == nameof(CommandLabels.Move))
                Ui.SetStatus($"Move '{srcNodeId}' to be the child of '{dstNodeId}'");
            else if (name == nameof(CommandLabels.Associate))
                Ui.SetStatus($"Associate '{srcNodeId}' with '{dstNodeId}'");
            else if (name.StartsWith("Cmd1"))
                Ui.SetStatus($"Command '{name}' on the node '{srcNodeId}'");
            else
            {
                var res = await Ui.ShowDialog($"Command '{name}' on the node '{srcNodeId}'");
                Ui.SetStatus($"Dialog response was '{res}'");
            }
        }

        //Returns the number of updates made to the object
        private int Properties2Node(List<A2aFormProperty> props, Node node)
        {
            var tp = node.GetType();
            var cnt = 0;
            foreach (var fi in tp.GetFields().Where(fi => !fi.IsStatic))
            {
                var prop = props.Where(p => p.Id == fi.Name).SingleEnsure("properties", fi.Name, "property list");
                if (!fi.GetValue(node).ToString().Equals(prop.Value))
                {
                    fi.SetValue(node, Convert.ChangeType(prop.Value, fi.FieldType));
                    cnt++;
                }
            }
            return cnt;
        }

        public static IEnumerable<A2aFormProperty> Node2Properties(Node node)
        {
            var tp = node.GetType();
            var cnt = 0;
            foreach (var fi in tp.GetFields().Where(fi => !fi.IsStatic))
            {
                var custAttr = fi.GetCustomAttributes();

                yield return new A2aFormProperty
                {
                    Id = fi.Name,
                    Label = fi.Name,
                    Type = fi.FieldType.Name.ToString(),
                    Value = fi.GetValue(node)?.ToString() ?? null,
                    Tooltip = fi.Name
                };
                cnt++;
            }

            if (cnt == 0)
                throw new Exception($"There are no fields in type '{tp.Name}'");
        }

        public IEnumerable<A2aCommandDesc> GetDragCommands(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeIdN)
        {
            if (String.IsNullOrEmpty(dstNodeIdN) || srcNodeId.Equals(dstNodeIdN))
                return Enumerable.Empty<A2aCommandDesc>();
            else
                return NbExt.Yield(new A2aCommandDesc { id = nameof(CommandLabels.Move), label = nameof(CommandLabels.Move) },
                    new A2aCommandDesc { id = nameof(CommandLabels.Associate), label = nameof(CommandLabels.Associate) }
                    );
        }

        public void Dispose()
        { }

        public IEnumerable<A2aCommandDesc> GetCommandsDouble(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsMultiple(string selNodeId, string selNodeType, string selNodeName, IEnumerable<string> nodeId)
        {
            throw new NotImplementedException();
        }

        public A2aT GetTypes()
        {
            throw new NotImplementedException();
        }
    }
}
