﻿using System;
using System.Diagnostics;
using System.IO;
using System.Xml.Serialization;

namespace All2All.Xml
{
    partial class all2all
    {
        public static Lazy<XmlSerializer> modelXmlSerializer = new Lazy<XmlSerializer>(() => new XmlSerializer(typeof(all2all)), false);
        public static all2all LoadXml(string xmlFileName)
        {
            try
            {
                all2all res;
                var fl = new FileInfo(xmlFileName);
                if (!fl.Exists)
                    throw new Exception($"Layout file does not exist: '{fl.FullName}'");

                using (FileStream str = new FileStream(fl.FullName, FileMode.Open))
                using (StreamReader rdr = new StreamReader(str))
                {
                    res = (all2all)modelXmlSerializer.Value.Deserialize(rdr);
                    //res.FileName = fl.FullName;
                }
                return res;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deserializing '{xmlFileName}'", ex);
            }
        }
    }

    /// <summary>
    /// All2All Xml generic Node 
    /// </summary>
    [DebuggerDisplay("Xml Node #{id} {type} {label}")]
    public partial class Node : IEquatable<Node>
    {
        public bool Equals(Node other) => id.Equals(other);
        public override int GetHashCode() => id.GetHashCode();
        public override bool Equals(object obj) => Equals(obj as Node);
    }

    /// <summary>
    /// All2All Xml generic Reference between nodes 
    /// </summary>
    public partial class Ref
    {
        public override string ToString() => $"'{from}' -({type})-> '{to}'";
    }
}
