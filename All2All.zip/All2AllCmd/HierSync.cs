﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace All2AllCmd
{
    public abstract class HierSync<A, B> 
        where A : class where B : class
    {
        public abstract bool Compare(A a, B b);
        public abstract IEnumerable<A> GetChildren(A a);
        public abstract IEnumerable<B> GetChildren(B b);

        public abstract void OnRemove(A a);
        public abstract void OnAdd(B b);
        public abstract void OnMatch(A a, B b);
        
        public abstract void OnPush(A a);
        public abstract void OnPop(A a);
        public abstract void OnError(Exception ex);



        public void SyncHierarchies(IEnumerable<A> listA, IEnumerable<B> listB)
        {
            try
            {
                foreach (var (a, b) in Sync(listA, listB))
                {
                    if (a != null && b != null)
                    {
                        OnMatch(a, b);
                        if (GetChildren(a).Any() || GetChildren(b).Any()) //TODO: thinks about HasChildren
                        {
                            OnPush(a);
                            SyncHierarchies(GetChildren(a), GetChildren(b)); //Recursive call
                            OnPop(a);
                        }
                    }
                    else if (a != null && b == null)
                        OnRemove(a);
                    else if (a == null && b != null)
                        OnAdd(b);
                    else
                        throw new Exception("Both parts of the pair are nulls");
                }
            }
            catch(Exception ex)
            {
                OnError(ex);
            }
        }

        private IEnumerable<(A, B)> Sync(IEnumerable<A> listA, IEnumerable<B> listB)
        {
            List<B> bees = listB.ToList();
            foreach (var a in listA)
            {
                B bN = bees.SingleOrDefault(b => Compare(a, b));
                yield return (a, bN);
                bees.Remove(bN);
            }
            foreach (var b in bees)
                yield return ((A)null, b);
        }
    }
}
