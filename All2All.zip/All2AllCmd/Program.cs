﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using All2All;
using A2aTypes.Xml;
using System.Diagnostics;
using All2All.Model;
using System.IO;
using all2allv1.Xml;
using NbTools;

namespace All2AllCmd
{
    class ModelDirHierSync : HierSync<Node, FileSystemInfo>
    {
        public readonly A2AXmlWithFlavoursModel Mdl;
        private readonly Stack<Node> CurrNode;

        public ModelDirHierSync()
        {
            Mdl = new A2AXmlWithFlavoursModel(new DummyUi());
            CurrNode = new Stack<Node>();
        }

        public override IEnumerable<Node> GetChildren(Node a) => a.ReferencesN.Where(r => r.IsDirect).Select(r => r.Node);

        public override IEnumerable<FileSystemInfo> GetChildren(FileSystemInfo d) =>
            (d as DirectoryInfo)?.EnumerateFileSystemInfos() ?? Enumerable.Empty<FileSystemInfo>();

        public override void OnAdd(FileSystemInfo b) => Debug.WriteLine($"Added: {b}");
        public override void OnRemove(Node a) => Debug.WriteLine($"Removed: {a}");
        public override void OnMatch(Node a, FileSystemInfo b)
        {
            Debug.WriteLine($"Match: {a} = {b}");
            if (CurrNode.Count == 0)
            {
                Mdl.RootNodes.Add(a);
            }
            else
            {
                //Mdl.LoadFilesAndDirsFromDirectory
            }
        }

        public override void OnPush(Node a)
        {
            Debug.WriteLine($"Push: {a}");
            CurrNode.Push(a);
        }
        public override void OnPop(Node a)
        {
            Debug.WriteLine($"Pop: {a}");
            var res = CurrNode.Pop();
            if (a != res) throw new Exception($"Popped nodes do not match: {a} != {res}");
        }
        public override void OnError(Exception ex) => Debug.WriteLine(NbException.Exception2String(ex));

        public override bool Compare(Node nd, FileSystemInfo fdi)
        {
            if (nd.TryGetFlavour(out FlavFile fileFlav) && fdi is FileInfo fi) //Both are files
            {
                if (fileFlav.file_name + fileFlav.extension == fi.Name)
                    return true;
            }
            else if (nd.TryGetFlavour(out FlavDirectory _) && fdi is DirectoryInfo di) //Both are dirs
            {
                if (nd.name == di.Name)
                    return true;
            }
            return false;
        }
    }


    class Program
    {
        static void Main() //string[] args
        {
            LoadFromDir();
        }

        const string VideoDir = @"C:\Users\budan\Videos";

        private static void LoadFromDir()
        {
            string srcFile = System.IO.Path.GetFullPath(@"C:\Repo\All2All\All2AllModelTest\FromFiles.xml");
            var ModelA = new A2AXmlWithFlavoursModel(new DummyUi());
            ModelA.LoadFromXmlModel(Root.LoadFile(srcFile));


            /*var ModelB = new All2All.Model.A2AModel(new DummyUi());
            ModelB.LoadFilesAndDirsFromDirectory(VideoDir);*/

            var rootDir = new DirectoryInfo(VideoDir);


            //var ModelC = new All2All.Model.A2AModel(new DummyUi());

            var hierSync = new ModelDirHierSync();
            hierSync.SyncHierarchies(ModelA.RootNodes, NbExt.Yield(rootDir));


            /*SyncHierarchies<Node, FileSystemInfo>(ModelA.RootNodes, n => n.ReferencesN.Where(r => r.IsDirect).Select(r => r.Node),
                NbExt.Yield(rootDir), d => (d as DirectoryInfo)?.EnumerateFileSystemInfos() ?? Enumerable.Empty<FileSystemInfo>(),
                Model2DirCompar);*/

        }


        private static void SyncHierarchies<A, B>(IEnumerable<A> listA, Func<A, IEnumerable<A>> childGetterA, IEnumerable<B> listB, Func<B, IEnumerable<B>> childGetterB, Func<A, B, bool> equal) where A : class where B : class
        {
            foreach (var (a, b) in Sync(listA, listB, equal))
            {
                if (a != null && b != null)
                {
                    Debug.WriteLine($"Match: {a} = {b}");
                    if (childGetterA(a).Any() || childGetterB(b).Any())
                    {
                        SyncHierarchies(childGetterA(a), childGetterA, childGetterB(b), childGetterB, equal); //Recursive call
                    }

                }
                else if (a != null && b == null)
                    Debug.WriteLine($"Removed: {a}");
                else if (a == null && b != null)
                    Debug.WriteLine($"Added: {b}");
                else
                    throw new Exception("Both parts of the pair are nulls");
            }
        }


        /*private static bool Model2DirCompar(Node nd, FileSystemInfo fdi)
        {
            if (nd.TryGetFlavour(out FlavFile fileFlav) && fdi is FileInfo fi) //Both are files
            {
                if (fileFlav.file_name + fileFlav.extension == fi.Name)
                    return true;
            }
            else if (nd.TryGetFlavour(out FlavDirectory _) && fdi is DirectoryInfo di) //Both are dirs
            {
                if (nd.name == di.Name)
                    return true;
            }
            return false;
        }*/

        //TODO: create a faster analogue with a dictionary
        private static IEnumerable<(A, B)> Sync<A, B>(IEnumerable<A> listA, IEnumerable<B> listB, Func<A, B, bool> equal) where A : class where B : class
        {
            List<B> bees = listB.ToList();
            foreach (var a in listA)
            {
                B bN = bees.SingleOrDefault(b => equal(a, b));
                yield return (a, bN);
                bees.Remove(bN);
            }
            foreach (var b in bees)
                yield return ((A)null, b);
        }
    }

    class DummyUi : IUserInterface
    {
        public void AddAllFields(UpdateType updType, string nodeId, string nodeType, string[] columns, int requestId) => throw new NotImplementedException();
        public void AddSimple(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId) => throw new NotImplementedException();
        public void AddWebPage(string html, int requestId) => throw new NotImplementedException();
        public Task<bool> EditForm(A2aFormParameters formParams) => throw new NotImplementedException();
        public void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId) => throw new NotImplementedException();
        public void SetStatus(string message) => throw new NotImplementedException();
        public Task<string> ShowDialog(string message) => throw new NotImplementedException();
    }
}
