﻿using All2All;
using NbTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace All2AllModelTest
{
    public class Loading
    {
        private const string Beyond = @"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe";

        [Fact]
        public void LoadFromDir()
        {
            string dstFile = Path.GetFullPath(@"..\..\..\All2AllModelTest\FromFiles.xml");

            var Model = new All2All.Model.A2AModel(new DummyUI());
            Model.LoadFromDirectory(@"D:\Videos");
            Model.SaveTo(dstFile);
        }

        [Fact]
        public void TestMethod1()
        {
            string srcFile = Path.GetFullPath(@"..\..\..\All2AllModel\MusExample.xml");
            string dstFile = Path.GetFullPath(@"..\..\..\All2AllModel\MusExample2.xml");


            var Model = new All2All.Model.A2AModel(new DummyUI());
            Model.LoadFromXml(srcFile);
            Model.SaveTo(dstFile);

            //NbProcess.RunSync(Beyond, null, srcFile, dstFile);

        }
    }


    public class DummyUI : IUserInterface
    {
        public void AddAllFields(UpdateType updType, string nodeId, string nodeType, string[] columns, int requestId)
        {
            throw new NotImplementedException();
        }

        public void AddSimple(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId)
        {
            //throw new NotImplementedException();
        }

        public void AddWebPage(string html, int requestId)
        {
            throw new NotImplementedException();
        }

        public Task<bool> EditForm(A2aFormParameters formParams)
        {
            throw new NotImplementedException();
        }

        public void SetColumns(IEnumerable<(string fieldName, DisplayStyle displayStyle)> columns, int requestId)
        {
            throw new NotImplementedException();
        }

        public void SetStatus(string message)
        {
            throw new NotImplementedException();
        }

        public Task<string> ShowDialog(string message)
        {
            throw new NotImplementedException();
        }
    }

}
