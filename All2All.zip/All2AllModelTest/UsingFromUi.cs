﻿using All2All.Model;
using all2allv1.Xml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace All2AllModelTest
{
    public class UsingFromUi
    {
        //private const string Beyond = @"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe";

        [Fact]
        public void GetRoot()
        {
            string srcFile = Path.GetFullPath(@"..\..\..\All2AllModelTest\FromFiles.xml");

            var Model = new All2All.Model.A2AModel(new DummyUI());
            Model.LoadFromXmlModel(Root.LoadFile(srcFile));
            using CancellationTokenSource canTokSrc = new CancellationTokenSource();
            Model.GetChildren(parentIdN: null, parentTypeN: null, flavoursN: new string[] { "File", "Dir" }, canTokSrc.Token, 1);

        }
    }
}
