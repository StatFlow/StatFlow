﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Xunit;

using A2aTypes.Xml;
using All2All;
using NbTools;
using All2All.Model;
using all2allv1.Xml;

namespace All2AllModelTest
{
    public class LoadingTests : IDisposable
    {
        private const string Beyond = @"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe";
        internal readonly string TmpDir;

        const string Dir1 = "Dir1";
        const string File11 = Dir1 + @"\File1.1.txt";
        const string File12 = Dir1 + @"\File1.2.txt";
        const string File2 = @"File2.txt";

        public LoadingTests()
        {
            TmpDir = Path.GetTempFileName();
            File.Delete(TmpDir);
            Directory.CreateDirectory(TmpDir);
            PopulateDir();
        }

        private void PopulateDir()
        {
            WriteAppendToFile(File11);
            WriteAppendToFile(File12);
            WriteAppendToFile(File2);
        }

        private void WriteAppendToFile(string filePath, bool append = false, string text = null)
        {
            var fi = new FileInfo(Path.Combine(TmpDir, filePath));
            NbExt.DirCreateRecursive(fi.Directory);

            if (append)
                File.AppendAllText(fi.FullName, text ?? filePath);
            else
                File.WriteAllText(fi.FullName, text ?? filePath);
        }


        //Think about replacing load with Sync on emtpy model

        //Separate Model and Xml Model


        [Fact]
        public void LoadFromDir()
        {
            //string dstFile = Path.GetFullPath(@"..\..\..\All2AllModelTest\FromFiles.xml");

            //Load Model from Dir
            var firstModel = new A2AModel(new DummyUI());
            firstModel.LoadFilesAndDirsFromDirectory(TmpDir);
            Assert.Single(firstModel.RootNodes);
            Assert.Equal(5, firstModel.Nodes.Count);

            //Make various changes to the dir
            WriteAppendToFile(File11, append: true, "\r\nNewText");  //File11 is changed
            File.Delete(Path.Combine(TmpDir, File12));                        //File12 is removed
            WriteAppendToFile(Dir1 + @"\File1.3.txt");         //File13 is created
            WriteAppendToFile(Dir1 + @"\File3.txt");                  //File3 is created in the root

            //Load the dir again and build a third model based on the change events produced

            var second = new A2AModel(new DummyUI());
            second.LoadFilesAndDirsFromDirectory(TmpDir);

            firstModel.SaveToXmlModel().Save(NbExt.FileNameWithTimeStamp(@"C:\AutoDelete\ModelFirst.txt"));
            second.SaveToXmlModel().Save(NbExt.FileNameWithTimeStamp(@"C:\AutoDelete\ModelSecond.txt"));

            var mergedModel = firstModel.MergeModels(second);
            mergedModel.SaveToXmlModel().Save(NbExt.FileNameWithTimeStamp(@"C:\AutoDelete\ModelMerged.txt"));

            //Check the merged model
            Assert.Single(mergedModel.RootNodes);
            Assert.Equal(7, mergedModel.Nodes.Count);

            //Load clean model from resulting dir
            var finalModel = new A2AModel(new DummyUI());
            finalModel.LoadFilesAndDirsFromDirectory(TmpDir);
            finalModel.SaveToXmlModel().Save(NbExt.FileNameWithTimeStamp(@"C:\AutoDelete\ModelFinal.txt"));
        }

        [Fact]
        public void TestMethod1()
        {
            string srcFile = Path.GetFullPath(@"..\..\..\All2AllModel\MusExample.xml");
            string dstFile = Path.GetFullPath(@"..\..\..\All2AllModel\MusExample2.xml");


            var Model = new A2AModel(new DummyUI());
            Model.LoadFromXmlModel(Root.LoadFile(srcFile));
            var newXmlModel = Model.SaveToXmlModel();
            newXmlModel.Save(dstFile);

            NbProcess.RunSync(Beyond, null, srcFile, dstFile);
        }


        public void Dispose()
        {
            Directory.Delete(TmpDir, recursive: true);
        }
    }
}
