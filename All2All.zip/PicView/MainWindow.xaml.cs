﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PicView
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ListBox_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            /*if (lsEmails.SelectedItem is Contact a)
            {
                Acute.Messenger.SendEmail window = new Acute.Messenger.SendEmail(NbExt.Yield(a));
                window.Show();
            }*/
        }

        private void ListBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            Key key = (e.Key == Key.System ? e.SystemKey : e.Key);
            if ((Keyboard.Modifiers & ModifierKeys.Control) != 0 && key == Key.V)
            {
                MessageBox.Show("Ctrl-V");
                e.Handled = true;
            }
        }

        private void Selection_Drop(object sender, DragEventArgs e)
        {
            /*List<Acute.Messenger.Xml.Contact> cnts = lsEmails.SelectedItems.OfType<Acute.Messenger.Xml.Contact>().ToList(); //Drop to selection
            if (cnts.Count == 0)
            {
                TextBlock tb = sender as TextBlock;
                Image im = sender as Image;
                if (tb == null && im == null)
                    throw new NbException("Sender in TextBlock_Drop is neither a TextBlock nor an Image");

                if (!((tb != null ? tb.DataContext : im.DataContext) is Acute.Messenger.Xml.Contact cnt))
                    throw new NbException("DataContext is not set to a contact");

                cnts.Add(cnt);
            }

            IDataObject data = e.Data;
            if ((e.KeyStates & DragDropKeyStates.ShiftKey) != 0)
            {
                //ShowAllClipboard(data);
                ClipBoardViewer cbv = new ClipBoardViewer(data);
                cbv.Show();
                e.Handled = true;
            }
            else
            {
                Email.SendDataToContactSafe(data, cnts);
                e.Handled = true;
            }
            // None    No modifier keys or mouse buttons are pressed.
            //LeftMouseButton     The left mouse button is pressed.
            //RightMouseButton     The right mouse button is pressed.
            //ShiftKey     The shift (SHIFT) key is pressed.
            //ControlKey     The control (CTRL) key is pressed.
            //MiddleMouseButton     The middle mouse button is pressed.
            //AltKey     The ALT key is pressed.*/
        }
    }
}
