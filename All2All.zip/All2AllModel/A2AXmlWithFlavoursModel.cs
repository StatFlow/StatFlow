﻿using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

using NbTools;
using NbHtmlGen;
using NbTools.Collections;
using NbTools.Sync;
using NbTools.SqlGen.Xml;


using all2allv1.Xml;
using A2aCommands.Xml;
using A2aTypes.Xml;
using LibNet;
using log4net;


[assembly: InternalsVisibleTo("All2AllModelTest")]

namespace All2All.Model
{
    internal class DummyUI : IUserInterface
    {
        public void AddAllFields(UpdateType updType, string nodeId, string nodeType, string[] columns, int requestId) => throw new NotImplementedException();
        public void AddSimple(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId) { }
        public void AddWebPage(string html, int requestId) => throw new NotImplementedException();
        public Task<bool> EditForm(A2aFormParameters formParams) => throw new NotImplementedException();
        public void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId) => throw new NotImplementedException();
        public void SetStatus(string message) => throw new NotImplementedException();
        public Task<string> ShowDialog(string message) => throw new NotImplementedException();
    }

    public class A2AXmlWithFlavoursModel : IDataProvider, INodeColl<Node>
    {
        private const string TypesXml = @"C:\Repo\All2All\All2AllModel\Types.xml";
        internal static readonly ILog Log = LogManager.GetLogger(nameof(A2AXmlWithFlavoursModel));

        private readonly IUserInterface Ui;
        internal NbDictionary<string, Node> Nodes;
        private NbDictionary<string, RefType> RefTypes;
        public List<Node> RootNodes; //TODO: hide it somehow
        private readonly RefType ContainsRefType;

        private int MaxNumericId;
        private string NextId() => (++MaxNumericId).ToString();

        private A2aT A2aT; //Contains list of columns for different types and the list of screens (for now)

        public A2AXmlWithFlavoursModel(IUserInterface ui)
        {
            Ui = ui;
            Nodes = new NbDictionary<string, Node>();
            RefTypes = new NbDictionary<string, RefType>();
            RootNodes = new List<Node>(0);
            MaxNumericId = 0;
            ContainsRefType = new RefType { id = "CNT", meaning = "Contains", meaning_reverse = "Contained in" };
        }

        #region INodeColl interface
        /// <summary>
        /// INodeColl Interface implementation
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Node> GetChildren() => RootNodes;
        /// <summary>
        /// The key used to compare two Nodes that can contain other nodes
        /// </summary>
        public string Key => this.ModelName;
        #endregion INodeColl interface


        /*private static (List<N> nodes, List<B> branches) SplitByType<N, B>(IEnumerable<N> src)
        {
            var nodes = new List<N>();
            var branches = new List<B>();
            foreach (var node in src)
                if (src is B branch)
                    branches.Add(branch);
                else
                    nodes.Add(node);
            return (nodes, branches);
        }*/

        /*internal A2AModel MergeWithDirectory(string tmpDir)
        {
            var second = new A2AModel(new DummyUI());
            second.LoadFilesAndDirsFromDirectory(tmpDir);
            return MergeModels(second);
        }*/

        /// <summary>
        /// Uses SyncR method to produce change events out of current and provided second model.
        /// Builds the resulting third model using the produced events and the stack for hierarchical processing
        /// </summary>
        /// <param name="second"></param>
        /// <returns></returns>
        internal A2AXmlWithFlavoursModel MergeModelsSymmetric(A2AXmlWithFlavoursModel second)
        {
            RefType defRefType = RefTypes.SingleVerbose().Value; //Single default ref-type for now (ContainsRefType)

            Stack<Node> stack = new Stack<Node>();
            var result = new A2AXmlWithFlavoursModel(new DummyUI());
            foreach (var change in SyncTools.SyncR(this, second))
            {
                Node parNode = stack.Count() == 0 ? null : stack.Peek();

                switch (change)
                {
                    case NodeChange<Node> nodeChange:
                        switch (nodeChange.ChangeType)
                        {
                            case ChangeType.None:
                                result.AddNode(nodeChange.NodeSrc, parNode, defRefType);
                                break;
                            case ChangeType.Add:
                                result.AddNode(nodeChange.NodeDst.CloneNewId(NextId()), parNode, defRefType);
                                break;
                            case ChangeType.Remove:
                                nodeChange.NodeSrc.deleted = true;
                                result.AddNode(nodeChange.NodeSrc, parNode, defRefType);
                                break;
                            case ChangeType.Update:
                                result.AddNode(nodeChange.NodeDst.CloneNewId(nodeChange.NodeSrc.id), parNode, defRefType);
                                break;

                            case ChangeType.Push:
                                stack.Push(nodeChange.NodeSrc);
                                break;
                            case ChangeType.Pop:
                                var nd = stack.Pop();
                                if (!ReferenceEquals(nd, nodeChange.NodeSrc))
                                    throw new NbExceptionInfo($"Popping node doesn't match one on the stack: {nodeChange.NodeSrc} and {nd}");
                                break;

                            default:
                                throw new NbExceptionEnum<ChangeType>(nodeChange.ChangeType);
                        }
                        break;
                    default:
                        throw new NbExceptionInfo($"Unsupported change type: {change.GetType().Name}");
                }
            }
            return result;
        }

        private void AddNode(Node nd, Node parentN, RefType rt)
        {
            Nodes.Add(nd.id, nd);

            if (parentN is null)
                RootNodes.Add(nd);
            else
                parentN.AddDoubleRef(nd, rt);
        }

        private void RemoveNode(string key)
        {
            if (!Nodes.TryGetValue(key, out Node nd))
                throw new NbExceptionInfo($"Can't delete node with key '{key}', because it is not found in the dictionary");

            foreach (var refer in nd.ReferencesN.Safe())
            {
                refer.Node.RemoveAllRefsTo(nd);
            }
            Nodes.Remove(key);
        }

        private void UpdateNode(string key, Node other)
        {
            if (!Nodes.TryGetValue(key, out Node nd))
                throw new NbExceptionInfo($"Can't update node with key '{key}', because it is not found in the dictionary");

            nd.UpdateFieldsFrom(other);
        }

        public IEnumerable<NodeChange<Node>> MergeIn(INodeColl<Node> other, bool markForDeletion = true)
        {
            RefType defRefType = RefTypes.SingleVerbose().Value; //Single default ref-type for now (ContainsRefType)

            Stack<Node> stack = new Stack<Node>();

            foreach (var change in SyncTools.SyncR(this, other))
            {
                Node parNode = stack.Count() == 0 ? null : stack.Peek();
                switch (change)
                {
                    case NodeChange<Node> nodeChange:
                        switch (nodeChange.ChangeType)
                        {
                            case ChangeType.None:
                                break;

                            case ChangeType.Add:
                                AddNode(nodeChange.NodeDst.CloneNewId(NextId()), parNode, defRefType);
                                break;

                            case ChangeType.Remove:
                                if (markForDeletion)
                                    nodeChange.NodeSrc.deleted = true;
                                else
                                    RemoveNode(nodeChange.NodeSrc.Key);
                                break;

                            case ChangeType.Update:
                                UpdateNode(nodeChange.NodeSrc.Key, nodeChange.NodeDst);
                                break;

                            case ChangeType.Push:
                                stack.Push(nodeChange.NodeSrc);
                                break;

                            case ChangeType.Pop:
                                var nd = stack.Pop();
                                if (!ReferenceEquals(nd, nodeChange.NodeSrc))
                                    throw new NbExceptionInfo($"Popping node doesn't match one on the stack: {nodeChange.NodeSrc} and {nd}");
                                break;

                            default:
                                throw new NbExceptionEnum<ChangeType>(nodeChange.ChangeType);
                        }
                        break;
                    default:
                        throw new NbExceptionInfo($"Unsupported change type: {change.GetType().Name}");
                }
            }
            yield break;
        }

        public void LoadFromXmlModel(Root xmlModel)
        {
            Nodes = xmlModel.nodes.ToNbDictionary(n => n.id, n => n, description: "A2A Nodes");
            RefTypes = xmlModel.ref_types.ToNbDictionary(n => n.id, n => n, description: "A2A RefTypes");

            foreach (var rf in xmlModel.refs)
            {
                var fromNode = Nodes[rf.frm];
                var toNode = Nodes[rf.to];
                var refType = RefTypes[rf.typ];

                fromNode.AddRef(toNode, refType, rf.ord, true);
                toNode.AddRef(fromNode, refType, rf.ord, false);
            }

            Log.Info($"Loaded {Nodes.Count} Nodes, {RefTypes.Count} RefTypes, {xmlModel.refs.Length} references ");

            //TODO XmlModel.refs can be Garbage collected at this point
            RootNodes = Nodes.Values.Where(n => !n.HasAnyParents()).ToList(); //There could be many root node (with different types)
            MaxNumericId = Nodes.Values.Max(n => Int32.TryParse(n.id, out int intId) ? intId : 0); //Get max of all ids that can be parsed to int

            Log.Info($"Loading {nameof(A2aT)} from '{TypesXml}'");
            A2aT = A2aT.LoadFile(TypesXml);
        }


        /// <summary>
        /// The method is loading file and directory flavours only, other flavours should be added separately
        /// </summary>
        /// <param name="dir"></param>
        public void LoadFilesAndDirsFromDirectory(string dir)
        {
            RefTypes = new NbDictionary<string, RefType>(1, null, "A2A RefTypes") { { ContainsRefType.id, ContainsRefType } };

            Nodes = new NbDictionary<string, Node>(1000, null, "A2A Nodes");
            RootNodes = new List<Node> { ProcDir(new DirectoryInfo(dir), ContainsRefType) }; //Only one root node when loading a directory
        }

        private Node ProcDir(DirectoryInfo di, RefType rf)
        {
            FlavDirectory flavDir = new FlavDirectory { created = di.CreationTime };
            var ndr = new Node { id = NextId(), name = di.Name, Items = new Flavour[] { flavDir } };  //Nodes.Count.ToString()
            Nodes.Add(ndr.id, ndr);

            int ord = 0;
            foreach (DirectoryInfo subDir in di.GetDirectories())
            {
                Node subDirNode = ProcDir(subDir, rf);
                ndr.AddDoubleRef(subDirNode, rf, ord++);
            }

            ord = 0;
            foreach (FileInfo fi in di.GetFiles())
            {
                //The name of the entry is editable, the name of the file should always be equal to file
                FlavFile flavFile = new FlavFile
                {
                    file_name = Path.GetFileNameWithoutExtension(fi.Name),
                    extension = fi.Extension,
                    length = fi.Length,
                    created = fi.CreationTime,
                    accessed = fi.LastAccessTime,
                    modified = fi.LastWriteTime
                };

                var flavours = NbExt.Yield<Flavour>(flavFile, TryVideoFlavourN(fi)).Where(i => i != null).ToArray(); //Take non-empty flavours
                var nd = new Node { id = NextId(), name = flavFile.file_name, Items = flavours };

                ndr.AddDoubleRef(nd, rf, ord++);
                Nodes.Add(nd.id, nd);
            }

            return ndr;
        }

        private FlavVideoFile TryVideoFlavourN(FileInfo fl)
        {
            var mi = NbMediaInfo.XmlForFile(fl.FullName);
            var r = new NbMediaInfo(mi);
            if (r.Tracks.ContainsKey("Video"))
                return new FlavVideoFile { hight = r.Height, width = r.Width, duration = r.Duration };
            else
                return null;
        }

        public Root SaveToXmlModel()
        {
            var xmlModel = new Root
            {
                nodes = Nodes.Values.ToArray(),
                ref_types = new RefType[] { ContainsRefType }
            };  //Do not initialize references, use inner lists for references

            List<Ref> refList = new List<Ref>(Nodes.Count * 2);
            foreach (Node no in xmlModel.nodes.OrderBy(n => n.id).Where(n => n.ReferencesN != null))
            {
                foreach (var rf in no.ReferencesN.Where(r => r.IsDirect)) //.OrderBy(r => r.node).ThenBy(r => r.refType).ThenBy(r => r.order)
                {
                    refList.Add(new Ref() { frm = no.id, to = rf.Node.id, ord = rf.Order, typ = rf.RefType.id });
                }
            }

            return new Root()
            {
                nodes = xmlModel.nodes,
                ref_types = xmlModel.ref_types,
                refs = refList.ToArray()
            };
        }

        public string ModelName => nameof(A2AXmlWithFlavoursModel);

        public Task ExecuteCommand(string cmdName, string scrNodeId, string scrNodeType, string scrNodeName, string dstNodeIdN)
        {
            throw new NotImplementedException();
        }

        public Task GetChildren(string parentIdN, string parentTypeN, IEnumerable<string> flavoursN, CancellationToken canToken, int requestId)
        {
            if (parentIdN == null)
            {
                if (flavoursN == null) throw new NbExceptionInfo("IEnumerable<string> flavoursN was not provided");
                foreach (string flavour in flavoursN)
                {
                    foreach (Node nd in RootNodes.Where(nd => nd.HasFlavour(flavour)))
                        Ui.AddSimple(UpdateType.Add, nd.id, "directory", null, nd.name, nd.HasChildren(ContainsRefType), requestId);
                }
            }
            return Task.CompletedTask;
        }

        public IEnumerable<A2aCommandDesc> GetCommandsSingle(string nodeId, string nodeType) { yield break; }

        public IEnumerable<A2aCommandDesc> GetDragCommands(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId) { yield break; }

        public Task GetList(NbSqlXml request, CancellationToken canToken, int prevRequestId, int requestId)
        {
            Log.Info($"GetList request from client");

            var andFilters = request?.filter;
            if (andFilters == null || andFilters.Length == 0)
                throw new Exception("No filters provided");

            var typesN = new string[] { "File" }; //TODO: pass with the message
            var tpHashN = typesN != null ? new HashSet<string>(typesN) : null;

            //TODO: support in_subtree in_node properly
            InSubtree subtreeFltN = request?.filter.SafeOfType<InSubtree>().SingleOrDefaultVerbose(who: "in_subtree filter", whats: "request filFMideters");
            IEnumerable<Node> resultNodes = null;

            NbSqlTable tbl = request.table.SingleVerbose(who: "Requested flavours in GetList() method", whats: "flavours");
            string flavourName = tbl.name;

            if (subtreeFltN != null)
            {
                var parentId = subtreeFltN.root_node_id;
                Log.Info($"Subtree filter, parent: {parentId}");

                if (String.IsNullOrEmpty(parentId)) throw new ArgumentException(nameof(parentId));
                var node = Nodes[parentId];
                resultNodes = node.ReferencesN?.Where(r => r.IsDirect).Select(r => r.Node) ?? Enumerable.Empty<Node>();
            }
            else //subtreeFltN == null
            {
                Log.Info($"No subtree filters");
                resultNodes = Nodes.Values;
            }

            int count = 0;
            List<(string name, DisplayStyles ds)> fields = null;
            foreach (Node n in resultNodes) //Of the selected type) 
            {
                if (!n.TryGetFlavour(flavourName, out Flavour flavour))
                    continue;

                if (++count == 1) //TODO: Support the request's columns list
                {
                    fields = GetNodeFields(flavourName).ToList();
                    Log.Info($"Set Columns: {String.Join(",", fields.Select(t => t.name))}");
                    Ui.SetColumns(fields, requestId);
                }

                var lst = fields.Select(f => flavour.GetFieldValue(f.name, n)).ToArray();
                Ui.AddAllFields(UpdateType.Add, n.id, "Dir", lst, requestId);
            }

            Log.Info($"AddAllFields: called {count} times");

            BuildWebPage(resultNodes, requestId);

            return Task.CompletedTask;
        }

        private void BuildWebPage(IEnumerable<Node> resultNodes, int requestId)
        {
            Log.Info($"BuildWebPage");

            using MemoryStream ms = new MemoryStream(10000);
            using StreamWriter wrtr = new StreamWriter(ms);

            var expFormat = new DfExportFormat { isMergeCells = false, isTableOnly = true, isVertical = false, isRemoveNullColumns = false };
            NbCss css = new NbCss(new DirectoryInfo(@"C:\Users\budan\.freemind\icons"), DfExportHtml.Css);

            var cols = new List<IHtmlColumnFormatter<Node>> { new ColId(), new ColName() };
            QueryResult.WriteFullHtml(wrtr, "Page title", t => TableFormatter.TableHor(t, css, cols, resultNodes));

            wrtr.Flush();
            ms.Position = 0;
            using StreamReader rdr = new StreamReader(ms);
            Ui.AddWebPage(rdr.ReadToEnd(), requestId);
        }


        private IEnumerable<(string, DisplayStyles)> GetNodeFields(string typeName)
        {
            Log.Info($"GetNodeFields for type '{typeName}'");
            A2aType tp = A2aT.TypesDict[typeName];
            return tp.column.Select(c => (c.name, c.display_type));
        }

        /*private IEnumerable<(FieldInfo, DisplayStyles)> GetNodeFieldsBasedOnObjectProperties(Node node)
        {
            Log.Info($"GetNodeFields");

            //var ndType = NodeTypes[node.type];

            foreach (var fld in node.GetType().GetFields().Where(f => !f.IsStatic
                && !f.Name.EndsWith("Specified")  //Boolean properties for null
                && !f.Name.EqIC("id") && !f.Name.EqIC("type")))     //Id or type will never be shown on the screen, these are functional fields
            {
                //var displayStyleXml = ndType[fld.Name];
                var displayStyle = (DisplayStyles)Enum.Parse(typeof(DisplayStyles), "String"); //DisplayStyle is defined in common interface that doesn't know about the xml schema
                yield return (fld, displayStyle);
            }
        }*/

        public void Dispose() { }

        public IEnumerable<A2aCommandDesc> GetCommandsDouble(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsMultiple(string selNodeId, string selNodeType, string selNodeName, IEnumerable<string> nodeId)
        {
            throw new NotImplementedException();
        }

        public A2aT GetTypes() => A2aT;

        IEnumerable<PropertyChange<Node>> ISync<Node>.Compare(Node other)
        {
            throw new NotImplementedException();
        }
    }

    public class ColId : IHtmlColumnFormatter<Node>
    {
        public string Name => "Id";
        public string CellText(Node nd, NbCss _) => nd.id;
    }

    public class ColName : IHtmlColumnFormatter<Node>
    {
        public string Name => "Name";
        public string CellText(Node nd, NbCss _) => nd.name;
    }
}
