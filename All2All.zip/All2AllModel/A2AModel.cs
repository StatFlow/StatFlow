﻿using System;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using NbTools;
using NbHtmlGen;
using NbTools.Collections;
using NbTools.SqlGen.Xml;

using all2allv1.Xml;
using A2aCommands.Xml;

namespace All2All.Model
{
    public class A2AModel : IDataProvider
    {
        private readonly IUserInterface Ui;
        private Root XmlModel;
        private NbDictionary<string, Node> Nodes;
        private NbDictionary<string, RefType> RefTypes;
        private Node RootNode;
        private RefType ContainsRefType;

        public A2AModel(IUserInterface ui)
        {
            Ui = ui;
            XmlModel = new Root();
        }

        public void LoadFromXml(string xmlFilename)
        {
            XmlModel = Root.LoadFile(xmlFilename);
            Nodes = XmlModel.nodes.ToNbDictionary(n => n.id, n => n, description: "A2A Nodes");
            RefTypes = XmlModel.ref_types.ToNbDictionary(n => n.id, n => n, description: "A2A RefTypes");

            foreach (var rf in XmlModel.refs)
            {
                var fromNode = Nodes[rf.frm];
                var toNode = Nodes[rf.to];
                var refType = RefTypes[rf.typ];

                fromNode.AddRef(toNode, refType, rf.ord, true);
                toNode.AddRef(fromNode, refType, rf.ord, false);
            }
            //TODO XmlModel.refs can be Garbage collected at this point
            RootNode = Nodes.Values.SingleOrDefault(n => !n.HasAnyParents());
        }

        public void LoadFromDirectory(string dir)
        {
            ContainsRefType = new RefType { id = "CNT", meaning = "Contains", meaning_reverse = "Contained in" };
            RefTypes = new NbDictionary<string, RefType>(1, null, "A2A RefTypes") { { ContainsRefType.id, ContainsRefType } };

            Nodes = new NbDictionary<string, Node>(1000, null, "A2A Nodes");
            RootNode = ProcDir(new DirectoryInfo(dir), ContainsRefType);

            XmlModel = new Root
            {
                nodes = Nodes.Values.ToArray(),
                ref_types = new RefType[] { ContainsRefType }
            };  //Do not initialize references, use inner lists for references
        }

        private Node ProcDir(DirectoryInfo di, RefType rf)
        {
            FlavDirectory flavDir = new FlavDirectory { };
            var ndr = new Node { id = Nodes.Count.ToString(), name = di.Name, Items = new Flavour[] { flavDir } };
            Nodes.Add(ndr.id, ndr);

            int ord = 0;
            foreach (DirectoryInfo subDir in di.GetDirectories())
            {
                Node subDirNode = ProcDir(subDir, rf);
                ndr.AddDoubleRef(subDirNode, rf, ord++);
            }

            ord = 0;
            foreach (FileInfo fi in di.GetFiles())
            {
                FlavFile flavFile = new FlavFile { file_name = Path.GetFileNameWithoutExtension(fi.Name), extension = fi.Extension, length = fi.Length };
                var nd = new Node { id = Nodes.Count.ToString(), name = flavFile.file_name, Items = new Flavour[] { flavFile } };

                ndr.AddDoubleRef(nd, rf, ord++);
                Nodes.Add(nd.id, nd);
            }

            return ndr;
        }

        public void SaveTo(string dstFile)
        {
            List<Ref> refList = new List<Ref>(Nodes.Count * 2);
            foreach (Node no in XmlModel.nodes.OrderBy(n => n.id).Where(n => n.ReferencesN != null))
            {
                foreach (var rf in no.ReferencesN.Where(r => r.IsDirect)) //.OrderBy(r => r.node).ThenBy(r => r.refType).ThenBy(r => r.order)
                {
                    refList.Add(new Ref() { frm = no.id, to = rf.Node.id, ord = rf.Order, typ = rf.RefType.id });
                }

            }


            Root newModel = new Root()
            {
                nodes = XmlModel.nodes,
                ref_types = XmlModel.ref_types,
                refs = refList.ToArray()
            };

            newModel.Save(dstFile);
        }

        public string ModelName => nameof(A2AModel);

        public Task ExecuteCommand(string cmdName, string scrNodeId, string scrNodeType, string scrNodeName, string dstNodeIdN)
        {
            throw new NotImplementedException();
        }

        public Task GetChildren(string parentIdN, string parentTypeN, IEnumerable<string> typesN, CancellationToken canToken, int requestId)
        {
            if (parentIdN == null)
                Ui.AddSimple(UpdateType.Add, RootNode.id, "Dir", null, RootNode.name, RootNode.HasChildren(ContainsRefType), requestId);
            return Task.CompletedTask;
        }

        public IEnumerable<A2aCommandDesc> GetCommandsSingle(string nodeId, string nodeType) { yield break; }

        public IEnumerable<A2aCommandDesc> GetDragCommands(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId) { yield break; }

        public Task GetList(NbSqlXml request, CancellationToken canToken, int requestId)
        {
            var andFilters = request?.filter;
            if (andFilters == null || andFilters.Length == 0)
                throw new Exception("No filters provided");

            var typesN = new string[] { "File" }; //TODO: pass with the message
            var tpHashN = typesN != null ? new HashSet<string>(typesN) : null;


            //TODO: support in_subtree in_node properly
            InSubtree subtreeFltN = request?.filter.SafeOfType<InSubtree>().SingleOrDefaultVerbose(who: "in_subtree filter", whats: "request filters");
            IEnumerable<Node> resultNodes = null;


            if (subtreeFltN != null)
            {
                var parentId = subtreeFltN.root_node_id;
                if (String.IsNullOrEmpty(parentId)) throw new ArgumentException(nameof(parentId));
                var node = Nodes[parentId];
                resultNodes = node.ReferencesN?.Where(r => r.IsDirect).Select(r => r.Node) ?? Enumerable.Empty<Node>();
            }
            else //subtreeFltN == null
            {
                resultNodes = Nodes.Values;
            }

            bool first = true;
            List<(FieldInfo fi, DisplayStyle ds)> fields = null;
            foreach (Node n in resultNodes) //Of the selected type) 
            {
                if (first) //TODO: Support the request's columns list
                {
                    fields = GetFieldsNode(n).ToList();
                    Ui.SetColumns(fields.Select(f => (f.fi.Name, f.ds)), requestId);
                    first = false;
                }

                var lst = fields.Select(f => f.fi.GetValue(n).ToString()).ToArray();
                Ui.AddAllFields(UpdateType.Add, n.id, "Dir", lst, requestId);
            }

            BuildWebPage(resultNodes, requestId);

            return Task.CompletedTask;
        }

        private void BuildWebPage(IEnumerable<Node> resultNodes, int requestId)
        {
            using MemoryStream ms = new MemoryStream(10000);
            using StreamWriter wrtr = new StreamWriter(ms);

            var expFormat = new DfExportFormat { isMergeCells = false, isTableOnly = true, isVertical = false, isRemoveNullColumns = false };
            NbCss css = new NbCss(new DirectoryInfo(@"C:\Users\budan\.freemind\icons"), DfExportHtml.Css);

            var cols = new List<IHtmlColumnFormatter<Node>> { new ColId(), new ColName() };
            QueryResult.WriteFullHtml(wrtr, "Page title", t => TableFormatter.TableHor(t, css, cols, resultNodes));

            wrtr.Flush();
            ms.Position = 0;
            using StreamReader rdr = new StreamReader(ms);
            Ui.AddWebPage(rdr.ReadToEnd(), requestId);
        }

        private IEnumerable<(FieldInfo, DisplayStyle)> GetFieldsNode(Node node)
        {
            //var ndType = NodeTypes[node.type];

            foreach (var fld in node.GetType().GetFields().Where(f => !f.IsStatic
                && !f.Name.EndsWith("Specified")  //Boolean properties for null
                && !f.Name.EqIC("id") && !f.Name.EqIC("type")))     //Id or type will never be shown on the screen, these are functional fields
            {
                //var displayStyleXml = ndType[fld.Name];
                var displayStyle = (DisplayStyle)Enum.Parse(typeof(DisplayStyle), "String"); //DisplayStyle is defined in common interface that doesn't know about the xml schema
                yield return (fld, displayStyle);
            }
        }

        public void Dispose() { }

        public IEnumerable<A2aCommandDesc> GetCommandsDouble(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<A2aCommandDesc> GetCommandsMultiple(string selNodeId, string selNodeType, string selNodeName, IEnumerable<string> nodeId)
        {
            throw new NotImplementedException();
        }
    }

    public class ColId : IHtmlColumnFormatter<Node>
    {
        public string Name => "Id";
        public string CellText(Node nd, NbCss _) => nd.id;
    }

    public class ColName : IHtmlColumnFormatter<Node>
    {
        public string Name => "Name";
        public string CellText(Node nd, NbCss _) => nd.name;
    }
}
