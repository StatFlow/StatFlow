﻿using NbTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace all2allv1.Xml
{
    public partial class Node
    {
        /// <summary>
        /// Inner representation of a reference kept inside the node
        /// </summary>
        public class InnerRef
        {
            public Node Node;
            public RefType RefType;
            public int Order;
            public bool IsDirect;

            public InnerRef(Node node, RefType refType, int order, bool isDirect)
            {
                Node = node;
                RefType = refType;
                Order = order;
                IsDirect = isDirect;
            }
        }


        [XmlIgnore]
        public List<InnerRef> ReferencesN; //FAR: Think about using array here


        internal void AddDoubleRef(Node nd, RefType rt, int order)
        {
            AddRef(nd, rt, order, true);
            nd.AddRef(this, rt, order, false);
        }

        internal void AddRef(Node nd, RefType rt, int order, bool isForward)
        {
            if (ReferencesN == null)
                ReferencesN = new List<InnerRef>(4);

            ReferencesN.Add(new InnerRef(nd, rt, order, isForward));
            //TODO: check for duplicate records
        }

        internal bool HasChildren(RefType refType) => ReferencesN?.Any(r => r.RefType == refType && r.IsDirect) ?? false;

        internal bool HasAnyParents() => ReferencesN?.Any(r => !r.IsDirect) ?? false;

        public override string ToString()
        {
            string types = String.Join(", ", Items.Safe().Select(i => i.GetType().Name));
            return $"Node '{name}' ({types})";
        }
    }


    public partial class RefType
    {
        public override string ToString() => "RefType: " + meaning;
    }
}
