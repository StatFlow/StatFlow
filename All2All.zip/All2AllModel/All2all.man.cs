﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using All2All.Model;
using NbTools;

namespace all2allv1.Xml
{
    public partial class Root
    {
        private void Resolve() { }
    }

    public partial class Node : INodeColl<Node>
    {
        internal Node CloneNewId(string newId)
        {
            var n = this.MemberwiseClone() as Node;
            n.id = newId;
            return n;
        }


        /// <summary>
        /// Inner representation of a reference kept inside the node
        /// </summary>
        public class InnerRef
        {
            public Node Node;
            public RefType RefType;
            public int Order;
            public bool IsDirect;

            public InnerRef(Node node, RefType refType, int order, bool isDirect)
            {
                Node = node;
                RefType = refType;
                Order = order;
                IsDirect = isDirect;
            }

            public override string ToString() => $"{RefType}, Dir: {IsDirect}, Ord: {Order}, {Node}";
        }

        [XmlIgnore]
        public Flavour[] Flavours => Items;


        [XmlIgnore]
        public List<InnerRef> ReferencesN; //FAR: Think about using array here


        internal void AddDoubleRef(Node nd, RefType rt, int? order = null)
        {
            AddRef(nd, rt, order, true);
            nd.AddRef(this, rt, order, false);
        }

        internal void AddRef(Node nd, RefType rt, int? order, bool isForward)
        {
            if (ReferencesN == null)
                ReferencesN = new List<InnerRef>(4);

            ReferencesN.Add(new InnerRef(nd, rt, order ?? ReferencesN.Count, isForward));
            //TODO: check for duplicate records
        }

        internal bool HasChildren(RefType refType) => ReferencesN?.Any(r => r.RefType == refType && r.IsDirect) ?? false;

        internal bool HasAnyParents() => ReferencesN?.Any(r => !r.IsDirect) ?? false;

        public override string ToString()
        {
            string types = String.Join(", ", Items.Safe().Select(i => i.GetType().Name));
            return $"Node '{name}' ({types})";
        }

        public bool HasFlavour(string flav) => Items?.Any(fl => fl.FlavourName == flav) ?? false;
        public bool HasAnyFlavour(ICollection<string> flavs) => Items?.Any(fl => flavs.Contains(fl.FlavourName)) ?? false;

        public bool TryGetFlavour(string flavourName, out Flavour flavour)
        {
            flavour = Items?.SingleOrDefault(f => f.FlavourName == flavourName);
            return flavour != null;
        }

        public bool TryGetFlavour<T>(out T flavour)
        {
            if (Items is null)
            {
                flavour = default;
                return false;
            }

            flavour = Items.OfType<T>().SingleOrDefault();
            return flavour != null;
        }


        //Branch interface
        public string Key => this.name;
        public IEnumerable<Node> GetChildren() => ReferencesN.Where(r => r.IsDirect).Select(r => r.Node);
    }

    public partial class RefType
    {
        public override string ToString() => "RefType: " + meaning;
    }

    public abstract partial class Flavour
    {
        [XmlIgnore]
        public abstract string FlavourName { get; }
        public abstract string GetFieldValue(string name, Node n);
    }

    public partial class FlavVideoFile : Flavour
    {
        public override string FlavourName => "video";

        //TODO: thing about Reflection reading here
        public override string GetFieldValue(string name, Node n) => name switch
        {
            "name" => n.name,
            nameof(bit_rate) => bit_rate.ToString(),
            nameof(duration) => duration.ToString(),
            nameof(hight) => hight.ToString(),
            nameof(width) => width.ToString(),
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };
    }

    public partial class FlavPlayable : Flavour
    {
        public override string FlavourName => "playable";
        public override string GetFieldValue(string name, Node n) => name switch
        {
            "name" => n.name,
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };
    }


    public partial class FlavDirectory : Flavour
    {
        public override string FlavourName => "directory";
        public override string GetFieldValue(string name, Node n) => name switch
        {
            "name" => n.name,
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };
    }

    public partial class FlavFile : Flavour
    {
        public override string FlavourName => "file";
        public override string GetFieldValue(string name, Node n) => name switch
        {
            "name" => n.name,
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };
    }

    public partial class FlavAudioFile : Flavour
    {
        public override string FlavourName => "audio";
        public override string GetFieldValue(string name, Node n) => name switch
        {
            "name" => n.name,
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };
    }
}
