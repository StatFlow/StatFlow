﻿using cs2xsd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace All2AllSchema
{
    class Program
    {
        //TODOL:
        //Resolving when loading and using names when saving
        //Think about injecting serialization code when creating the file

        static void Main()
        {
            //Cs2Xsd.Generate(All2allv1.Root(), "all2allv1", @"..\..\..\All2AllModel\All2all.xsd", createCs: true);
            //Cs2Xsd.Generate(A2aCommand.Root(), "A2aCommands", @"C:\Repo\NbTools\NbTools\Filter\A2aCommands.xsd", createCs: true);
            Cs2Xsd.Generate(NbSqlXml.Root(), "NbTools.SqlGen", @"C:\Repo\NbTools\NbTools\Filter\NbSqlXml.xsd", createCs: true);
        }
    }
}
