﻿using cs2xsd;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace All2AllSchema
{
    class A2aCommand
    {
        internal static Elem Root()
        {
            var Nd = new TypeAttrOnly("A2aCommandDescNode",
                new Attr("id", XsType.String, Uses.Required),
                new Attr("type", XsType.String, Uses.Optional),
                new Attr("name", XsType.String, Uses.Optional)
                );

            var Nodes = new TypeChoice("Nodes", min: 0, max: -1, new Elem("node", Nd, 0, 1));

            var Root = new TypeSequence("A2aCommandDesc",
                new Elem("src", Nd, 0, 1),
                new Elem("dst", Nd, 0, 1),
                new Elem("nodes", Nodes, 0, 1),
                new Attr("id", XsType.String, Uses.Required),
                new Attr("label", XsType.String, Uses.Required),
                new Attr("tooltip", XsType.String, Uses.Optional),
                new Attr("hotkey", XsType.String, Uses.Optional)
                );

            return new Elem("a2a_command", Root);
        }
    }
}
