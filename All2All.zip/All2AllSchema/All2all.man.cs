﻿namespace all2allv1.Xml
{
    public partial class Root
    {
        private void Resolve() { }
    }
}