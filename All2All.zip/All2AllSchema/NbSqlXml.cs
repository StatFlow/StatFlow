﻿using cs2xsd;

namespace All2AllSchema
{
    class NbSqlXml
    {
        internal static Elem Root()
        {
            var Join = new TypeAttrOnly("NbSqlJoin",
                new Attr("field", XsType.String),
                new Attr("to_table", XsType.String),
                new Attr("to_field", XsType.String)
                );

            var Field = new TypeAttrOnly("NbSqlField",
                new Attr("name", XsType.String),
                new Attr("alias", XsType.String),
                new Attr("filter", XsType.String),
                new Attr("order_ind", XsType.Int, Uses.Optional, "-1"),
                new Attr("order_desc", XsType.Bool, Uses.Optional, "false")
                );

            var Table = new TypeSequence("NbSqlTable",
                new Elem("join", Join, 0, 1),
                new Elem("field", Field, 1, Elem.Unbounded),
                new Attr("name", XsType.String),
                new Attr("alias", XsType.String)
                );

            var filterBase = new TypeAttrOnly("FilterBase",
                new Attr("field", XsType.String, Uses.Required)
                ); //base class

            var FltEqual = new TypeDerived("FltEqual", filterBase,
                new Attr("val", XsType.String, Uses.Required)
                );

            var FltContain = new TypeDerived("FltContain", filterBase,
                new Attr("val", XsType.String, Uses.Optional),
                new Attr("regex", XsType.String, Uses.Optional)
                );

            var InNode = new TypeDerived("InNode", filterBase,
                new Attr("node_id", XsType.String, Uses.Required),
                new Attr("node_type", XsType.String, Uses.Required)
                );

            var InSubtree = new TypeDerived("InSubtree", filterBase,
                new Attr("tree_table", XsType.String, Uses.Required), //The table holding the tree, such as Dirs or Tags
                new Attr("root_node_id", XsType.String, Uses.Required),
                new Attr("root_node_type", XsType.String, Uses.Required)
                );

            var Filter = new TypeChoice("Filter", min: 1, max: -1,
                new Elem("equal", FltEqual, 0, 1),
                new Elem("contain", FltContain, 0, 1),
                new Elem("in_node", InNode, 0, 1),
                new Elem("in_subtree", InSubtree, 0, 1)
                );

            var Root = new TypeSequence("NbSqlXml",
                new Attr("top", XsType.Int, Uses.Optional, "100"),
                new Elem("sql", XsType.String, 0, 1),
                new Elem("table", Table, 1, Elem.Unbounded),
                new Elem("filter", Filter, 0, 1)
                );

            return new Elem("sql_xml", Root);
        }
    }
}
