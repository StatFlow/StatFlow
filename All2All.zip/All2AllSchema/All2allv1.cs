﻿using cs2xsd;

namespace All2AllSchema
{
    static class All2allv1
    {
        internal static Elem Root()
        {
            var Root = new TypeSequence("Root",
                new Elem("nodes", Nodes(), 0, 1),
                new Elem("ref_types", RefTypes(), 0, 1),
                new Elem("refs", Refs(), 0, 1)
                );

            return new Elem("all2all", Root);
        }

        static TypeChoice Refs()
        {
            var Ref = new TypeAttrOnly("Ref",
                new Attr("typ", XsType.NCName, Uses.Required),
                new Attr("frm", XsType.String, Uses.Required),
                new Attr("to", XsType.String, Uses.Required),
                new Attr("ord", XsType.Int, Uses.Optional, deflt: "-1")); //base class

            return new TypeChoice("Refs", min: 0, max: -1, new Elem("ref", Ref, 0, 1));
        }

        static TypeChoice RefTypes()
        {
            var RefType = new TypeAttrOnly("RefType", new Attr("id", XsType.NCName, Uses.Required),
                new Attr("meaning", XsType.String, Uses.Required),
                new Attr("meaning_reverse", XsType.String, Uses.Required)); //base class

            return new TypeChoice("RefTypes", min: 0, max: -1, new Elem("ref_type", RefType, 0, 1));
        }

        static TypeChoice Nodes()
        {
            var flavour = new TypeAttrOnly("Flavour"); //base class

            //TODO: introduce reference to other object instead of directory
            var File = new TypeDerived("FlavFile", flavour,
                new Attr("file_name", XsType.String, Uses.Required),
                new Attr("extension", XsType.String),
                new Attr("length", XsType.Long, Uses.Required));

            //TODO: introduce type for time period
            var AudioFile = new TypeDerived("FlavAudioFile", flavour, new Attr("bit_rate", XsType.Int), new Attr("time", XsType.Int));

            var Directory = new TypeDerived("FlavDirectory", flavour);

            var Playable = new TypeDerived("FlavPlayable", flavour, new Attr("is_list", XsType.Int));

            var Node = new TypeChoice("Node", min: 1, max: -1,
                new Elem("file", File, 0, 1),
                new Elem("audio", AudioFile, 0, 1),
                new Elem("playable", Playable, 0, 1),
                new Elem("directory", Directory, 0, 1),

                new Attr("id", XsType.String),
                new Attr("name", XsType.String)
                );

            return new TypeChoice("Nodes", min: 0, max: -1, new Elem("node", Node, 0, 1));
        }
    }
}
