﻿using cs2xsd;
using System.Collections.Generic;

namespace All2AllSchema
{
    class A2aTypes
    {

        //public enum DisplayStyle { String, Number, TimeMinSec, FileSize }
        internal static Elem Root()
        {
            var DisplayStyles = new TypeEnum("DisplayStyles", XsType.String, new Dictionary<string, string> {
                { "String", "Doc for String" },
                { "Number", "Doc for Number" },
                { "TimeMinSec", "Doc for TimeMinSec" },
                { "FileSize", "Doc for FileSize" }
            });

            var Column = new TypeAttrOnly("Column", 
                new Attr("name", XsType.String, Uses.Required),
                new Attr("display_type", DisplayStyles, Uses.Required)
                );

            var A2aType = new TypeSequence("A2aType",
                new Attr("name", XsType.String, Uses.Required),
                new Attr("hierarchy_table", XsType.String, Uses.Optional),
                new Elem("column", Column, 1, Elem.Unbounded)
                );

            var TreeView = new TypeSequence("TreeView",
                new Attr("name", XsType.String, Uses.Required),
                new Elem("type", XsType.String, 1, Elem.Unbounded) //List of types allowed in the trees
                );

            var ListView = new TypeAttrOnly("ListView",
                new Attr("name", XsType.String, Uses.Required),
                new Attr("type", XsType.String, Uses.Required) //Only one type allowed in a given listview
                );

            var Root = new TypeSequence("A2aT",
                new ListSingleType("type", A2aType),
                new ListSingleType("tree_view", TreeView),
                new ListSingleType("list_view", ListView)
                );

            return new Elem("a2a_types", Root);
        }
    }
}
