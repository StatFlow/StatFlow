﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Timer = System.Windows.Forms.Timer;

using NbTools;
using A2aCommands.Xml;
using All2All.Model;
using A2aTypes.Xml;

namespace All2All
{
    public partial class MainForm : Form, IUserInterface, IMainForm
    {
        //Request Id is stored in order to identify the entries coming with it in the Add method. Useful when Addding a root node must also cause
        //a request to add its children, but no further down the tree
        public const int RootRequest = 1;
        private int RequestCounter = 100;
        public int GetNextRequestId() => Interlocked.Increment(ref RequestCounter);

        private const int StatusMessageTimeout = 3000;
        private readonly Timer StatusTimer;

        private readonly Dictionary<Keys, A2aCommandDesc> fCurrentHotKeys = new Dictionary<Keys, A2aCommandDesc>(10);
        private readonly Dictionary<Keys, A2aCommandDesc> fTempHotKeys = new Dictionary<Keys, A2aCommandDesc>(10);

        //private readonly List<string> TypesInTrees = new List<string> { "Dir", "Tag" };
        private A2aTypes.Xml.A2aT A2aT;
        private readonly List<Screens.Tree> TreeScreeens = new List<Screens.Tree>(10);

        //private Screens.Tree TreeDirScreen;
        //private Screens.Tree TreeTagScreen;
        private Screens.List ListScreen;
        private Screens.Web WebScreen;

        #region IMainForm interface implementation

        public IDataProvider Model { get; private set; }
        public UserProfileManager UserProfile { get; private set; }
        public void SetStatus1(string message) => SetStatus(message);

        public Selection CurrentSelection
        {
            get { return fCurrentSelection; }
            set
            {
                fCurrentSelection = value;
                RefreshSelection();
            }
        }
        private Selection fCurrentSelection = null;

        private async void Form1_Load(object sender, EventArgs e)
        {
#if NETCOREAPP3_0
            Model = new All2All.ModelAll2All(this);
#else
            //Model = new All2All.Xml.ModelXml(this); //Old xml model

            //Model = new A2AModel(this);
            //((A2AModel)Model).LoadFromXml(@"C:\Repo\All2All\All2AllModelTest\FromFiles.xml");

            Model = new FMan.ModelAll2All(this);
            //Model = new All2All.Disk.ModelDisk(this);
#endif

            A2aT = Model.GetTypes();
            UserProfile = new UserProfileManager(Model.ModelName + ".csv");

            if (Model == null)
            {
                await ShowDialog("Model is not set");
                return;
            }

            foreach(var tr in A2aT.tree_views)
            {
                A2aTypes.Xml.A2aType singleTreeType = tr.TypesResoved[0];
                var tScr = new Screens.Tree(this, nodesType: singleTreeType.name, subTreeTableName: singleTreeType.hierarchy_table); //TODO: support multiple types
                ReceiveSelectionFrom(tScr); //Main form to monitor selection
                TreeScreeens.Add(tScr);
            }

            //TreeTagScreen = new Screens.Tree(this, nodesType: "Tag", subTreeTableName: "Tags");
            //ReceiveSelectionFrom(TreeTagScreen); //Main form to monitor selection

            ListScreen = new Screens.List(this);
            ReceiveSelectionFrom(ListScreen);
            WebScreen = new Screens.Web(this);

            foreach(var ts in TreeScreeens)
            {
                ListScreen.ReceiveFilterFrom(ts);
                WebScreen.ReceiveFilterFrom(ts);
                ShowScreen(ts, ts.ToString());
            }

            ShowScreen(WebScreen, "Web");
            ShowScreen(ListScreen, "List");

            using CancellationTokenSource canTokSrc = new CancellationTokenSource();

            IEnumerable<Task> tasks = A2aT.tree_views
                .Select(tr => Model?.GetChildren(null, null, tr.TypesResoved.Select(t => t.name), canTokSrc.Token, GetNextRequestId())
                .ContinueWith(t => SetStatus("Loading complete")));
            await Task.WhenAll(tasks);
        }

        private void ShowScreen(DockContent dockWnd, string label)
        {
            dockWnd.Text = label;
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                dockWnd.MdiParent = this;
                dockWnd.Show();
            }
            else
                dockWnd.Show(dockPanel);
        }


        public void RefreshSelection()
        {
            SetStatus("Selected: " + fCurrentSelection ?? "Nothing");
            ShowCommandOnToolStrip();
        }

        public void ShowDragDropMenu(IEnumerable<A2aCommandDesc> commands, string srcNodeId, string srcNodeType, string srcNodeName, string dstNodeId)
        {
            mnDragDrop.Items.Clear();
            foreach (var cmd in commands)
            {
                var item = new ToolStripMenuItem { Name = cmd.id, Text = cmd.label, ToolTipText = cmd.tooltip, Tag = cmd };
                item.Click += (_, __) => Model.ExecuteCommand(cmd.id, srcNodeId, srcNodeType, srcNodeName, dstNodeId);
                mnDragDrop.Items.Add(item);
            }
            mnDragDrop.Show(MousePosition);
        }


        /// <summary>
        /// Action on the node comes from screen. It might not necessarily happen on the current selection, the screen provides the itemId.
        /// Therefore we have to check all commands for the hotkey. fCurrentHotKeys reflects the hotkeys of the current selection.
        /// </summary>
        /// <param name="key">The key press that caused the action. This key will be searched in the command's hotkeys</param>
        /// <param name="nodeId">The node Id to action on</param>
        public void NodeActionFromScreen(Keys key, string nodeId, string nodeType)
        {
            foreach (var comd in Model.GetCommandsSingle(nodeId ?? throw new ArgumentNullException("itemId in NodeActionFromScreen must not be null"),
                nodeType ?? throw new ArgumentNullException("itemType in NodeActionFromScreen must not be null")))
            {
                if (!String.IsNullOrEmpty(comd.hotkey))
                {
                    var cmdKey = ParseHotKey(comd.hotkey);
                    if (key == cmdKey && CurrentSelection != null)
                        Task.Run(() => Model.ExecuteCommand(comd.id, CurrentSelection.NodeId, CurrentSelection.NodeType, CurrentSelection.NodeName, null));
                }
            }
        }

        private void MainForm_KeyDown(object _, KeyEventArgs e)
        {
            if (fCurrentHotKeys.TryGetValue(e.KeyCode, out var cmd))
            {
                if (CurrentSelection != null)
                    Task.Run(() => Model.ExecuteCommand(cmd.id, CurrentSelection.NodeId, CurrentSelection.NodeType, CurrentSelection.NodeName, null));
                else
                    SetStatus($"Command '{cmd.id}' is requested by hotkey, but there is no selection");
            }
        }
        #endregion IMainForm interface implementation

        public MainForm()
        {
            InitializeComponent();
            StatusTimer = new Timer();
            StatusTimer.Tick += StatusTimer_Tick;
            StatusTimer.Interval = StatusMessageTimeout;
        }

        public delegate void SetStatusDelegate(string message);
        public void SetStatus(string Message)
        {
            if (InvokeRequired)
            {
                Invoke(new SetStatusDelegate(SetStatus), Message);
                return;
            }

            sbText.Text = Message;
            StatusTimer.Start();
        }

        private void StatusTimer_Tick(object sender, EventArgs e)
        {
            sbText.Text = null;
            StatusTimer.Stop();
        }

        public delegate void InvokeDelegate(TaskCompletionSource<string> tsc, string message);
        public Task<string> ShowDialog(string message)
        {
            var tcs = new TaskCompletionSource<string>();
            BeginInvoke(new InvokeDelegate(ShowD), tcs, message);
            return tcs.Task;
        }

        private void ShowD(TaskCompletionSource<string> tcs, string message)
        {
            var res = MessageBox.Show(this, message, "Caption", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            tcs.SetResult(res.ToString());
        }

        private readonly HashSet<ISelectionProvider> SelectionProviders = new HashSet<ISelectionProvider>();

        public void ReceiveSelectionFrom(ISelectionProvider prov)
        {
            if (SelectionProviders.Contains(prov))
                return;
            SelectionProviders.Add(prov);
            prov.SelectionChanged += SelectionProvider_SelectionChanged;
        }

        private void SelectionProvider_SelectionChanged(string nodeId, string nodeType, string nodeName)
        {
            var cmd = Model.GetCommandsSingle(nodeId, nodeType).ToList(); //TODO: think about not reallocating the list (Clear, addrange)
            CurrentSelection = new Selection(nodeId, nodeType, nodeName, cmd);
        }

        private static Keys ParseHotKey(string hotKey) =>
            Enum.TryParse<Keys>(hotKey, out var res) ? res : throw new Exception($"Can't parse Hot Key out of '{hotKey}'");

        private async void ToolStripButton_Click(object sender, EventArgs e)
        {
            var btn = sender as ToolStripButton ?? throw new NbExceptionInfo($"Sender type '{sender.GetType().Name}' where {nameof(ToolStripButton)} was expected");
            var nodeIdAndType = btn.Tag as Selection ?? throw new NbExceptionBadType("sender.Tag", nameof(Selection), btn.Tag?.GetType().Name ?? "None");
            await Task.Run(() => Model.ExecuteCommand(btn.Name, nodeIdAndType.NodeId, nodeIdAndType.NodeType, nodeIdAndType.NodeName, null));
        }

        #region Selection Management

        private void ShowCommandOnToolStrip()
        {
            toolStrip1.Items.Clear();

            if (CurrentSelection != null)
            {
                fCurrentHotKeys.Clear();
                foreach (var c in CurrentSelection.Commands)
                //foreach (var c in Model.GetCommands(CurrentSelection.Value.NodeId, CurrentSelection.Value.NodeType))
                {
                    var btn = new ToolStripButton
                    {
                        Name = c.id,
                        Text = c.label,
                        ToolTipText = c.tooltip,
                        Tag = CurrentSelection  //Normal tuple to allow back casting into tuple
                    };
                    btn.Click += ToolStripButton_Click;
                    toolStrip1.Items.Add(btn);

                    if (!String.IsNullOrEmpty(c.hotkey))
                    {
                        var key = ParseHotKey(c.hotkey);
                        if (fCurrentHotKeys.TryGetValue(key, out var existingCmd))
                            throw new Exception($"Conflicting hotkey '{c.hotkey}'. Commands: '{existingCmd.id}' and '{c.id}'");
                        fCurrentHotKeys.Add(key, c);
                    }
                }
            }
        }

        /*private void FillHotKeyDict(Dictionary<Keys, A2aCommandDesc> dict, string nodeId, string noteType)
        {
            dict.Clear();
            foreach (var c in Model.GetCommands(nodeId, noteType))
            {
                var btn = new ToolStripButton { Name = c.Id, Text = c.Label, ToolTipText = c.Tooltip, Tag = nodeId };
                btn.Click += ToolStripButton_Click;
                toolStrip1.Items.Add(btn);

                if (!String.IsNullOrEmpty(c.HotKey))
                {
                    var key = ParseHotKey(c.HotKey);
                    if (dict.TryGetValue(key, out var existingCmd))
                        throw new Exception($"Conflicting hotkey '{c.HotKey}'. Commands: '{existingCmd.Id}' and '{c.Id}'");
                    dict.Add(key, c);
                }
            }
        }*/
        #endregion Selection Management

        #region Update Management
        public void AddSimple(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId)
        {
            TreeScreeens.ForEachSafe(ts => ts.AddSimple(updType, nodeId, nodeType, parentId, Label, hasChildren, requestId));
        }

        public void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId) =>
            ListScreen.SetColumns(columns, requestId);

        public void AddAllFields(UpdateType updType, string nodeId, string nodeType, string[] columns, int requestId) =>
            ListScreen.AddAllFields(updType, nodeId, nodeType, columns, requestId);

        public void AddWebPage(string html, int requestId) => WebScreen.ShowPage(html, requestId);

        public Task<bool> EditForm(A2aFormParameters formParams) =>
            Task.Factory.FromAsync(BeginInvoke(new EditNodeDelegate(ShowEditObjectDialog), formParams), a => (bool)this.EndInvoke(a));

        delegate bool EditNodeDelegate(A2aFormParameters formParams);

#pragma warning disable IDE0017 // Simplify object initialization
        //TODO: think about returning the button number
        public bool ShowEditObjectDialog(A2aFormParameters formParams)
        {

            using var frm = new EditObject(formParams.Properties, this);
            frm.Text = formParams.FormTitle;
            frm.ShowDialog(this);
            SetStatus($"The result of the dialog: {(frm.Success ? "Save" : "Cancel")}");
            return frm.Success;

            /*var props = string.Join("\r\n", properties.Select(p => $"PropId: {p.Id}, propLabel: {p.Label}, propValue: {p.Value}"));
            var res = await ShowDialog($"Edit node '{nodeId}'\r\n" + props);
            SetStatus($"The result of the dialog: {res}");
            return res == "Yes";*/
        }

#pragma warning restore IDE0017 // Simplify object initialization
        #endregion Update Management

    }

}
