﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using NbTools;
using A2aTypes.Xml;


namespace All2All
{
    public class UserProfileManager : IDisposable
    {
        private readonly List<ListViewColumnDesc> Columns;
        private readonly FileInfo FileInfo;
        //private readonly static CsvParameters CsvPar = new CsvParameters { FieldDelimiterN = '\t' };

        internal UserProfileManager(string fileName)
        {
            FileInfo = new FileInfo(fileName);
            if (FileInfo.Exists)
                Columns = NbExt.FromCsv<ListViewColumnDesc>(FileInfo.FullName/*, CsvPar*/).ToList();
            else
                Columns = new List<ListViewColumnDesc>();
        }

        public void Dispose() => Save();

        internal void Save()
        {
            NbExt.DirCreateRecursive(FileInfo.Directory);
            NbExt.ToCsv(Columns.OrderBy(c => c.DescName).ThenBy(c => c.Order), FileInfo.FullName);
        }

        internal ListViewColumnDesc GetColumnDesc(string profileName, string columnName, DisplayStyles dispStyle, int order)
        {
            var ret = Columns.SingleOrDefaultVerbose(c => c.DescName == profileName && c.ColumnName == columnName,
                i => $"There are {i} records for field '{columnName}' in the profile '{profileName}'");

            if (ret == null)
            {
                ret = new ListViewColumnDesc
                {
                    DescName = profileName,
                    ColumnName = columnName,
                    Order = order,
                    DisplayStyle = dispStyle,
                    Width = 100,
                    Alignment = (dispStyle == DisplayStyles.Number || dispStyle == DisplayStyles.TimeMinSec) ? HorizontalAlignment.Right : HorizontalAlignment.Left
                };
                Columns.Add(ret);
            }
            return ret;
        }

        internal void Reorder(ListViewColumnDesc desc, int newPos)
        {
            string currDesc = desc.DescName;
            var colArr = Columns.Where(c => c.DescName == currDesc).OrderBy(c => c.Order).ToList();
            if (newPos < 0 || newPos >= colArr.Count)
                throw new Exception($"Position '{newPos}' is out of bounds for '{currDesc}' column description");

            colArr.Remove(desc);    //Not the most efficient, but more stable solution
            colArr.Insert(newPos, desc);
            for (int i = 0; i < colArr.Count; ++i)
                colArr[i].Order = i;
        }
    }

#pragma warning disable CS0649 //Fields used in serializing
    [DebuggerDisplay("#{ColumnName} {Order} {DisplayStyle}")]
    class ListViewColumnDesc
    {
        public string DescName;
        public string ColumnName;
        public int Order;
        public int Width;
        public bool Hidden;
        public DisplayStyles DisplayStyle;
        public HorizontalAlignment Alignment;
    }
#pragma warning restore CS0649
}
