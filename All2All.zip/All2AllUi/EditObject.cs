﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace All2All
{
    public partial class EditObject : Form
    {
        private readonly List<A2aFormProperty> Desc;
        public bool Success = false;

        public EditObject()
        {
            InitializeComponent();
        }

        public EditObject(List<A2aFormProperty> desc, Form mainForm) : this()
        {
            //Parent = mainForm; TODO: set parent window
            Desc = desc.ToList();
            RenderDesc(Desc);
        }

        const int VertStep = 24;
        const int TopPaddingLb = 3;
        const int TopPaddingTb = TopPaddingLb + 2;
        const int FieldsWidth = 200;

        private void RenderDesc(List<A2aFormProperty> desc)
        {
            int maxLabelWidth;
            using(var gr = CreateGraphics())
            {
                maxLabelWidth = (int)Math.Ceiling(desc.Max(p => gr.MeasureString(p.Label, this.Font).Width)) + 3;
            }

            int cnt = 0;
            foreach(var prop in desc)
            {
                Label lbl = new Label
                {
                    Name = "lb" + prop.Id,
                    Text = prop.Label,
                    Top = TopPaddingLb + cnt * VertStep,
                    Width = maxLabelWidth,
                    TextAlign = ContentAlignment.MiddleRight
                };

                TextBox tb = new TextBox
                {
                    Name = prop.Id, //No prefix to facilitate the search
                    Text = prop.Value,
                    Left = maxLabelWidth,
                    Top = TopPaddingTb + cnt * VertStep,
                    Width = FieldsWidth,
                    CausesValidation = true,
                    Tag = prop,
                    ReadOnly = prop.IsReadonly

                };
                tb.Validating += Tb_Validating;

                this.Controls.Add(lbl);
                this.Controls.Add(tb);
                cnt++;
            }

            var btUpdate = new Button
            {
                Name = "btUpdate",
                Text = "Update",
                Top = TopPaddingTb + cnt * VertStep
            };

            var btCancel = new Button
            {
                Name = "btCancel",
                Text = "Cancel",
                Top = TopPaddingTb + cnt * VertStep,
                Left = 100
            };

            btUpdate.Click += BtUpdate_Click;
            btCancel.Click += (s, e) => { Success = false; Close(); };
            this.Controls.Add(btUpdate);
            this.Controls.Add(btCancel);
            this.AcceptButton = btUpdate;
            this.CancelButton = btCancel;
        }

        private void Tb_Validating(object sender, CancelEventArgs e)
        {
            var tb = sender as TextBox ?? throw new Exception($"Textbox is expected, '{sender.GetType().Name}' was sent");
            var prop = tb.Tag as A2aFormProperty ?? throw new Exception($"Textbox {tb.Name} doesn't have a Tag field set to {nameof(A2aFormProperty)}");
            var valMessN = prop.ValidationMessage?.Invoke(tb.Text);

            errorProvider1.SetError(tb, valMessN);
            e.Cancel = !String.IsNullOrEmpty(valMessN);
        }

        private void BtUpdate_Click(object sender, EventArgs e)
        {
            foreach(var tb in Controls.OfType<TextBox>())
            {
                var prop = tb.Tag as A2aFormProperty ?? throw new Exception($"Textbox {tb.Name} doesn't have a Tag field set to {nameof(A2aFormProperty)}");
                prop.Value = tb.Text;
            }
            Success = true;
            Close();
        }
    }
}
