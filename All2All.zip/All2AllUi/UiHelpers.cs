﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using NbTools;
using NbTools.SqlGen.Xml;
using A2aCommands.Xml;
using A2aTypes.Xml;

namespace All2All
{
    internal class TreeNodeState
    {
        public bool ChildrenInitialised;
        public string NodeType;
    }

    internal interface IMainForm
    {
        /// <summary>
        /// Repeat the query for the details without changing the Current Selection (F5)
        /// </summary>
        void RefreshSelection();

        IDataProvider Model { get; }
        UserProfileManager UserProfile { get; }
        void ShowDragDropMenu(IEnumerable<A2aCommandDesc> commands, string srcNodeId, string srcNodeType, string srcNodeName, string dstNodeId);

        /// <summary>
        /// If there was an action on the component inside the screen (such as DoubleClick). The screen notifies the Main Form about it
        /// The main form may launch an action for the component if there is Hot Key for it
        /// </summary>
        /// <param name="key">LButton - for mouse double click or any other key press</param>
        /// <param name="itemId">The Id of the node (item) as a string</param>
        void NodeActionFromScreen(Keys key, string itemId, string nodeType);

        void SetStatus1(string message);

        int GetNextRequestId();
    }

    public delegate void SelectionChangedHandler(string nodeId, string nodeType, string nodeName);
    public delegate void FilterChangedHandler(IFilterProvider sender, List<FilterBase> filter);

    public interface ISelectionProvider
    {
        event SelectionChangedHandler SelectionChanged;
    }

    public interface IFilterProvider
    {
        event FilterChangedHandler FilterChanged;
    }


    static class UIHelpsers
    {
        const int FileSizePrecision = 3;

        public static string ConvertStringByDisplayStyle(this string str, DisplayStyles style)
        {
            return style switch
            {
                DisplayStyles.FileSize => Int64.TryParse(str, out long bytes) ? NbExt.UserFriendlyFileSize(bytes, FileSizePrecision) : str,
                DisplayStyles.Number => str,
                DisplayStyles.TimeMinSec => (Int32.TryParse(str, out int totSec) ? $"{totSec / 60}:{totSec % 60}" : str),
                DisplayStyles.String => str,
                _ => throw new NbExceptionEnum<DisplayStyles>(style),
            };
        }
    }
}
