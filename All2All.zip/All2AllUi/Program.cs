﻿using log4net;
using NbTools;
using System;
using System.Threading;
using System.Windows.Forms;

namespace All2All
{
    static class Program
    {

        public static readonly log4net.ILog Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                Log.Info("Starting");

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
                MainForm = new MainForm();

                Application.Run(MainForm);
            }
            finally
            {
                Log.Info("Finished");
            }
        }

        private static MainForm MainForm;

        private static void ShowDialog(string header, string exMessage)
        {
            MessageBox.Show(MainForm, exMessage, header, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
            => ShowDialog(sender.ToString(), NbException.Exception2String(e.Exception));

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
            => ShowDialog($"Unhandled Exception from {sender}", e.ExceptionObject.ToString());
    }
}
