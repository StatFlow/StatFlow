﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace All2All.Screens
{
    public partial class Web : DockContent  //, ISelectionProvider, IFilterProvider
    {
        private readonly IMainForm Main;

        internal Web(IMainForm mainForm) : this()
        { Main = mainForm; }


        public Web()
        {
            InitializeComponent();
        }

        internal void ReceiveFilterFrom(Tree _treeDirScreen)
        {
            //throw new NotImplementedException();
        }

        internal void ShowPage(string html, int _)
        {
            var doc = webBrowser1.Document;
            if (doc == null)
            {
                webBrowser1.DocumentText = html;
            }
            else
            {
                webBrowser1.DocumentText = "0";

                webBrowser1.Document.OpenNew(true);
                webBrowser1.Document.Write(html);
                webBrowser1.Refresh();
            }


            /*a.Write(html);

            //https://stackoverflow.com/questions/5362591/how-to-display-the-string-html-contents-into-webbrowser-control
            webBrowser1.DocumentText = "0";

            webBrowser1.Document.OpenNew(true);
            webBrowser1.Document.Write(html);
            webBrowser1.Refresh();

            DisplayHtml(html);*/
        }

        /*private void DisplayHtml(string html)
        {
            webBrowser1.Navigate("about:blank");
            try
            {
                if (webBrowser1.Document != null)
                {
                    webBrowser1.Document.Write(string.Empty);
                }
            }
            catch (Exception e)
            { } // do nothing with this
            webBrowser1.DocumentText = html;
        }*/
    }
}
