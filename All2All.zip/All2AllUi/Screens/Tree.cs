﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

using WeifenLuo.WinFormsUI.Docking;
using NbTools;
using NbTools.SqlGen.Xml;

namespace All2All.Screens
{
    public partial class Tree : DockContent, ISelectionProvider, IFilterProvider
    {
        private readonly IMainForm Main;
        public readonly string NodesType;
        public readonly string TableHoldingATree;
        private string RootNodeId = null;

        public event SelectionChangedHandler SelectionChanged;
        public event FilterChangedHandler FilterChanged;

        /// <summary>
        /// Creates new TreeView component
        /// </summary>
        /// <param name="mainForm">Back reference to the main form</param>
        /// <param name="nodesType">The types of nodes to show on the tree</param>
        internal Tree(IMainForm mainForm, string nodesType, string subTreeTableName) : this()
        {
            Main = mainForm;
            NodesType = nodesType;
            TableHoldingATree = subTreeTableName;
        }

        public Tree() { InitializeComponent(); }

        public delegate void AddSimpleDelegate(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId);

        /// <summary>
        /// From IUserInterface interface. Creates the nodes on the tree (simple list wit Id and Names only).
        /// </summary>
        /// <param name="updType">Add, Update, Remove</param>
        /// <param name="nodeId">String unique id of the node</param>
        /// <param name="nodeType">String of the node type i.e. File or Dir</param>
        /// <param name="parentId">String unique Id of the parent of the node</param>
        /// <param name="Label">Label - simple name to show on the tree or in the list</param>
        /// <param name="hasChildren">Has children - useful to show the pluses on the tree without opening the node</param>
        /// <param name="requestId">Requestid a number useful to ingnore events after the request was cancelled</param>
        public void AddSimple(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId)
        {
            if (nodeType != NodesType)
                return;

#warning Use Has children
            if (InvokeRequired)
            {
                BeginInvoke(new AddSimpleDelegate(AddSimple), updType, nodeId, nodeType, parentId, Label, hasChildren, requestId);
                return;
            }

            TreeNode tn;
            switch (updType)
            {
                case UpdateType.Add:
                    tn = new TreeNode { Text = Label, Name = nodeId, Tag = new TreeNodeState { ChildrenInitialised = false, NodeType = nodeType } };
                    if (String.IsNullOrEmpty(parentId))
                    {
                        treeView1.Nodes.Add(tn);
                        treeView1.SelectedNode = tn;
                        //treeView1.SelectedNode.Expand(); Expand doesn' work here, because the children were not loaded yet
                    }
                    else
                    {
                        var res = TreeNodeById(parentId);
                        res.Nodes.Add(tn);
                    }

                    if (requestId == MainForm.RootRequest) //Re-issue request for childrens
                    {
                        RootNodeId = nodeId;
                        //Task.Run(() => Main.Model.GetChildren(Id, TypesInTree, default, 0)); Will be issued by the user
                    }
                    break;

                case UpdateType.Update:
                    tn = TreeNodeById(nodeId);
                    if (tn.Text != Label)
                        tn.Text = Label;
                    break;

                case UpdateType.Remove:
                    break;
                default:
                    throw new NbExceptionEnum<UpdateType>(updType);
            }

        }

        private TreeNode TreeNodeById(string id)
        {
            var res = treeView1.Nodes.Find(id, searchAllChildren: true);
            return res.Length switch
            {
                0 => throw new Exception($"Node '{id}' was not found in the tree"),
                1 => res[0],
                _ => throw new Exception($"'{res.Length}' nodes with ID '{id}' was found in the tree"),
            };
        }

        private string TreeViewDestNode(int x, int y)
        {
            Point targetPoint = treeView1.PointToClient(new Point(x, y)); // Retrieve the client coordinates of the drop location.
            TreeNode targetNode = treeView1.GetNodeAt(targetPoint); // Retrieve the node at the drop location.
            return targetNode?.Name ?? RootNodeId ?? throw new Exception("Drop is not on any of treeview nodes and the root tree node was not set");
        }

        //https://stackoverflow.com/questions/20915260/c-sharp-winforms-dragdrop-within-the-same-treeviewcontrol
        private void TreeView1_DragDrop(object sender, DragEventArgs e)
        {
            var (srcNodeId, srcNodeType, srcNodeName) = Screens.Common.GetDraggedNodeId(e.Data);
            var dstNodeId = TreeViewDestNode(e.X, e.Y);
            var cmds = Main.Model.GetDragCommands(srcNodeId, srcNodeType, srcNodeName, dstNodeId);
            Main.ShowDragDropMenu(cmds, srcNodeId, srcNodeType, srcNodeName, dstNodeId);

            // Optional: Select the dropped node and navigate (however you do it)
            // treeView1.SelectedNode = draggedNode;*/
            // NavigateToContent(draggedNode.Tag);
        }

        private void TreeView1_DragOver(object sender, DragEventArgs e)
        {
            var (srcNodeId, srcNodeType, srcNodeName) = Screens.Common.GetDraggedNodeId(e.Data);
            var dstNodeId = TreeViewDestNode(e.X, e.Y);
            var cmds = Main.Model.GetDragCommands(srcNodeId, srcNodeType, srcNodeName, dstNodeId).ToList(); //TODO: do not create list, use enumerator to test
            e.Effect = (cmds.Count == 0) ? DragDropEffects.None : DragDropEffects.Move;
        }

        private TreeNode TreeSelection = null; //Tree node selection is remembered to prevent reloading of the node if focus moves from the list back to the tree

        private static (string nodeId, string nodeType) SelectionFromNode(TreeNode it)
        {
            var tns = it.Tag as TreeNodeState ?? throw new Exception($"Tree node '{it.Name}' doesn't have a Tag object");
            return (it.Name, tns.NodeType);
        }

        private async void TreeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node == TreeSelection)
                return; //This node has already been selected
            else
                TreeSelection = e.Node;

            //TODO: Experiment with parallel requests
            var tns = TreeSelection.Tag as TreeNodeState ?? throw new Exception("Tree node doesn't have a Tag object");
            if (!tns.ChildrenInitialised)
            {
                tns.ChildrenInitialised = true;
                await Main.Model.GetChildren(TreeSelection.Name, tns.NodeType, new SingleSequence<string>(NodesType), default, 0);
            }

            SelectionChanged?.Invoke(TreeSelection.Name, tns.NodeType, TreeSelection.Text);
            UpdateFilter();
        }

        //TODO: Call this from selection change, selection clearence button and from mode change: subtree vs current only 
        private void UpdateFilter()
        {
            List<FilterBase> filter = null;

            if (TreeSelection != null && TreeSelection.Parent != null) //If Root is selected treat it as no selection
            {
                var tns = TreeSelection.Tag as TreeNodeState ?? throw new Exception("Tree node doesn't have a Tag object");

                filter = new List<FilterBase> { new InSubtree {
                    field = "ParentDirId", //The field of the table to filter by
                    table = "Files", //The table to filter
                    tree_table = TableHoldingATree, //The name of the table holding a tree, such as Dirs or Tags
                    root_node_id = TreeSelection.Name, //The Id of the node which is a root of the tree
                    root_node_type = tns.NodeType  //The type of the node  which is a root of the tree
                } };
            }

            FilterChanged?.Invoke(this, filter);
        }


        private void TreeView1_ItemDrag(object sender, ItemDragEventArgs e) => DoDragDrop(e.Item, DragDropEffects.Move);

        private void TreeView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var it = treeView1.GetNodeAt(e.X, e.Y);
            if (it != null)
            {
                var (nodeId, nodeType) = SelectionFromNode(it);
                Main.NodeActionFromScreen(Keys.LButton, nodeId, nodeType);
            }
        }

        private void ContextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {
            contextMenuStrip1.Items.Clear();
            if (treeView1.SelectedNode != null)
            {
                contextMenuStrip1.Items.Add($"Context menu for the item: {treeView1.SelectedNode.Name}");
            }
            else
            {
                contextMenuStrip1.Items.Add($"Context menu for no selection");
            }
        }

        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            switch (e.Button)
            {
                case MouseButtons.Left:
                    break;
                //case MouseButtons.None:
                //    break;
                case MouseButtons.Right:
                    treeView1.SelectedNode = e.Node;
                    break;
                default:
                    MessageBox.Show($"Mouse button pressed: {e.Button}");
                    break;
            }
        }
    }
}
