﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using WeifenLuo.WinFormsUI.Docking;
using NbTools;
using NbTools.SqlGen.Xml;

namespace All2All.Screens
{
    //TODO: implemet virtual list

    public partial class List : DockContent, ISelectionProvider
    {
        private readonly IMainForm Main;
        const string ColumnDescDefaultName = "ColumnDescDefault";
        /// <summary>
        /// At what indexs visually first, second, etc. column data will appear in the array with fields in SetColumns
        /// </summary>
        private int[] ColumnOrder = null;
        private string[] FilterN = null;

        //private readonly List<string> TypesInList = new List<string> { "File" };
        private readonly Timer ListFilerChangedTimer;
        private const int SearchTimeout = 500; //Timeout when user enters symbols into the search textbox
        private string SortColumn = "Name";
        private bool SortDesc = false;


        //Keeps selection providers and the filtering criteria they have send last time. The resulting criteria must merge all the list into single data_requestFilter
        private readonly Dictionary<IFilterProvider, List<FilterBase>> FilterProviders = new Dictionary<IFilterProvider, List<FilterBase>>();
        private readonly FilterBase HideDeletedFilter = new FltEqual { field = "Deleted", val = "0" };
        private readonly string[] Columns = new[] { "Name", "Extension", "Size", "Id", "Hash" };

        internal List(IMainForm mainForm) : this()
        { Main = mainForm; }

        public List()
        {
            InitializeComponent();
            ListFilerChangedTimer = new Timer();
            ListFilerChangedTimer.Tick += ListFilterChangedTimer_Tick;
            ListFilerChangedTimer.Interval = SearchTimeout;
        }

        #region Search Timer
        private void TbSearch_TextChanged(object _, EventArgs __)
        {
            ListFilerChangedTimer.Stop();
            ListFilerChangedTimer.Start();
        }

        private void ListFilterChangedTimer_Tick(object _, EventArgs __)
        {
            ListFilerChangedTimer.Stop();
            FilterN = tbSearch.Text.Split(' ').Where(s => !String.IsNullOrWhiteSpace(s)).ToArray();

            //TODO: add tbSearch here
            var fltr = FilterProviders.Values.Where(v => v != null).SelectMany(p => p).Concat(NbExt.Yield(HideDeletedFilter)).ToArray();

            var currRequestId = Main.GetNextRequestId(); //TODO: remember and cancel requests if another comes in
                                                         //data_request rq = new data_request { columns = Columns, filter = filter, sort = SortBy };
            
            List<NbSqlField> fields = new List<NbSqlField>(); //TODO: create array straight away
            foreach (string col in Columns)
            {
                if (col == SortColumn)
                    fields.Add(new NbSqlField() { name = col, order_ind = 1, order_desc = SortDesc});
                else
                    fields.Add(new NbSqlField() { name = col });
            }

            var req = new NbSqlXml
            {
                top = 1000,
                table = new NbSqlTable[] { new NbSqlTable { name = "Files", field = fields.ToArray() } },
                filter = fltr
            };

            //Get new list after the timer to avoid multiple calls due to search symbols typing or quick treeview selection change, or multiple tree selection update
            Task.Run(() => Main.Model.GetList(req, default, currRequestId));
            //this.Text = nodeName;
            //Main.RefreshSelection(); //F5 Do we really want to referesh selection - this is about about another call to get the list
        }


        private void BtSearchReset_Click(object _, EventArgs __) => tbSearch.Text = String.Empty;

        #endregion Search Timer

        #region Selection Provider
        public event SelectionChangedHandler SelectionChanged;

        private void ListView1_SelectedIndexChanged(object _, EventArgs __)
        {
            if (listView1.SelectedItems.Count == 0)
                SelectionChanged?.Invoke(null, null, null);
            else
            {
                var (nodeId, nodeType, nodeName) = SelectionFromNode(listView1.SelectedItems[0]);
                SelectionChanged?.Invoke(nodeId, nodeType, nodeName);
            }
        }

        private static (string nodeId, string nodeType, string nodeName) SelectionFromNode(ListViewItem it)
        {
            var itType = it.Tag as string ?? throw new Exception($"List Item '{it.Name}' doesn't have Tag set up");
            return (it.Name, itType, it.Text);
        }
        #endregion Selection Provider


        #region Filter Receiver

        //Main form calls this and sets up the selection providers
        public void ReceiveFilterFrom(IFilterProvider prov)
        {
            NbExt.AssertNotNull(prov, nameof(prov));
            if (FilterProviders.ContainsKey(prov))
                throw new Exception($"Filter provider '{prov}' already registered with the Listview");
            //return;
            FilterProviders.Add(prov, null); //No filter is set yet
            prov.FilterChanged += Prov_FilterChanged;
        }

        public void StopReceivingSelectionFrom(IFilterProvider prov)
        {
            NbExt.AssertNotNull(prov, nameof(prov));
            if (!FilterProviders.ContainsKey(prov))
                throw new Exception($"Filter provider '{prov}' was not registered with the Listview, but there is a request to remove it");

            FilterProviders.Remove(prov);
            prov.FilterChanged -= Prov_FilterChanged;
        }

        //Update the filtering criteria in the dictionary and kick off the timer
        private void Prov_FilterChanged(IFilterProvider sender, List<FilterBase> filter)
        {
            if (!FilterProviders.ContainsKey(sender))
                throw new Exception($"Filter provider '{sender}' was not registered with the list view screen");

            FilterProviders[sender] = filter;
            ListFilerChangedTimer.Stop();
            ListFilerChangedTimer.Start();
        }
        #endregion Filter Receiver



        private bool TryDescByIndex(int ind, out ListViewColumnDesc desc, out ColumnHeader colHdr)
        {
            colHdr = listView1.Columns[ind];
            desc = colHdr.Tag as ListViewColumnDesc;
            return !(desc is null);
        }

        private void ListView1_ColumnReordered(object __, ColumnReorderedEventArgs e)
        {
            if (TryDescByIndex(e.OldDisplayIndex, out var desc, out _))
                Main.UserProfile.Reorder(desc, e.NewDisplayIndex);
        }

        private void ListView1_ColumnWidthChanged(object _, ColumnWidthChangedEventArgs e)
        {
            if (TryDescByIndex(e.ColumnIndex, out var desc, out var col))
                desc.Width = col.Width;
        }

        public delegate void SetColumnsDelegate(IEnumerable<(string fieldName, DisplayStyle displayStyle)> columns, int requestId);
        public void SetColumns(IEnumerable<(string fieldName, DisplayStyle displayStyle)> columns, int requestId)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new SetColumnsDelegate(SetColumns), columns, requestId);
                return;
            }

            listView1.Columns.Clear();
            listView1.Items.Clear();

            List<ListViewColumnDesc> colDescs = new List<ListViewColumnDesc>(30);
            int cntr = 0; //Assume the order it has been listed in
            foreach (var (fieldName, displayStyle) in columns)
                colDescs.Add(Main.UserProfile.GetColumnDesc(ColumnDescDefaultName, fieldName, displayStyle, cntr++)); //Looked up or created

            var tmpOrder = colDescs.Select(cd => cd.Order).ToArray();
            ColumnOrder = Enumerable.Range(0, tmpOrder.Length).Select(i => Array.IndexOf(tmpOrder, i)).ToArray();

            var colHeaders = colDescs.OrderBy(cd => cd.Order).Select(cd => new ColumnHeader { Text = cd.ColumnName, TextAlign = cd.Alignment, Width = cd.Width, Tag = cd }).ToArray();
            listView1.Columns.AddRange(colHeaders);
        }


        public delegate void AddAllFieldsDelegate(UpdateType updType, string nodeId, string nodeType, string[] columns, int requestId);
        public void AddAllFields(UpdateType updType, string nodeId, string nodeType, string[] columns, int requestId)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new AddAllFieldsDelegate(AddAllFields), updType, nodeId, nodeType, columns, requestId);
                return;
            }

            switch (updType)
            {
                case UpdateType.Add:
                    if (!AllowedByFilter(columns))
                        return;

                    var lvi = new ListViewItem { Name = nodeId, Tag = nodeType };
                    SetItemColumns(updType, lvi, columns);
                    listView1.Items.Add(lvi);
                    break;

                case UpdateType.Update:
                    var lviu = listView1.Items[nodeId];
                    if (lviu != null) //The list view node is not necessarily in the list
                        SetItemColumns(updType, lviu, columns);
                    break;

                case UpdateType.Remove:
                    listView1.Items.RemoveByKey(nodeId);
                    break;

                default:
                    throw new NbExceptionEnum<UpdateType>(updType);
            }
        }


        private bool AllowedByFilter(string[] columns)
        {
            if (FilterN == null || FilterN.Length == 0)
                return true;
            else
            {
                bool res = FilterN.All(f => columns.Any(str => str.ContainsIC(f)));
                return res;
            }
        }
        //THINK: if all subitems created first then it will be possible to use Enumerable<string> for column values
        //But this all will change with the implementtion of the virtual mode

        /// <summary>
        /// Adds of replaces the main sext and the subitems of the ListViewItem with the columns given in the collection
        /// </summary>
        /// <param name="updType"></param>
        /// <param name="lvi"></param>
        /// <param name="columns"></param>
        private void SetItemColumns(UpdateType updType, ListViewItem lvi, string[] columns)
        {
            if (ColumnOrder == null) throw new NbExceptionInfo("ColumnOrder is not set");

            int cnt = 0;
            foreach (var pos in ColumnOrder)
            {
                var str = columns[pos]; //Orignal string
                if (listView1.Columns[cnt].Tag is ListViewColumnDesc colDesc) //If there is a column description - we can get the display style
                    str = str.ConvertStringByDisplayStyle(colDesc.DisplayStyle); //Apply the displays style

                if (cnt == 0)
                    lvi.Text = str;
                else
                {
                    if (updType == UpdateType.Add)
                        lvi.SubItems.Add(str);
                    else
                        lvi.SubItems[cnt].Text = str;  //SubItem[0] is the Text property
                }
                cnt++;
            }
        }

        private string ListViewDestNodeN(int x, int y)
        {
            Point targetPoint = listView1.PointToClient(new Point(x, y)); // Retrieve the client coordinates of the drop location.
            var targetNode = listView1.GetItemAt(targetPoint.X, targetPoint.Y); // Retrieve the node at the drop location.
            if (targetNode == null)
                return null;
            else
                return targetNode.Name ?? throw new Exception($"Destination listview item doesn't have an Id");
        }

        private void ListView1_DragDrop(object sender, DragEventArgs e)
        {
            var (srcNodeId, srcNodeType, srcNodeName) = Common.GetDraggedNodeId(e.Data);
            string dstNodeId = ListViewDestNodeN(e.X, e.Y);
            var cmds = Main.Model.GetDragCommands(srcNodeId, srcNodeType, srcNodeName, dstNodeId);
            Main.ShowDragDropMenu(cmds, srcNodeId, srcNodeType, srcNodeName, dstNodeId);
        }

        private void ListView1_DragOver(object sender, DragEventArgs e)
        {
            var (srcNodeId, srcNodeType, srcNodeName) = Common.GetDraggedNodeId(e.Data);
            string dstNodeId = ListViewDestNodeN(e.X, e.Y);
            var cmds = Main.Model.GetDragCommands(srcNodeId, srcNodeType, srcNodeName, dstNodeId).ToList(); //TODO: use enumerator instead
            e.Effect = (cmds.Count == 0) ? DragDropEffects.None : DragDropEffects.Move;
        }

        private void ListView1_ItemDrag(object sender, ItemDragEventArgs e) => DoDragDrop(e.Item, DragDropEffects.Move);


        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            contextMenuStrip1.Items.Clear();
            var it = listView1.GetItemAt(e.X, e.Y);
            if (it != null)
            {
                if (listView1.SelectedItems.Count == 1)
                {
                    var (nodeId, nodeType, nodeName) = SelectionFromNode(it);
                    var cmds = Main.Model.GetCommandsSingle(nodeId, nodeType);
                    foreach (var cmd in cmds)
                    {
                        var tsmi = new ToolStripMenuItem() { Text = cmd.label, Tag = cmd };
                        tsmi.Click += (_, __) => Main.Model.ExecuteCommand(cmd.id, nodeId, nodeType, nodeName, null);
                        contextMenuStrip1.Items.Add(tsmi);
                    }
                }
                else if (listView1.SelectedItems.Count == 2)
                {
                    var fromItem = listView1.SelectedItems[0] == it ? listView1.SelectedItems[1] : listView1.SelectedItems[0];
                    var (fromNodeId, fromNodeType, fromNodeName) = SelectionFromNode(fromItem);
                    var (toNodeId, toNodeType, toNodeName) = SelectionFromNode(it);

                    contextMenuStrip1.Items.Add($"Context menu for two items: {fromNodeName} => {toNodeName} ");
                }
                else
                {
                    contextMenuStrip1.Items.Add($"Context menu for multiple selection:");
                }


                contextMenuStrip1.Items.Add(new ToolStripSeparator());

                var subItem = it.GetSubItemAt(e.X, e.Y);
                string shortenedText = subItem.Text.Length > 30 ? subItem.Text.Substring(30) + "..." : subItem.Text;
                var copyCellMenu = new ToolStripMenuItem() { Text = $"Copy '{shortenedText}'" };
                copyCellMenu.Click += (_, __) => Clipboard.SetText(subItem.Text);
                contextMenuStrip1.Items.Add(copyCellMenu);
            }
            else
            {
                contextMenuStrip1.Items.Add($"Context menu for no seletion");
            }
            contextMenuStrip1.Show();
        }


        /*var col = GetListViewColumnN(listView1, e.X);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int GetScrollPos(IntPtr hWnd, Orientation nBar);

        // Return the column under this X position.
        static public ColumnHeader GetListViewColumnN(ListView lvw, int x)
        {
            x += GetScrollPos(lvw.Handle, Orientation.Horizontal); // Get the horizontal scroll bar's position.
          
            foreach(ColumnHeader col in lvw.Columns)
            {
                x -= col.Width;
                if (x <= 0) return col;
            }
            return null;
        }*/

        private void ListView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var it = listView1.GetItemAt(e.X, e.Y);
            if (it != null)
            {
                var (nodeId, nodeType, _) = SelectionFromNode(it);
                Main.NodeActionFromScreen(Keys.LButton, nodeId, nodeType);
            }
        }
    }
}
