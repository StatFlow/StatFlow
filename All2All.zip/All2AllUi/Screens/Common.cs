﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace All2All.Screens
{
    internal static class Common
    {
        internal static (string nodeId, string nodeType, string nodeName) GetDraggedNodeId(IDataObject dObj)
        {
            TreeNode draggedNode = (TreeNode)dObj.GetData(typeof(TreeNode)); // Retrieve the node that was dragged.
            if (draggedNode != null)
            {
                //TODO: think about extracting the Tag in one place
                var tns = draggedNode.Tag as TreeNodeState ?? throw new Exception($"Tree node '{draggedNode.Name}' doesn't have a Tag object");
                return (draggedNode.Name, tns.NodeType, draggedNode.Text);
            }

            ListViewItem draggedLv = (ListViewItem)dObj.GetData(typeof(ListViewItem));
            if (draggedLv != null)
            {   
                //TODO: think about extracting the Tag in one place
                var itType = draggedLv.Tag as string ?? throw new Exception($"List Item '{draggedLv.Name}' doesn't have Tag set up");
                return (draggedLv.Name, itType, draggedLv.Text);
            }

            return (null, null, null);
        }
    }
}
