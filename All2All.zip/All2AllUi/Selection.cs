﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using A2aCommands.Xml;

namespace All2All
{
    public class Selection
    {
        public readonly string NodeId;
        public readonly string NodeType;
        public readonly string NodeName;
        public readonly List<A2aCommandDesc> Commands;

        public Selection(string nodeId, string nodeType, string nodeName, List<A2aCommandDesc> commands)
        {
            NodeId = nodeId;
            NodeType = nodeType;
            NodeName = nodeName;
            Commands = commands;
        }
    }
}
