Notes
=====

Notes can be added to a commit. Notes will be stored separately and will not be pushed. To add a new note
choose ``add notes`` in the context menu of the commit information box.

.. image:: /images/add_note_context_menu.png

The editor that has been configured in the settings dialog will be used to enter or edit the notes. The Git
Extensions editor is advised.

.. image:: /images/note_editor.png
