Command line
============

Git Extensions command line
---------------------------

Most features can be started from the command line. It is recommended to add ``gitex.cmd`` to the path
when using from the command line. It is typically stored in the ``C:\Program Files (x86)\GitExtensions`` folder.

.. figure:: /images/command_line_usage.png

..

.. figure:: /images/command_line.png
