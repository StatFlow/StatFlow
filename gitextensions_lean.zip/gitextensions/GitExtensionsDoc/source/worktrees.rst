Worktrees
=========

Git Extensions support Git worktrees: Multiple checked out working directories can share local branches.
For more information see the Git documentation: https://git-scm.com/docs/git-worktree

.. image:: /images/worktree_context_menu.png
