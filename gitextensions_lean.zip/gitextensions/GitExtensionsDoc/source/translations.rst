Translations
============

Change language
---------------

In the settings dialog the language can be chosen.

.. image:: /images/install/language.png

Translate Git Extensions
------------------------

More information in the Git Extensions wiki:
https://github.com/gitextensions/gitextensions/wiki/Translations

Translations are done on Transifex: https://www.transifex.com/git-extensions/git-extensions/