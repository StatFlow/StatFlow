Windows Explorer
================

The common commands can be started from Windows Explorer using the shell extensions. This option is only available
when Shell Extensions are installed.

.. image:: /images/explorer_integration.png

If the folder do not have a Git repository, you can clone.

.. image:: /images/explorer_integration_new.png

