# Title1

## Title2

### Title3

#### Title4

This *is italic*.
This _is italic_.
This **is bold**.
This __is bold__.

> Blockquote

Example of `code inlined`.

```
some
multiline
code
```


    some other code

Lists:

 1. of
 2. ordered
 3. items


 * of
 * unordered
 * items

Links:

[Web](https://github.com/gitextensions/gitextensions)
[relative](README.md)

Some html:

  <a href="https://github.com/gitextensions/gitextensions/contributors"><img src="https://opencollective.com/gitextensions/contributors.svg?width=890&button=false" /></a>
