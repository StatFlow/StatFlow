﻿namespace ConEmuInside
{
    internal class ConEmuStartArgs
    {
        internal bool runAs = false;

        internal bool debug = false;

        internal bool log = false;

        internal bool autoClose = false;

        internal bool useGuiMacro = false;

        internal string xmlFilePath = "";

        internal string startupDirectory = "";

        internal string cmdLine = "";

        internal string conemuExePath = "";
    }
}