﻿using System.Reflection;

[assembly: AssemblyDescription("GitExtensions is a GUI for git")]