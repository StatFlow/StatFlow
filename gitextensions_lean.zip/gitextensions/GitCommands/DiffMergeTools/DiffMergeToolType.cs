﻿namespace GitCommands.DiffMergeTools
{
    public enum DiffMergeToolType
    {
        Diff = 0,
        Merge
    }
}