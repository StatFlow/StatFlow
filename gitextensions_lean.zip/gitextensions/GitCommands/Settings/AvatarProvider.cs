using System;

namespace GitCommands
{
    public enum AvatarProvider
    {
        // DO NOT RENAME THESE -- doing so will break user preferences
        Default = 0,
        Custom,
        None,
    }
}
