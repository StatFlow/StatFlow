﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyDescription("GitExtensions commands")]

[assembly: InternalsVisibleTo("GitCommands.Tests")]
[assembly: InternalsVisibleTo("GitUI.Tests")]
