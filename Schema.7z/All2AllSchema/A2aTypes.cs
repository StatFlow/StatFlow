﻿using NbXsdV1.Xml;

namespace All2AllSchema
{
    class A2aTypes
    {

        //public enum DisplayStyle { String, Number, TimeMinSec, FileSize }
        internal static Elem Root()
        {
            var DisplayStyles = new TypeEnum("DisplayStyles", XsType.String, new EnumItem[] {
                new EnumItem { key = "String", value = "Doc for String"}
                ,new EnumItem { key = "Number", value = "Doc for Number"}
                ,new EnumItem { key = "TimeMinSec", value = "Doc for TimeMinSec"}
                ,new EnumItem { key = "FileSize", value = "Doc for FileSize"}
            });

            var Column = new TypeAttrOnly("Column",
                new Attr("name", XsType.String, Uses.Required),
                new Attr("display_type", DisplayStyles, Uses.Required)
                );

            var A2aType = new TypeSequence("A2aType"
                , new Attr("name", XsType.String, Uses.Required)
                , new Attr("icon", XsType.String, Uses.Optional)
                , new Attr("hierarchy_table", XsType.String, Uses.Optional)
                , new Elem("column", Column, 1, Elem.Unbounded)
                );

            var TreeView = new TypeSequence("TreeViewXml",
                new Attr("name", XsType.String, Uses.Required),
                new Attr("root_id", XsType.String, Uses.Optional, doc: "Allows tree to show a subtree of nodes"),
                new Elem("type", XsType.String, 1, Elem.Unbounded, doc: "The list of types allowed in this tree view") //List of types allowed in the trees
                );

            var ListView = new TypeAttrOnly("ListViewXml"
                , new Attr("name", XsType.String, Uses.Required)
                , new Attr("type", XsType.String, Uses.Required) //Only one type allowed in a given listview
                , new Attr("request_name", XsType.String, Uses.Required, doc: "The name of the view or a table that will be inserted in the sql xml request constructed in the view")
                );

            var WebView = new TypeAttrOnly("WebViewXml"
                , new Attr("name", XsType.String, Uses.Required)
                , new Attr("type", XsType.String, Uses.Required) //Only one type allowed in a given listview
                , new Attr("request_name", XsType.String, Uses.Required, doc: "The name of the view or a table that will be inserted in the sql xml request constructed in the view")
                );

            var Root = new TypeSequence("A2aT"
                , new ListSingle("type", A2aType)
                , new ListSingle("tree_view", TreeView)
                , new ListSingle("list_view", ListView)
                , new ListSingle("web_view", WebView)
                );

            return new Elem("a2a_types", Root);
        }
    }
}
