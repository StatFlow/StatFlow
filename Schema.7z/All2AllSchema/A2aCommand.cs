﻿using NbXsdV1.Xml;

namespace All2AllSchema
{
    class A2aCommand
    {
        internal static Elem Root()
        {
            //namespace System.Windows.Forms.DataFormats

            var ClipboardData = new TypeEnum("ClipboardData", XsType.String, new EnumItem[] {
                new EnumItem { key = "None", value = "No need for clipboard data"}
                ,new EnumItem { key = "FileDrop", value = "FileDrop"}
                ,new EnumItem { key = "Url", value = "UniformResourceLocatorW"}
                ,new EnumItem { key = "MozillaUrl", value = "text/x-moz-url"}
                ,new EnumItem { key = "Text", value = "Text"}
                ,new EnumItem { key = "UnicodeText", value = "UnicodeText"}
                ,new EnumItem { key = "Bitmap", value = "Bitmap"}
                ,new EnumItem { key = "Html", value = "HTML Format"}
                ,new EnumItem { key = "Rtf", value = "Rich Text Format"}
                ,new EnumItem { key = "Csv", value = "CommaSeparatedValue"}
                });

            var ShowOn = new TypeEnum("ShowOn", XsType.String, new EnumItem[] {
                new EnumItem { key = "None", value = "Don't show command on UI, useful for HotKey-only commands"} ,
                new EnumItem { key = "ContextMenu", value = "Show command on context menu"} ,
                new EnumItem { key = "Toolbar", value = "Show command on toolbar menu"},
                new EnumItem { key = "ToolbarAndContextMenu", value = "UniformResourceLocatorW"},
                });

            var Nd = new TypeAttrOnly("A2aNode",
                new Attr("id", XsType.String, Uses.Required),
                new Attr("type", XsType.String, Uses.Optional),
                new Attr("name", XsType.String, Uses.Optional, null, "The text label that is shown in the tree view or other views")
                );

            //Useful for intefacing with All2AllInterfaces.cs
            var NbTree = new TypeDerived("A2aNodeTree", Nd,
                new Attr("parentId", XsType.String, Uses.Optional, null, "If parent is null the node is considered to be Root"),
                new Attr("icon", XsType.String, Uses.Optional, null),
                new Attr("has_children", XsType.Bool, Uses.Optional, "false", "Used in tree view to show the + sign without quering the child nodes")
                );

            var Nodes = new TypeChoice("Nodes", min: 0, max: -1, new Elem("node", Nd, 0, 1));

            var Root = new TypeSequence("A2aCommand"
                , new Elem("src", Nd, 0, 1)
                , new Elem("dst", Nd, 0, 1)
                , new Elem("nodes", Nodes, 0, 1)
                , new Attr("id", XsType.String, Uses.Required)
                , new Attr("label", XsType.String, Uses.Required)
                , new Attr("disabled", XsType.Bool, Uses.Optional, "false", "Show greyed-out menu option with the commend why it is not available in the tooltip")
                , new Attr("icon", XsType.String, Uses.Optional)
                , new Attr("tooltip", XsType.String, Uses.Optional)
                , new Attr("hotkey", XsType.String, Uses.Optional)
                , new Attr("show_on", ShowOn, Uses.Optional, "ContextMenu", "Where to show the command: toolbar, context menu or both")
                , new Attr("show_label", XsType.Bool, Uses.Optional, "true", "Can be used for icon-only buttons on the toolbox")
                , new Attr("data_requred", ClipboardData, Uses.Optional, "None", "Requiest for additional Clipboard data, such as FileDrop list or Mozilla Link")
                , new Elem("_nouse", NbTree, 0, 1, "Only here the make the tool generate the class for A2aNodeTree")
                );

            return new Elem("a2a_command", Root);
        }
    }
}
