﻿using NbXsdV1.Xml;
namespace All2AllSchema
{
    class Program
    {
        //TODOL:
        //Resolving when loading and using names when saving
        //Think about injecting serialization code when creating the file

        static void Main()
        {
            //Cs2Xsd.Generate(All2allv1.Root(), "all2allv1", @"..\..\..\FlavoursModel\All2all.xsd", createCs: true);
            //Cs2Xsd.Generate(A2aCommand.Root(), "A2aCommands", @"C:\Repo\NbTools\NbTools\Filter\A2aCommands.xsd", createCs: true);
            //Cs2Xsd.Generate(A2aTypes.Root(), "A2aTypes", @"C:\Repo\NbTools\NbTools\Filter\A2aTypes.xsd", createCs: true);
            Cs2Xsd.Generate(A2aForms.Root(), "A2aForms", @"C:\Repo\NbTools\NbTools\Filter\A2aForms.xsd", createCs: true);
            //Cs2Xsd.Generate(NbSqlXml.Root(), "NbTools.SqlGen", @"C:\Repo\NbTools\NbTools\Filter\NbSqlXml.xsd", createCs: true);
        }
    }
}
