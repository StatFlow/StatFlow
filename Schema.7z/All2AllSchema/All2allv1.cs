﻿using NbXsdV1.Xml;

namespace All2AllSchema
{
    static class All2allv1
    {
        static TypeChoice Refs()
        {
            var Ref = new TypeAttrOnly("Ref",
                new Attr("typ", XsType.NCName, Uses.Required),
                new Attr("frm", XsType.String, Uses.Required),
                new Attr("to", XsType.String, Uses.Required),
                new Attr("ord", XsType.Int, Uses.Optional, deflt: "-1")); //base class

            return new TypeChoice("Refs", min: 0, max: -1, new Elem("ref", Ref, 0, 1));
        }

        static TypeChoice RefTypes()
        {
            var RefType = new TypeAttrOnly("RefType", new Attr("id", XsType.NCName, Uses.Required),
                new Attr("meaning", XsType.String, Uses.Required),
                new Attr("meaning_reverse", XsType.String, Uses.Required)); //base class

            return new TypeChoice("RefTypes", min: 0, max: -1, new Elem("ref_type", RefType, 0, 1));
        }

        static TypeChoice Nodes()
        {
            var flavour = new TypeAttrOnly("Flavour", new Attr("icon", XsType.String, Uses.Optional, doc: "Icon name to show different icons for different types of object in the Tree View")); //base class

            //TODO: introduce reference to other object instead of directory
            var File = new TypeDerived("FlavFile", flavour
                , new Attr("file_name", XsType.String, Uses.Required)
                , new Attr("extension", XsType.String)
                , new Attr("length", XsType.Long, Uses.Required)
                , new Attr("created", XsType.DateTime, Uses.Required)
                , new Attr("modified", XsType.DateTime, Uses.Required)
                , new Attr("accessed", XsType.DateTime, Uses.Required)
                );

            //TODO: introduce type for time period
            var AudioFile = new TypeDerived("FlavAudioFile", flavour, new Attr("bit_rate", XsType.Int), new Attr("time", XsType.Int));

            var VideoFile = new TypeDerived("FlavVideoFile", flavour
                , new Attr("hight", XsType.Int, Uses.Optional, "0")
                , new Attr("width", XsType.Int, Uses.Optional, "0")
                , new Attr("bit_rate", XsType.Int, Uses.Optional, "0")
                , new Attr("duration", XsType.Float, Uses.Optional, "0"));

            var Playable = new TypeDerived("FlavPlayable", flavour, new Attr("is_list", XsType.Int));




            var Folder = new TypeDerived("FlavFolder", flavour
                , new Attr("created", XsType.DateTime, Uses.Optional)
                , new Attr("length", XsType.Long, Uses.Optional)  //Will be calculated
                );

            var Sync = new TypeDerived("FlavSync", flavour
                , new Attr("profile", XsType.String, Uses.Required, null, "Specifies profile for syncing, like K325, RedSansa")
                );



            var LmLink = new TypeDerived("FlavLmLink", flavour
                , new Attr("accessed", XsType.DateTime, Uses.Optional)
                , new Attr("archived", XsType.DateTime, Uses.Optional)
                , new Attr("clipboard", XsType.String, Uses.Optional)
                , new Attr("shortcut", XsType.String, Uses.Optional)
                , new Attr("url", XsType.String)
                );

            var LmLauncher = new TypeDerived("FlavLmLauncher", flavour
                , new Attr("exe_name", XsType.String, Uses.Required)
                , new Attr("params", XsType.String)
                );

            var Node = new TypeChoice("Node", min: 1, max: -1
                , new Elem("file", File, 0, 1)
                , new Elem("audio", AudioFile, 0, 1)
                , new Elem("video", VideoFile, 0, 1)
                , new Elem("playable", Playable, 0, 1)
                , new Elem("folder", Folder, 0, 1)
                , new Elem("sync", Sync, 0, Elem.Unbounded, "Use if you want this node to participate in folder synchronization")
                , new Elem("lm_link", LmLink, 0, 1)
                , new Elem("lm_lancher", LmLauncher, 0, 1)

                , new Attr("id", XsType.String)
                , new Attr("name", XsType.String)
                , new Attr("icon", XsType.String, Uses.Optional, doc: "Each node can have its own icon, even without flavours")
                , new Attr("deleted", XsType.Bool, Uses.Optional, deflt: "false")
                );

            return new TypeChoice("Nodes", min: 0, max: -1, new Elem("node", Node, 0, 1));
        }

        internal static Elem Root()
        {
            /*var Property = new TypeAttrOnly("Property", new Attr("id", XsType.String, Uses.Required));
            
            var PropRef = new TypeAttrOnly("PropRef",
                new Attr("node", XsType.NCName, Uses.Required),
                new Attr("frm", XsType.String, Uses.Required),
                new Attr("value", XsType.String, Uses.Required));*/

            var Root = new TypeSequence("Root"
                , new Attr("next_id", XsType.Int, Uses.Optional, "0", "The id to be used for the new node inserted into the model (with checks for existing ids)")
                , new Elem("nodes", Nodes(), 0, 1)
                , new Elem("ref_types", RefTypes(), 0, 1)
                //.new ListSingle("property", Property)
                , new Elem("refs", Refs(), 0, 1)
                //,new ListSingle("prop_ref", PropRef)
                );

            return new Elem("all2all", Root);
        }
    }
}
