﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MuzQuiz2.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<DbArtist> DbArtists { get; set; }
        public DbSet<Quiz> Quizzes { get; set; }
        public DbSet<QuizAnswer> QuizAnswers { get; set; }
    }

    /*public class ApplicationUser : IdentityUser
    {
        public ICollection<Quiz> Quizzes { get; set; }  //Quizzes for users
    }*/

    public class DbArtist
    {
        public int Id { get; set; }
        public string ShortName { get; set; }

        public ICollection<Quiz> Quizzes { get; set; }  //Quizzes for Artist
    }

    public class Quiz
    {
        public int Id { get; set; }

        [ForeignKey("User")]
        public string UserId { get; set; }  //Quizzes for users
        public virtual IdentityUser User { get; set; }

        [ForeignKey("Artist")]
        public int ArtistId { get; set; }  //Quizzes for Artist
        public virtual DbArtist Artist { get; set; }

        public DateTime StartTime { get; set; }
        public TimeSpan? TimeTaken { get; set; }
        public int? Score { get; set; }

        public ICollection<QuizAnswer> QuizAnswers { get; set; }  //QuizAnswers for Quiz
    }

    public class QuizAnswer
    {
        public int Id { get; set; }

        public DateTime Time { get; set; }
        public int? Score { get; set; }

        [ForeignKey("Quiz")]
        public int QuizId { get; set; } //QuizAnswers for Quiz
        public virtual Quiz Quiz { get; set; }
    }
}
