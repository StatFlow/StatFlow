﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MuzQuiz
{
    public static class Extensions
    {
        public static Random Rnd = new Random();

        public static T Random<T>(this IList<T> list)
        {
            int ind = Rnd.Next(list.Count);
            return list[ind];
        }

        public static IList<T> RandomRange<T>(this IList<T> list, int numOfItems)
        {
            if (numOfItems >= list.Count)
                return list;

            int ind = Rnd.Next(list.Count - numOfItems + 1);
            return list.Skip(ind).Take(numOfItems).ToList();
        }

        public static T Random<T>(this IList<T> list, int previous)
        {
            if (list.Count == 1)
                return list[0];

            int ind;
            do
            {
                ind = Rnd.Next(list.Count);
            } while (ind != previous);
            
            return list[ind];
        }


        public static string TheToTheEnd(this string aStr)
        {
            if (aStr.Length > 4 && aStr.Substring(0, 4).ToLowerInvariant().Equals("the ")) //Move "the" to the end
                return aStr.Substring(4) + ", The";
            else
                return aStr;
        }
    }
}
