﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Newtonsoft.Json.Linq;
using KindleCreator;
using NbTools;
using NbTools.Audio;

namespace MuzQuiz.Models
{
    public class SongDataModel
    {
        internal readonly LrcArtist Artist;

        public SongDataModel()
        {
            //Albums = LoadFromTxtDir();
            Artist = new LrcArtist(new DirectoryInfo(@"C:\App\MuzQuiz.data\lrc\Queen"));
        }

        internal LrcSong SongById(string sngId) => Artist.SongById(sngId);
        internal LrcAlbum AlbumById(string albId) => Artist.AlbumById(albId);
        public JArray JsonForJstree() => Artist.JsonForJstree();

        internal LrcSong RandomSong() => Artist.Albums.Random().Songs.Random();

        internal (LrcSong, IEnumerable<LrcSong.Line>, string) RandomLyrics(int numOfLines)
        {
            var sng = RandomSong();

            var retries = 10;
            var lines = sng.LyricsLines.RandomRange(numOfLines);
            var nameSections = sng.SongNameSections.ToList();

            //Make sure the song name is not in the 
            while (lines.Any(l => nameSections.Any(sec => l.Text.Contains(sec, StringComparison.OrdinalIgnoreCase)) && retries-- > 0))
            {
                lines = sng.LyricsLines.RandomRange(numOfLines);
            }

            var mp3File = CreateMp3Section(sng, lines[0].From, lines[^1].To);
            return (sng, lines, mp3File);
        }

        private string CreateMp3Section(LrcSong sng, TimeSpan from, TimeSpan to)
        {
            if (to < from)
                throw new NbExceptionInfo("to must be creater than from");

            var mp3 = sng.Mp3FileName;
            if (!File.Exists(mp3))
                throw new NbExceptionInfo($"Mp3 file '{mp3}' doesn't exist");

            var fileName = $"{Guid.NewGuid()}.mp3";
            NbAudio.TrimMp3(mp3, @"wwwroot\mp3\" + fileName, from.Add(TimeSpan.FromMilliseconds(-300)), to.Add(TimeSpan.FromMilliseconds(300)));
            return fileName;
        }
    }
}
