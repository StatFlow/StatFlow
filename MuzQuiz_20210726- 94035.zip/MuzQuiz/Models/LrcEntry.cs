﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using MuzQuiz;
using NbTools;
using Newtonsoft.Json.Linq;

namespace KindleCreator
{
    internal class LrcArtist
    {
        public readonly int Id;
        public readonly string Title;
        public List<LrcAlbum> Albums;

        //private static readonly Regex fAlbOutOfDirName = new Regex(@"^(\d{4}\w?)\s-\s(.+)$");
        private static int IdCounter = 1;

        public LrcArtist(string title)
        {
            Id = IdCounter++;
            Title = title;
        }

        public LrcArtist(DirectoryInfo di)
        {
            Id = IdCounter++;
            Title = di.Name;
            Albums = di.GetDirectories("*", SearchOption.TopDirectoryOnly).Select(d => new LrcAlbum(d, this)).ToList();
        }

        internal LrcSong SongById(string sngId) => Albums.SelectMany(a => a.Songs).SingleVerbose(s => s.Id == sngId,
                () => $"Song with id '{sngId}' was not found", i => $"There are {i} songs with the id '{sngId}' found");

        internal LrcAlbum AlbumById(string albId) => Albums.SingleVerbose(a => a.Id == albId,
                () => $"Album with id '{albId}' was not found",  i => $"There are {i} albums with the id '{albId}' found");

        internal JArray JsonForJstree() => new JArray(Albums.Select(a => a.ToJstreeJson()));

        public override string ToString() => $"{Title}({Albums.Count()})";
    }

    internal class LrcAlbum
    {
        public readonly string Id;
        public readonly string Title;
        public readonly string TitleThe;
        public readonly string Year;
        public readonly LrcArtist fArtist;
        public List<LrcSong> Songs;

        private static readonly Regex fAlbOutOfDirName = new Regex(@"^(\d{4}\w?|\d{4}\.\d{2}\.\d{2})" + //Year followed by optional letter or yyyy.mm.dd   //Group 1
            @"(\s-\s+|\s+)" + //Space of ' - '                                                                      //Group 2
            @"(.+)$");  //The rest is album name                                                                //Group 3
        private static int IdCounter = 1;

        public LrcAlbum(string title, LrcArtist art)
        {
            fArtist = art;
            Title = title;
            TitleThe = String.Format("{1} (album by {0})", Title.TheToTheEnd(), fArtist.Title);
            Id = (IdCounter++).ToString();

            //Year = //TODO:
        }

        public LrcAlbum(DirectoryInfo di, LrcArtist art)
        {
            fArtist = art;
            var match = fAlbOutOfDirName.Match(di.Name);
            if (!match.Success)
                throw new NbException($"Album Dir name doesn't match regex: {di.FullName}");

            Id = match.Groups[1].Value;
            Year = match.Groups[1].Value;
            Title = match.Groups[3].Value;
            var lrcAndTxt = di.GetFiles("*.lrc", SearchOption.TopDirectoryOnly).Union(di.GetFiles("*.txt", SearchOption.TopDirectoryOnly)).OrderBy(fi => fi.Name).ToList();
            Songs = lrcAndTxt.Select(fi => LrcSong.FileToSong(fi, this)).ToList();
            TitleThe = String.Format("{1} (album by {0})", Title.TheToTheEnd(), fArtist.Title);
        }

        public JObject ToJstreeJson()
        {
            return new JObject(
                new JProperty("id", Id), //1977.10.28
                new JProperty("text", Title),
                new JProperty("children", new JArray(Songs.Select(f => f.ToJstreeJson())))
                );
        }

        public override string ToString() => $"{Year} - {Title}({Songs.Count()})";
    }

    internal class LrcSong
    {
        internal readonly struct Line
        {
            public Line(TimeSpan from, TimeSpan to, string text)
            {
                From = from;
                To = to;
                Text = text;
            }

            internal readonly TimeSpan From;
            internal readonly TimeSpan To;
            internal readonly string Text;
        }


        public string MiniLyricsId;
        public string Ti;
        public string Ar;
        public string Al;
        public string By;

        public readonly string Id;
        public readonly LrcAlbum Album;
        public readonly string Title;
        public readonly string FileName;

        public string TitleThe;

        public string Lyrics;
        public List<Line> LyricsLines;

        private static readonly TimeSpan millisecond = new TimeSpan(TimeSpan.TicksPerMillisecond);
        private static readonly Regex fStringWithTime3 = new Regex(@"\[(\d+):(\d+)\.(\d+)\]");
        private static readonly Regex fStringWithTime2 = new Regex(@"\[(\d+):(\d+)\]");

        private static int IdCounter = 1;


        public LrcSong(string id, string title, LrcAlbum album, string fileName)
        {

            Id = id;
            Title = title;
            Album = album ?? throw new NbExceptionInfo("Album is empty");
            FileName = fileName;
        }

        public LrcSong(Tuple<string, string> linkAndName, string songFileName, LrcAlbum aAlbum)
            : this(id: (IdCounter++).ToString(), title: linkAndName.Item2, album: aAlbum, fileName: songFileName)
        {
            if (Title.Length > 4 && Title.Substring(0, 4).ToLowerInvariant().Equals("the ")) //Move "the" to the end
                TitleThe = Title.Substring(4) + ", The";
            else
                TitleThe = Title;

            TitleThe += String.Format(" ({0})", aAlbum.fArtist.Title);
            LyricsOutOfWiki(songFileName);
        }

        public string Mp3FileName => FileName.Replace("lrc", "mp3");

        private static readonly Regex fSongOutOfFileName = new Regex(@"(\d+)" + //Song number
            @"(\.\s+|\s*-\s*|\s)" + //May be followed by '. ' of by ' - '                 //Group 2
            @"(.+)" + //Song name                                                //Group 3
            @"\.(txt|lrc)", RegexOptions.IgnoreCase);  //Extension                 //Group 4


        public static LrcSong FileToSong(FileInfo fi, LrcAlbum aAlbum)
        {
            var match1 = fSongOutOfFileName.Match(fi.Name);
            if (!match1.Success)
                throw new NbException($"Can't parse song name out of the file: {fi.FullName}");

            LrcSong entry = new LrcSong(id: aAlbum.Id + '_' + match1.Groups[1].Value,
                title: match1.Groups[3].Value,
                album: aAlbum, 
                fileName: fi.FullName);

            if (entry.Title.Length > 4 && entry.Title.Substring(0, 4).ToLowerInvariant().Equals("the ")) //Move "the" to the end
                entry.TitleThe = entry.Title.Substring(4) + ", The";
            else
                entry.TitleThe = entry.Title;

            entry.TitleThe += String.Format(" ({0})", aAlbum.fArtist.Title);


            if (match1.Groups[4].Value.ToLowerInvariant().Equals("lrc")) //extenstion
                entry.LyricsOutOfLrc(fi.FullName);
            else
                entry.LyricsOutOfTxt(fi.FullName);


            return entry;
        }

        private void LyricsOutOfTxt(string aFileName) => Lyrics = File.ReadAllText(aFileName);

        private void LyricsOutOfWiki(string songFileName)
        {
            Lyrics = String.Join(Environment.NewLine, File.ReadAllLines(songFileName)
                .Where(l => !l.StartsWith("===="))
                .Select(l => l.Trim('\\')));
        }

        private void LyricsOutOfLrc(string aFileName)
        {
            var dict = LrcFileToDictionary(aFileName);
            LyricsLines = new List<Line>(dict.Count); //Will not contain empty strings

            KeyValuePair<TimeSpan, string> prevPair = default;
            foreach (var pair in dict)
            {
                //Comparing value type with default without boxing
                if (EqualityComparer<KeyValuePair<TimeSpan, string>>.Default.Equals(prevPair, default))
                {
                    prevPair = pair;
                    continue;
                }
                if (!String.IsNullOrWhiteSpace(prevPair.Value)) //Save only lines with text
                {
                    var l = new Line(from: prevPair.Key, to: pair.Key, text: prevPair.Value);
                    LyricsLines.Add(l);
                }
                prevPair = pair;
            }

            StringBuilder bld = new StringBuilder();
            foreach (var line in dict.Values) //Ignore timestamps, we need them only for ordering
            {
                bld.AppendLine(line);
            }
            Lyrics = bld.ToString();
        }

        private SortedDictionary<TimeSpan, string> LrcFileToDictionary(string aFileName)
        {
            var dict = new SortedDictionary<TimeSpan, string>();
            int lineCount = 1;
            foreach (var line in File.ReadLines(aFileName))
            {
                if (String.IsNullOrWhiteSpace(line)) //Ignore empty lines
                {
                    lineCount++;
                    continue;
                }

                if (line.Length >= 5)
                    switch (line.Substring(0, 4).ToLowerInvariant())
                    {
                        case "[id:":
                            MiniLyricsId = line[4..^1].Trim(); //remove the last ] 
                            continue;
                        case "[ti:":
                            Ti = line[4..^1].Trim(); //remove the last ] 
                            continue;
                        case "[ar:":
                            Ar = line[4..^1].Trim(); //remove the last ] 
                            continue;
                        case "[al:":
                            Al = line[4..^1].Trim(); //remove the last ] 
                            continue;
                        case "[by:":
                            By = line[4..^1].Trim(); //remove the last ] 
                            continue;
                        case "[off": //Ignore offset
                        case "[len": //Ignore length
                            continue;
                        default:
                            break;
                    }


                var matches = fStringWithTime3.Matches(line);
                if (matches.Count == 0)
                {
                    matches = fStringWithTime2.Matches(line);
                    if (matches.Count == 0)
                    {
                        Console.WriteLine("{0}({1}): Unparsed line: {2}", aFileName, lineCount, line);
                        lineCount++;
                        continue; //No timestamp matches found
                    }
                }

                TimeSpan[] timeSpans = new TimeSpan[matches.Count];

                int cnt = 0;
                int timesLen = 0;
                foreach (Match match in matches) //For each timestamp of the line
                {
                    timesLen += match.Groups[0].Value.Length;
                    timeSpans[cnt++] = new TimeSpan(0, 0, Convert.ToInt32(match.Groups[1].Value), Convert.ToInt32(match.Groups[2].Value),
                        (match.Groups.Count == 4) ? Convert.ToInt32(match.Groups[3].Value) * 10 : 0); //The milliseconds may not be provided
                }

                string text = line.Substring(timesLen).Trim(); //timesLen - Total length of all timestamps
                if (!String.IsNullOrWhiteSpace(text))
                    text = text.Substring(0, 1).ToUpperInvariant() + text.Substring(1); //Capitalize first letter

                foreach (var ts in timeSpans)
                {
                    TimeSpan candidate = ts;
                    while (dict.ContainsKey(candidate))   //Deal with multiple occurences of the same time stamp
                        candidate = candidate.Add(millisecond);

                    dict.Add(candidate, text);
                }
                lineCount++;
            }
            return dict;
        }

        //TODO: not properly implemented - split sections such as () in the name
        public IEnumerable<string> SongNameSections
        {
            get { yield return Title; }
        }

        public JObject ToJstreeJson() => new JObject(new JProperty("id", Id), new JProperty("text", Title));

        public override string ToString() => Title;
    }
}
