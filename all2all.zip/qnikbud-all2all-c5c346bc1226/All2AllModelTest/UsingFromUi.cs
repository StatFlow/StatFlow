﻿using System.IO;
using System.Threading;
using Xunit;

using A2aTypes.Xml;
using All2All;
using all2allv1.Xml;

namespace All2AllModelTest
{
    public class UsingFromUi
    {
        //private const string Beyond = @"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe";

        [Fact]
        public void GetRoot()
        {
            string srcFile = Path.GetFullPath(@"..\..\..\All2AllModelTest\FromFiles.xml");
            string typesFile = @"C:\Repo\Cs\PCast\ModelFMan\Types.xml";

            var Model = new All2All.Model.FlavoursModel(new NullUI());
            Model.LoadFromXmlModel(Root.LoadFile(srcFile), A2aT.LoadFile(typesFile));
            using CancellationTokenSource canTokSrc = new CancellationTokenSource();
            Model.GetChildren(parentIdN: null, parentTypeN: null, reqFlavours: new string[] { "File", "Dir" }, canTokSrc.Token, 1);
        }
    }
}
