﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Xunit;

using A2aTypes.Xml;
using All2All;
using All2All.Model;
using all2allv1.Xml;

namespace All2AllModelTest
{
    public class SyncTests
    {
        //private const string Beyond = @"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe";

        [Fact]
        public void CreateADir_AndLoadIntoModel()
        {
            //var a = Path.GetTempPath();
            //var b = Path.GetTempFileName();

            //Create the dir
            string dstFile = Path.GetFullPath(@"..\..\..\All2AllModelTest\FromFiles.xml");

            var Model = new All2All.Model.FlavoursModel(new NullUI());
            Model.LoadFromFileStructure(new DirectoryInfo(Environment.ExpandEnvironmentVariables(@"N:\Videos")));
            var newXmlModel = Model.SaveToXmlModel();
            newXmlModel.Save(dstFile);

            //Check the created file


            //Delete the dir

        }

        [Fact]
        public void TestMethod1()
        {
            string srcFile = Path.GetFullPath(@"..\..\..\All2AllModel\MusExample.xml");
            string typesFile = @"C:\Repo\Cs\PCast\ModelFMan\Types.xml";
            string dstFile = Path.GetFullPath(@"..\..\..\All2AllModel\MusExample2.xml");

            var Model = new All2All.Model.FlavoursModel(new NullUI());
            Model.LoadFromXmlModel(Root.LoadFile(srcFile), A2aT.LoadFile(typesFile));
            var newXmlModel = Model.SaveToXmlModel();
            newXmlModel.Save(dstFile);

            //NbProcess.RunSync(Beyond, null, srcFile, dstFile);
        }
    }

    public class TestFileStruct : IDisposable
    {
        private readonly string DirName;

        public TestFileStruct()
        {
            DirName = Path.GetTempFileName();
            File.Delete(DirName);
            Directory.CreateDirectory(DirName);
        }

        public void Dispose()
        {
            Directory.Delete(DirName, recursive: true);
        }
    }
}
