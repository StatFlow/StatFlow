﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using NbTools;
using NbTools.Collections;
using NbTools.Sync;
using Xunit;

namespace All2AllModelTest
{
    public class Currency : ISync<Currency>
    {
        public DateTime Date;
        public string Name;
        public decimal Exchange;

        public string Key => Name;


        //TODO: think about merging the changes of nodes and the changes off properties (and maybe changes of Flavours)

        //TODO: never called.
        public IEnumerable<PropertyChange> GetChanges(Currency other)
        {
            if (Exchange == 0)
                yield return new PropertyChange(ChangeType.ValidationError, nameof(Exchange), Exchange, other.Exchange, "Baseline exchange rate is 0");
            else if (Exchange < 0)
                yield return new PropertyChange(ChangeType.ValidationError, nameof(Exchange), Exchange, other.Exchange, "Baseline exchange rate is negative");

            if (other.Exchange == 0)
                yield return new PropertyChange(ChangeType.ValidationError, nameof(Exchange), Exchange, other.Exchange, "Exchange rate is 0");
            else if (other.Exchange < 0)
                yield return new PropertyChange(ChangeType.ValidationError, nameof(Exchange), Exchange, other.Exchange, "Exchange rate is negative");

            if (Exchange != other.Exchange)
            {
                decimal changePercent = Math.Abs(1 - (other.Exchange / Exchange)) * 100;
                if (changePercent >= 10)
                    yield return new PropertyChange(ChangeType.ValidationError, nameof(Exchange), Exchange, other.Exchange, "The exchange rate has changed by 10% or more");
                else if (changePercent >= 5)
                    yield return new PropertyChange(ChangeType.ValidationError, nameof(Exchange), Exchange, other.Exchange, "The exchange rate has changed by 5-10%");
            }
        }
    }

    public class RatesList : INodeColl<Currency>
    {
        public readonly string Name;
        private readonly List<Currency> Rates;

        public RatesList(string name, List<Currency> list)
        {
            Name = name;
            Rates = list;
        }

        public RatesList(string filename)
        {
            Name = new FileInfo(filename).Name;
            Rates = NbExt.FromCsv<Currency>(filename).ToList();
        }

        public string Key => Name;
        public IEnumerable<PropertyChange> GetChanges(Currency other) { yield break; }
        public IEnumerable<Currency> GetChildren(string refTypeName) => Rates;
        public bool HasChildren(string _) => Rates.Count > 0;
    }

    public enum LogMessageType { Info, Warning, Error }

    public class MergeLogMessage
    {
        public MergeLogMessage(LogMessageType tp, string paramName, string mess)
        {
            Type = tp;
            ParamName = paramName;
            Message = mess;
        }

        public LogMessageType Type;
        public string ParamName;
        public string Message;

        public string IconName => Type switch
        {
            LogMessageType.Error => "IconErrorEncoded",
            LogMessageType.Warning => "IconWarningEncoded",
            LogMessageType.Info => "IconInfoEncoded",
            _ => throw new NbExceptionEnum<LogMessageType>(Type),
        };
    }


    public class CsvMergeTests
    {
        //private static readonly DateTime Today = DateTime.Now.Date;
        //private static readonly DateTime Yesterday = Today.AddDays(-1);
        private static readonly RatesList yestRates = new RatesList(@"Data/RatesYesterday.csv");
        private static readonly RatesList todayRates = new RatesList(@"Data/RatesToday.csv");



        [Fact]
        public void SymmetricMerge_Test()
        {
            var logMessages = new List<MergeLogMessage>();


            foreach (var ch in SyncTools.SyncR(yestRates, todayRates, "Contains"))
            {
                switch (ch)
                {
                    case NodeChange<Currency, Currency> nodeCh:
                        switch (nodeCh.ChangeType)
                        {
                            case ChangeType.None:
                                break;

                            case ChangeType.Add:
                                logMessages.Add(new MergeLogMessage(LogMessageType.Warning, nodeCh.NodeDst.Key, "Extra rate added"));
                                break;

                            case ChangeType.Remove:
                                logMessages.Add(new MergeLogMessage(LogMessageType.Error, nodeCh.NodeSrc.Key, "Rate is missing"));
                                break;

                            case ChangeType.Update:
                                logMessages.Add(new MergeLogMessage(LogMessageType.Info, nodeCh.NodeSrc.Key, "Rate's value has changed"));
                                foreach(var propCh in nodeCh.PropChangesN.Safe())
                                {
                                    switch (propCh.ChangeType)
                                    {
                                        case ChangeType.ValidationError:
                                            logMessages.Add(new MergeLogMessage(LogMessageType.Error, nodeCh.NodeSrc.Key, $"Validation error for property { propCh.PropertyName}: { propCh.OldValue} => { propCh.NewValue}. { propCh.Comment}"));
                                            //Debug.WriteLine($"Validation error for property {propChange.PropertyName}: {propChange.OldValue} => {propChange.NewValue}. {propChange.Comment}");
                                            break;

                                        case ChangeType.ValidationWarning:
                                            logMessages.Add(new MergeLogMessage(LogMessageType.Warning, nodeCh.NodeSrc.Key, $"Validation warning for property { propCh.PropertyName}: { propCh.OldValue} => { propCh.NewValue}. { propCh.Comment}"));
                                            //Debug.WriteLine($"Validation warning for property {propCh.PropertyName}: {propCh.OldValue} => {propCh.NewValue}. {propCh.Comment}");
                                            break;

                                        //case ChangeType.Push:
                                        //case ChangeType.Pop:
                                        default:
                                            throw new NbExceptionEnum<ChangeType>(propCh.ChangeType);
                                    }
                                }
                                break;

                            default:
                                throw new NbExceptionEnum<ChangeType>(nodeCh.ChangeType);
                        }
                        break;

                    default:
                        throw new NbExceptionInfo($"Unsupported change type: '{ch.GetType().Name}'");
                }
            }

            var file = CreateHtml(logMessages);
            Process.Start(@"C:\Program Files\Mozilla Firefox\firefox.exe", file);
        }

        private string CreateHtml(List<MergeLogMessage> logMessages)
        {
            string filename = $@"C:\AutoDelete\res_{DateTime.Now.ToLongTimeString().Replace(":", "_")}.html";
            using StreamWriter wrtr = new StreamWriter(filename);
            wrtr.WriteLine("<!doctype html>");
            var myT = NbTag.Create(wrtr).TT("html", t => t
                .TT("head", t1 => t1
                     ["title", "Market Data comparison report"]
                     .TA("meta", a => a["charset"] = "utf-8")
                     .TV("style", File.ReadAllText(@"Data\ms.css"), encode: false)
                    )
                .TT("body", t => CreateList(t, logMessages))
                );
            return filename;
        }

        private void CreateList(INbTag tag, List<MergeLogMessage> logMessages)
        {
            var cols = new string[] { "", "Rate", "Message" };

            tag.TT("table", t =>
            {
                t.TT("tr", tr =>
                {
                    foreach (string colName in cols)
                        tr.TAV("th", a => a["style"] = "font-weight: bold", colName);
                });

                foreach (var mess in logMessages)
                {
                    t.TT("tr", tr =>
                    {
                        tr.TA("td", c1 => c1["class"] = mess.IconName);
                        tr.TV("td", mess.ParamName);
                        tr.TV("td", mess.Message);
                    });
                }
            });
        }
    }
}

