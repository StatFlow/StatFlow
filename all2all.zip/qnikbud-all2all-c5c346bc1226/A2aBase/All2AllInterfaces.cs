﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

using A2aCommands.Xml;
using A2aTypes.Xml;
using A2aForms.Xml;
using NbTools.SqlGen.Xml;

namespace All2All
{
    public enum UpdateType { Add, Update, Remove }
    //public enum DisplayStyles { String, Number, TimeMinSec, FileSize }

    public class NullUI : IUserInterface
    {
        public void AddAllFields(UpdateType updType, string[] columns, int requestId) => throw new NotImplementedException();
        public void UpdateNode(UpdateType updType, A2aNodeTree node, int requestId) { }
        public void AddWebPage(string html, int requestId) => throw new NotImplementedException();
        public Task<bool> EditForm(A2aFormParameters formParams) => throw new NotImplementedException();
        public void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId) => throw new NotImplementedException();
        public void SetStatus(string message) => throw new NotImplementedException();

        public Task<string> ShowDialog(string message) => throw new NotImplementedException();
        public Task<A2aDialogResult> ShowDialog(string message, string caption, A2aMessageBoxButtons btns, A2aMessageBoxIcon info) => throw new NotImplementedException();
        public Task<A2aForm> ShowDynamicForm(A2aForm form) => throw new NotImplementedException();
    }

    public enum NodeFields { NodeId, NodeType, NodeIcon, NodeName, Deleted, ParentDirId } //Predefined fields

    public interface IUserInterface //All fields for displaying in the data grid
    {
        /// <summary>
        /// Asks UI to add the top-level description (no detail) of a node, usually on the tree. 
        /// </summary>
        /// <param name="updType">Type of update: Add, Update, Remove</param>
        /// <param name="nodeId">Unique id of the node as a string</param>
        /// <param name="nodeId">Node type as a string</param>
        /// <param name="parentId">Id of the parent node is should be attached to in the hierarchy</param>
        /// <param name="Label">The short description of the node</param>
        /// <param name="hasChildren">yes if children are expected or known to exist</param>
        /// <param name="requestId">Unique RequestId, which will allow the UI to identify the data coming back</param>
        void UpdateNode(UpdateType updType, A2aNodeTree node, int requestId);

        /// <summary>
        /// Set Columns is a long-term solution and is preferred to Types set to List view at construction for the following reasons:
        /// * It might not be possible to know all columns for pivot-type queries, where columns will be created based on data
        /// * Some models such as All-to-all XMl might have user-defined columns that will not be known  in the model
        /// </summary>
        /// <param name="columns">The collection can be null, then the Type provided for the ListView in A2aTypes will be used</param>
        /// <param name="requestId"></param>
        //void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columnsN, int requestId);

        void AddAllFields(UpdateType updType, string[] columns, int requestId);  //NodeId, NodeType, NodeName & NodeIcon should be passed in columns

        void AddWebPage(string html, int requestId);

        void SetStatus(string message);
        Task<string> ShowDialog(string message);

        public Task<A2aDialogResult> ShowDialog(string message, string caption, A2aMessageBoxButtons btns, A2aMessageBoxIcon info);

        public Task<A2aForm> ShowDynamicForm(A2aForm form);

        //TODO: must return the properties separately, because this interface will work across the network or other languages
        Task<bool> EditForm(A2aFormParameters formParams); //returns - save (true) of cancel (false)
    }

    public abstract class NullDataProvider : IDataProvider
    {
        public virtual string ModelName => throw new NotImplementedException();

        public virtual A2aT GetTypes() => throw new NotImplementedException();
        public virtual Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> typesN, CancellationToken canToken, int requestId) => throw new NotImplementedException();
        public virtual Task<List<string>> GetList(NbSqlXml request, int requestId, CancellationToken canToken) => throw new NotImplementedException();
        public virtual Task<string> GetWebPage(NbSqlXml request, int requestId, CancellationToken canToken) => throw new NotImplementedException();

        public void StopReceivingUpdates(byte requestGroup) => throw new NotImplementedException();

        public virtual IEnumerable<A2aCommand> GetCommandsDouble(A2aNode src, A2aNode dst) => throw new NotImplementedException();
        public virtual IEnumerable<A2aCommand> GetCommandsMultiple(A2aNode src, IEnumerable<A2aNode> nodes) => throw new NotImplementedException();
        public virtual IEnumerable<A2aCommand> GetCommandsSingle(A2aNode src) => throw new NotImplementedException();
        public virtual IEnumerable<A2aCommand> GetDragCommands(A2aNode src, A2aNode dst, string[] formats) => throw new NotImplementedException();

        public virtual Task ExecuteCommand(string cmdName, A2aNode src, A2aNode dst, object addObject) => throw new NotImplementedException();
        
        public abstract void Dispose();
    }


    public interface IDataProvider : IDisposable
    {
        string ModelName { get; }

        A2aT GetTypes();

        /// <summary>
        /// Asks data layer to provide data for the tree view. Expected callbacks: AddSimple()
        /// </summary>
        /// <param name="parentIdN">Id of the node to get children for, if null - request for the parent node. There can only be a single parent</param>
        /// <param name="typesN"></param>
        /// <param name="canToken"></param>
        /// <param name="requestId"></param>
        /// <returns>The nodes that can be returned straigh away</returns>
        Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> typesN, CancellationToken canToken, int requestId);

        /// <summary>
        /// Get the full list of fields for the requested nodes based on NbSqlXml object sent in
        /// </summary>
        /// <param name="request"></param>
        /// <param name="previousRequestId"></param>
        /// <param name="requestId"></param>
        /// <param name="canToken"></param>
        /// <returns></returns>
        Task<List<string>> GetList(NbSqlXml request, int requestId, CancellationToken canToken);

        Task<string> GetWebPage(NbSqlXml request, int requestId, CancellationToken canToken);

        /// <summary>
        /// Commands for a single selected element
        /// </summary>
        /// <param name="nodeId"></param>
        /// <param name="nodeType"></param>
        /// <returns></returns>
        IEnumerable<A2aCommand> GetCommandsSingle(A2aNode node);

        /// <summary>
        /// Commands for a pair of elements
        /// </summary>
        /// <param name="srcNodeId">Id of the other (first selected) element </param>
        /// <param name="scrNodeType"></param>
        /// <param name="srcNodeName"></param>
        /// <param name="dstNodeId">Id of the last selected (focused) element in the pair</param>
        /// <returns></returns>
        IEnumerable<A2aCommand> GetCommandsDouble(A2aNode src, A2aNode dst);

        /// <summary>
        /// Gets collection of commands that can be performed when one node is dropped onto another
        /// </summary>
        /// <param name="srcNodeId"></param>
        /// <param name="scrNodeType"></param>
        /// <param name="srcNodeName"></param>
        /// <param name="dstNodeId"></param>
        /// <returns></returns>
        IEnumerable<A2aCommand> GetDragCommands(A2aNode src, A2aNode dst, string[] formats); //TODO: Think if double is the same as drag

        /// <summary>
        /// Commands for a set of 
        /// </summary>
        /// <param name="selNodeId"></param>
        /// <param name="selNodeType"></param>
        /// <param name="selNodeName"></param>
        /// <param name="nodeId"></param>
        /// <returns></returns>
        IEnumerable<A2aCommand> GetCommandsMultiple(A2aNode src, IEnumerable<A2aNode> nodes);

        /// <summary>
        /// The model can't give a command object to the UI to execute because this protocol will potentially work over the net
        /// </summary>
        /// <param name="cmdName"></param>
        /// <param name="src"></param>
        /// <param name="dst"></param>
        /// <param name="addObject">Additional object, such as FileDrop list of Mozilla Link</param>
        /// <returns></returns>
        Task ExecuteCommand(string cmdName, A2aNode src, A2aNode dst, object addObject = null);

        /// <summary>
        /// The highest byte of the request will be a request group. Receiving another request in the same group will mean cancelling previous request from this group.
        /// If the client wants to cancel request explicitly they can do it with this method.
        /// </summary>
        /// <param name="requestGroup"></param>
        void StopReceivingUpdates(byte requestGroup);
    }

    public class FormDesc
    {
        public List<A2aFormProperty> Properties;
    }

    [DebuggerDisplay("{FormTitle}({Properties.Count})")]
    public class A2aFormParameters
    {
        public string FormTitle;
        public List<A2aFormProperty> Properties;
        //TODO: Buttons
    }


    /// <summary>
    /// Descriptor of a field used in the Editor Window. Includes the Value, Type, Label and Tooltip
    /// </summary>
    [DebuggerDisplay("{Id}({Type}): {Value}")]
    public class A2aFormProperty
    {
        //
        public string Id;
        public string Type;
        public string Value;
        public string Label;
        public string Tooltip;

        public Func<string, string> ValidationMessage;
        public bool IsReadonly = false;
    }

    /// <summary>
    /// Specifies identifiers to indicate the return value of a dialog box.
    /// </summary>
    public enum A2aDialogResult
    {
        //
        // Summary:
        //     Nothing is returned from the dialog box. This means that the modal dialog continues
        //     running.
        None = 0,
        //
        // Summary:
        //     The dialog box return value is OK (usually sent from a button labeled OK).
        OK = 1,
        //
        // Summary:
        //     The dialog box return value is Cancel (usually sent from a button labeled Cancel).
        Cancel = 2,
        //
        // Summary:
        //     The dialog box return value is Abort (usually sent from a button labeled Abort).
        Abort = 3,
        //
        // Summary:
        //     The dialog box return value is Retry (usually sent from a button labeled Retry).
        Retry = 4,
        //
        // Summary:
        //     The dialog box return value is Ignore (usually sent from a button labeled Ignore).
        Ignore = 5,
        //
        // Summary:
        //     The dialog box return value is Yes (usually sent from a button labeled Yes).
        Yes = 6,
        //
        // Summary:
        //     The dialog box return value is No (usually sent from a button labeled No).
        No = 7
    }

    /// <summary>
    /// Specifies constants defining which buttons to display on a System.Windows.Forms.MessageBox.
    /// </summary>
    public enum A2aMessageBoxButtons
    {
        //
        // Summary:
        //     The message box contains an OK button.
        OK = 0,
        //
        // Summary:
        //     The message box contains OK and Cancel buttons.
        OKCancel = 1,
        //
        // Summary:
        //     The message box contains Abort, Retry, and Ignore buttons.
        AbortRetryIgnore = 2,
        //
        // Summary:
        //     The message box contains Yes, No, and Cancel buttons.
        YesNoCancel = 3,
        //
        // Summary:
        //     The message box contains Yes and No buttons.
        YesNo = 4,
        //
        // Summary:
        //     The message box contains Retry and Cancel buttons.
        RetryCancel = 5
    }

    /// <summary>
    /// Specifies constants defining which information to display.
    /// </summary>
    public enum A2aMessageBoxIcon
    {
        //
        // Summary:
        //     The message box contain no symbols.
        None = 0,
        //
        // Summary:
        //     The message box contains a symbol consisting of a white X in a circle with a
        //     red background.
        Hand = 16,
        //
        // Summary:
        //     The message box contains a symbol consisting of white X in a circle with a red
        //     background.
        Stop = 16,
        //
        // Summary:
        //     The message box contains a symbol consisting of white X in a circle with a red
        //     background.
        Error = 16,
        //
        // Summary:
        //     The message box contains a symbol consisting of a question mark in a circle.
        //     The question-mark message icon is no longer recommended because it does not clearly
        //     represent a specific type of message and because the phrasing of a message as
        //     a question could apply to any message type. In addition, users can confuse the
        //     message symbol question mark with Help information. Therefore, do not use this
        //     question mark message symbol in your message boxes. The system continues to support
        //     its inclusion only for backward compatibility.
        Question = 32,
        //
        // Summary:
        //     The message box contains a symbol consisting of an exclamation point in a triangle
        //     with a yellow background.
        Exclamation = 48,
        //
        // Summary:
        //     The message box contains a symbol consisting of an exclamation point in a triangle
        //     with a yellow background.
        Warning = 48,
        //
        // Summary:
        //     The message box contains a symbol consisting of a lowercase letter i in a circle.
        Asterisk = 64,
        //
        // Summary:
        //     The message box contains a symbol consisting of a lowercase letter i in a circle.
        Information = 64
    }
}
