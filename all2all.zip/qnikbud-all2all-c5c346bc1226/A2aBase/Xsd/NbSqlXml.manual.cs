using A2aBase;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace NbTools.SqlGen.Xml
{
    public partial class NbSqlXml
    {
        [XmlIgnore]
        public bool IsResolved { get; private set; }

        public static NbSqlXml LoadFromString(string xml)
        {
            NbSqlXml mus;
            try
            {
                using StringReader rdr = new StringReader(xml);
                mus = ((NbSqlXml)Ser.Deserialize(rdr)) ?? throw new Exception("Deserialization failed");
                mus.Resolve();
                return mus;
            }
            catch (Exception ex) { throw new Exception($"Error parsing NbSqlXml from string: '{xml}' xml file", ex); }
        }

        public void Resolve()
        {
            table.ForEachSafe(t => t.Resolve());
            filter.ForEachSafe(t => t.Resolve(table));
            IsResolved = true;
        }

        public override string ToString()
        {
            string tblList = String.Join(", ", table.Select(t => $"{t.name} {t.alias}"));
            string fltList = String.Join(", ", filter.Select(t => filter.ToString()));
            return $"tables:{tblList} filters:{fltList}";
        }

        public string ToXmlString()
        {
            using StringWriter wrtr = new StringWriter();
            Ser.Serialize(wrtr, this);
            return wrtr.ToString();
        }
    }

    //public partial class NbSqlJoin { }

    public partial class NbSqlTable
    {
        internal void Resolve()
        {
            field.ForEachSafe(t => t.Resolve(this));
        }

        public override string ToString()
        {
            var flds = String.Join(",", field.Safe().Select(fld => fld.ToString()));
            return $"{name} ({flds})";
        }
    }

    public class NbSqlFields : KeyedCollection<string, NbSqlField>
    {
        protected override string GetKeyForItem(NbSqlField item) => item.name;
    }

    public partial class NbSqlField
    {
        public NbSqlField(string name) : this()
        {
            this.name = name;
        }

        [XmlIgnore]
        private NbSqlTable Parent;

        internal void Resolve(NbSqlTable tbl)
        {
            Parent = tbl;
        }

        public string OrderBySql => $"{Parent.alias}.{name} {(order_desc ? " desc" : "")}";

        public override string ToString() => $"{name}";
    }

    public partial class FilterBase
    {
        [XmlIgnore]
        public NbSqlTable TableResolved;

        public FilterBase Clone(string srcTable, string srcField)
        {
            var ret = (FilterBase)MemberwiseClone();
            ret.table = srcTable;
            ret.field = srcField;
            return ret;
        }

        internal void Resolve(NbSqlTable[] tables)
        {
            if (!String.IsNullOrEmpty(table)) //it is allowed for table to be null when the object is used by the treeview to provide filters
                TableResolved = tables.SingleVerbose(t => t.name.EqIC(table), () => $"Filter refers to the table '{table}' which was not found", i => $"Filter refers to the table '{table}'. {i} tables with this name was found");
            //throw new NbExceptionInfo($"Table parameter was not set for the Filter Tag for field {field}");
        }
    }

    public partial class Subtree
    {
        public override string ToString() => $"Display nodes {(exclude ? "not" : "")} in the current node {(root_node_only ? "only" : "and it's subtree")}. Root Node #{root_node_id} of type '{root_node_type}'. Table containing tree: '{tree_table}'";
    }
}

/*public partial class FltContain { }
public partial class FltEqual { }
public partial class NbSqlXml { }*/
