﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2aForms.Xml
{
    public partial class A2aForm
    {
        public A2aForm() { }
        public A2aForm(params A2aFormFieldBase[] fields) => field = fields;

        public void SetButtons(params A2aFormButton[] buttons) => this.buttons = buttons;

        public void Resolve() { }
    }
}
