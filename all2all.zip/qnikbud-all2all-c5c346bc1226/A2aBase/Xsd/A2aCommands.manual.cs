﻿using System;

namespace A2aCommands.Xml
{
    public partial class A2aCommand
    {
        public void Resolve() { } //No need to resolve anything

        public override string ToString() => $"#{id} '{label}' {src}->{dst}";

        public static ClipboardData ParseClipboardData(string str)
        {
            if (!Enum.TryParse(str, out ClipboardData clipboardData))
                return ClipboardData.None;
            //throw new NbExceptionEnum<ClipboardData>(str);
            return clipboardData;
        }

    }

    public partial class A2aNode
    {
        public A2aNode() { } //For Xml serialization

        public A2aNode(string id, string type, string name)
        {
            this.id = id;
            this.type = type;
            this.name = name;
        }

        public override string ToString() => $"#{id} <{type}> '{name}'";
    }
}
