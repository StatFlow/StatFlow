﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace A2aBase
{
    internal static class Ext
    {
        public static bool EqIC(this string source, string other) => String.Equals(source, other, StringComparison.OrdinalIgnoreCase);

        public static TSource SingleVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicateN, Func<string> noMatchError, Func<long, string> multipleError)
        {
            TSource result = default;
            TSource dupe = default;
            long count = 0;
            foreach (TSource element in source ?? throw new ArgumentException(null, nameof(source)))
            {
                if (predicateN?.Invoke(element) ?? true) //If predicate is not specified - apply to all
                {
                    result = element;
                    if (count == 0)
                        dupe = element;
                    checked { count++; }
                }
            }
            return count switch
            {
                0 => throw new Exception(noMatchError() ?? "Element in the sequence was not found"),
                1 => result,
                _ => throw new Exception(multipleError(count) ?? $"There are more than one element in the sequence: '{dupe}', '{result}'"),
            };
        }

        [DebuggerStepThrough]
        public static void ForEachSafe<T>(this IEnumerable<T> aCollection, Action<T> aAction)
        {
            if (aCollection == null)
                return;
            foreach (T item in aCollection)
                aAction(item);
        }

        public static IEnumerable<T> Safe<T>(this IEnumerable<T> enumer) => enumer ?? Enumerable.Empty<T>();
        public static IEnumerable<T> Safe<T>(this Lazy<List<T>> enumer) => (enumer != null && enumer.IsValueCreated) ? enumer.Value : Enumerable.Empty<T>();
        public static IEnumerable<T> SafeOfType<T>(this IList enumer) => (enumer == null) ? Enumerable.Empty<T>() : enumer.OfType<T>();

        public static NbDictionary<TKey, TValue> ToNbDictionary<TObj, TKey, TValue>(this IEnumerable<TObj> sequence, Func<TObj, TKey> keyGetter, Func<TObj, TValue> valueGetter,
            IEqualityComparer<TKey> comparer = null, int capacity = 0, [CallerMemberName] string description = "", Func<TKey, TValue> creator = null, [CallerMemberName] string caller = "")
        {
            if (sequence == null) throw new ArgumentNullException(nameof(sequence), caller);
            if (keyGetter == null) throw new ArgumentNullException(nameof(keyGetter), caller);
            if (valueGetter == null) throw new ArgumentNullException(nameof(valueGetter), caller);

            NbDictionary<TKey, TValue> dict = new NbDictionary<TKey, TValue>(capacity, comparer, description, creator);
            foreach (var obj in sequence)
                dict.Add(keyGetter(obj), valueGetter(obj));
            return dict;
        }


        public class NbDictionary<TKey, TValue> : Dictionary<TKey, TValue>
        {
            private readonly string Description;
            private readonly Func<TKey, TValue> CreatorN;

            public NbDictionary(int capacity = 0, IEqualityComparer<TKey> comparer = null, [CallerMemberName] string description = "", Func<TKey, TValue> creator = null)
                : base(capacity, comparer)
            {
                Description = description;
                CreatorN = creator;
            }

            public new TValue this[TKey key]
            {
                get
                {
                    if (TryGetValue(key, out TValue res))
                        return res;
                    else if (CreatorN != null)
                    {
                        res = CreatorN(key);
                        Add(key, res);
                        return res;
                    }
                    else
                    {
                        TKey key1 = key;
                        throw new Exception($"Key '{key1}' is not found in the '{Description}' dictionary and creator function was not supplied");
                    }
                }
                set { base[key] = value; }
            }

            public new void Add(TKey key, TValue value)
            {
                if (base.ContainsKey(key))
                    throw new Exception($"Key '{key}' already exists in the '{Description}' dictionary");
                else
                    base.Add(key, value);
            }

            public TValue GetOrNull(TKey key)
            {
                TryGetValue(key, out TValue existing);
                return existing;
            }

            public void AddRange(IEnumerable<TValue> values, Func<TValue, TKey> keyGetter)
            {
                foreach (var v in values)
                    Add(keyGetter(v), v);
            }
        }
    }
}
