﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Serialization;

using A2aCommands.Xml;
using A2aTypes.Xml;
using All2All;
using Nb.Backup;
using NbCore;
using NbTools;
using NbTools.SqlGen.Xml;

namespace Nbb
{
    public sealed class NbbA2a : NullDataProvider
    {
        private const string TypeFolder = "folder";
        private const string TypeFile = "file";

        //private readonly IUserInterface Ui;
        private readonly string FileName;
        private readonly RootDirDesc Root;
        private readonly XmlSerializer Ser;
        private readonly A2aT A2aT;

        public NbbA2a(string fileName)
        {
            // Ui = ui;  IUserInterface ui
            FileName = fileName;
            Ser = new XmlSerializer(typeof(RootDirDesc));
            using (FileStream src = new FileStream(FileName, FileMode.Open, FileAccess.Read))
            {
                Root = Ser.Deserialize(src) as RootDirDesc;
                Root.Resolve(null);
            }
            A2aT = A2aT.LoadFile("NbbA2aTypes.xml");
        }

        public override string ModelName => "Nbb A2a";
        public override A2aT GetTypes() => A2aT;

        public override Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> typesN, CancellationToken canToken, int requestId)
        {
            if (parentIdN == null)
            {
                //Ui.AddSimple(UpdateType.Add, nodeId: "\\", TypeFolder, nodeIcon: "folder", parentId: null, label: FileName, hasChildren: Root.Dirs.Length > 0, requestId);
                var l = new List<A2aNodeTree> { new A2aNodeTree { id = "\\", type = TypeFolder, name = FileName, icon = TypeFolder, has_children = Root.Dirs.Length > 0, parentId = null } };
                return Task.FromResult(l);
            }
            else if (parentIdN == "\\") //Root.Name Could be null or empty
            {
                //foreach (var fld in Root.Dirs)
                //    Ui.AddSimple(UpdateType.Add, nodeId: fld.FullName, "folder", nodeIcon: "folder", parentId: parentIdN, label: fld.Name, hasChildren: Root.Dirs.Length > 0, requestId);

                var l = Root.Dirs.Select(fld => new A2aNodeTree { id = fld.FullName, type = TypeFolder, name = fld.Name, icon = TypeFolder, has_children = (fld.Dirs?.Length ?? 0) > 0, parentId = parentIdN }).ToList();
                return Task.FromResult(l);
            }
            else
            {
                var node = Root.NodeByPath(parentIdN.Split(Path.DirectorySeparatorChar).ToList());
                var dir = node as DirDesc ?? throw new NbExceptionInfo($"Node '{parentIdN}' is not a directory");
                if (dir.Dirs == null)
                    return Task.FromResult(new List<A2aNodeTree>()); //Empty

                var l = dir.Dirs.Select(fld => new A2aNodeTree { id = fld.FullName, type = TypeFolder, name = fld.Name, icon = TypeFolder, has_children = (fld.Dirs?.Length ?? 0) > 0, parentId = parentIdN }).ToList();
                return Task.FromResult(l);
            }
        }

        public override Task<List<string>> GetList(NbSqlXml request, int requestId, CancellationToken canToken)
        {
            //Also clears the list
            //Ui.SetColumns(A2aT.types.First(t => t.name == "file").column.Select(c => (c.name, c.display_type)), requestId); //TODO think about doing it on the client side (just specify the type)
            //Ui.SetColumns(columnsN: null, requestId); //Main type provided in the A2aTypes will be used for columns

            Subtree subTree = request.filter.OfType<Subtree>().FirstOrDefault();
            DirDesc currDir = Root;  //Use root if no filter
            if (subTree != null)
                currDir = Root[subTree.root_node_id] as DirDesc ?? throw new Exception($"{subTree.root_node_id} is not a dir");

            var table = request.table?[0] ?? throw new Exception("Tables were not provided in the request");

            var fieldNames = table.field.Safe().Where(f => !f.exclude).ToArray();

            List<string> list = new List<string> { String.Join(",", fieldNames.Select(f => f.name)) }; //Header

            StringBuilder bld = new StringBuilder();
            foreach (FileDesc file in currDir.Files.Safe())
            {
                //Ui.AddAllFields(UpdateType.Add, file.FullName, TypeFile, nodeIcon: "default", new[] { file.Name, file.Length.ToString() }, requestId);
                bool first = true;
                foreach (var fld in fieldNames)
                {
                    if (!first)
                        bld.Append(',');
                    else
                        first = false;

                    switch (fld.name)
                    {
                        case nameof(NodeFields.NodeId):
                            bld.Append(NbExt.ToCsvString(file.FullName));
                            break;

                        case nameof(NodeFields.NodeName):
                            bld.Append(NbExt.ToCsvString(file.Name));
                            break;

                        case nameof(NodeFields.NodeType):
                            bld.Append(TypeFile);
                            break;

                        case nameof(NodeFields.NodeIcon):
                            bld.Append("default");
                            break;

                        case "Size":
                            bld.Append(file.Length.ToString());
                            break;

                        default:
                            throw new Exception($"Unsupported field '{fld.name}'");
                    }
                }
                list.Add(bld.ToString());
                bld.Clear();
            }

            return Task.FromResult(list);
        }

        public override IEnumerable<A2aCommand> GetCommandsSingle(A2aNode node) { yield break; }

        public override void Dispose() { }
    }
}
