﻿using NbXsdV1.Xml;

namespace All2AllSchema
{
    class NbSqlXml
    {
        internal static Elem Root()
        {
            var Join = new TypeAttrOnly("NbSqlJoin",
                new Attr("field", XsType.String),
                new Attr("to_table", XsType.String),
                new Attr("to_field", XsType.String)
                );

            var Field = new TypeSequence("NbSqlField",
                new Attr("name", XsType.String),
                new Attr("alias", XsType.String),
                new Attr("display_style", XsType.String, Uses.Optional, null, doc: "Display style, such as FileSize = 14.6 Mb. Not used by the sql, but useful for the client UI"),
                new Attr("filter_eq", XsType.String, Uses.Optional, null, "The simplest possible filter, can be provided in-line"),
                new Attr("filter_like", XsType.String, Uses.Optional, null, "The simplest possible filter, can be provided in-line"),
                new Attr("order_ind", XsType.Int, Uses.Optional, "-1", "If the result should be ordered by several or one fields, such fields should have this attribute set according to the order of sorting"),
                new Attr("order_desc", XsType.Bool, Uses.Optional, "false"),
                new Attr("exclude", XsType.Bool, Uses.Optional, "false", "A field can be used for filtering or ordering, but excluded from the results with this attribute")
                );

            var Table = new TypeSequence("NbSqlTable",
                new Elem("join", Join, 0, 1),
                new Elem("field", Field, 1, Elem.Unbounded),
                new Attr("name", XsType.String),
                new Attr("alias", XsType.String)
                );

            var filterBase = new TypeAttrOnly("FilterBase",
                new Attr("field", XsType.String, Uses.Required, doc: "Field name to filter by"),
                new Attr("table", XsType.String, Uses.Required, doc: "The name of the fable with the field to filter by") 
                ); //base class

            //// Filters ////

            var FltEqual = new TypeDerived("FltEqual", filterBase,
                new Attr("val", XsType.String, Uses.Required)
                );

            var FltContain = new TypeDerived("FltContain", filterBase,
                new Attr("val", XsType.String, Uses.Optional),
                new Attr("regex", XsType.String, Uses.Optional)
                );

            var Subtree = new TypeDerived("Subtree", filterBase,
                new Attr("tree_table", XsType.String, Uses.Required, doc: "The table holding the tree, such as Directories or Tags"),
                new Attr("root_node_id", XsType.String, Uses.Required),
                new Attr("root_node_type", XsType.String, Uses.Required),
                new Attr("root_node_only", XsType.Bool, Uses.Optional, "false", doc: "Set root_node_only='true' if you want to filter on the nodes that are only in the provided root_node_id. No matching on the whole subtree"),
                new Attr("exclude", XsType.Bool, Uses.Optional, "false", doc: "Set exclude='true' if you want to filter on the nodes NOT in the provided subtree")
                );

            var NamedFilter = new TypeDerived("NamedFilter", filterBase,  //Filter which logic is only know on the servers side
                new Attr("name", XsType.String, Uses.Required),
                new Attr("value", XsType.String, Uses.Required)
                );

            var Filter = new TypeChoice("Filter", min: 1, max: -1,
                new Elem("equal", FltEqual, 0, 1),
                new Elem("contain", FltContain, 0, 1),
                new Elem("subtree", Subtree, 0, 1),
                new Elem("named_filter", NamedFilter, 0, 1)
                );

            ////// The root

            var Root = new TypeSequence("NbSqlXml",
                new Attr("top", XsType.Int, Uses.Optional, "100"),
                new Elem("sql", XsType.String, 0, 1),
                new Elem("table", Table, 1, Elem.Unbounded),
                new Elem("filter", Filter, 0, 1)
                );

            return new Elem("sql_xml", Root);
        }
    }
}
