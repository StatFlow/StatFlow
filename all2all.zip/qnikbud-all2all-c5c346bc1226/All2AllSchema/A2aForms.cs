﻿using NbTools;
using NbXsdV1.Xml;
using System.Collections.Generic;

namespace All2AllSchema
{
    class A2aForms
    {
        internal static Elem Root()
        {
            const string pref = "A2aForm";

            /*var DateTypes = new TypeEnum("DateTypes", XsType.String, new Dictionary<string, string> {
                { "String", "Single" },
                { "Int", "Doc for Number" },
            });*/

            var A2aFormFieldBase = new TypeAttrOnly(pref + "FieldBase"
                , new Attr("id", XsType.String, Uses.Required, doc: "Unique Field name")
                , new Attr("label", XsType.String, Uses.Required, doc: "Label to show on the form")
                , new Attr("required", XsType.Bool, Uses.Optional, deflt: "true", doc: "Whether the field is mandatory. True by default")
                ); //base class

            #region Field Types

            var FieldString = new TypeDerived(pref + "FieldString", A2aFormFieldBase
                , new Attr("val", XsType.String, Uses.Optional, doc: "Value for the field")
                , new Attr("max_length", XsType.Int, Uses.Optional, "250")
                , new Attr("regex", XsType.String, Uses.Optional, doc: "Regex for validation")
                );

            var FieldNumber = new TypeDerived(pref + "FieldNumber", A2aFormFieldBase
                , new Attr("val", XsType.Int, Uses.Optional, "0", doc: "Value for the field")
                , new Attr("min", XsType.Int, Uses.Optional, "0")
                , new Attr("max", XsType.Int, Uses.Optional, int.MaxValue.ToString())
                );

            var FieldBoolean = new TypeDerived(pref + "FieldBoolean", A2aFormFieldBase
                , new Attr("val", XsType.Bool, Uses.Optional, "false", doc: "Value for the field")
                );

            var FieldEnum = new TypeDerived(pref + "FieldEnum", A2aFormFieldBase
                , new Elem("list", XsType.String, 1, Elem.Unbounded)
                , new Attr("val", XsType.String, Uses.Optional, doc: "Value for the field")
                , new Attr("user_values", XsType.Bool, Uses.Optional, deflt: "false", doc: "Allow user enter his own values")
                );

            #endregion Field Types

            var A2aFormField = new TypeChoice(pref + "Field", min: 1, max: Elem.Unbounded
                , new Elem("string", FieldString, 0, 1)
                , new Elem("number", FieldNumber, 0, 1)
                , new Elem("boolean", FieldBoolean, 0, 1)
                , new Elem("enum", FieldEnum, 0, 1)
                //, new Attr("deleted", XsType.Bool, Uses.Optional, deflt: "false")
                );

            var ButtonTypes = new TypeEnum(pref + "ButtonTypes", XsType.String, new EnumItem[] {
                new EnumItem { key = "None", value = "No special functions"}
                ,new EnumItem { key = "Enter", value = "Accept button"}
                ,new EnumItem { key = "Esc", value = "Cancel Button"}}
               );

            var A2aFormButton = new TypeAttrOnly(pref + "Button"
                , new Attr("id", XsType.String, Uses.Required)
                , new Attr("label", XsType.String, Uses.Required)
                , new Attr("tooltip", XsType.String, Uses.Optional)
                , new Attr("disabled", XsType.String, Uses.Optional, deflt: "false")
                , new Attr("type", ButtonTypes, Uses.Optional, "None", doc: "Accept or Cancel buttons that work automatically on Enter or Esc")
                , new Attr("clicked", XsType.Bool, Uses.Optional, deflt: "false", doc: "Returned by the Dynamic Form back to caller")
                );

            var Root = new TypeSequence(pref
                , new Elem("field", A2aFormField, 0, 1)
                , new ListSingle("button", A2aFormButton)
                );

            return new Elem("a2a_form", Root);
        }
    }
}