﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

using NbTools;
using NbTools.SqlGen.Xml;
using A2aCommands.Xml;
using A2aTypes.Xml;

namespace All2All
{
    internal record TreeNodeState(string NodeType)
    {
        public bool ChildrenInitialised { get; set; } = false;
    }

    internal interface IMainForm
    {
        /// <summary>
        /// Repeat the query for the details without changing the Current Selection (F5)
        /// </summary>
        void RefreshSelection();

        IDataProvider Model { get; }
        UserProfileManager UserProfile { get; }
        void ShowDragDropMenu(IEnumerable<A2aCommand> commands, A2aNode src, A2aNode dst, IDataObject dataObject);

        /// <summary>
        /// If there was an action on the component inside the screen (such as DoubleClick). The screen notifies the Main Form about it
        /// The main form may launch an action for the component if there is Hot Key for it
        /// </summary>
        /// <param name="key">LButton - for mouse double click or any other key press</param>
        /// <param name="itemId">The Id of the node (item) as a string</param>
        void NodeActionDoubleClick(Keys key, A2aNode node);

        void SetStatus1(string message);

        int GetNextRequestId();
    }

    public class FilterInfo
    {
        public FilterInfo(string componentName, DateTime timeSet, List<FilterBase> filters)
        {
            ComponentName = componentName;
            TimeSet = timeSet;
            Filters = filters;
        }

        public readonly string ComponentName;
        public readonly DateTime TimeSet;
        public readonly List<FilterBase> Filters;
    }

    public delegate void SelectionChangedHandler(ISelectionProvider sender, A2aNode selection, A2aNode parent);
    public interface ISelectionProvider
    {
        string Name { get; }
        event SelectionChangedHandler SelectionChanged;
    }

    static class UIHelpsers
    {
        const int FileSizePrecision = 3;

        public static string ConvertStringByDisplayStyle(this string str, DisplayStyles style)
        {
            return style switch
            {
                DisplayStyles.FileSize => Int64.TryParse(str, out long bytes) ? NbExt.UserFriendlyFileSize(bytes, FileSizePrecision) : str,
                DisplayStyles.Number => str,
                DisplayStyles.TimeMinSec => (Int32.TryParse(str, out int totSec) ? $"{totSec / 60}:{totSec % 60}" : str),
                DisplayStyles.String => str,
                _ => throw new NbExceptionEnum<DisplayStyles>(style),
            };
        }
    }
}
