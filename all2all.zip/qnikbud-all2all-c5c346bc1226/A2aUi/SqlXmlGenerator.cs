﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using WeifenLuo.WinFormsUI.Docking;
using NbTools;
using NbTools.SqlGen.Xml;
using A2aTypes.Xml;
//using log4net;
using A2aCommands.Xml;
using Timer = System.Windows.Forms.Timer;

namespace All2All.Screens
{
    internal class SqlXmlGenerator
    {
        //Keeps selection providers and the filtering criteria they have send last time. The resulting criteria must merge all the list into single data_requestFilter
        internal readonly Dictionary<ISelectionProvider, (A2aNode? selection, A2aNode? parent, DateTime timeStamp)> SelectionProviders;

        private readonly A2aType MainType;
        private readonly string Name;
        private readonly string RequestName;
        private readonly Func<NbSqlXml, Task> RequestAction;
        private readonly Timer ReloadListTimer;
        private const int SearchTimeout = 500; //Timeout when user enters symbols into the search text box

        private string? sortColumn = "Name";
        private string? likeFilter = null;
        private readonly bool SortDesc = false;

        internal SqlXmlGenerator(string name, A2aType mainType, string reqName, Func<NbSqlXml, Task> reloadAction)
        {
            MainType = mainType;
            Name = name;
            RequestName = reqName;
            RequestAction = reloadAction ?? throw new NbArgumentException(nameof(reloadAction), "Must be specified in " + nameof(SqlXmlGenerator));
            SelectionProviders = new();
            ReloadListTimer = new();
            ReloadListTimer.Tick += ReloadListView;
            ReloadListTimer.Interval = SearchTimeout;
        }

        internal string? LikeFilter { get => likeFilter; set => likeFilter = ResetTimer(value); }
        internal string? SortColumn { get => sortColumn; set => sortColumn = ResetTimer(value); }

        private T ResetTimer<T>(T val)
        {
            ReloadListTimer.Stop();
            ReloadListTimer.Start();
            return val;
        }

        private async void ReloadListView(object? _, EventArgs __)
        {
            //Log.Info($"List -  {nameof(ReloadListView)}");

            ReloadListTimer.Stop();
            string? firstFilt = null;
            if (!String.IsNullOrEmpty(LikeFilter))
            {
                var filt = LikeFilter.Split(' ').Where(s => !String.IsNullOrWhiteSpace(s)).ToArray();
                firstFilt = filt.Length > 0 ? filt[0] : null;
            }
            NbSqlXml req = GenerateRequestSql(firstFilt);

            //Log.Info($"Model.GetList: {nameof(ReloadListView)}, request:\r\n{req.ToXmlString()}");
            req.Save(@"C:\AutoDelete\A2A_Request.xml");

            await RequestAction(req);
            //Main.RefreshSelection(); //F5 Do we really want to refresh selection - this is about another call to get the list
        }

        private NbSqlXml GenerateRequestSql(string? likeFilter) //TODO: temp like filter
        {
            NbSqlFields fields = new()
            {
                new NbSqlField() { name = nameof(NodeFields.NodeId) },
                new NbSqlField() { name = nameof(NodeFields.NodeType) },
                new NbSqlField() { name = nameof(NodeFields.NodeName) },
                new NbSqlField() { name = nameof(NodeFields.Deleted), exclude = true, filter_eq = "0" },
                new NbSqlField() { name = nameof(NodeFields.ParentDirId), exclude = true } //Can be used in filters
            };

            foreach (Column col in MainType.column)
            {
                bool add = false;
                if (fields.TryGetValue(n => n.name.EqIC(col.name), out NbSqlField fld)) //If this field was already added as excluded above
                    fld.exclude = false; //Make it included
                else //Create new field
                {
                    fld = new NbSqlField() { name = col.name };
                    add = true;
                }

                fld.display_style = col.display_type.ToString(); //Set display style because it will be shown

                if (col.name == SortColumn)
                {
                    fld.order_ind = 1;
                    fld.order_desc = SortDesc;
                }

                if (!String.IsNullOrEmpty(likeFilter) && col.name.Equals(nameof(NodeFields.NodeName), StringComparison.OrdinalIgnoreCase))
                    fld.filter_like = likeFilter;

                if (add)
                    fields.Add(fld);
            }

            List<FilterBase> filter = new List<FilterBase>();
            foreach (var pair in SelectionProviders.Where(v => v.Value.selection != null).OrderByDescending(v => v.Value.timeStamp))
            {
                FilterBase fltBase = new Subtree
                {
                    exclude = false,
                    tree_table = "NoTreeTableProvided",
                    table = "TableNotProvided",
                    root_node_id = pair.Value.selection.id, //The Id of the node which is a root of the tree
                    root_node_type = pair.Value.selection.type,  //The type of the node  which is a root of the tree
                    root_node_only = true
                };
                filter.Add(fltBase);
                break; //Use only one most recent filter
            }


            /*if (TreeSelection != null && FilterMode != FilterModes.Inactive) //If Root is selected treat it as no selection
            {
                var tns = TreeSelection.Tag as TreeNodeState ?? throw new Exception("Tree node doesn't have a Tag object");

                // field and table are not set, they will be set at enrichment stage, where the real table names are known
                FilterBase fltBase = new Subtree
                {
                    exclude = false,
                    tree_table = TableHoldingATree, //The name of the table holding a tree, such as Dirs or Tags
                    root_node_id = TreeSelection.Name, //The Id of the node which is a root of the tree
                    root_node_type = tns.NodeType,  //The type of the node  which is a root of the tree
                    root_node_only = true
                };

                filter = new List<FilterBase> { fltBase };
            }*/


            /*FilterBase[] fltList;
            if (MostRecentFilterOnly)
            {
                var maxTime = FilterProviders.Values.Max(v => v?.TimeSet);
                fltList = FilterProviders.Values.Where(v => v != null && v.TimeSet == maxTime).SelectMany(v => v.Filters).ToArray();
            }
            else
                fltList = FilterProviders.Values.Where(v => v != null).SelectMany(p => p.Filters).ToArray();*/

            var req = new NbSqlXml
            {
                top = 1000,
                table = new NbSqlTable[] { new NbSqlTable { name = RequestName, field = fields.ToArray() } },
                filter = filter.ToArray()
            };

            //req.Resolve(); Leave requirement to resolve for now. so that fields can refer to tables that will replace the view
            return req;
        }


        #region Selection Receiver
        internal void ReceiveSelectionFrom(ISelectionProvider selProv)
        {
            NbExt.AssertNotNull(selProv, nameof(selProv));

            if (SelectionProviders.ContainsKey(selProv))
                throw new Exception($"Selection provider '{selProv}' already registered with '{Name}'");

            SelectionProviders.Add(selProv, (default(A2aNode), default(A2aNode), default(DateTime))); //No filter is set yet
            selProv.SelectionChanged += SelProv_SelectionChanged;
        }

        internal void StopReceivingSelectionFrom(ISelectionProvider selProv)
        {
            NbExt.AssertNotNull(selProv, nameof(selProv));
            if (!SelectionProviders.ContainsKey(selProv))
                throw new Exception($"Selection provider '{selProv}' was not registered with '{Name}', but there is a request to remove it");

            SelectionProviders.Remove(selProv);
            selProv.SelectionChanged -= SelProv_SelectionChanged;
        }

        private void SelProv_SelectionChanged(ISelectionProvider sender, A2aNode selection, A2aNode parent)
        {
            if (!SelectionProviders.ContainsKey(sender))
                throw new Exception($"Filter provider '{sender}' was not registered with the list view screen");

            SelectionProviders[sender] = (selection, parent, DateTime.UtcNow);
            ReloadListTimer.Stop();
            ReloadListTimer.Start();
        }
        #endregion Selection Receiver
    }
}
