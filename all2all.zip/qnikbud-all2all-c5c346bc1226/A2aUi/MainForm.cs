﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using Timer = System.Windows.Forms.Timer;
//using log4net;

using NbTools;
using A2aCommands.Xml;
using All2All.Model;
using A2aTypes.Xml;
//using All2AllXml.Blt;
//using FMan;
using System.IO;
using A2aForms.Xml;
using All2All.Screens;
using HpModel;
//using HpModel;

namespace All2All
{
    public partial class MainForm : Form, IUserInterface, IMainForm
    {
        private readonly string[] Args;
        enum A2aModes
        {
            Flavours, PCast, Disk, Blt,
            /// <summary>
            /// Xml images of a directory created with Nbb tool
            /// </summary>
            Nbb,
            Hp
        }

        //public static readonly ILog Log = LogManager.GetLogger(nameof(MainForm));

        //Request Id is stored in order to identify the entries coming with it in the Add method. Useful when Adding a root node must also cause
        //a request to add its children, but no further down the tree
        public const int RootRequest = 1;
        private int RequestCounter = 100;
        public int GetNextRequestId() => Interlocked.Increment(ref RequestCounter);

        private const int StatusMessageTimeout = 3000;
        private readonly Timer StatusTimer;

        private readonly Dictionary<Keys, A2aCommand> fCurrentHotKeys = new(10);
        private readonly Dictionary<Keys, A2aCommand> fTempHotKeys = new(10);

        private A2aT A2aT;

        private readonly ImageList ImgList;
        private readonly List<Tree> TreeScreeens = new(10);
        private readonly List<List> ListScreens = new(10);
        private readonly List<Web> WebScreens = new(10);
        //private Screens.Web WebScreen;

        #region IMainForm interface implementation

        public IDataProvider Model { get; private set; }
        public UserProfileManager UserProfile { get; private set; }
        public void SetStatus1(string message) => SetStatus(message);

        public Selection CurrentSelection
        {
            get { return fCurrentSelection; }
            set
            {
                fCurrentSelection = value;
                RefreshSelection();
            }
        }
        private Selection fCurrentSelection = null;

        public MainForm(string[] args)
        {
            Args = args;
            InitializeComponent();
            StatusTimer = new Timer();
            StatusTimer.Tick += StatusTimer_Tick;
            StatusTimer.Interval = StatusMessageTimeout;

            ImgList = new ImageList(this.components)
            {
                ColorDepth = ColorDepth.Depth32Bit,
                ImageSize = new Size(16, 16),
                TransparentColor = Color.Transparent,
            };
        }

        private const string LinksDataPath = @"C:\Repo\All2All\FlavoursModel\Data\Links\";

        private async void Form1_Load(object sender, EventArgs e)
        {
            try
            {

                //Log.Info("In " + nameof(Form1_Load));

#if NETCOREAPP3_0
            Model = new All2All.ModelAll2All(this);
#endif
                if (Args.Length == 0)
                    throw new Exception("All2All expects command line parameter for module");

                var mode = Args[0].ParseEnum<A2aModes>();
                switch (mode)
                {
                    case A2aModes.Flavours:
                        Model = new FlavoursModel(this);
                        ((FlavoursModel)Model).LoadFromXmlFile(@"C:\Repo\All2All\A2aFlavours\Data\ATMW\Model.xml", @"C:\Repo\All2All\A2aFlavours\Data\ATMW\Types.xml");
                        //((FlavoursModel)Model).LoadFromXmlFile(LinksDataPath + "LinkManager.a2a.xml", LinksDataPath + "Types.xml");
                        break;

                    /*case A2aModes.PCast:
                        Model = new ModelFMan(this); //PCast model
                        break;

                    case A2aModes.Disk:
                        Model = new Disk.ModelDisk(this);
                        break;

                    case A2aModes.Blt:
                        Model = new BltModel(this);
                        break;

                    case A2aModes.Nbb:
                        Model = new Nbb.NbbA2a(@"C:\Temp\videos.xml");
                        break;*/

                    case A2aModes.Hp:
                        Model = new HpAll2All();
                        break;

                    default: throw new NbExceptionEnum<A2aModes>(mode);
                }



                A2aT = Model.GetTypes(); //Contains the screens (treeviews and list views)
                UserProfile = new UserProfileManager(Model.ModelName + ".csv");

                if (Model == null)
                {
                    await ShowDialog("Model is not set");
                    return;
                }

                string iconDir = @"C:\Users\budan\.freemind\icons";
                PopulateImageListFromDir(ImgList, iconDir);

                foreach (TreeViewXml tr in A2aT.tree_views.Safe())
                {
                    var tScr = new Screens.Tree(this, tr, ImgList);
                    ReceiveSelectionFrom(tScr); //Main form to monitor selection
                    TreeScreeens.Add(tScr);
                }

                foreach (var lv in A2aT.list_views.Safe())
                {
                    var lScr = new Screens.List(this, lv, ImgList);
                    ReceiveSelectionFrom(lScr);
                    ListScreens.Add(lScr);
                }

                foreach (var wv in A2aT.web_views.Safe())
                {
                    var wScr = new Screens.Web(this, wv);
                    WebScreens.Add(wScr);
                }

                foreach (var ts in TreeScreeens)
                {
                    //ListScreens.ForEach(ls => ls.ReceiveFilterFrom(ts)); //All Lists will receive filter event from all trees
                    //WebScreens.ForEach(ls => ls.ReceiveFilterFrom(ts));

                    ListScreens.ForEach(ls => ls.SelectionReceiver.ReceiveSelectionFrom(ts)); //All Lists will receive filter event from all trees
                    WebScreens.ForEach(ls => ls.SelectionReceiver.ReceiveSelectionFrom(ts));
                    ShowScreen(ts, ts.Name);
                }

                foreach (var ls in ListScreens)
                {
                    ShowScreen(ls, ls.Name);
                }

                foreach (var ws in WebScreens)
                {
                    ShowScreen(ws, ws.Name);
                }


                using CancellationTokenSource canTokSrc = new();

                //Log.Info("Request root nodes for all trees: " + String.Join(", ", A2aT.tree_views.Select(tv => tv.name)));

                foreach (var ts in TreeScreeens)
                {
                    await ts.LoadRoot();
                }

                /*List<Task> rootLoaders = new List<Task>();
                foreach (TreeViewXml tvXml in A2aT.tree_views)
                {

                    List<A2aNodeTree> list = await Model?.GetChildren(null, null, tvXml.TypesResoved.Select(t => t.name).ToList(), canTokSrc.Token, GetNextRequestId());
                    rootLoaders.Add(tsk);
                }

                await Task.WhenAll(rootLoaders); Do parallelism later*/

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Close();
            }
        }

        private static void PopulateImageListFromDir(ImageList imgList, string iconDir)
        {
            var dir = new DirectoryInfo(iconDir);
            if (!dir.Exists)
                throw new Exception($"Icon directory '{iconDir}' doesn't' exist");
            foreach (var file in dir.GetFiles("*").Where(f => !f.Extension.EqIC(".svg")))
            {
                imgList.Images.Add(file.NameWithoutExtension(), Image.FromFile(file.FullName));
            }
        }

        private Image IconByName(string iconName) => ImgList.Images[iconName];

        private void ShowScreen(DockContent dockWnd, string label)
        {
            dockWnd.Text = label;
            if (dockPanel1.DocumentStyle == DocumentStyle.SystemMdi)
            {
                dockWnd.MdiParent = this;
                dockWnd.Show();
            }
            else
                dockWnd.Show(dockPanel1);
        }


        public void RefreshSelection()
        {
            //Log.Info("Selected: " + fCurrentSelection ?? "Nothing");
            SetStatus("Selected: " + fCurrentSelection ?? "Nothing");
            ShowCommandOnToolStrip();
        }

        public void ShowDragDropMenu(IEnumerable<A2aCommand> commands, A2aNode src, A2aNode dst, IDataObject dataObject)
        {
            mnDragDrop.Items.Clear();
            foreach (var cmd in commands)
            {
                var item = new ToolStripMenuItem { Name = cmd.id, Text = cmd.label, ToolTipText = cmd.tooltip, Tag = cmd };
                item.Click += (_, __) => ExecCommand(cmd, src, dst, dataObject);
                mnDragDrop.Items.Add(item);
            }
            mnDragDrop.Show(MousePosition);
        }

        private void ExecCommand(A2aCommand cmd, A2aNode src, A2aNode dst, IDataObject dataObject)
        {
            object? addData = cmd.data_requred switch
            {
                ClipboardData.FileDrop => dataObject.GetData(DataFormats.FileDrop),
                ClipboardData.Url => dataObject.GetData("UniformResourceLocatorW"),
                ClipboardData.MozillaUrl => dataObject.GetData("text/x-moz-url"),

                ClipboardData.None => null,
                _ => null,
            };
            Model.ExecuteCommand(cmd.id, src, dst, addData);
        }


        /// <summary>
        /// Action on the node comes from screens, such as doubleclick. It might not necessarily happen on the current selection, the screen provides the itemId.
        /// Therefore we have to check all commands for the hotkey. fCurrentHotKeys reflects the hotkeys of the current selection.
        /// </summary>
        /// <param name="key">The key press that caused the action. This key will be searched in the command's hotkeys</param>
        /// <param name="nodeId">The node Id to action on</param>
        public void NodeActionDoubleClick(Keys key, A2aNode node)
        {
            foreach (var cmd in Model.GetCommandsSingle(node).Where(cmd => !String.IsNullOrEmpty(cmd.hotkey)))
            {
                var cmdKey = ParseHotKey(cmd.hotkey);
                if (key == cmdKey && CurrentSelection != null)
                    Task.Run(() => Model.ExecuteCommand(cmd.id, src: CurrentSelection.CurrentNode, dst: CurrentSelection.ParentNode));
            }
        }

        private void MainForm_KeyDown(object _, KeyEventArgs e)
        {
            if (fCurrentHotKeys.TryGetValue(e.KeyCode, out var cmd))
            {
                if (CurrentSelection != null)
                    Task.Run(() => Model.ExecuteCommand(cmd.id, CurrentSelection.CurrentNode, CurrentSelection.ParentNode));
                else
                    SetStatus($"Command '{cmd.id}' is requested by hotkey, but there is no selection");
            }
        }
        #endregion IMainForm interface implementation

        public delegate void SetStatusDelegate(string message);
        public void SetStatus(string Message)
        {
            if (InvokeRequired)
            {
                Invoke(new SetStatusDelegate(SetStatus), Message);
                return;
            }

            sbText.Text = Message;
            StatusTimer.Start();
        }

        private void StatusTimer_Tick(object sender, EventArgs e)
        {
            sbText.Text = null;
            StatusTimer.Stop();
        }

        public delegate void InvokeDelegate(TaskCompletionSource<string> tsc, string message);
        public Task<string> ShowDialog(string message)
        {
            var tcs = new TaskCompletionSource<string>();
            BeginInvoke(new InvokeDelegate(ShowD), tcs, message);
            return tcs.Task;
        }

        private void ShowD(TaskCompletionSource<string> tcs, string message)
        {
            var btns = message.EndsWith("?") ? MessageBoxButtons.YesNoCancel : MessageBoxButtons.OK;
            DialogResult res = MessageBox.Show(this, message, "All 2 All", btns, MessageBoxIcon.Information);
            tcs.SetResult(res.ToString());
        }


        public delegate void InvokeDelegate2(TaskCompletionSource<A2aDialogResult> tsc, string message, string caption, MessageBoxButtons btns, MessageBoxIcon info);
        public Task<A2aDialogResult> ShowDialog(string message, string caption, A2aMessageBoxButtons btns, A2aMessageBoxIcon info)
        {
            var tcs = new TaskCompletionSource<A2aDialogResult>();
            BeginInvoke(new InvokeDelegate2(ShowD2), tcs, message, caption, btns, info); //Casting from A2aMessageBoxButtons to MessageBoxButtons happens here
            return tcs.Task;
        }

        private void ShowD2(TaskCompletionSource<A2aDialogResult> tcs, string message, string caption, MessageBoxButtons btns, MessageBoxIcon info)
        {
            var res = (A2aDialogResult)MessageBox.Show(this, message, caption, btns, info);
            tcs.SetResult(res);
        }



        public delegate void InvokeShowForm(TaskCompletionSource<A2aForm> tcs, A2aForm form);
        public Task<A2aForm> ShowDynamicForm(A2aForm form)
        {
            var tcs = new TaskCompletionSource<A2aForm>();
            BeginInvoke(new InvokeShowForm(DoShowForm), tcs, form);
            return tcs.Task;
        }

        private void DoShowForm(TaskCompletionSource<A2aForm> tcs, A2aForm form)
        {
            var df = new DynamicForm(form);
            df.ShowDialog();
            tcs.SetResult(df.ResultN);
        }

        private readonly HashSet<ISelectionProvider> SelectionProviders = new();

        public void ReceiveSelectionFrom(ISelectionProvider prov)
        {
            if (SelectionProviders.Contains(prov))
                return;
            SelectionProviders.Add(prov);
            prov.SelectionChanged += SelectionProvider_SelectionChanged;
        }

        private readonly List<A2aCommand> Commands = new();

        private void SelectionProvider_SelectionChanged(ISelectionProvider sender, A2aNode selection, A2aNode parent)
        {
            Commands.Clear(); //Do not reallocate list all the time
            if (selection != null)
                Commands.AddRange(Model.GetCommandsSingle(selection));
            CurrentSelection = new Selection(selection, parent, Commands);
        }

        private static Keys ParseHotKey(string hotKey) =>
            Enum.TryParse<Keys>(hotKey, out var res) ? res : throw new Exception($"Can't parse Hot Key out of '{hotKey}'");

        private async void ToolStripButton_Click(object sender, EventArgs e)
        {
            var btn = sender as ToolStripButton ?? throw new NbExceptionInfo($"Sender type '{sender.GetType().Name}' where {nameof(ToolStripButton)} was expected");
            var selection = btn.Tag as Selection ?? throw new NbExceptionBadType("sender.Tag", nameof(Selection), btn.Tag?.GetType().Name ?? "None");
            await Task.Run(() => Model.ExecuteCommand(btn.Name, selection.CurrentNode, selection.ParentNode));
        }

        #region Selection Management

        private void ShowCommandOnToolStrip()
        {
            toolStrip2.Items.Clear();

            if (CurrentSelection != null)
            {
                fCurrentHotKeys.Clear();
                foreach (var c in CurrentSelection.Commands.Where(c => c.show_on == ShowOn.Toolbar || c.show_on == ShowOn.ToolbarAndContextMenu))
                {
                    var btn = new ToolStripButton
                    {
                        Name = c.id,
                        Text = c.label,
                        ToolTipText = c.tooltip,
                        Tag = CurrentSelection  //Normal tuple to allow back casting into tuple
                    };

                    if (!String.IsNullOrWhiteSpace(c.icon) && ImgList.Images.ContainsKey(c.icon))
                        btn.Image = ImgList.Images[c.icon];

                    btn.Click += ToolStripButton_Click;
                    toolStrip2.Items.Add(btn);

                    if (!String.IsNullOrEmpty(c.hotkey))
                    {
                        var key = ParseHotKey(c.hotkey);
                        if (fCurrentHotKeys.TryGetValue(key, out var existingCmd))
                            throw new Exception($"Conflicting hot key '{c.hotkey}'. Commands: '{existingCmd.id}' and '{c.id}'");
                        fCurrentHotKeys.Add(key, c);
                    }
                }
            }
        }

        /*private void FillHotKeyDict(Dictionary<Keys, A2aCommand> dict, string nodeId, string noteType)
        {
            dict.Clear();
            foreach (var c in Model.GetCommands(nodeId, noteType))
            {
                var btn = new ToolStripButton { Name = c.Id, Text = c.Label, ToolTipText = c.Tooltip, Tag = nodeId };
                btn.Click += ToolStripButton_Click;
                toolStrip2.Items.Add(btn);

                if (!String.IsNullOrEmpty(c.HotKey))
                {
                    var key = ParseHotKey(c.HotKey);
                    if (dict.TryGetValue(key, out var existingCmd))
                        throw new Exception($"Conflicting hotkey '{c.HotKey}'. Commands: '{existingCmd.Id}' and '{c.Id}'");
                    dict.Add(key, c);
                }
            }
        }*/
        #endregion Selection Management

        #region Update Management

        public void UpdateNode(UpdateType updType, A2aNodeTree node, int requestId) => TreeScreeens.ForEachSafe(ts => ts.UpdateNode(updType, node, requestId));
        
        [Obsolete("Use Type on definition instead")]
        public void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId) =>
            ListScreens.ForEach(ls => ls.SetColumns(columns, requestId)); //S

        public void AddAllFields(UpdateType updType, string[] columns, int requestId) =>
            ListScreens.ForEach(ls => ls.AddAllFields(updType, columns, requestId));  //Send to all screens, they should filter their request.

        public void AddWebPage(string html, int requestId) => WebScreens.ForEach(ws => ws.ShowPage(html, requestId));

        public Task<bool> EditForm(A2aFormParameters formParams) =>
            Task.Factory.FromAsync(BeginInvoke(new EditNodeDelegate(ShowEditObjectDialog), formParams), a => (bool)this.EndInvoke(a));

        delegate bool EditNodeDelegate(A2aFormParameters formParams);

        //TODO: think about returning the button number
        public bool ShowEditObjectDialog(A2aFormParameters formParams)
        {

            using var frm = new EditObject(formParams.Properties, this);
            frm.Text = formParams.FormTitle;
            frm.ShowDialog(this);
            SetStatus($"The result of the dialog: {(frm.Success ? "Save" : "Cancel")}");
            return frm.Success;

            /*var props = string.Join("\r\n", properties.Select(p => $"PropId: {p.Id}, propLabel: {p.Label}, propValue: {p.Value}"));
            var res = await ShowDialog($"Edit node '{nodeId}'\r\n" + props);
            SetStatus($"The result of the dialog: {res}");
            return res == "Yes";*/
        }
        #endregion Update Management

        private void BtSave_Click(object sender, EventArgs e)
        {
            switch (Model)
            {
                case FlavoursModel flv:
                    flv.SaveToFile();
                    break;
                default:
                    throw new Exception($"There is not support for saving in model <{Model.GetType().Name}> {Model.ModelName}");
            }
        }
    }
}
