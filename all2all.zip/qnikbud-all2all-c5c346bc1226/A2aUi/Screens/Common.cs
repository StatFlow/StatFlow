﻿using A2aCommands.Xml;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace All2All.Screens
{
    internal static class Common
    {
        internal static A2aNode? GetDraggedNodeIdN(IDataObject? dObj)
        {
            // Retrieve the node that was dragged.
            if (dObj?.GetData(typeof(TreeNode)) is TreeNode draggedNode)
                return TreeViewNode2A2aNode(draggedNode);

            if (dObj?.GetData(typeof(ListViewItem)) is ListViewItem draggedLv)
                return ListViewItem2A2aNodeN(draggedLv);

            return null;
        }

        internal static A2aNode? TreeViewNode2A2aNode(TreeNode draggedNode)
        {
            if (draggedNode == null)
                return null;

            var tns = draggedNode.Tag as TreeNodeState ?? throw new Exception($"Tree node '{draggedNode.Name}' doesn't have a Tag object");
            return new A2aNode { id = draggedNode.Name, type = tns.NodeType, name = draggedNode.Text };
        }

        internal static A2aNode? ListViewItem2A2aNodeN(ListViewItem draggedLv)
        {
            if (draggedLv == null)
                return null;

            var itType = draggedLv.Tag as string ?? throw new Exception($"List Item '{draggedLv.Name}' doesn't have Tag set up");
            return new A2aNode { id = draggedLv.Name, type = itType, name = draggedLv.Text };
        }
    }
}
