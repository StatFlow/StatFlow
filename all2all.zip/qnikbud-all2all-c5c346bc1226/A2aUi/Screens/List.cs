﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using WeifenLuo.WinFormsUI.Docking;
using NbTools;
using NbTools.SqlGen.Xml;
using A2aTypes.Xml;
//using log4net;
using A2aCommands.Xml;
using Timer = System.Windows.Forms.Timer;

namespace All2All.Screens
{
    //TODO: implement virtual list

    public partial class List : DockContent, ISelectionProvider
    {
        //public static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly IMainForm Main;
        const string ColumnDescDefaultName = "ColumnDescDefault";
        /// <summary>
        /// At what indexes visually first, second, etc. column data will appear in the array with fields in SetColumns
        /// </summary>
        private int[]? ColumnOrder = null;
        private readonly string[]? FilterN = null;

        private const int SearchTimeout = 500; //Timeout when user enters symbols into the search text box
        //private readonly bool SortDesc = false;

        private readonly FilterBase HideDeletedFilter = new FltEqual { field = "Deleted", table = "Files", val = "0" };

        private readonly A2aType MainType;
        private readonly string RequestName;
        private int CurrRequestId = 0; //Keep current request until the next one in order to receive updates and send cancel to stop updates
        private readonly StringBuilder StrBld = new StringBuilder();

        internal readonly SqlXmlGenerator SelectionReceiver;

        internal List(IMainForm mainForm, ListViewXml lvx, ImageList imgList) : this()
        {
            Main = mainForm;
            Name = lvx.name;
            MainType = lvx.TypeResoved;
            RequestName = lvx.request_name;
            listView1.SmallImageList = imgList;

            SelectionReceiver = new("ListView " + Name, mainType: lvx.TypeResoved, reqName: lvx.request_name, reloadAction: DoRequest);

        }

        public List()
        {
            InitializeComponent();
        }

        #region Search Timer
        private void TbSearch_TextChanged(object? _, EventArgs __)
        {
            SelectionReceiver.LikeFilter = tbSearch.Text; //Kicks off the timer
        }

        //Reloads request from the file, giving user the opportunity to edit it manually
        private async void ReloadListButton_Click(object _, EventArgs __)
        {
            var req = NbSqlXml.LoadFile(@"C:\AutoDelete\A2A_Request.xml");
            await DoRequest(req);
        }

        private async Task DoRequest(NbSqlXml req)
        {
            //int prevReqId = CurrRequestId; //Stop receiving updates
            CurrRequestId = Main.GetNextRequestId(); //TODO: remember and cancel requests if another comes in
                                                     //data_request rq = new data_request { columns = Columns, filter = filter, sort = SortBy };
            ResetColumns();

            var list = await Main.Model.GetList(req, CurrRequestId, canToken: default);
            listView1.BeginUpdate();
            bool first = true;
            string[] header;
            foreach (string line in list)
            {
                var allCols = NbExt.DeCsvLine(line, StrBld, ',', trim: true).ToArray();
                if (first)
                {
                    header = allCols;
                    first = false;
                    continue;
                }

                if (allCols.Length < 3)
                    throw new Exception("All Columns array is shorter than three columns");

                var lvi = new ListViewItem { Name = allCols[0], Tag = allCols[1], ImageKey = "default" };  // Name = nodeId, Tag = nodeType, ImageKey = nodeIcon
                SetItemColumns(UpdateType.Add, lvi, allCols.Skip(2).ToArray()); //TODO: use full length array everywhere   Name 
                listView1.Items.Add(lvi);
            }
            listView1.EndUpdate();
        }

        private void ResetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columnsN = null)
        {
            var columns = columnsN ?? MainType.column.Select(c => (c.name, c.display_type)); //If columns were not provided - assume the MainType columns

            List<ListViewColumnDesc> colDescs = new List<ListViewColumnDesc>(30);
            int cntr = 0; //Assume the order it has been listed in
            foreach (var (fieldName, displayStyle) in columns)
                colDescs.Add(Main.UserProfile.GetColumnDesc(ColumnDescDefaultName, fieldName, displayStyle, cntr++)); //Looked up or created

            int newOrd = 0; //Repair if the same order repeats twice
            foreach (var colDesc in colDescs.OrderBy(cd => cd.Order))
                colDesc.Order = newOrd++;

            var tmpOrder = colDescs.Select(cd => cd.Order).ToArray();
            ColumnOrder = Enumerable.Range(0, tmpOrder.Length).Select(i => Array.IndexOf(tmpOrder, i)).ToArray();

            var colHeaders = colDescs.OrderBy(cd => cd.Order).Select(cd => new ColumnHeader { Text = cd.ColumnName, TextAlign = cd.Alignment, Width = cd.Width, Tag = cd }).ToArray();

            listView1.BeginUpdate();
            listView1.Columns.Clear();
            listView1.Items.Clear();
            listView1.Columns.AddRange(colHeaders);
            listView1.EndUpdate();
        }

        const bool MostRecentFilterOnly = (1 == 1);

        private void BtSearchReset_Click(object _, EventArgs __) => tbSearch.Text = String.Empty;

        #endregion Search Timer

        #region Selection Provider
        public event SelectionChangedHandler SelectionChanged;

        private void ListView1_SelectedIndexChanged(object _, EventArgs __)
        {
            if (listView1.SelectedItems.Count == 0)
                SelectionChanged?.Invoke(this, null, null);
            else
            {
                var sel = SelectionFromNode(listView1.SelectedItems[0]);
                A2aNode par = null; //TODO: provide parent from the treeview's selection
                //For this consider moving filter creation from TreeView to ListView, so that TreeView only provides the selected node, not the filter logic
                SelectionChanged?.Invoke(this, sel, par);
            }
        }

        private static A2aNode SelectionFromNode(ListViewItem it)
        {
            var itType = it.Tag as string ?? throw new Exception($"List Item '{it.Name}' doesn't have Tag set up");
            return new A2aNode { id = it.Name, type = itType, name = it.Text };
        }
        #endregion Selection Provider

        private bool TryDescByIndex(int ind, out ListViewColumnDesc desc, out ColumnHeader colHdr)
        {
            colHdr = listView1.Columns[ind];
            desc = colHdr.Tag as ListViewColumnDesc;
            return !(desc is null);
        }

        private void ListView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (TryDescByIndex(e.Column, out var desc, out _))
                SelectionReceiver.SortColumn = desc.ColumnName; //Resets the timer
        }

        private void ListView1_ColumnReordered(object __, ColumnReorderedEventArgs e)
        {
            if (TryDescByIndex(e.OldDisplayIndex, out var desc, out _))
                Main.UserProfile.Reorder(desc, e.NewDisplayIndex);
        }

        private void ListView1_ColumnWidthChanged(object _, ColumnWidthChangedEventArgs e)
        {
            if (TryDescByIndex(e.ColumnIndex, out var desc, out var col))
                desc.Width = col.Width;
        }

        public delegate void SetColumnsDelegate(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId);
        public void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> _, int _1)
        {
            /*if (InvokeRequired)
            {
                BeginInvoke(new SetColumnsDelegate(SetColumns), columnsN, requestId);
                return;
            }

            listView1.Columns.Clear();
            listView1.Items.Clear();

            var columns = columnsN ?? MainType.column.Select(c => (c.name, c.display_type)); //If columns were not provided - assume the MainType columns

            List <ListViewColumnDesc> colDescs = new List<ListViewColumnDesc>(30);
            int cntr = 0; //Assume the order it has been listed in
            foreach (var (fieldName, displayStyle) in columns)
                colDescs.Add(Main.UserProfile.GetColumnDesc(ColumnDescDefaultName, fieldName, displayStyle, cntr++)); //Looked up or created

            int newOrd = 0; //Repair if the same order repeats twice
            foreach (var colDesc in colDescs.OrderBy(cd => cd.Order))
                colDesc.Order = newOrd++;

            var tmpOrder = colDescs.Select(cd => cd.Order).ToArray();
            ColumnOrder = Enumerable.Range(0, tmpOrder.Length).Select(i => Array.IndexOf(tmpOrder, i)).ToArray();

            var colHeaders = colDescs.OrderBy(cd => cd.Order).Select(cd => new ColumnHeader { Text = cd.ColumnName, TextAlign = cd.Alignment, Width = cd.Width, Tag = cd }).ToArray();
            listView1.Columns.AddRange(colHeaders);*/
        }


        public delegate void AddAllFieldsDelegate(UpdateType updType, string[] columns, int requestId);
        public void AddAllFields(UpdateType updType, string[] columns, int requestId)
        {
            if (InvokeRequired)
            {
                BeginInvoke(new AddAllFieldsDelegate(AddAllFields), updType, null, null, columns, requestId);
                return;
            }

            if (columns.Length < 3)
                throw new Exception($"Array of at least 2 columns [NodeId, NodeType, NodeName] is expected in {nameof(AddAllFields)} method");

            string nodeId = columns[0];
            string nodeType = columns[1];

            switch (updType)
            {
                case UpdateType.Add:
                    if (!AllowedByFilter(columns))
                        return;

                    var lvi = new ListViewItem { Name = columns[0], Tag = nodeType, ImageKey = "default" };
                    SetItemColumns(updType, lvi, columns.Skip(2).ToArray());
                    listView1.Items.Add(lvi);
                    break;

                case UpdateType.Update:
                    var lviu = listView1.Items[nodeId];
                    if (lviu != null) //The list view node is not necessarily in the list
                        SetItemColumns(updType, lviu, columns.Skip(2).ToArray()); //Skip NodeId, NodeType, keep NodeName
                    break;

                case UpdateType.Remove:
                    listView1.Items.RemoveByKey(nodeId);
                    break;

                default:
                    throw new NbExceptionEnum<UpdateType>(updType);
            }
        }


        private bool AllowedByFilter(string[] columns)
        {
            if (FilterN == null || FilterN.Length == 0)
                return true;
            else
            {
                bool res = FilterN.All(f => columns.Any(str => str.ContainsIC(f)));
                return res;
            }
        }
        //THINK: if all sub-items created first then it will be possible to use Enumerable<string> for column values
        //But this all will change with the implementation of the virtual mode

        /// <summary>
        /// Adds of replaces the main sext and the sub-items of the ListViewItem with the columns given in the collection
        /// </summary>
        /// <param name="updType"></param>
        /// <param name="lvi"></param>
        /// <param name="columns"></param>
        private void SetItemColumns(UpdateType updType, ListViewItem lvi, string[] columns)
        {
            if (ColumnOrder == null) throw new NbExceptionInfo("ColumnOrder is not set");

            int cnt = 0;
            foreach (var pos in ColumnOrder)
            {
                var str = columns[pos]; //Original string
                if (listView1.Columns[cnt].Tag is ListViewColumnDesc colDesc) //If there is a column description - we can get the display style
                    str = str.ConvertStringByDisplayStyle(colDesc.DisplayStyle); //Apply the displays style

                if (cnt == 0)
                    lvi.Text = str;
                else
                {
                    if (updType == UpdateType.Add)
                        lvi.SubItems.Add(str);
                    else
                        lvi.SubItems[cnt].Text = str;  //SubItem[0] is the Text property
                }
                cnt++;
            }
        }

        private A2aNode? ListViewDestNodeN(int x, int y)
        {
            Point targetPoint = listView1.PointToClient(new Point(x, y)); // Retrieve the client coordinates of the drop location.
            ListViewItem targetNode = listView1.GetItemAt(targetPoint.X, targetPoint.Y); // Retrieve the node at the drop location.
            return Common.ListViewItem2A2aNodeN(targetNode);
        }

        private void ListView1_DragOver(object sender, DragEventArgs e)
        {
            A2aNode? src = Common.GetDraggedNodeIdN(e.Data);
            A2aNode? dst = ListViewDestNodeN(e.X, e.Y);
            if (src?.id == dst?.id)
                return; //Don't allow dropping on itself

            var cmds = Main.Model.GetDragCommands(src, dst, e.Data.GetFormats()).ToList(); //Do we need to call GetDragCommands on Drag Over and Drap Drop???
            e.Effect = (cmds.Count == 0) ? DragDropEffects.None : DragDropEffects.Move;
        }

        private void ListView1_DragDrop(object sender, DragEventArgs e)
        {
            A2aNode? src = Common.GetDraggedNodeIdN(e.Data);
            A2aNode? dst = ListViewDestNodeN(e.X, e.Y);
            var cmds = Main.Model.GetDragCommands(src, dst, e.Data.GetFormats());
            Main.ShowDragDropMenu(cmds, src, dst, e.Data);
        }

        private void ListView1_ItemDrag(object sender, ItemDragEventArgs e)
        {
            DoDragDrop(e.Item, DragDropEffects.Move);

            /*switch (e.Item)
            {
                case ListViewItem lvi:
                    (string nodeId, string nodeType, string nodeName) = SelectionFromNode(lvi);
                    if (nodeType == "File")
                    {
                        var sc = new StringCollection();
                        sc.Add(@"C:\Temp\cb5b758b-3652-4b3d-a9f8-646c743987a7.pdf");

                        DataObject dObj = new DataObject(); //(DataFormats.FileDrop, @"C:\Temp\cb5b758b-3652-4b3d-a9f8-646c743987a7.pdf");
                        dObj.SetFileDropList(sc);
                        var res = DoDragDrop(dObj, DragDropEffects.Copy);
                        Debug.WriteLine($"Item Drag Finished with {res}");
                    }

                    break;

                default:
                    throw new NbExceptionInfo($"ListView ItemDrag received a {e.Item.GetType().Name} object, which is not supported");
            }

            var a = e.Item;*/
            //this.listBox1.DoDragDrop(new DataObject(DataFormats.FileDrop, filesToDrag), DragDropEffects.Copy);

            //Debug.WriteLine($"Item Drag Finished with {res}");
        }

        private void ListView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right)
                return;

            contextMenuStrip1.Items.Clear();
            var it = listView1.GetItemAt(e.X, e.Y);
            if (it != null)
            {
                if (listView1.SelectedItems.Count == 1)
                {
                    var src = SelectionFromNode(it);
                    var cmds = Main.Model.GetCommandsSingle(src);
                    foreach (var cmd in cmds.Where(c => c.show_on == ShowOn.ContextMenu || c.show_on == ShowOn.ToolbarAndContextMenu))
                    {
                        var tsmi = new ToolStripMenuItem() { Text = cmd.label, Tag = cmd };
                        tsmi.Click += (_, __) => Main.Model.ExecuteCommand(cmd.id, src, null, null);
                        contextMenuStrip1.Items.Add(tsmi);
                    }
                }
                else if (listView1.SelectedItems.Count == 2)
                {
                    var fromItem = listView1.SelectedItems[0] == it ? listView1.SelectedItems[1] : listView1.SelectedItems[0];
                    var from = SelectionFromNode(fromItem);
                    var to = SelectionFromNode(it);

                    contextMenuStrip1.Items.Add($"Context menu for two items: {from} => {to} ");
                }
                else
                {
                    contextMenuStrip1.Items.Add($"Context menu for multiple selection:");
                }

                //List view specific: Add "Copy cell menu" under a separator
                contextMenuStrip1.Items.Add(new ToolStripSeparator());

                var subItem = it.GetSubItemAt(e.X, e.Y);
                string shortenedText = subItem.Text.Length > 30 ? subItem.Text.Substring(30) + "..." : subItem.Text;
                var copyCellMenu = new ToolStripMenuItem() { Text = $"Copy '{shortenedText}'" };
                copyCellMenu.Click += (_, __) => Clipboard.SetText(subItem.Text);
                contextMenuStrip1.Items.Add(copyCellMenu);
            }
            else
            {
                contextMenuStrip1.Items.Add($"Context menu for no selection");
            }
            contextMenuStrip1.Show();
        }


        /*var col = GetListViewColumnN(listView1, e.X);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int GetScrollPos(IntPtr hWnd, Orientation nBar);

        // Return the column under this X position.
        static public ColumnHeader GetListViewColumnN(ListView lvw, int x)
        {
            x += GetScrollPos(lvw.Handle, Orientation.Horizontal); // Get the horizontal scroll bar's position.
          
            foreach(ColumnHeader col in lvw.Columns)
            {
                x -= col.Width;
                if (x <= 0) return col;
            }
            return null;
        }*/

        private void ListView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var it = listView1.GetItemAt(e.X, e.Y);
            if (it != null)
            {
                Main.NodeActionDoubleClick(Keys.LButton, SelectionFromNode(it));
            }
        }
    }
}
