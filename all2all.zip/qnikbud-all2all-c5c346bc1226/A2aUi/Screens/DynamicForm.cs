﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using WeifenLuo.WinFormsUI.Docking;
using NbTools;
using NbTools.SqlGen.Xml;
using A2aTypes.Xml;
//using log4net;
using A2aCommands.Xml;
using A2aForms.Xml;

namespace All2All.Screens
{
    public partial class DynamicForm : DockContent
    {
        private const int LineInterval = 25;
        private readonly A2aForm FormDesc;

        public DynamicForm()
        {
            InitializeComponent();
        }

        public DynamicForm(A2aForm form)
        {
            FormDesc = form;
            InitializeComponent();

            SuspendLayout();
            int line = 0;
            int lblWidth = splitContainer1.Panel1.Width - 4;

            foreach (A2aFormFieldBase fldDesc in form.field ?? throw new NbExceptionInfo("The A2aForm doesn't have any fields defined"))
            {
                Label lbl = new Label { Name = fldDesc.id + "_lbl", Text = fldDesc.label, TextAlign = ContentAlignment.MiddleRight, Left = 2, Top = 2 + line * LineInterval, Width = lblWidth };
                splitContainer1.Panel1.Controls.Add(lbl);

                switch (fldDesc)
                {
                    case A2aFormFieldEnum fldEnum:
                        ComboBox cmb = new ComboBox { Name = fldDesc.id, Left = 2, Top = 2 + line * LineInterval, TabIndex = line };
                        cmb.Items.AddRange(fldEnum.list);
                        splitContainer1.Panel2.Controls.Add(cmb);
                        cmb.Text = fldEnum.val;
                        break;

                    case A2aFormFieldString fldStr:
                        TextBox tb1 = new TextBox { Name = fldStr.id, Left = 2, Top = 2 + line * LineInterval, TabIndex = line };
                        splitContainer1.Panel2.Controls.Add(tb1);
                        tb1.Text = fldStr.val;
                        break;

                    case A2aFormFieldNumber fldNum:
                        TextBox tb2 = new TextBox { Name = fldNum.id, Left = 2, Top = 2 + line * LineInterval, TabIndex = line };
                        splitContainer1.Panel2.Controls.Add(tb2);
                        tb2.Text = fldNum.val.ToString(); //TODO: Support numbers
                        break;

                    default:
                        TextBox tb = new TextBox { Name = fldDesc.id, Left = 2, Top = 2 + line * LineInterval, TabIndex = line };
                        splitContainer1.Panel2.Controls.Add(tb);
                        //tb.Text = fldDesc.val;
                        break;
                }
                line++;
            }

            int buttonLeft = 10;
            int buttonTop = 10;

            foreach (A2aFormButton btnDesc in form.buttons ?? throw new NbExceptionInfo("The A2aForm doesn't have any buttons defined"))
            {
                //btnDesc.type

                Button btn = new Button() { Name = btnDesc.id, Text = btnDesc.label, Tag = btnDesc, Location = new Point(buttonLeft, buttonTop) };
                btn.Click += Btn_Click;
                panel1.Controls.Add(btn);
                switch(btnDesc.type)
                {
                    case A2aFormButtonTypes.Enter:
                        AcceptButton = btn;
                        break;

                    case A2aFormButtonTypes.Esc:
                        CancelButton = btn;
                        break;
                }

                buttonLeft += btn.Width;

                /*ToolStripButton tBtn = new ToolStripButton { Name = btnDesc.id, Text = btnDesc.label, Tag = btnDesc };
                tBtn.Click += Btn_Click;
                toolStrip1.Items.Add(tBtn);*/
            }
            ResumeLayout();
        }

        public A2aForm ResultN = null;

        private void Btn_Click(object sender, EventArgs e)
        {
            A2aFormButton btnDesc;
            switch (sender)
            {
                case ToolStripButton tsb:
                    btnDesc = tsb.Tag as A2aFormButton;
                    break;

                case Button b:
                    btnDesc = b.Tag as A2aFormButton;
                    break;

                default:
                    throw new NbExceptionInfo($"The button is neither ToolStripButton nor Button: '{sender.GetType().Name}'"); ;
            }

            //TODO btnDesc.Clicked = true;
            switch (btnDesc.type)
            {
                case A2aFormButtonTypes.None:
                    break;
                case A2aFormButtonTypes.Enter:
                    SaveControlsToResultN();
                    break;
                case A2aFormButtonTypes.Esc:
                    break;
                default: throw new NbExceptionEnum<A2aFormButtonTypes>(btnDesc.type);
            }
            Close();
        }

        private void SaveControlsToResultN()
        {
            if (FormDesc.field.Length != splitContainer1.Panel2.Controls.Count)
                throw new NbExceptionInfo($"The number of field descriptors and controls on panel2 of DynamicForm do not match: {FormDesc.field.Length} != {splitContainer1.Panel2.Controls.Count}");

            ResultN = FormDesc;
            for (int i = 0; i < FormDesc.field.Length; ++i)
            {
                switch (FormDesc.field[i])
                {
                    case A2aFormFieldEnum fldEnum:
                        Control cnt1 = splitContainer1.Panel2.Controls[i];
                        fldEnum.val = cnt1.Text;
                        break;

                    case A2aFormFieldString fldStr:
                        Control cnt2 = splitContainer1.Panel2.Controls[i];
                        fldStr.val = cnt2.Text;
                        break;

                    case A2aFormFieldBoolean fldBool:
                        CheckBox chk = splitContainer1.Panel2.Controls[i] as CheckBox;
                        fldBool.val = chk.Checked;
                        break;

                    case A2aFormFieldNumber fldNum:
                        Control cnt3 = splitContainer1.Panel2.Controls[i];
                        fldNum.val = Int32.TryParse(cnt3.Text, out int res1) ? res1 : Int32.MinValue;
                        break;

                    default:
                        throw new NbExceptionInfo($"Unsupported A2aFormFieldBase type {FormDesc.field[i].GetType().Name}");
                }
            }
        }
    }
}
