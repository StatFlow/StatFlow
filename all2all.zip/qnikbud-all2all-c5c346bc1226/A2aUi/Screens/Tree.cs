﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

using WeifenLuo.WinFormsUI.Docking;
using NbTools;
using NbTools.SqlGen.Xml;
using System.Threading.Tasks;
using System.Diagnostics;
using A2aTypes.Xml;
using A2aCommands.Xml;

namespace All2All.Screens
{
    public enum FilterModes { Inactive, ChildrenOfNode, InSubtree, NotInSubtree };

    public partial class Tree : DockContent, ISelectionProvider//, IFilterProvider
    {
        private const string LoadNodeText = "Loading...";
        private const string BtFilterMode = "btFilterMode";

        private readonly IMainForm Main;
        private readonly TreeViewXml TrXml;
        public readonly string TableHoldingATree;
        private TreeNode RootTreeNode = null;

        public event SelectionChangedHandler SelectionChanged;

        public FilterModes FilterMode
        {
            get => _filterMode;
            set
            {
                string val = value.ToString();
                foreach (ToolStripMenuItem option in btFilterMode.DropDownItems)
                    option.Checked = option.Name.Replace(BtFilterMode, String.Empty) == val; //TODO: simplify with Substr

                _filterMode = value;
                //UpdateFilter();
            }
        }
        private FilterModes _filterMode;


        private void FilterModeMenu_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem option = sender as ToolStripMenuItem ?? throw new NbExceptionBadType(nameof(sender), nameof(ToolStripMenuItem), sender);
            if (!Enum.TryParse(option.Name.Replace(BtFilterMode, String.Empty), out FilterModes mode))
                throw new NbExceptionEnum<FilterModes>(option.Name.Replace(BtFilterMode, String.Empty));

            FilterMode = mode;
        }

        /// <summary>
        /// Creates new TreeView component
        /// </summary>
        /// <param name="mainForm">Back reference to the main form</param>
        /// <param name="nodesType">The types of nodes to show on the tree</param>
        internal Tree(IMainForm mainForm, TreeViewXml trXml, ImageList imgList) : this()
        {
            Main = mainForm;
            TrXml = trXml;
            TableHoldingATree = TrXml.TypesResoved[0].hierarchy_table; //TODO: Support multiple types
            Name = trXml.name;

            treeView1.ImageList = imgList;
            FilterMode = FilterModes.ChildrenOfNode; //Default setting for now
        }

        public Tree() => InitializeComponent();

        public delegate void AddSimpleDelegate(UpdateType updType, A2aNodeTree node, int requestId);

        /// <summary>
        /// From IUserInterface interface. Creates the nodes on the tree (simple list wit Id and Names only).
        /// </summary>
        /// <param name="updType">Add, Update, Remove</param>
        /// <param name="nodeId">String unique id of the node</param>
        /// <param name="nodeType">String of the node type i.e. File or Dir</param>
        /// <param name="parentId">String unique Id of the parent of the node</param>
        /// <param name="label">Label - simple name to show on the tree or in the list</param>
        /// <param name="hasChildren">Has children - useful to show the pluses on the tree without opening the node</param>
        /// <param name="requestId">Request Id a number useful to ignore events after the request was canceled</param>
        public void UpdateNode(UpdateType updType, A2aNodeTree node, int requestId)
        {
            //if (String.IsNullOrWhiteSpace(nodeIcon))
            //    nodeIcon = "folder";

            //A2aNode node = new A2aNode { id = nodeId, type = nodeType, name = label };
            //A2aNodeTree node = new A2aNodeTree { id = nodeId, type = nodeType, name = label, icon = nodeIcon, parentId = parentId, has_children = hasChildren };

            if (!TrXml.TypesResoved.Any(nt => nt.name == node.type))
                return;

            if (InvokeRequired)
            {
                BeginInvoke(new AddSimpleDelegate(UpdateNode), updType, node, requestId);
                return;
            }

            TreeNode tn;
            switch (updType)
            {
                case UpdateType.Add:
                    if (node.has_children)
                    {
                        TreeNode[] chld = new TreeNode[] { new TreeNode(LoadNodeText) { Tag = LoadNodeText } };
                        tn = new TreeNode(node.name, chld) { Name = node.id, ImageKey = node.icon, SelectedImageKey = node.icon, Tag = new TreeNodeState(node.type) };
                    }
                    else
                        tn = new TreeNode(node.name) { Name = node.id, Tag = new TreeNodeState(node.type), ImageKey = node.icon, SelectedImageKey = node.icon };

                    Debug.Print($"Adding node:  {Name} {node.name}");
                    if (String.IsNullOrEmpty(node.parentId)) //If root node
                    {
                        treeView1.Nodes.Add(tn);
                        treeView1.SelectedNode = tn;
                        RootTreeNode = tn;
                        //RootNode = node;
                        //treeView1.SelectedNode.Expand(); Expand doesn't work here, because the children were not loaded yet
                    }
                    else if (TryGetTreeNode(node.parentId, out var resN)) //The node doesn't necessarily exist - this notification can be sent for a different control, that has the node
                        resN.Nodes.Add(tn);

                    if (requestId != MainForm.RootRequest) //Re-issue request for children
                    {
                        break;
                        //Task.Run(() => Main.Model.GetChildren(Id, TypesInTree, default, 0)); Will be issued by the user
                    }
                    break;

                case UpdateType.Update:
                    if (TryGetTreeNode(node.id, out var res1N) && res1N.Text != node.name)//The node doesn't necessarily exist - this notification can be sent for a different control, that has the node
                    {
                        res1N.Text = node.name;
                        res1N.ImageKey = node.icon;
                        res1N.SelectedImageKey = node.icon;
                    }
                    break;

                case UpdateType.Remove:
                    if (TryGetTreeNode(node.id, out var res2N)) //The node doesn't necessarily exist - this notification can be sent for a different control, that has the node
                        treeView1.Nodes.Remove(res2N);
                    break;

                default:
                    throw new NbExceptionEnum<UpdateType>(updType);
            }
        }

        private async void TreeView1_AfterExpand(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Nodes.Count > 0 && //Child entries exist
                Object.ReferenceEquals(e.Node.Nodes[0].Tag, LoadNodeText)) //The node is Loading... node
            {
                e.Node.Nodes.RemoveAt(0);
                await InitChildren(e.Node);
            }
        }

        private bool TryGetTreeNode(string id, out TreeNode treeNode)
        {
            var res = treeView1.Nodes.Find(id, searchAllChildren: true);
            switch (res.Length)
            {
                case 0:
                    treeNode = null;
                    return false;
                case 1:
                    treeNode = res[0];
                    return true;
                default:
                    throw new Exception($"'{res.Length}' nodes with ID '{id}' was found in the tree");
            };
        }

        private TreeNode TreeSelection = null; //Tree node selection is remembered to prevent reloading of the node if focus moves from the list back to the tree

        private static A2aNode SelectionFromNode2(TreeNode it)
        {
            var tns = it.Tag as TreeNodeState ?? throw new Exception($"Tree node '{it.Name}' doesn't have a Tag object");
            return new A2aNode { id = it.Name, type = tns.NodeType, name = it.Text };
        }

        private async void TreeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node == TreeSelection)
                return; //This node has already been selected
            else
                TreeSelection = e.Node;

            //TODO: Experiment with parallel requests
            var tns = TreeSelection.Tag as TreeNodeState ?? throw new Exception("Tree node doesn't have a Tag object");
            await InitChildren(TreeSelection);

            A2aNode parent = null; //Parent node is required in order to delete the reference to parent among many
            if (TreeSelection.Parent?.Tag is TreeNodeState parTns)
                parent = new A2aNode(TreeSelection.Parent.Name, parTns.NodeType, TreeSelection.Parent.Text);

            SelectionChanged?.Invoke(this, new A2aNode(TreeSelection.Name, tns.NodeType, TreeSelection.Text), parent);
            //UpdateFilter();
        }

        //Called from the main window to initiate the data load
        internal async Task LoadRoot()
        {
            List<A2aNodeTree> list = await Main.Model.GetChildren(
                parentIdN: TrXml.root_id,
                parentTypeN: null,
                typesN: TrXml.TypesResoved.Select(t => t.name).ToList(),
                canToken: default,
                requestId: Main.GetNextRequestId());

            treeView1.BeginUpdate();
            foreach (A2aNodeTree n in list)
            {
                A2aNodeTree node = new() { id = n.id, type = n.type, name = n.name, icon = n.icon, parentId = null, has_children = n.has_children };
                UpdateNode(UpdateType.Add, node, 0);
            }
            treeView1.EndUpdate();
        }

        private async Task InitChildren(TreeNode nd)
        {
            var tns = nd.Tag as TreeNodeState ?? throw new Exception("Tree node doesn't have a Tag object");
            if (!tns.ChildrenInitialised)
            {
                //int reqId = Main.GetNextRequestId();

                tns.ChildrenInitialised = true;
                Debug.Print($"Init request: {nd.Name} {nd.Text}");
                List<A2aNodeTree> list = await Main.Model.GetChildren(nd.Name, tns.NodeType, TrXml.TypesResoved.Select(t => t.name).ToList(), default, 0); //0 for init??? TODO: use proper counter

                treeView1.BeginUpdate();
                foreach (A2aNodeTree n in list)
                {
                    A2aNodeTree node = new A2aNodeTree { id = n.id, type = n.type, name = n.name, icon = n.icon, parentId = n.parentId, has_children = n.has_children };
                    UpdateNode(UpdateType.Add, node, 0);
                }
                treeView1.EndUpdate();
            }
        }


        //TODO: Call this from selection change, selection clearance button and from mode change: subtree vs current only 
        private void UpdateFilter()
        {
            List<FilterBase> filter = null;

            if (TreeSelection != null && /*TreeSelection.Parent != null &&*/ FilterMode != FilterModes.Inactive) //If Root is selected treat it as no selection
            {
                var tns = TreeSelection.Tag as TreeNodeState ?? throw new Exception("Tree node doesn't have a Tag object");

                bool excl = (FilterMode == FilterModes.NotInSubtree);
                bool rootNodeOnly = (FilterMode == FilterModes.ChildrenOfNode);

                // field and table are not set, they will be set at enrichment stage, where the real table names are known
                FilterBase fltBase = new Subtree
                {
                    exclude = excl,
                    tree_table = TableHoldingATree, //The name of the table holding a tree, such as Dirs or Tags
                    root_node_id = TreeSelection.Name, //The Id of the node which is a root of the tree
                    root_node_type = tns.NodeType,  //The type of the node  which is a root of the tree
                    root_node_only = rootNodeOnly
                };

                filter = new List<FilterBase> { fltBase };
            }

            var ret = new FilterInfo(Name, DateTime.UtcNow, filter);
            //FilterChanged?.Invoke(this, ret);
        }

        private void TreeView1_ItemDrag(object sender, ItemDragEventArgs e) => DoDragDrop(e.Item, DragDropEffects.Move);

        private void TreeView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var it = treeView1.GetNodeAt(e.X, e.Y);
            if (it != null)
            {
                var nd = SelectionFromNode2(it);
                Main.NodeActionDoubleClick(Keys.LButton, nd);
            }
        }

        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            switch (e.Button)
            {
                case MouseButtons.Left:
                    break;
                //case MouseButtons.None:
                //    break;
                case MouseButtons.Right:
                    treeView1.SelectedNode = e.Node;
                    ShowContextMenu(Cursor.Position);
                    break;
                default:
                    MessageBox.Show($"Mouse button pressed: {e.Button}");
                    break;
            }
        }

        //ContextMenuStrip1_Opening is not used because it was not reliably opening
        private void ShowContextMenu(Point loc)
        {
            contextMenuStrip1.Items.Clear();
            if (treeView1.SelectedNode != null)
            {
                var src = SelectionFromNode2(treeView1.SelectedNode);
                var cmds = Main.Model.GetCommandsSingle(src);
                foreach (var cmd in cmds.Where(c => c.show_on == ShowOn.ContextMenu || c.show_on == ShowOn.ToolbarAndContextMenu))
                {
                    var tsmi = new ToolStripMenuItem() { Text = cmd.label, Tag = cmd };
                    tsmi.Click += (_, __) => Main.Model.ExecuteCommand(cmd.id, src, null, null);
                    contextMenuStrip1.Items.Add(tsmi);
                }
            }
            else
            {
                contextMenuStrip1.Items.Add($"Context menu no multiple selection:");
            }


            contextMenuStrip1.Show(loc);

            //ContextMenu.Show(this, myDataGridView.PointToClient(Cursor.Position)); 
        }

        #region Drag And Drop

        private TreeNode TreeViewDestNode(int x, int y)
        {
            Point targetPoint = treeView1.PointToClient(new Point(x, y)); // Retrieve the client coordinates of the drop location.
            TreeNode targetNode = treeView1.GetNodeAt(targetPoint); // Retrieve the node at the drop location.
            return targetNode;
        }

        private A2aNode DragSrcNode;
        private A2aNode DragDstNode;

        private readonly List<A2aCommand> DragCommands = new List<A2aCommand>(); //Do not reallocate the list
        private TreeNode DragDstTreeNode;

        private void TreeView1_DragEnter(object sender, DragEventArgs e)
        {
            DragSrcNode = Screens.Common.GetDraggedNodeIdN(e.Data); //Calculate only once on entry
            Debug.WriteLine($"Drag Enter at {e.X},{e.Y}");
        }

        private void TreeView1_DragLeave(object sender, EventArgs e)
        {
            DragSrcNode = null;
            DragDstNode = null;
            DragDstTreeNode = null;
            DragCommands.Clear();
            Debug.WriteLine($"Drag Leave");
        }


        //TODO: need to determine current selection and raise another even for the selection
        private void TreeView1_DragOver(object sender, DragEventArgs e)
        {
            TreeNode dstTreeNode = TreeViewDestNode(e.X, e.Y) ?? RootTreeNode;
            if (dstTreeNode == DragDstTreeNode)
                return; //No change in destination node

            DragDstTreeNode = dstTreeNode;
            DragDstNode = Common.TreeViewNode2A2aNode(dstTreeNode);
            Debug.WriteLine($"Drag {DragSrcNode} over {DragDstNode} at {e.X},{e.Y}");

            DragCommands.Clear();
            DragCommands.AddRange(Main.Model.GetDragCommands(DragSrcNode, DragDstNode, e.Data.GetFormats()));
            e.Effect = (DragCommands.Count == 0) ? DragDropEffects.None : DragDropEffects.Move;
        }


        //https://stackoverflow.com/questions/20915260/c-sharp-winforms-dragdrop-within-the-same-treeviewcontrol
        private void TreeView1_DragDrop(object sender, DragEventArgs e)
        {
            A2aNode src = Common.GetDraggedNodeIdN(e.Data);
            TreeNode dstTreeNode = TreeViewDestNode(e.X, e.Y) ?? RootTreeNode;
            A2aNode dst = Common.TreeViewNode2A2aNode(dstTreeNode);
            var cmds = Main.Model.GetDragCommands(src, dst, e.Data.GetFormats());
            Main.ShowDragDropMenu(cmds, src, dst, e.Data);

            // Optional: Select the dropped node and navigate (however you do it)
            // treeView1.SelectedNode = draggedNode;*/
            // NavigateToContent(draggedNode.Tag);
        }

        #endregion Drag And Drop

    }
}
