﻿using WeifenLuo.WinFormsUI.Docking;
using Microsoft.Web.WebView2.Core;

using NbTools;
using NbTools.SqlGen.Xml;
//using log4net;
using A2aTypes.Xml;
using Timer = System.Windows.Forms.Timer;

namespace All2All.Screens
{
    public partial class Web : DockContent  //, ISelectionProvider, IFilterProvider
    {
        //public static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private readonly IMainForm Main;
        private readonly ShowPageDel RunShowPage;
        //private readonly Dictionary<IFilterProvider, FilterInfo> FilterProviders = new Dictionary<IFilterProvider, FilterInfo>();
        //private readonly Dictionary<ISelectionProvider, (A2aNode selection, A2aNode parent, DateTime timeStamp)> SelectionProviders = new Dictionary<ISelectionProvider, (A2aNode selection, A2aNode parent, DateTime timeStamp)>();

        private readonly Timer ListFilerChangedTimer;
        private const int SearchTimeout = 500; //Timeout when user enters symbols into the search text box
        private int CurrRequestId = 0; //Keep current request until the next one in order to receive updates and send cancel to stop updates

        internal readonly SqlXmlGenerator SelectionReceiver;

        internal Web(IMainForm mainForm, WebViewXml xml) : this()
        {
            Main = mainForm;
            RunShowPage = new ShowPageDel(ShowPage);
            A2aType type = new A2aType();
            SelectionReceiver = new("WebView " + Name,
                mainType: xml.TypeResoved ?? throw new NbArgumentException("xml.type", $"Type {xml.type} is not resolved"),
                reqName: xml.request_name, reloadAction: DoRequest);

            ListFilerChangedTimer = new Timer();
            ListFilerChangedTimer.Tick += ReloadWebView;
            ListFilerChangedTimer.Interval = SearchTimeout;

            webView21.CoreWebView2InitializationCompleted += WebView21_CoreWebView2InitializationCompleted;
            webView21.EnsureCoreWebView2Async(null);
        }

        private void WebView21_CoreWebView2InitializationCompleted(object? sender, CoreWebView2InitializationCompletedEventArgs e)
        {
        }

        private async void ReloadWebView(object? _, EventArgs __)
        {
            //Log.Info($"List -  {nameof(ReloadWebView)}");

            ListFilerChangedTimer.Stop();

            //Get new list after the timer to avoid multiple calls due to search symbols typing or quick treeview selection change, or multiple tree selection update
            NbSqlXml req = GenerateRequestSql();

            //Log.Info($"Model.GetList: {nameof(ReloadWebView)}, request:\r\n{req.ToXmlString()}");
            req.Save(@"C:\AutoDelete\A2A_Request.xml");

            await DoRequest(req);
            //Main.RefreshSelection(); //F5 Do we really want to refresh selection - this is about another call to get the list
        }

        private NbSqlXml GenerateRequestSql()
        {
            NbSqlFields fields = new NbSqlFields
            {
                new NbSqlField() { name = nameof(NodeFields.NodeId)},
                new NbSqlField() { name = nameof(NodeFields.NodeType)},
                new NbSqlField() { name = nameof(NodeFields.NodeName)},
                new NbSqlField() { name = nameof(NodeFields.Deleted), exclude = true, filter_eq = "0" },
                new NbSqlField() { name = nameof(NodeFields.ParentDirId), exclude = true } //Can be used in filters
            };

            /*foreach (Column col in MainType.column)
            {
                bool add = false;
                if (fields.TryGetValue(n => n.name.EqIC(col.name), out NbSqlField fld)) //If this field was already added as excluded above
                    fld.exclude = false; //Make it included
                else //Create new field
                {
                    fld = new NbSqlField() { name = col.name };
                    add = true;
                }

                fld.display_style = col.display_type.ToString(); //Set display style because it will be shown

                if (col.name == SortColumn)
                {
                    fld.order_ind = 1;
                    fld.order_desc = SortDesc;
                }

                if (col.name.Equals(nameof(NodeFields.NodeName), StringComparison.OrdinalIgnoreCase))
                    fld.filter_like = likeFilter;

                if (add)
                    fields.Add(fld);
            }*/

            var req = new NbSqlXml
            {
                top = 1000,
                table = new NbSqlTable[] { new NbSqlTable { name = "RequestName", field = fields.ToArray() } },
                //filter = FilterProviders.Values.Where(v => v != null).SelectMany(p => p.Filters).ToArray()
            };

            //req.Resolve(); Leave requirement to resolve for now. so that fields can refer to tables that will replace the view
            return req;
        }

        private async Task DoRequest(NbSqlXml req)
        {
            //int prevReqId = CurrRequestId; //Stop receiving updates
            CurrRequestId = Main.GetNextRequestId(); //TODO: remember and cancel requests if another comes in
                                                     //data_request rq = new data_request { columns = Columns, filter = filter, sort = SortBy };
                                                     //ResetColumns();

            var html = await Main.Model.GetWebPage(req, CurrRequestId, canToken: default);
            ShowPage(html, CurrRequestId);


            //var list = await Main.Model.GetList(req, CurrRequestId, canToken: default);
            /*listView1.BeginUpdate();
            bool first = true;
            string[] header = null;
            foreach (string line in list)
            {
                var allCols = NbExt.DeCsvLine(line, StrBld, ',', trim: true).ToArray();
                if (first)
                {
                    header = allCols;
                    first = false;
                    continue;
                }

                if (allCols.Length < 3)
                    throw new Exception("All Columns array is shorter than three columns");

                var lvi = new ListViewItem { Name = allCols[0], Tag = allCols[1], ImageKey = "default" };  // Name = nodeId, Tag = nodeType, ImageKey = nodeIcon
                SetItemColumns(UpdateType.Add, lvi, allCols.Skip(2).ToArray()); //TODO: use full length array everywhere   Name 
                listView1.Items.Add(lvi);
            }
            listView1.EndUpdate();*/
        }

        private void TbSearch_TextChanged(object _, EventArgs __)
        {
            ListFilerChangedTimer.Stop();
            ListFilerChangedTimer.Start();
        }

        public Web()
        {
            InitializeComponent();
        }


        delegate void ShowPageDel(string html, int requestId);

        const string tempFile = @"C:\AutoDelete\tmpHtml.html";
        private static readonly Uri EmptyUri = new Uri("about:blank");

        internal void ShowPage(string html, int requestId)
        {
            if (InvokeRequired)
            {
                Invoke(RunShowPage, html, requestId);
            }
            else
            {

                File.WriteAllText(tempFile, html);

                webView21.Source = EmptyUri;
                webView21.Source = new Uri("file:///" + tempFile);
                /*var doc = web.Document;
                if (doc == null)
                {
                    webBrowser1.DocumentText = html;
                }
                else
                {
                    webBrowser1.DocumentText = "0";

                    webBrowser1.Document.OpenNew(true);
                    webBrowser1.Document.Write(html);
                    webBrowser1.Refresh();
                }*/
            }
            /*a.Write(html);

            //https://stackoverflow.com/questions/5362591/how-to-display-the-string-html-contents-into-webbrowser-control
            webBrowser1.DocumentText = "0";

            webBrowser1.Document.OpenNew(true);
            webBrowser1.Document.Write(html);
            webBrowser1.Refresh();

            DisplayHtml(html);*/
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (File.Exists(tempFile))
                File.Delete(tempFile);
        }
    }
}
