﻿namespace All2All.Screens
{
    partial class Tree
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tree));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tbSearch = new System.Windows.Forms.ToolStripTextBox();
            this.btSearchReset = new System.Windows.Forms.ToolStripButton();
            this.btRemoveSelection = new System.Windows.Forms.ToolStripButton();
            this.btFilterMode = new System.Windows.Forms.ToolStripDropDownButton();
            this.btFilterModeInactive = new System.Windows.Forms.ToolStripMenuItem();
            this.btFilterModeChildrenOfNode = new System.Windows.Forms.ToolStripMenuItem();
            this.btFilterModeInSubtree = new System.Windows.Forms.ToolStripMenuItem();
            this.btFilterModeNotInSubtree = new System.Windows.Forms.ToolStripMenuItem();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tbSearch,
            this.btSearchReset,
            this.btRemoveSelection,
            this.btFilterMode});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(279, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tbSearch
            // 
            this.tbSearch.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(150, 25);
            // 
            // btSearchReset
            // 
            this.btSearchReset.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btSearchReset.Image = ((System.Drawing.Image)(resources.GetObject("btSearchReset.Image")));
            this.btSearchReset.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btSearchReset.Name = "btSearchReset";
            this.btSearchReset.Size = new System.Drawing.Size(23, 22);
            this.btSearchReset.Text = "x";
            // 
            // btRemoveSelection
            // 
            this.btRemoveSelection.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btRemoveSelection.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btRemoveSelection.Image = ((System.Drawing.Image)(resources.GetObject("btRemoveSelection.Image")));
            this.btRemoveSelection.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btRemoveSelection.Name = "btRemoveSelection";
            this.btRemoveSelection.Size = new System.Drawing.Size(23, 22);
            this.btRemoveSelection.Text = "Remove Selection";
            // 
            // btFilterMode
            // 
            this.btFilterMode.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btFilterMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btFilterModeInactive,
            this.btFilterModeChildrenOfNode,
            this.btFilterModeInSubtree,
            this.btFilterModeNotInSubtree});
            this.btFilterMode.Image = ((System.Drawing.Image)(resources.GetObject("btFilterMode.Image")));
            this.btFilterMode.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btFilterMode.Name = "btFilterMode";
            this.btFilterMode.Size = new System.Drawing.Size(29, 22);
            this.btFilterMode.Text = "btFilterModeDropDown";
            // 
            // btFilterModeInactive
            // 
            this.btFilterModeInactive.AutoToolTip = true;
            this.btFilterModeInactive.Name = "btFilterModeInactive";
            this.btFilterModeInactive.Size = new System.Drawing.Size(165, 22);
            this.btFilterModeInactive.Text = "Inactive";
            this.btFilterModeInactive.ToolTipText = "Not filter is applied to the query based on the selection in this treeview";
            this.btFilterModeInactive.Click += new System.EventHandler(this.FilterModeMenu_Click);
            // 
            // btFilterModeChildrenOfNode
            // 
            this.btFilterModeChildrenOfNode.Name = "btFilterModeChildrenOfNode";
            this.btFilterModeChildrenOfNode.Size = new System.Drawing.Size(165, 22);
            this.btFilterModeChildrenOfNode.Text = "Children of Node";
            this.btFilterModeChildrenOfNode.ToolTipText = "Only direct children of the selected node will be included in the report";
            this.btFilterModeChildrenOfNode.Click += new System.EventHandler(this.FilterModeMenu_Click);
            // 
            // btFilterModeInSubtree
            // 
            this.btFilterModeInSubtree.Name = "btFilterModeInSubtree";
            this.btFilterModeInSubtree.Size = new System.Drawing.Size(165, 22);
            this.btFilterModeInSubtree.Text = "In subtree";
            this.btFilterModeInSubtree.ToolTipText = "Items belonging to the selected node and its children will be included in the que" +
    "ry";
            this.btFilterModeInSubtree.Click += new System.EventHandler(this.FilterModeMenu_Click);
            // 
            // btFilterModeNotInSubtree
            // 
            this.btFilterModeNotInSubtree.Name = "btFilterModeNotInSubtree";
            this.btFilterModeNotInSubtree.Size = new System.Drawing.Size(165, 22);
            this.btFilterModeNotInSubtree.Text = "Not in subtree";
            this.btFilterModeNotInSubtree.ToolTipText = "Items not belonging to the selected node and its children will be included in the" +
    " query";
            this.btFilterModeNotInSubtree.Click += new System.EventHandler(this.FilterModeMenu_Click);
            // 
            // treeView1
            // 
            this.treeView1.AllowDrop = true;
            this.treeView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.HideSelection = false;
            this.treeView1.Location = new System.Drawing.Point(0, 25);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(279, 421);
            this.treeView1.TabIndex = 1;
            this.treeView1.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.TreeView1_AfterExpand);
            this.treeView1.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.TreeView1_ItemDrag);
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TreeView1_AfterSelect);
            this.treeView1.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.TreeView1_NodeMouseClick);
            this.treeView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.TreeView1_DragDrop);
            this.treeView1.DragEnter += new System.Windows.Forms.DragEventHandler(this.TreeView1_DragEnter);
            this.treeView1.DragOver += new System.Windows.Forms.DragEventHandler(this.TreeView1_DragOver);
            this.treeView1.DragLeave += new System.EventHandler(this.TreeView1_DragLeave);
            this.treeView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TreeView1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // Tree
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 446);
            this.Controls.Add(this.treeView1);
            this.Controls.Add(this.toolStrip1);
            this.DockAreas = WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Tree";
            this.Text = "Tree";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripTextBox tbSearch;
        private System.Windows.Forms.ToolStripButton btSearchReset;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripButton btRemoveSelection;
        private System.Windows.Forms.ToolStripDropDownButton btFilterMode;
        private System.Windows.Forms.ToolStripMenuItem btFilterModeInactive;
        private System.Windows.Forms.ToolStripMenuItem btFilterModeChildrenOfNode;
        private System.Windows.Forms.ToolStripMenuItem btFilterModeInSubtree;
        private System.Windows.Forms.ToolStripMenuItem btFilterModeNotInSubtree;
    }
}