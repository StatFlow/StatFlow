﻿using System;
using System.Collections.Generic;
using A2aCommands.Xml;
using NbTools;

namespace All2All
{
    public class Selection
    {
        public A2aNode CurrentNode;
        /// <summary>
        /// Parent node is useful when selected node is being deleted and we need to know which reference to the parent among many should be removed
        /// </summary>
        public A2aNode ParentNode; 

        public readonly string NodeId;
        public readonly string NodeType;
        public readonly string NodeName;
        public readonly List<A2aCommand> Commands;

        public Selection(A2aNode current, A2aNode parent, List<A2aCommand> commands)
        {
            CurrentNode = current;
            ParentNode = parent;
            Commands = commands;
        }

        public override string ToString() => $"{CurrentNode}, par: {ParentNode}, cmd: '{String.Join(", ", Commands.Safe())}'";
    }
}
