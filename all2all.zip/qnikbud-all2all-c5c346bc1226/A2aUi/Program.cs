﻿using System.Diagnostics;

using log4net;
using NbTools;

namespace All2All
{
    static class Program
    {
        public static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod()!.DeclaringType);

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                /*Log.Info("\r\nStarting");
                Task.Run(async() =>
                {
                    await Task.Delay(5000);
                    string logName = GetLogFileName();
                    Process.Start(@"C:\Program Files (x86)\ConfigMgr 2012 Toolkit R2\ClientTools\CMTrace.exe", logName);
                });*/

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
                MainForm = new MainForm(args);

                Application.Run(MainForm);
            }
            finally
            {
                Log.Info("Finished");
            }
        }

        public static string GetLogFileName()
        {
            var rootAppender = ((log4net.Repository.Hierarchy.Hierarchy)LogManager.GetRepository())
                                         .Root.Appenders.OfType<log4net.Appender.FileAppender>()
                                         .FirstOrDefault();

            return rootAppender != null ? rootAppender.File : string.Empty;
            //var rootAppender = LogManager.GetRepository().GetAppenders().OfType<log4net.Appender.FileAppender>().FirstOrDefault(fa => fa.Name == name);
            //return rootAppender != null ? rootAppender.File : string.Empty;
        }

        private static MainForm? MainForm;

        private static void ShowDialog(string? header, Exception? ex)
        {
            string exMessage = NbException.Exception2String(ex);

            Log.Error($"Exception at the Main level: {exMessage}", ex);
            if (MainForm != null)
                MessageBox.Show(MainForm, exMessage, header, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
            => ShowDialog(sender?.ToString(), e.Exception);

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
            => ShowDialog($"Unhandled Exception from {sender}", e.ExceptionObject as Exception);
    }
}
