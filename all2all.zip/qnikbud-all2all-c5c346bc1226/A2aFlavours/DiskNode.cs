﻿using all2allv1.Xml;
using NbTools.Sync;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace All2AllModel
{
    /*internal class DiskNodeDir : Node
    {
        private readonly DirectoryInfo Di;

        internal DiskNodeDir(DirectoryInfo di, RefType refType)
        {
            Di = di;
            id = di.FullName;
            name = di.Name;
            Items = new Flavour[] { new FlavFolder() { created = Di.CreationTime, createdSpecified = true } };

            ReferencesN = new List<InnerRef>();
            int cnt = 0;
            foreach (DirectoryInfo subDir in di.GetDirectories())
            {
                var subNode = new DiskNodeDir(subDir, refType);
                AddDoubleRef(subNode, refType, cnt++);
            }

            foreach (FileInfo fi in di.GetFiles())
            {
                var file = new DiskNodeFile(fi);
                AddDoubleRef(file, refType, cnt++);
            }
        }
    }

    internal class DiskNodeFile : Node
    {
        //private readonly FileInfo Fi;

        internal DiskNodeFile(FileInfo fi)
        {
            //Fi = fi;
            id = fi.FullName;
            name = fi.Name;
            Items = new Flavour[] { new FlavFile() { created = fi.CreationTime,accessed = fi.LastAccessTime, modified = fi.LastWriteTime, 
                length= fi.Length, file_name = Path.GetFileNameWithoutExtension(fi.Name), extension = Path.GetExtension(fi.Name) } };
        }
    }*/
}