﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using A2aCommands.Xml;
using NbTools;
using NbTools.Sync;

namespace all2allv1.Xml
{
    public partial class Root
    {
        private void Resolve() { }
    }

    public partial class Node
    {
        internal Node CloneNewId(string newId)
        {
            var n = this.MemberwiseClone() as Node;
            n.id = newId;
            n.ReferencesN = null; //Don't carry the children on the node into the clone
            //n.Items = null; //Items are the flavours - keep them
            return n;
        }

        /// <summary>
        /// Inner representation of a reference kept inside the node
        /// </summary>
        internal class InnerRef
        {
            internal Node Node;
            internal RefType RefType;
            internal int Order;
            internal bool IsForward;

            internal InnerRef(Node node, RefType refType, int order, bool isDirect)
            {
                Node = node;
                RefType = refType;
                Order = order;
                IsForward = isDirect;
            }

            public override string ToString() => $"{RefType}, Forward: {IsForward}, Ord: {Order}, {Node}";
        }

        /// <summary>
        /// The array of Flavour objects kept inside each node. Better name for Items array provided by default by xsd.exe
        /// </summary>
        [XmlIgnore]
        public Flavour[] Flavours => Items;

        [XmlIgnore]
        internal List<InnerRef> ReferencesN; //FAR: Think about using array here

        internal void AddDoubleRef(Node nd, RefType rt, int? order = null)
        {
            AddRef(nd, rt, order, true);
            nd.AddRef(this, rt, order, false);
        }

        private void AddRef(Node nd, RefType rt, int? order, bool isForward)
        {
            if (ReferencesN == null)
                ReferencesN = new List<InnerRef>(4);

            ReferencesN.Add(new InnerRef(nd, rt, order ?? ReferencesN.Count, isForward));
            //TODO: check for duplicate records
        }

        internal bool HasChildren(RefType refType) => ReferencesN?.Any(r => r.RefType.Equals(refType) && r.IsForward) ?? false;

        internal bool HasChildren(RefType refType, params FlvNames[] flavourNames) => ReferencesN?.Any(r => r.IsForward && r.RefType.Equals(refType) && r.Node.HasAnyFlavour(flavourNames)) ?? false;

        /// <summary>
        /// Returns if children of the given type exist.
        /// </summary>
        /// <param name="refTypeName">The name or Id of the reference type</param>
        /// <returns></returns>
        public bool HasChildren(string refTypeName) => ReferencesN?.Any(r => r.RefType.id.Equals(refTypeName) && r.IsForward) ?? false;

        internal bool HasAnyParents() => ReferencesN?.Any(r => !r.IsForward) ?? false;

        /// <summary>
        /// Short string represensation of the node and its Flavours
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            string types = String.Join(", ", Items.Safe().Select(i => i.GetType().Name));
            return $"Node '{name}' ({types})";
        }

        /// <summary>
        /// Checking if the node has the flavour with specified name. Flavour names are taken from Class properties and should be matching the xml flavour name: public override string FlavourName => "video";
        /// </summary>
        /// <param name="flav">Flavour name as a sting</param>
        /// <returns>true if such flavour exists</returns>
        public bool HasFlavour(FlvNames flav) => Items?.Any(fl => fl.FlavourName == flav) ?? false;

        //public bool HasAnyFlavour(ICollection<string> flavs) => Items?.Any(fl => flavs.Contains(fl.FlavourName)) ?? false;

        /// <summary>
        /// Checks whether the node has any flavour from the list of flavour names given. Flavour names are taken from Class properties and should be matching the xml flavour name: public override string FlavourName => "video";
        /// </summary>
        /// <param name="flavs">Collection of flavour names as string.</param>
        /// <returns>true if any of the flavours in the list have been found</returns>
        public bool HasAnyFlavour(params FlvNames[] flavs) => Items?.Any(fl => flavs.Contains(fl.FlavourName)) ?? false;

        /// <summary>
        /// Try to get Flavour object by its name
        /// </summary>
        /// <param name="flavourName">The name of the Flavour as it appears in the XML</param>
        /// <param name="flavour">The flavour object, if it can be found</param>
        /// <returns>true if flavour is found, false otherwise</returns>
        public bool TryGetFlavour(FlvNames flavourName, out Flavour flavour)
        {
            flavour = Items?.SingleOrDefault(f => f.FlavourName == flavourName);
            return flavour != null;
        }

        /// <summary>
        /// Return the Flavour object by its type (if it exists)
        /// </summary>
        /// <typeparam name="T">The type of the Flavour object (Such as Folder or File)</typeparam>
        /// <param name="flavour">The instance of the Flavour object returned</param>
        /// <returns>True if the object was found</returns>
        public bool TryGetFlavour<T>(out T flavour)
        {
            if (Items is null)
            {
                flavour = default;
                return false;
            }

            flavour = Items.OfType<T>().SingleOrDefault();
            return flavour != null;
        }

        /// <summary>
        /// Tries to get the best icon name
        /// </summary>
        public string Icon
        {
            get
            {
                var flav = Flavours.FirstOrDefault();
                return NbExt.FirstNonEmptyString(icon, flav?.icon, flav?.DefIcon, "default");
            }
        }

        /// <summary>
        /// Return the value of one of Nodes generic fields: Id, Name, Icon. Other fields will be available in Flavours.
        /// </summary>
        /// <param name="fldName">Name of the field</param>
        /// <param name="fieldValue">The string value of the fields returned</param>
        /// <returns>True if such fields was found, otherwise false</returns>
        public bool TryGetFieldValue(string fldName, out string fieldValue)
        {
            switch (fldName)
            {
                case nameof(id):
                    fieldValue = id;
                    return true;
                case nameof(name):
                    fieldValue = name;
                    return true;
                case nameof(icon):
                    fieldValue = icon;
                    return true;
                default:
                    fieldValue = null;
                    return false;
            }
        }

        internal IEnumerable<(int level, Node node)> FlatTree(string refTypeName) =>
            GetChildren(refTypeName).SelectMany(nd => nd.FlatTree(refTypeName), (_, p) => (p.level + 1, p.node)).Prepend((0, this));

        internal IEnumerable<(int level, Node node)> FlatTreeOrdered<T>(string refTypeName, Func<Node, T> keySelector) =>
            GetChildren(refTypeName).OrderBy(keySelector).SelectMany(nd => nd.FlatTreeOrdered(refTypeName, keySelector), (_, p) => (p.level + 1, p.node)).Prepend((0, this));

        /// <summary>
        /// Prints a tree for a given reference type name into a string
        /// </summary>
        /// <param name="refTypeName"></param>
        /// <returns></returns>
        public string PrintTree(string refTypeName)
        {
            StringBuilder bld = new StringBuilder();
            foreach ((int level, Node nd) in FlatTreeOrdered(refTypeName, n => n.name))
            {
                for (int i = 0; i < level; ++i)
                    bld.Append("  ");
                //bld.Append(i == 0 ? "|-" : "--");

                bld.AppendLine(nd.ToString());
            }

            return bld.ToString();
        }

        internal string NamePath(string refTypeName, FlvNames flvName)
        {
            Node parentN = GetParents(refTypeName).Where(p => p.HasFlavour(flvName)).SingleOrDefaultVerbose(null, i => $"There are '{i}' parents for '{name}' node with '{refTypeName}' reference type. The graph is not a tree");
            if (parentN == null)
                return name;
            else
                return parentN?.NamePath(refTypeName, flvName) + Path.DirectorySeparatorChar + name; //TODO think about string builder
        }

        /// <summary>
        /// Going through the ReferencesN List, taking only direct links (to parents) and getting the nodes out of links
        /// </summary>
        /// <param name="refName">The string with the reference type name is used because the reference type can be a different object from a different model</param>
        /// <returns></returns>
        public IEnumerable<Node> GetParents(string refName) => ReferencesN.Safe().Where(r => !r.IsForward && refName.Equals(r.RefType.id)).Select(r => r.Node);

        /// <summary>
        /// Going through the ReferencesN List, taking only direct links (to children, not to parents) and getting the nodes out of links
        /// </summary>
        /// <param name="refName">The string with the reference type name is used because the reference type can be a different object from a different model</param>
        /// <returns></returns>
        public IEnumerable<Node> GetChildren(string refName) => ReferencesN.Safe().Where(r => r.IsForward && refName.Equals(r.RefType.id)).Select(r => r.Node);

        /// <summary>
        /// List all the children of the node using multiple filters
        /// </summary>
        /// <param name="refTypeNameN"></param>
        /// <param name="nodeNameN"></param>
        /// <param name="flavNameN"></param>
        /// <returns></returns>
        public IEnumerable<Node> GetChildren(string refTypeNameN = null, string nodeNameN = null, FlvNames? flavNameN = null)
        {
            foreach (var rfr in ReferencesN.Safe().Where(r => r.IsForward))
            {
                if (refTypeNameN != null && rfr.RefType.id != refTypeNameN)
                    continue;
                if (nodeNameN != null && rfr.Node.name != nodeNameN)
                    continue;
                if (flavNameN != null && !rfr.Node.Flavours.Any(f => f.FlavourName == flavNameN))
                    continue;
                yield return rfr.Node;
            }
        }



        internal bool IsChild(Node dstN, string refTypeName) => GetChildren(refTypeName).Any(nd => nd.Equals(dstN));


        /// <summary>
        /// Goes through the list of direct links in ReferencesN, checks that the child node has one of the provided flavours
        /// </summary>
        /// <param name="flavours">Array with flavour names to be matched with when searching</param>
        /// <returns></returns>
        public IEnumerable<Node> GetChildrenWithFlavours(params FlvNames[] flavours) => ReferencesN.Where(r => r.IsForward).Select(r => r.Node).Where(n => n.HasAnyFlavour(flavours));

        internal void RemoveAllRefsTo(Node nd)
        {
            if (ReferencesN == null)
                return; //No references to delete

            for (int i = ReferencesN.Count - 1; i >= 0; i--) //Going backwards in order to be able to delete as we go
            {
                if (Object.ReferenceEquals(ReferencesN[i].Node, nd))
                    ReferencesN.RemoveAt(i);

            }
        }

        internal void UpdateFieldsFrom(Node other)
        {
            //Compare Flavours as lists and generate diffs


            //Compare references and generate diffs

            throw new NotImplementedException();
        }

        /// <summary>
        /// Compares two nodes and generates the changes between the nodes as series of PropertyChange objects
        /// </summary>
        /// <param name="other">The node to compare to</param>
        /// <returns></returns>
        /// <exception cref="NotImplementedException"></exception>
        public IEnumerable<PropertyChange> GetChanges(Node other)
        {
            Dictionary<FlvNames, Flavour> flvBs = other.Flavours.ToDictionary(f => f.FlavourName);

            foreach (Flavour flvA in Flavours)
            {
                if (flvBs.TryGetValue(flvA.FlavourName, out Flavour flvB))
                {
                    foreach (var change in flvA.GetChanges(flvB))
                        yield return change;
                }

            }
        }

        /// <summary>
        /// Conversion to A2aNodeTree Xml serializable class
        /// </summary>
        /// <param name="flavName"></param>
        /// <param name="parentId"></param>
        /// <param name="hasChildren"></param>
        /// <returns></returns>
        public A2aNodeTree ToA2aNodeTree(string flavName, string parentId, bool hasChildren = false)
        {
            return new A2aNodeTree { id = id, type = flavName, name = name, icon = icon, parentId = parentId, has_children = hasChildren };
        }
    }
}

