﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

using A2aCommands.Xml;
using all2allv1.Xml;

#nullable enable

namespace All2All.Model.Commands
{
    internal class Sync : Base
    {
        internal override string Name => nameof(Sync);

        public Sync(FlavoursModel model, IUserInterface ui) : base(model, ui) { }

        internal override IEnumerable<A2aCommand> GetSingle(Node node, FlvNames nodeType)
        {
            if (nodeType == FlvNames.sync)
            {
                FlavSync flv = GetNodeFlavour<FlavSync>(node, FlvNames.sync);
                if (!String.IsNullOrEmpty(flv.profile)) //Only if the path exists i.e. show only for root node
                    yield return new A2aCommand { id = Name, label = Name, show_on = ShowOn.ContextMenu, tooltip = "Synchronize the folder" }; //TODO: make static
            }
        }

        internal override async Task Execute(Node? srcN, FlvNames srcType, Node? dst, FlvNames dstType, object addObject)
        {
            FlavSync flv = GetNodeFlavour<FlavSync>(srcN, FlvNames.sync);
            if (A2aDialogResult.OK == await Ui.ShowDialog($"Sync the folder to {flv.profile}", "Syncing", A2aMessageBoxButtons.OKCancel, A2aMessageBoxIcon.Question))
            {
                Model.MirrorFilesTo(srcN, flv.profile);
                await Ui.ShowDialog("Done!");
            }
        }
    }
}

#nullable disable