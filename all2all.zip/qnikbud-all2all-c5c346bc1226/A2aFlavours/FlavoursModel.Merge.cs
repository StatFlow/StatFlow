﻿using System;
using System.Collections.Generic;
using System.Linq;

using NbTools;
using NbTools.Sync;

using all2allv1.Xml;

using System.Text;
using System.IO;

namespace All2All.Model
{
    public sealed partial class FlavoursModel : IDataProvider
    {
        /// <summary>
        /// Uses SyncR method to produce change events out of current and provided second model.
        /// Builds the resulting third model using the produced events and the stack for hierarchical processing
        /// </summary>
        /// <param name="_"></param>
        /// <param name="_2">The name of the reference type</param>
        /// <returns></returns>
        internal FlavoursModel MergeModelsSymmetric(FlavoursModel _, string _2)
        {
            RefType _3 = RefTypes.SingleVerbose().Value; //Single default ref-type for now (ContainsRefType)  defRefType

            //Stack<Node> stack = new Stack<Node>();
            var result = new FlavoursModel(new NullUI());
            /*foreach (var change in SyncTools.SyncR(RootNode, second.RootNode, refTypeName))
            {
                Node parNode = stack.Count() == 0 ? null : stack.Peek();

                switch (change)
                {
                    case NodeChange<Node> nodeChange:
                        switch (nodeChange.ChangeType)
                        {
                            case ChangeType.None:
                                result.AddNode(nodeChange.NodeSrc, parNode, defRefType);
                                break;
                            case ChangeType.Add:
                                result.AddNode(nodeChange.NodeDst.CloneNewId(GetNextUniqueId()), parNode, defRefType);
                                break;
                            case ChangeType.Remove:
                                nodeChange.NodeSrc.deleted = true;
                                result.AddNode(nodeChange.NodeSrc, parNode, defRefType);
                                break;
                            case ChangeType.Update:
                                result.AddNode(nodeChange.NodeDst.CloneNewId(nodeChange.NodeSrc.id), parNode, defRefType);
                                break;

                            case ChangeType.Push:
                                stack.Push(nodeChange.NodeSrc);
                                break;
                            case ChangeType.Pop:
                                var nd = stack.Pop();
                                if (!ReferenceEquals(nd, nodeChange.NodeSrc))
                                    throw new NbExceptionInfo($"Popping node doesn't match one on the stack: {nodeChange.NodeSrc} and {nd}");
                                break;

                            default:
                                throw new NbExceptionEnum<ChangeType>(nodeChange.ChangeType);
                        }
                        break;
                    default:
                        throw new NbExceptionInfo($"Unsupported change type: {change.GetType().Name}");
                }
            }*/
            return result;
        }

        public void MirrorFilesTo(Node mirrorRootNode, string dstDir)
        {
            if (!Directory.Exists(dstDir))
                throw new NbExceptionInfo($"Destination directory '{dstDir}' doesn't exist");

            MirrorFilesToRecur(mirrorRootNode, dstDir);
        }

        private void MirrorFilesToRecur(Node mirrorRootNode, string dstDir)
        {
            var di = new DirectoryInfo(dstDir);
            var dirs = new HashSet<string>(di.GetDirectories().Select(d => d.Name), StringComparer.OrdinalIgnoreCase);
            var files = new HashSet<string>(di.GetFiles().Select(f => f.Name), StringComparer.OrdinalIgnoreCase);

            foreach (var node in mirrorRootNode.GetChildren(ContainsRefType.id))
            {
                if (node.HasAnyFlavour(FlvNames.folder, FlvNames.sync))
                {
                    string subDir = Path.Combine(dstDir, node.name);
                    if (!dirs.Contains(node.name))
                        Directory.CreateDirectory(subDir);
                    else
                        dirs.Remove(node.name);

                    MirrorFilesToRecur(node, subDir); //Recursive call
                }
                else if (node.HasFlavour(FlvNames.file))
                {
                    string dstFileName = Path.Combine(dstDir, node.name);
                    string srcFileName = node.NamePath(ContainsRefType.id, FlvNames.folder);
                    if (!File.Exists(srcFileName))
                        throw new NbExceptionInfo($"Source file '{srcFileName}' doesn't exist");

                    if (!files.Contains(node.name))
                        File.Copy(srcFileName, dstFileName);
                    else
                        files.Remove(node.name);
                }
            }

            foreach (var d in dirs)
                Directory.Delete(Path.Combine(dstDir, d), recursive: true);
            foreach (var f in files)
                File.Delete(Path.Combine(dstDir, f));
        }

        /// <summary>
        /// Method for merging the other node collection into this one. 
        /// </summary>
        /// <param name="other">The collection being merged into the current one</param>
        /// <param name="pars">Object with various settings</param>
        /// <returns>Enumerable of NodeChanges (like events)</returns>
        public IEnumerable<NodeChange<Node, Node>> MergeIn<T>(FlavoursModel other, MergeParameters<T> pars)
        {
            RefType refTypeA = RefTypes[pars.ReferencefTypeA];
            RefType refTypeB = other.RefTypes[pars.ReferencefTypeB];

            return MergeNodeIn(RootNode, other.RootNode, refTypeA, refTypeB, pars);
        }

        private IEnumerable<NodeChange<Node, Node>> MergeNodeIn<T>(Node rootA, Node rootB, RefType refTypeA, RefType refTypeB, MergeParameters<T> pars)
        {
            var A = rootA.GetChildren(refTypeA.id).ToList();
            var B = rootB.GetChildren(refTypeB.id).ToDictionary(pars.KeySelector ?? throw new NbExceptionInfo("Key selector is mandatory"));

            //Processing nodes
            foreach (var ndA in A.Safe())
            {
                if (B.TryGetValue(pars.KeySelector(ndA), out Node ndB)) //TODO: think about more complicated matching, such as on contents
                {   //Match if found with modelB => examine properties, continue the merge recursively.
                    var propChanges = ndA.GetChanges(ndB);
                    if (propChanges.Any())
                        yield return new NodeChange<Node, Node>(ChangeType.Update, ndA, ndB, propChanges);
                    else if (pars.ProduceNoChangeEvents)
                        yield return new NodeChange<Node, Node>(ChangeType.None, ndA, ndB);

                    if (ndA.HasChildren(refTypeA) || ndB.HasChildren(refTypeB)) //If both nodes are collections and one of them has children
                    {
                        foreach (var res in MergeNodeIn(ndA, ndB, refTypeA, refTypeB, pars))
                            yield return res;
                    }

                    B.Remove(pars.KeySelector(ndB));
                }
                else
                {   //No match with ModelB => delete from ModelA
                    if (pars.MarkForDeletion)
                        ndA.deleted = true;
                    else
                        DeleteNode(ndA.id);
                    yield return new NodeChange<Node, Node>(ChangeType.Remove, ndA, null);
                }
            }

            foreach (var ndB in B.Values) //Only new remaining
            {
                Node newA = AddNewNode(ndB, rootA, refTypeA);
                yield return new NodeChange<Node, Node>(ChangeType.Add, null, ndB);

                if (ndB.HasChildren(refTypeB))
                {
                    foreach (var res in MergeNodeIn(newA, ndB, refTypeA, refTypeB, pars))
                        yield return res;
                }
            }

        }

        internal void DisconnectNodes(Node childNode, Node parentNode, RefType refType)
        {
            throw new NotImplementedException();
        }

        /*public IEnumerable<BaseChange<Node>> MergeIn(INodeColl<Node> other, string refTypeName, bool markForDeletion = true)
        {
            RefType defRefType = RefTypes.SingleVerbose().Value; //Single default ref-type for now (ContainsRefType)

            Stack<Node> stack = new Stack<Node>();
            foreach (var change in SyncTools.SyncR(RootNode, other, refTypeName))
            {
                Node parNode = stack.Count() == 0 ? null : stack.Peek();
                switch (change)
                {
                    case NodeChange<Node> nodeChange:
                        switch (nodeChange.ChangeType)
                        {
                            case ChangeType.None:
                                break;

                            case ChangeType.Add:
                                AddNode(nodeChange.NodeDst.CloneNewId(GetNextUniqueId()), parNode, defRefType);
                                break;

                            case ChangeType.Remove:
                                if (markForDeletion)
                                    nodeChange.NodeSrc.deleted = true;
                                else
                                    RemoveNode(nodeChange.NodeSrc.Key);
                                break;

                            case ChangeType.Update:
                                UpdateNode(nodeChange.NodeSrc.Key, nodeChange.NodeDst);
                                break;

                            case ChangeType.Push:
                                stack.Push(nodeChange.NodeSrc);
                                break;

                            case ChangeType.Pop:
                                var nd = stack.Pop();
                                if (!ReferenceEquals(nd, nodeChange.NodeSrc))
                                    throw new NbExceptionInfo($"Popping node doesn't match one on the stack: {nodeChange.NodeSrc} and {nd}");
                                break;

                            default:
                                throw new NbExceptionEnum<ChangeType>(nodeChange.ChangeType);
                        }
                        break;
                    default:
                        throw new NbExceptionInfo($"Unsupported change type: {change.GetType().Name}");
                }
                yield return change;
            }
        }*/
    }

    /// <summary>
    /// Object containing the parameters of the MergeIn operation
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class MergeParameters<T>
    {
        /// <summary>
        /// Reference type definiting the tree structure of the recepient model
        /// </summary>
        public string ReferencefTypeA;
        /// <summary>
        /// Reference type definiting the tree structure of the donor model
        /// </summary>
        public string ReferencefTypeB;

        /// <summary>
        /// The key to match the nodes, name is the most common
        /// </summary>
        public Func<Node, T> KeySelector;

        /// <summary>
        /// if true the current node is only marked for deletion, false - it is deleted straight away
        /// </summary>
        public bool MarkForDeletion = false;
        /// <summary>
        /// Suppress NoChange events which have very limited use
        /// </summary>
        public bool ProduceNoChangeEvents = false;
    }
}
