﻿using A2aCommands.Xml;
using A2aForms.Xml;
using A2aTypes.Xml;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace All2All.Model
{
    public static class Immediate
    {
        public static void Main(string[] arg)
        {

            //string fileName = @"C:\Repo\All2All\All2AllModel\MusExample.xml";

            //Debug.Print("Test");

            //A2AModel mdl = new A2AModel(new DummyUi());
            //mdl.LoadFromXml(fileName);
        }


        class DummyUi : IUserInterface
        {
            public void AddAllFields(UpdateType updType, string nodeId, string nodeType, string[] columns, int requestId) => throw new NotImplementedException();

            public void AddSimple(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId) => throw new NotImplementedException();
            public void AddWebPage(string html, int requestId) => throw new NotImplementedException();
            public Task<bool> EditForm(A2aFormParameters formParams) => throw new NotImplementedException();
            public void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId) => throw new NotImplementedException();
            public void SetStatus(string message) => throw new NotImplementedException();
            public Task<string> ShowDialog(string message) => throw new NotImplementedException();

            public void AddAllFields(UpdateType updType, string[] columns, int requestId)
            {
                throw new NotImplementedException();
            }

            public Task<A2aDialogResult> ShowDialog(string message, string caption, A2aMessageBoxButtons btns, A2aMessageBoxIcon info)
            {
                throw new NotImplementedException();
            }

            public Task<A2aForm> ShowDynamicForm(A2aForm form)
            {
                throw new NotImplementedException();
            }

            public void UpdateNode(UpdateType updType, A2aNodeTree node, int requestId)
            {
                throw new NotImplementedException();
            }
        }
    }
}

