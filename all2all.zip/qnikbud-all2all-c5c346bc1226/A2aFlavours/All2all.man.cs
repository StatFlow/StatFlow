﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

using NbTools;
using NbTools.Sync;

namespace all2allv1.Xml
{
    public partial class RefType : IEquatable<RefType>
    {
        /// <remarks/>
        public bool Equals(RefType other) => id.EqIC(other?.id);

        /// <remarks/>
        public override string ToString() => $"RefType: #{id} '{meaning}'";
    }

    /// <summary>
    /// Enum of all possible flavours - think about defining it in FlavourXml
    /// </summary>
    public enum FlvNames
    {
        /// <remarks/>
        none = 0,
        /// <remarks/>
        audio,
        /// <remarks/>
        file,
        /// <remarks/>
        folder,
        /// <remarks/>
        lm_launcher,
        /// <remarks/>
        lm_link,
        /// <remarks/>
        playable,
        /// <remarks/>
        video,
        /// <remarks/>
        sync
    }


    public abstract partial class Flavour
    {
        /// <remarks/>
        public static FlvNames ParseFlvName(string flvName)
        {
            if (String.IsNullOrWhiteSpace(flvName))
                return FlvNames.none;
            if (!Enum.TryParse<FlvNames>(flvName, out var flavourName))
                throw new NbExceptionInfo($"Can't find flavour name '{flvName}'");
            return flavourName;
        }

        /// <summary>
        /// Flavour name    
        /// </summary>
        [XmlIgnore]
        public abstract FlvNames FlavourName { get; } //TODO: think about using the type names instead of other names?

        internal virtual IEnumerable<PropertyChange> GetChanges(Flavour flvB) { yield break; }

        /// <remarks/>
        [XmlIgnore]
        public virtual string DefIcon => "default";

        /// <summary>
        /// Get the value of the field
        /// </summary>
        /// <param name="name">Field name</param>
        /// <param name="n">Node</param>
        /// <returns></returns>
        public virtual string GetFieldValue(string name, Node n) => name switch
        {
            "name" => n.name,
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };

        /// <summary>
        /// Constructs empty flavour by its name
        /// </summary>
        /// <param name="flvNameStr">Flavour name as string</param>
        /// <returns>Flavour class</returns>
        /// <exception cref="NbExceptionEnum{FlvNames}">Throws if the enum options is not yet supported</exception>
        public static Flavour Construct(string flvNameStr) => Construct(ParseFlvName(flvNameStr));

        /// <summary>
        /// Constructs empty flavour by its name
        /// </summary>
        /// <param name="flvNames">Flavour name</param>
        /// <returns>Flavour class</returns>
        /// <exception cref="NbExceptionEnum{FlvNames}">Throws if the enum options is not yet supported</exception>
        public static Flavour Construct(FlvNames flvNames) => flvNames switch
        {
            FlvNames.none => null,
            FlvNames.audio => new FlavAudioFile(),
            FlvNames.file => new FlavFile() { created = DateTime.UtcNow }, //TODO: think about making created a base property
            FlvNames.folder => new FlavFolder() { created = DateTime.UtcNow },
            FlvNames.lm_launcher => new FlavLmLauncher(),
            FlvNames.lm_link => new FlavLmLink(),
            FlvNames.playable => new FlavPlayable(),
            FlvNames.video => new FlavVideoFile(),
            FlvNames.sync => new FlavSync(),
            _ => throw new NbExceptionEnum<FlvNames>(flvNames),
        };
    }

    public partial class FlavVideoFile : Flavour
    {
        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.video;

        //TODO: thing about Reflection reading here
        /// <remarks/>
        public override string GetFieldValue(string name, Node n) => name switch
        {
            "name" => n.name,
            nameof(bit_rate) => bit_rate.ToString(),
            nameof(duration) => duration.ToString(),
            nameof(hight) => hight.ToString(),
            nameof(width) => width.ToString(),
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };
    }

    public partial class FlavPlayable : Flavour
    {
        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.playable;
    }

    public partial class FlavFolder : Flavour
    {
        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.folder;
        /// <remarks/>
        public override string DefIcon => "folder";
    }

    public partial class FlavSync : Flavour
    {
        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.sync;
    }

    public partial class FlavFile : Flavour
    {
        /// <remarks/>
        public FlavFile() { }

        /// <remarks/>
        public FlavFile(FileInfo fi)
        {
            file_name = fi.Name;
            extension = fi.Extension;
            length = fi.Length;
            created = fi.CreationTime;
            accessed = fi.LastAccessTime;
            modified = fi.LastWriteTime;
        }

        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.file;

        internal IEnumerable<PropertyChange> GetChanges(FileInfo fi)
        {
            if (file_name != fi.Name)
                yield return new PropertyChange(ChangeType.Update, nameof(file_name), file_name, fi.Name);
            if (extension != fi.Extension)
                yield return new PropertyChange(ChangeType.Update, nameof(extension), extension, fi.Extension);
            if (length != fi.Length)
                yield return new PropertyChange(ChangeType.Update, nameof(length), length, fi.Length);
            if (created != fi.CreationTime)
                yield return new PropertyChange(ChangeType.Update, nameof(created), created, fi.CreationTime);
            if (accessed != fi.LastAccessTime)
                yield return new PropertyChange(ChangeType.Update, nameof(accessed), accessed, fi.LastAccessTime);
            if (modified != fi.LastWriteTime)
                yield return new PropertyChange(ChangeType.Update, nameof(modified), modified, fi.LastWriteTime); //TODO: think about using UTC
        }

        /// <remarks/>
        public override string GetFieldValue(string name, Node n) => name switch
        {
            nameof(file_name) => file_name,
            nameof(extension) => extension,
            nameof(length) => length.ToString(),
            nameof(created) => created.ToString(),
            nameof(accessed) => accessed.ToString(),
            nameof(modified) => modified.ToString(),
            _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
        };
    }

    public partial class FlavAudioFile : Flavour
    {
        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.audio;
    }


    public partial class FlavLmLink : Flavour
    {
        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.lm_link;
        /// <remarks/>
        public override string GetFieldValue(string name, Node n) //TODO: take node and error login to the base class and have the TryGetValue abstract method here, think about reflection for now
        {
            if (n.TryGetFieldValue(name, out var res)) //Fields are found in the Node itself (id, name, icon)
                return res;

            return name switch
            {
                nameof(accessed) => accessed.ToString(),
                nameof(archived) => archived.ToString(),
                nameof(clipboard) => clipboard.ToString(),
                nameof(shortcut) => shortcut.ToString(),
                nameof(url) => url.ToString(),
                _ => throw new NbExceptionInfo($"Unsupported field '{name}' in flavour '{FlavourName}'")
            };
        }
    }

    public partial class FlavLmLauncher : Flavour
    {
        /// <remarks/>
        public override FlvNames FlavourName => FlvNames.lm_launcher;
    }
}
