﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NbTools;
using NbTools.Media;

using A2aCommands.Xml;
using A2aForms.Xml;
using all2allv1.Xml;
using All2All;
using All2All.Model;

#nullable enable

namespace All2All.Model.Commands
{
    internal abstract class Base
    {
        internal abstract string Name { get; }
        internal protected readonly IUserInterface Ui;
        internal protected readonly FlavoursModel Model;

        internal Base(FlavoursModel model, IUserInterface ui)
        {
            Model = model;
            Ui = ui;
        }

        internal virtual IEnumerable<A2aCommand> GetSingle(Node node, FlvNames nodeType) { yield break; }
        internal virtual IEnumerable<A2aCommand> GetDragCommands(A2aNode? src, FlvNames srcType, A2aNode dst, FlvNames dstType, ClipboardData[] formats) { yield break; }
        internal abstract Task Execute(Node? srcN, FlvNames srcType, Node? dst, FlvNames dstType, object addObject);

        protected F GetNodeFlavour<F>(Node? nd, FlvNames flvName, bool isSource = true)
            where F : Flavour
        {
            if (nd == null)
                throw new Exception($"{(isSource ? "Source" : "Destination")} node must be provided for '{GetType().Name}' {Name} command");
            if (!nd.TryGetFlavour(flvName, out Flavour flv))
                throw new Exception($"{(isSource ? "Source" : "Destination")} node '{nd.id}' doesn't contain required flavour '{flvName}' in '{GetType().Name}' {Name} command");
            var flavour = flv as F ?? throw new Exception($"{(isSource ? "Source" : "Destination")} node '{nd.id}' doesn't contain required flavour '{flvName}' in '{GetType().Name}' {Name} command"); ;
            return flavour;
        }

        internal static IEnumerable<Base> Commands(FlavoursModel mdl, IUserInterface ui)
        {
            yield return new CommandOpen(mdl, ui); //Doesn't need MDL, but other commands to need it
            yield return new CommandAddNode(mdl, ui);
            yield return new CommandUpdateNode(mdl, ui);
            yield return new CommandRemoveNode(mdl, ui);
            yield return new CommandNodeDrop(mdl, ui);
            yield return new CommandFileDrop(mdl, ui);
            yield return new Sync(mdl, ui);

            //yield return new CommandDebugInfo(ui);
        }
    }

    internal class CommandOpen : Base
    {
        internal override string Name => "Open";
        public CommandOpen(FlavoursModel model, IUserInterface ui) : base(model, ui) { }

        internal override IEnumerable<A2aCommand> GetSingle(Node node, FlvNames nodeType)
        {
            if (nodeType == FlvNames.file || nodeType == FlvNames.folder || nodeType == FlvNames.lm_link)
                yield return new A2aCommand { id = Name, label = Name, hotkey = "LButton", show_on = ShowOn.ToolbarAndContextMenu, tooltip = "Open provided URL or document" }; //TODO: make static
        }

        const string FireFox = @"C:\Program Files\Mozilla Firefox\firefox.exe";

        internal override async Task Execute(Node? srcN, FlvNames srcType, Node? dst, FlvNames dstType, object addObject)
        {
            if (srcN == null)
                throw new NbExceptionInfo($"Source Node must be provided for '{Name}' command");
            if (!srcN.TryGetFlavour(srcType, out Flavour flv))
                throw new Exception($"Source Node '{srcN.id}' doesn't contain the flavour '{srcType}'");

            switch (srcType)
            {
                case FlvNames.lm_link:
                    FlavLmLink flav = flv as FlavLmLink ?? throw new Exception($"{nameof(FlvNames.lm_link)} is not a {nameof(FlavLmLink)}"); //TODO: think of better casting
                    var (_, _1, _2) = await NbProcess.RunAsync(FireFox, null, flav.url);
                    break;

                case FlvNames.folder:
                    var path1 = srcN.NamePath(FlavoursModel.ContainsRefType.id, FlvNames.folder); //Only use folders to trace up the path
                    Process.Start("explorer.exe", $"/select,\"{path1}\"");
                    break;

                case FlvNames.file:
                    var path2 = srcN.NamePath(FlavoursModel.ContainsRefType.id, FlvNames.folder); //Only use folders to trace up the path
                    Process.Start(new ProcessStartInfo { Verb = "open", FileName = $"\"{path2}\"" });
                    break;

                default:
                    throw new NbExceptionInfo($"Flavour {srcType} is not supported in '{Name}' command");
            }
        }
    }

    internal class CommandAddNode : Base
    {
        internal override string Name => "Add Node";

        public CommandAddNode(FlavoursModel model, IUserInterface ui) : base(model, ui) { }

        internal override IEnumerable<A2aCommand> GetSingle(Node node, FlvNames nodeType)
        {
            //if (nodeType == FlvNames.folder) //All for all types for now
            yield return new A2aCommand { id = Name, label = Name, show_on = ShowOn.ToolbarAndContextMenu, icon = "folder", hotkey = "Insert", tooltip = "Add child folder" }; //TODO: make static
        }

        //No Drag Commands

        internal override async Task Execute(Node? srcN, FlvNames srcType, Node? dst, FlvNames dstType, object addObject)
        {
            if (srcN == null)
                throw new NbArgumentException(nameof(srcN), $"source folder is required in '{nameof(CommandAddNode)}' command");

            RefType refType = FlavoursModel.ContainsRefType;

            var form = new A2aForm(
                new A2aFormFieldString { id = "Name", label = "Folder name", val = "New Folder" },
                new A2aFormFieldEnum { id = "Type", label = "Type", list = Enum.GetNames(typeof(FlvNames)) });

            form.SetButtons(
                new A2aFormButton { id = "OK", label = "Create Node", type = A2aFormButtonTypes.Enter },
                new A2aFormButton { id = "Cancel", label = "Cancel", type = A2aFormButtonTypes.Esc });

            var resForm = await Ui.ShowDynamicForm(form);
            if (resForm == null)
            {
                Ui.SetStatus($"User Cancelled");
                return;
            }

            var fldName = resForm.field[0] as A2aFormFieldString ?? throw new NbExceptionInfo("Form field mismatch");
            var fldType = resForm.field[1] as A2aFormFieldEnum ?? throw new NbExceptionInfo("Form field mismatch");

            Flavour flav = Flavour.Construct(fldType.val);
            Node nd = Model.AddNode(id: null, name: fldName.val, icon: null, parentNodeN: srcN, refType: refType, flav);

            var nodeTree = nd.ToA2aNodeTree(fldType.val, srcN.id);
            Ui.UpdateNode(UpdateType.Add, nodeTree, requestId: 0);

            Ui.SetStatus($"Node '{nd.name}' added");
        }
    }

    internal class CommandUpdateNode : Base
    {
        internal override string Name => "Update Node";

        public CommandUpdateNode(FlavoursModel model, IUserInterface ui) : base(model, ui) { }

        internal override IEnumerable<A2aCommand> GetSingle(Node node, FlvNames nodeType)
        {
            //if (nodeType == FlvNames.folder) //All for all types for now
            yield return new A2aCommand { id = Name, label = Name, show_on = ShowOn.ToolbarAndContextMenu, icon = "folder", hotkey = "F2", tooltip = "Edit node" }; //TODO: make static
        }

        //No Drag Commands

        internal override async Task Execute(Node? srcN, FlvNames srcType, Node? dst, FlvNames dstType, object addObject)
        {
            if (srcN == null)
                throw new NbArgumentException(nameof(srcN), $"source folder is required in '{nameof(CommandAddNode)}' command");

            RefType refType = FlavoursModel.ContainsRefType;

            var form = new A2aForm(
                new A2aFormFieldString { id = "Name", label = "Folder name", val = srcN.name },
                new A2aFormFieldString { id = "Type", label = "Type readonly", val = String.Join(", ", srcN.Flavours.Safe().Select(f => f.FlavourName)) },
                new A2aFormFieldString { id = "Icon", label = "Icon", val = srcN.Icon }
            );

            form.SetButtons(
                new A2aFormButton { id = "OK", label = "Update Node", type = A2aFormButtonTypes.Enter },
                new A2aFormButton { id = "Cancel", label = "Cancel", type = A2aFormButtonTypes.Esc });

            var resForm = await Ui.ShowDynamicForm(form);
            if (resForm == null)
            {
                Ui.SetStatus($"User Cancelled");
                return;
            }

            var fldName = resForm.field[0] as A2aFormFieldString ?? throw new NbExceptionInfo("Form field mismatch");
            var fldIcon = resForm.field[2] as A2aFormFieldString ?? throw new NbExceptionInfo("Form field mismatch");

            srcN.name = fldName.val; //TODO: detect real change
            srcN.icon = fldIcon.val;

            var nodeTree = srcN.ToA2aNodeTree(srcType.ToString(), parentId: null); //Do we need parent here?
            Ui.UpdateNode(UpdateType.Update, nodeTree, requestId: 0);

            Ui.SetStatus($"Node '{srcN.name}' updated");
        }
    }

    internal class CommandRemoveNode : Base
    {
        internal override string Name => "Remove Node";
        private readonly RefType RefType = FlavoursModel.ContainsRefType;

        public CommandRemoveNode(FlavoursModel model, IUserInterface ui) : base(model, ui) { }

        internal override IEnumerable<A2aCommand> GetSingle(Node node, FlvNames nodeType)
        {
            yield return new A2aCommand { id = Name, label = Name, show_on = ShowOn.ToolbarAndContextMenu, hotkey = "Delete", tooltip = "Delete child node" }; //TODO: make static
        }

        //No Drag Commands

        /// <summary>
        /// Source node is the node being deleted, while the destination node is the parent. 
        /// Similar to the drag and drop situation, when the source node is dropped onto its future parent node (dst)
        /// </summary>
        /// <param name="srcN"></param>
        /// <param name="srcType"></param>
        /// <param name="dstN"></param>
        /// <param name="dstType"></param>
        /// <param name="addObject"></param>
        /// <returns></returns>
        /// <exception cref="NbArgumentException"></exception>
        /// <exception cref="NbExceptionInfo"></exception>
        internal override async Task Execute(Node? srcN, FlvNames srcType, Node? dstN, FlvNames dstType, object addObject)
        {
            if (srcN == null)
                throw new NbArgumentException(nameof(srcN), $"source folder is required in '{nameof(CommandAddNode)}' command");

            int parentsCount = srcN.GetParents(RefType.id).Count();
            var userAnswer = parentsCount > 1 ?
                await Ui.ShowDialog($"Nod '{srcN.name}' is referred from {parentsCount} other nodes. Only this reference will be removed. Do you want to continue?") :
                await Ui.ShowDialog($"This is the only reference to the node '{srcN.name}'. Do you want to delete it?");

            if (userAnswer != "Yes")
                return;

            if (parentsCount > 1)
            {
                if (dstN == null)
                    throw new NbExceptionInfo("Need to know the parent node in order to disconnect the current node");
                Model.DisconnectNodes(childNode: srcN, parentNode: dstN, RefType);  //TODO: Need to know whos is the parent
            }
            else
                Model.DeleteNode(srcN.id);

            var nodeTree = srcN.ToA2aNodeTree(srcType.ToString(), parentId: null);//TODO: Need to know whos is the parent
            Ui.UpdateNode(UpdateType.Remove, nodeTree, requestId: 0);
        }
    }


    /// <summary>
    /// Support for internal drag'n'drop (Node on Node)
    /// </summary>
    internal class CommandNodeDrop : Base //TODO: think - have a button, that uses current contents of the clipboard to drag/drop
    {
        private readonly RefType RefType = FlavoursModel.ContainsRefType;

        internal override string Name => "NodeDrop";
        public CommandNodeDrop(FlavoursModel model, IUserInterface ui) : base(model, ui) { }

        internal override IEnumerable<A2aCommand> GetDragCommands(A2aNode? src, FlvNames srcType, A2aNode dst, FlvNames dstType, ClipboardData[] formats)
        {
            if (src == null) //Internal drop needs source file
                yield break;

            //TODO: implement the matrix of support - which node is allowed to be dropped on which node?
            yield return new A2aCommand { id = Name, label = "Node Drop", src = src, dst = dst };
        }


        internal override async Task Execute(Node? dragNode, FlvNames dragType, Node? dropNode, FlvNames dropType, object addObject)
        {
            if (dragNode == null) throw new NbArgumentException(nameof(dragNode), $"Source node is required in internal drag & drop command");
            if (dropNode == null) throw new NbArgumentException(nameof(dropNode), $"Destination node is required in internal drag & drop command");

            if (dragNode.IsChild(dropNode, RefType.id)) //Check if already exists.
            {
                await Ui.ShowDialog($"{dragNode} already {RefType.meaning} {dropNode}");
                return;
            }

            //TODO: Check if breaks the tree

            Model.ConnectNodes(childNode: dragNode, parentNode: dropNode, RefType);

            var nodeTree = dragNode.ToA2aNodeTree(dragType.ToString(), dropNode.id);
            Ui.UpdateNode(UpdateType.Add, nodeTree, requestId: 0);
        }
    }


    /// <summary>
    /// Support for external drag and drop (from Windows Explorer)
    /// </summary>
    internal class CommandFileDrop : Base //TODO: think - have a button, that uses current contents of the clipboard to drag/drop
    {
        private readonly FlvNames[] NodesSupportingFileDrop = new[] { FlvNames.folder };

        internal override string Name => "FileDrop";
        public CommandFileDrop(FlavoursModel model, IUserInterface ui) : base(model, ui) { }
        //No Button presses

        internal override IEnumerable<A2aCommand> GetDragCommands(A2aNode? src, FlvNames srcType, A2aNode dst, FlvNames dstType, ClipboardData[] formats)
        {
            if (!formats.Contains(ClipboardData.FileDrop))
                yield break;

            if (NodesSupportingFileDrop.Contains(dstType))
                yield return new A2aCommand { id = Name, label = "File Drop", src = src, dst = dst, data_requred = ClipboardData.FileDrop }; //Request additional information on FileDrop
        }

        internal override async Task Execute(Node? srcN, FlvNames srcType, Node? dst, FlvNames dstType, object addObject)
        {
            if (dst == null) throw new NbExceptionInfo($"Destination node is not speciefied in '{Name}' command");
            string[] files = addObject as string[] ?? throw new Exception($"FileDrop additional object is not string[], but {(addObject?.GetType().Name ?? "NULL")}");

            List<string> exts = files.GroupBy(f => Path.GetExtension(f).TrimStart('.').ToLowerInvariant()).Select(g => g.Key).ToList();
            if (exts.Count == 0) //No files provided
                return;
            if (exts.Count > 1)
            {
                await Ui.ShowDialog($"Drag and Drop for files with different extensions is not supported: {String.Join(", ", exts)}", "Drag and Drop", A2aMessageBoxButtons.OK, A2aMessageBoxIcon.Stop);
                return;
            }

            string ext = exts[0];
            switch (ext)
            {
                case "url":
                    foreach (FileInfo fi in files.Select(f => new FileInfo(f)))
                    {
                        (string url, string linkName) = NbMedia.ProcessUrlLinkFile(fi);
                        var res = await Ui.ShowDialog($"Add link '{linkName}' to {dstType} node '{dst.name}'", "Drag and Drop", A2aMessageBoxButtons.YesNoCancel, A2aMessageBoxIcon.Question);
                        switch (res)
                        {
                            case A2aDialogResult.Yes:
                                FlavLmLink flav = new FlavLmLink { url = url, accessed = DateTime.Now };
                                Node nd = Model.AddNode(id: null, name: linkName, icon: null, parentNodeN: dst, refType: FlavoursModel.ContainsRefType, flav);

                                var nodeTree = nd.ToA2aNodeTree(flav.FlavourName.ToString(), dst.id);
                                Ui.UpdateNode(UpdateType.Add, nodeTree, requestId: 0);

                                //TODO: refresh node?
                                //await Ui.ShowDialog($"Command {cmdName}. Dropping Url onto {dst.type} #{dst.id}");
                                break;
                            case A2aDialogResult.No:
                                break;
                            case A2aDialogResult.Cancel:
                                goto endloop;
                            default: throw new Exception($"Unexpectd reply from Dialog: {res}");
                        }
                    }
                endloop: break;
            }
        }
    }


    internal class CommandDebugInfo : Base
    {
        public CommandDebugInfo(FlavoursModel model, IUserInterface ui) : base(model, ui) { }

        internal override string Name => "DebugInfo";

        internal override Task Execute(Node? srcN, FlvNames srcType, Node? dst, FlvNames dstType, object addObject) =>
            Ui.ShowDialog($"Command DebugInfo: Node '{srcN}' of type '{srcType}' => Node '{dst}' of type '{dstType}'. Clipboard object: {addObject}");

        internal override IEnumerable<A2aCommand> GetDragCommands(A2aNode? src, FlvNames srcType, A2aNode dst, FlvNames dstType, ClipboardData[] formats)
        {
            yield return new A2aCommand { id = Name, label = Name, show_on = ShowOn.ContextMenu, tooltip = "Debug command" };
        }

        internal override IEnumerable<A2aCommand> GetSingle(Node node, FlvNames nodeType)
        {
            yield return new A2aCommand { id = Name, label = Name, show_on = ShowOn.ContextMenu, tooltip = "Debug command" };
        }
    }
}

#nullable disable