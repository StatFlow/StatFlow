﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Runtime.CompilerServices;

using NbTools;
using NbTools.Collections;
using NbTools.Sync;
using NbTools.SqlGen.Xml;

using all2allv1.Xml;
using A2aCommands.Xml;
using A2aTypes.Xml;
using log4net;

[assembly: InternalsVisibleTo("All2AllModelTest")]

#nullable enable

namespace All2All.Model
{
    /// <summary>
    /// The All2All model providing the sup-entries (Flavours) for every node. The data is stored in XML
    /// </summary>
    public sealed partial class FlavoursModel : NullDataProvider
    {
        /// <summary>
        /// The root nodes of the model. Publicly shared for Merge code, should be hidden later
        /// </summary>
        public Node RootNode;

        internal static readonly ILog Log = LogManager.GetLogger(nameof(FlavoursModel));

        private readonly IUserInterface Ui;
        internal NbDictionary<string, Node> Nodes;
        private NbDictionary<string, RefType> RefTypes;
        private readonly NbDictionary<string, Commands.Base> Commands;

        private string? DataFileName;

        private int MaxNumericId;
        private string GetNextUniqueId() => (++MaxNumericId).ToString();

        private A2aT? A2aT; //Contains list of columns for different types and the list of screens (for now)

        /// <summary>
        /// Default reference type meaning "Contains"
        /// </summary>
        public readonly static RefType ContainsRefType = new RefType { id = "CNT", meaning = "Contains", meaning_reverse = "Contained in" };

        /// <summary>
        /// Constructor for FlavoursModel that takes the IUserInterface interface for its callbacks
        /// </summary>
        /// <param name="ui"></param>
        public FlavoursModel(IUserInterface ui)
        {
            Ui = ui;
            Nodes = new NbDictionary<string, Node>();
            RefTypes = new NbDictionary<string, RefType>();
            MaxNumericId = 1000; //Lower Ids reserved for user creating manual Nodes
            RefTypes.Add(ContainsRefType.id, ContainsRefType);
            RootNode = new Node { id = GetNextUniqueId(), name = "Root" };
            Nodes.Add(RootNode.id, RootNode);
            Commands = Model.Commands.Base.Commands(this, ui).ToNbDictionary(c => c.Name, c => c, description: "Flavour model commands");
        }

        /// <summary>
        /// Simple string representation of the Node
        /// </summary>
        /// <returns></returns>
        public override string ToString() => $"Nodes: {Nodes.Count}, Contains Children: {RootNode.GetChildren(ContainsRefType.id).Count()}";

        /// <summary>
        /// Simplified interface - add node with simple Id, Name and parent Node link
        /// </summary>
        /// <param name="id"></param>
        /// <param name="name"></param>
        /// <param name="icon"></param>
        /// <param name="parentNodeN"></param>
        /// <param name="refType">Reference type to use when connecting child to parent node. If null "Contains" ref type will be used</param>
        /// <param name="flavours">The list of flavours for the node</param>
        /// <returns>Newly created node object</returns>
        public Node AddNode(string? id, string name, string? icon, Node? parentNodeN, RefType? refType, params Flavour[] flavours)
        {
            if (id == null)
                id = GetNextUniqueId();
            else if (Nodes.ContainsKey(id))
                throw new NbExceptionInfo($"Id '{id}' already exists in the data");

            Node nd = new Node { id = id, name = name, icon = icon, Items = flavours };
            AddNode(nd, parentNodeN, refType ?? ContainsRefType);
            return nd;
        }

        /// <summary>
        /// Add a new node to the model making a clone and generating the Id appropriate for this model. The original ID record will be ignored.
        /// </summary>
        /// <param name="nd">Node to add. It will be cloned, Id will be ignored</param>
        /// <param name="parentN">Optional parent node existing in the model</param>
        /// <param name="rt">The reference type for defininig the parent-child relationship</param>
        public Node AddNewNode(Node nd, Node? parentN, RefType rt)
        {
            var newNode = nd.CloneNewId(GetNextUniqueId());
            AddNode(newNode, parentN, rt);
            return newNode;
        }

        private void AddNode(Node nd, Node? parentN, RefType rt)
        {
            Nodes.Add(nd.id, nd);
            (parentN ?? RootNode).AddDoubleRef(nd, rt);
        }

        /// <summary>
        /// Connect two existing nodes with a reference
        /// </summary>
        /// <param name="childNode">Child node</param>
        /// <param name="parentNode">Parent node</param>
        /// <param name="rt">The refrence type used for connection</param>
        public void ConnectNodes(Node childNode, Node parentNode, RefType? rt) => parentNode.AddDoubleRef(childNode, rt ?? ContainsRefType);

        /// <summary>
        /// Deletes the node from the model, removing all references to it, no check are made. Other nodes may become orphaned
        /// </summary>
        /// <param name="id"></param>
        /// <exception cref="NbExceptionInfo"></exception>
        public void DeleteNode(string id)
        {
            if (!Nodes.TryGetValue(id, out Node nd))
                throw new NbExceptionInfo($"Can't delete node with id '{id}', because it is not found in the dictionary");

            foreach (var refer in nd.ReferencesN.Safe())
            {
                refer.Node.RemoveAllRefsTo(nd);
            }
            Nodes.Remove(id);
        }

        private void UpdateNode(string key, Node other)
        {
            if (!Nodes.TryGetValue(key, out Node nd))
                throw new NbExceptionInfo($"Can't update node with key '{key}', because it is not found in the dictionary");

            nd.UpdateFieldsFrom(other);
        }


        #region Loading and Saving

        /// <summary>
        /// Initialize the model in memory using xml model and xml types files
        /// </summary>
        /// <param name="dataFile">Filename of themodel xml</param>
        /// <param name="typesFile">Filename of the types object</param>
        public void LoadFromXmlFile(string dataFile, string typesFile)
        {
            if (!File.Exists(dataFile))
                throw new NbExceptionInfo($"File '{dataFile}' doesn't exist");
            if (!File.Exists(typesFile))
                throw new NbExceptionInfo($"File '{typesFile}' doesn't exist");

            DataFileName = dataFile;
            LoadFromXmlModel(Root.LoadFile(dataFile), A2aT.LoadFile(typesFile));
        }

        /// <summary>
        /// Initialize the model in memory using xml Model and A2a Types that were loaded from XML
        /// </summary>
        /// <param name="xmlModel">Xml representation of the model parsed into xml object</param>
        /// <param name="types">The type information parsed into xmls objects</param>
        public void LoadFromXmlModel(Root xmlModel, A2aT types)
        {
            A2aT = types;
            Nodes = xmlModel.nodes.ToNbDictionary(n => n.id, n => n, description: "A2A Nodes");
            RefTypes = xmlModel.ref_types.ToNbDictionary(n => n.id, n => n, description: "A2A RefTypes");

            foreach (var rf in xmlModel.refs)
            {
                var fromNode = Nodes[rf.frm];
                var toNode = Nodes[rf.to];
                fromNode.AddDoubleRef(toNode, RefTypes[rf.typ], rf.ord);
            }

            Log.Info($"Loaded {Nodes.Count} Nodes, {RefTypes.Count} RefTypes, {xmlModel.refs.Length} references ");

            //TODO XmlModel.refs can be Garbage collected at this point
            RootNode = Nodes.Values.SingleVerbose(n => !n.HasAnyParents(), () => "Can't find any root nodes in the XML", i => $"There are {i} roots in the XML. Flavours model doesn't support multiple roots any longer");
            MaxNumericId = Nodes.Values.Max(n => Int32.TryParse(n.id, out int intId) ? intId : 0); //Get max of all ids that can be parsed to int
        }

        /// <summary>
        /// Saving the data to xml file if the model was loaded with LoadFromXmlFile() and the filename was saved.
        /// </summary>
        public void SaveToFile()
        {
            if (String.IsNullOrWhiteSpace(DataFileName))
                throw new NbExceptionInfo("DataFileName was not set in FlavourModel on loading or modeXmlFile parameter was not provided on save");

            Root r = SaveToXmlModel();
            r.Save(DataFileName);
        }

        /// <summary>
        /// Converts Flavour model data from in-memory representation to XML-bases model (where links are object and not references in lists)
        /// </summary>
        /// <returns>The Root object of the XML model that can serialize to file</returns>
        public Root SaveToXmlModel()
        {
            var xmlModel = new Root
            {
                nodes = Nodes.Values.ToArray(),
                ref_types = new RefType[] { ContainsRefType },
                next_id = MaxNumericId,
            };  //Do not initialize references, use inner lists for references

            List<Ref> refList = new List<Ref>(Nodes.Count * 2);
            foreach (Node no in xmlModel.nodes.OrderBy(n => n.id).Where(n => n.ReferencesN != null))
            {
                foreach (var rf in no.ReferencesN.Where(r => r.IsForward)) //.OrderBy(r => r.node).ThenBy(r => r.refType).ThenBy(r => r.order)
                {
                    refList.Add(new Ref() { frm = no.id, to = rf.Node.id, ord = rf.Order, typ = rf.RefType.id });
                }
            }

            return new Root()
            {
                nodes = xmlModel.nodes,
                ref_types = xmlModel.ref_types,
                refs = refList.ToArray()
            };
        }

        /// <summary>
        /// The method is loading file and directory flavours only, other flavours should be added separately
        /// </summary>
        /// <param name="dirInfo"></param>
        public void LoadFromFileStructure(DirectoryInfo dirInfo)
        {
            RefTypes = new NbDictionary<string, RefType>(1, null, "A2A RefTypes") { { ContainsRefType.id, ContainsRefType } };
            Nodes = new NbDictionary<string, Node>(1000, null, "A2A Nodes");
            RootNode = LoadFromOneDir(dirInfo, ContainsRefType); //Only one root node when loading a directory
            Nodes.Add(RootNode.id, RootNode);
        }

        /// <summary>
        /// Initialize empty model with Root name and some flavours for the root
        /// </summary>
        /// <param name="fileName">The name of XML where the modes will be saved to</param>
        /// <param name="rootName"></param>
        /// <param name="flavours"></param>
        public void InitEmptyModel(string fileName, string rootName, params Flavour[] flavours)
        {
            var fi = new FileInfo(fileName);
            if (!fi.Directory.Exists)
                throw new NbExceptionInfo($"Directory '{fi.Directory.FullName}' doesn't exist");

            DataFileName = fileName;
            RootNode.name = rootName;
            RootNode.Items = flavours;
        }


        /// <summary>
        /// The method is merging the file structure into existing model, saving on disk access
        /// </summary>
        /// <param name="dirInfo">Directory to load the files and folders from</param>
        /// <param name="refType">The reference type to use for tree structure</param>
        public IEnumerable<NodeChange<Node, FileSystemInfo>> MergeFileStructureIn(DirectoryInfo dirInfo, RefType refType)
        {
            if (RootNode is null)
                throw new NbExceptionInfo($"RootNode must be initialized before the File Structure Merge-in");
            if (Nodes is null)
                throw new ArgumentNullException(nameof(Nodes));

            return MergeFromOneDir(RootNode, dirInfo, refType);
        }

        private IEnumerable<NodeChange<Node, FileSystemInfo>> MergeFromOneDir(Node rootNode, DirectoryInfo rootDi, RefType refType)
        {
            var rootChildren = rootNode.GetChildren(refType.id).Where(n => n.HasAnyFlavour(FlvNames.folder, FlvNames.file)).ToDictionary(n => n.name, StringComparer.OrdinalIgnoreCase);

            foreach (DirectoryInfo di in rootDi.GetDirectories())
            {
                if (rootChildren.TryGetValue(di.Name, out Node nodeA)) //If such directory already exists
                {
                    //TODO: Compare dir properties

                    rootChildren.Remove(di.Name); //Remove processed dir from dictionary
                }
                else //Node doesn't exist. It a new directory
                {
                    FlavFolder flavDir = new FlavFolder { created = di.CreationTime };
                    nodeA = new Node { id = GetNextUniqueId(), name = di.Name, Items = new Flavour[] { flavDir } };  //Nodes.Count.ToString()
                    Nodes.Add(nodeA.id, nodeA);
                    rootNode.AddDoubleRef(nodeA, refType);
                    yield return new NodeChange<Node, FileSystemInfo>(ChangeType.Add, nodeA, di);
                }

                foreach (var evt in MergeFromOneDir(nodeA, di, refType)) //Whether the dir node existed or has been created - process it recursively regardless
                    yield return evt;
            }

            foreach (FileInfo fi in rootDi.GetFiles())
            {
                if (rootChildren.TryGetValue(fi.Name, out Node nodeA)) //If such file already exists
                {
                    if (!nodeA.TryGetFlavour<FlavFile>(out var flavFile))
                        throw new NbExceptionInfo($"Node {nodeA} is expected to have {nameof(FlavFile)} flavour, but is doesn't have one");

                    var propChanges = flavFile.GetChanges(fi);
                    if (propChanges.Any())
                        yield return new NodeChange<Node, FileSystemInfo>(ChangeType.Update, nodeA, fi, propChanges);

                    rootChildren.Remove(fi.Name); //Remove processed file from dictionary
                }
                else //File doesn't exist. It a new file
                {
                    FlavFile flavFile = new FlavFile(fi);
                    var flavours = NbExt.Yield<Flavour>(flavFile, GetVideoFlavourN(fi)!).ToArray(); //Take non-empty flavours
                    var nd = new Node { id = GetNextUniqueId(), name = flavFile.file_name, Items = flavours };
                    rootNode.AddDoubleRef(nd, refType);
                    Nodes.Add(nd.id, nd);

                    yield return new NodeChange<Node, FileSystemInfo>(ChangeType.Add, nd, fi);
                }
            }

            foreach (Node nodeA in rootChildren.Values) //Existing folders and files that were not found in the File Structure
            {
                foreach (var evt in DeleteSubtree(nodeA, refType))
                    yield return evt;
            }
        }


        private IEnumerable<NodeChange<Node, FileSystemInfo>> DeleteSubtree(Node nodeA, RefType refType)
        {
            var rootChildren = nodeA.GetChildren(refType.id).ToList();
            foreach (Node child in rootChildren)
                foreach (var evt in DeleteSubtree(child, refType))
                    yield return evt;

            DeleteNode(nodeA.id);
            yield return new NodeChange<Node, FileSystemInfo>(ChangeType.Remove, nodeA, null!);
        }

        private Node LoadFromOneDir(DirectoryInfo di, RefType rf)
        {
            FlavFolder flavDir = new FlavFolder { created = di.CreationTime };
            var ndr = new Node { id = GetNextUniqueId(), name = di.Name, Items = new Flavour[] { flavDir } };  //Nodes.Count.ToString()
            Nodes.Add(ndr.id, ndr);

            int ord = 0;
            foreach (DirectoryInfo subDir in di.GetDirectories())
            {
                Node subDirNode = LoadFromOneDir(subDir, rf);
                ndr.AddDoubleRef(subDirNode, rf, ord++);
            }

            ord = 0;
            foreach (FileInfo fi in di.GetFiles())
            {
                //The name of the entry is editable, the name of the file should always be equal to file
                FlavFile flavFile = new FlavFile(fi);
                var flavours = NbExt.Yield<Flavour>(flavFile, GetVideoFlavourN(fi)!).Where(i => i != null).ToArray(); //TODO: Support audio
                var nd = new Node { id = GetNextUniqueId(), name = flavFile.file_name, Items = flavours };

                ndr.AddDoubleRef(nd, rf, ord++);
                Nodes.Add(nd.id, nd);
            }

            return ndr;
        }
        #endregion Loading and Saving


        private FlavVideoFile? GetVideoFlavourN(FileInfo _1) //fl
        {
            return null;
            /*var mi = NbMediaInfo.XmlForFile(fl.FullName);
            var r = new NbMediaInfo(mi);
            if (r.Tracks.ContainsKey("Video"))
                return new FlavVideoFile { hight = r.Height, width = r.Width, duration = r.Duration };
            else
                return null;*/
        }


        #region IDataProvider implementation

        /// <summary>
        /// The name of the model to chose among many
        /// </summary>
        public override string ModelName => nameof(FlavoursModel);

        /// <summary>
        /// Get A2A Types model (loaded from XML). The Model is the client side description of screens and column types.
        /// </summary>
        /// <returns></returns>
        public override A2aT GetTypes() => A2aT ?? throw new ArgumentNullException(nameof(A2aT), $"A2aT types object was not initialized");

        /// <summary>
        /// Asks data layer to provide data for the tree view. Expected callbacks: AddSimple()
        /// </summary>
        /// <param name="parentIdN">Id of the node to get children for, if null - request for the parent node. There can only be a single parent</param>
        /// <param name="parentTypeN"></param>
        /// <param name="canToken"></param>
        /// <param name="reqFlavours"></param>
        /// <param name="requestId"></param>
        /// <returns></returns>
        public override Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> reqFlavours, CancellationToken canToken, int requestId)
        {
            //Nodes requested with parentIdN = null will not show RootNode as its parent, so RootNode is never shown in the UI.

            FlvNames[] flavArr = reqFlavours?.Select(f => Flavour.ParseFlvName(f)).ToArray() ?? throw new NbExceptionInfo("ICollection<string> flavoursN was not provided");

            List<Node> nodes;
            if (parentIdN == null)
                nodes = RootNode.GetChildren(ContainsRefType.id).ToList();
            else if (Nodes.TryGetValue(parentIdN, out Node parentNode))
                nodes = parentNode.GetChildren(ContainsRefType.id).ToList();
            else
                throw new NbExceptionInfo($"Can't find node with Id '{parentIdN}'");

            /*foreach (Node nd in nodes) //Old approach with AddSimple() call
            {
                Flavour? matchingFlvN = nd.Flavours?.FirstOrDefault(f => flavours.Contains(f.FlavourName));
                if (matchingFlvN != null)
                    Ui.AddSimple(UpdateType.Add,
                        nd.id,
                        nodeType: matchingFlvN.FlavourName,
                        nodeIcon: NbExt.FirstNonEmptyString(nd.icon, matchingFlvN?.icon, matchingFlvN?.DefIcon, DefIcon),
                        parentId: parentIdN,
                        nd.name,
                        nd.HasChildren(ContainsRefType, flavArr),
                        requestId);
            }*/

            List<A2aNodeTree> lst = new List<A2aNodeTree>();
            foreach (Node nd in nodes)
            {
                Flavour? matchingFlvN = nd.Flavours?.FirstOrDefault(f => reqFlavours.Contains(f.FlavourName.ToString()));
                if (matchingFlvN != null)
                    lst.Add(new A2aNodeTree
                    {
                        id = nd.id,
                        type = matchingFlvN.FlavourName.ToString(),
                        icon = nd.Icon,
                        parentId = parentIdN,
                        name = nd.name,
                        has_children = nd.HasChildren(ContainsRefType, flavArr)
                    });
            }
            return Task.FromResult(lst);
        }

        /// <summary>
        /// Calls SetColumns() once and AddAllFields() on the UiModel kept as reference. This provides asynchronous data updates
        /// </summary>
        /// <param name="request">Request in NbSqlXml format</param>
        /// <param name="canToken">Cancellation token</param>
        /// <param name="requestId"></param>
        /// <returns></returns>
        public override Task<List<string>> GetList(NbSqlXml request, int requestId, CancellationToken canToken)
        {
            Log.Info($"GetList request from client");
            NbSqlTable tbl = request.table.SingleVerbose(who: "Requested flavours in GetList() method", whats: "flavours");
            FlvNames flavourName = Flavour.ParseFlvName(tbl.name);
            var resultNodes = ApplyFilters(request).ToList(); //Used twice - in for loop and in Build Web Page

            if (request.table.Length != 1)
                throw new Exception($"Only requests with one table are supported. The table count is {request.table}");
            var table = request.table[0];
            if (table.field.Length == 0)
                throw new Exception("Request table has no fields");

            int count = 0;
            List<(string name, DisplayStyles ds)>? fields = null;
            foreach (Node n in resultNodes) //Of the selected type) 
            {
                if (!n.TryGetFlavour(flavourName, out Flavour flavour))
                    continue;

                if (++count == 1) //TODO: Support the request's columns list
                {
                    fields = GetNodeFields(flavourName.ToString(), table.field).ToList();
                    Log.Info($"Set Columns: {String.Join(",", fields.Select(t => t.name))}");
                    //Ui.SetColumns(fields, requestId); Columns must be provided by type
                }

                var lst = fields.Select(f => flavour.GetFieldValue(f.name, n)).Prepend(flavour.FlavourName.ToString()).Prepend(n.id).ToArray();
                Ui.AddAllFields(UpdateType.Add, columns: lst, requestId);

                //nodeIcon: NbExt.FirstNonEmptyString(n.icon, flavour.icon, flavour.DefIcon, DefIcon),
            }

            Log.Info($"AddAllFields: called {count} times");

            BuildWebPage(resultNodes, requestId);

            return Task.FromResult(new List<string>());
        }


        private IEnumerable<Node> ApplyFilters(NbSqlXml request)
        {
            //TODO: support in_subtree in_node properly
            Subtree subtreeFltN = request.filter.SafeOfType<Subtree>().SingleOrDefaultVerbose(who: "in_subtree filter", whats: "request filFMideters");

            NbSqlTable tbl = request.table.SingleVerbose(who: "Requested flavours in GetList() method", whats: "flavours");
            string flavourName = tbl.name;

            if (subtreeFltN != null)
            {
                var parentId = subtreeFltN.root_node_id;
                Log.Info($"Subtree filter, parent: {parentId}");

                if (String.IsNullOrEmpty(parentId)) throw new ArgumentException(nameof(parentId));
                var node = Nodes[parentId];
                return node.ReferencesN?.Where(r => r.IsForward).Select(r => r.Node) ?? Enumerable.Empty<Node>();
            }
            else //subtreeFltN == null
            {
                Log.Info($"No subtree filters");
                return Nodes.Values;
            }
        }


        /// <summary>
        /// Try to find a node by its Id
        /// </summary>
        /// <param name="id">id of the node</param>
        /// <param name="node">Node if it is found</param>
        /// <returns>true if node is found</returns>
        public bool TryGetNode(string id, out Node node) => Nodes.TryGetValue(id, out node);

        private void BuildWebPage(IEnumerable<Node> resultNodes, int requestId)
        {
            Log.Info($"BuildWebPage");

            using MemoryStream ms = new MemoryStream(10000);
            using StreamWriter wrtr = new StreamWriter(ms);

            var expFormat = new DfExportFormat { isMergeCells = false, isTableOnly = true, isVertical = false, isRemoveNullColumns = false };
            NbCss css = new NbCss(new DirectoryInfo(@"C:\Users\budan\.freemind\icons"), DfExportHtml.Css);

            /*var cols = new List<IHtmlColumnFormatter<Node>> { new ColIdFormatter(), new ColNameFormatter() };
            QueryResult.WriteFullHtml(wrtr, "Page title", t => TableFormatter.TableHor(t, css, cols, resultNodes));*/

            wrtr.Flush();
            ms.Position = 0;
            using StreamReader rdr = new StreamReader(ms);
            Ui.AddWebPage(rdr.ReadToEnd(), requestId);
        }

        /// <summary>
        /// Returns the list of pairs (name of the field, Display stype) for supported fields that were requested in the request
        /// </summary>
        /// <param name="typeName">The record type from A2AType xml</param>
        /// <param name="requestedFields">Fields requested by the client. The client might not need all the fields presented in the underlying data</param>
        /// <returns></returns>
        private IEnumerable<(string name, DisplayStyles displayStyle)> GetNodeFields(string typeName, IEnumerable<NbSqlField> requestedFields)
        {
            Log.Info($"GetNodeFields for type '{typeName}'");

            A2aType tp = GetTypes().TypesDict[typeName];
            foreach (NbSqlField reqFld in requestedFields)
            {
                Column clmn = tp.column.FirstOrDefault(c => c.name.EqIC(reqFld.name));
                if (clmn != null)
                    yield return (clmn.name, clmn.display_type);
            }
        }

        /*private IEnumerable<(FieldInfo, DisplayStyles)> GetNodeFieldsBasedOnObjectProperties(Node node)
        {
            Log.Info($"GetNodeFields");

            //var ndType = NodeTypes[node.type];

            foreach (var fld in node.GetType().GetFields().Where(f => !f.IsStatic
                && !f.Name.EndsWith("Specified")  //Boolean properties for null
                && !f.Name.EqIC("id") && !f.Name.EqIC("type")))     //Id or type will never be shown on the screen, these are functional fields
            {
                //var displayStyleXml = ndType[fld.Name];
                var displayStyle = (DisplayStyles)Enum.Parse(typeof(DisplayStyles), "String"); //DisplayStyle is defined in common interface that doesn't know about the xml schema
                yield return (fld, displayStyle);
            }
        }*/
        #endregion IDataProvider implementation


        enum CmdEnum
        {
            Open, Rename, SendUpdate, ShowDialog,
            AddFolder,
            FileDrop
        }


        /// <summary>
        /// Request to get commands for a give node. Will be shown in context menu and toolbar
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        public override IEnumerable<A2aCommand> GetCommandsSingle(A2aNode node)
        {
            if (node == null)
                return Enumerable.Empty<A2aCommand>();
            
            Node srcNode = Nodes[node.id];
            var flvName = Flavour.ParseFlvName(node.type);
            return Commands.SelectMany(c => c.Value.GetSingle(srcNode, flvName));
        }

        /// <summary>
        /// Gets collection of commands that can be performed when one node is dropped onto another
        /// </summary>
        /// <param name="srcN">Source Node</param>
        /// <param name="dstN">Destination Node. Can be null if the node is dragged over the empty space</param>
        /// <param name="formats">The list of additional parameters, such as FileDrop</param>
        /// <returns></returns>
        public override IEnumerable<A2aCommand> GetDragCommands(A2aNode? srcN, A2aNode? dstN, string[] formats)
        {
            if (dstN == null)
                return Enumerable.Empty<A2aCommand>();

            var srcType = Flavour.ParseFlvName(srcN?.type);
            var dstType = Flavour.ParseFlvName(dstN.type);
            return Commands.SelectMany(c => c.Value.GetDragCommands(srcN, srcType, dstN, dstType, formats.Select(f => A2aCommand.ParseClipboardData(f)).ToArray()));
        }


        const string FireFox = @"C:\Program Files\Mozilla Firefox\firefox.exe";

        /// <summary>
        /// The command was chosen by the user: Execute command by its description
        /// </summary>
        /// <param name="cmdName">The unique name of the command that parsed into CmdEnum enum</param>
        /// <param name="srcN">Drag and Drop source Node attributes. Can be null if the dragging is from the external application</param>
        /// <param name="dstN">Drag and Drop destination Node attributes</param>
        /// <param name="addObject">Additional object used for Windows drag and drops, such as FileDrops</param>
        /// <returns></returns>
        public async override Task ExecuteCommand(string cmdName, A2aNode? srcN, A2aNode? dstN, object addObject)
        {
            var cmdClass = Commands[cmdName];
            Node? srcNodeN = srcN == null ? null : Nodes[srcN.id];
            Node? dstNodeN = dstN == null ? null : Nodes[dstN.id];

            var srcType = Flavour.ParseFlvName(srcN?.type);
            var dstType = Flavour.ParseFlvName(dstN?.type);
            try
            {
                await cmdClass.Execute(srcNodeN, srcType, dstNodeN, dstType, addObject); //Return?
            }
            catch (Exception ex)
            {
                await Task.Run(async () => await Ui.ShowDialog(ex.Message));
            }
        }

        private async Task ExecuteLmLink(FlavLmLink lmLink)
        {
            //exitCode, stdOut, errOut
            var (_, _1, _2) = await NbProcess.RunAsync(FireFox, null, lmLink.url);
        }


        /*internal async Task ExecuteAsync(int Ind, DfRepository rep)
        {
            string LauncherId = rep.Entities.Launcher[Ind];
            string url = rep.Entities.Url[Ind];
            if (!String.IsNullOrEmpty(LauncherId)) //If launcher is provided
            {
                if (LauncherId.EqIC("Function"))
                {
                    switch (url)
                    {
                        //case "Work": await Nb.Library.Web.Selenium.Work.Run(fStatusN.GetTxt()); break;
                        case "Work":
                            using (var os = new Os(@"NbSelenium.exe"))  //C:\Repo\NbTools\NbSelenium\bin\Debug\
                            {
                                var res = await os.Start("Barc " + fMainUI.GetTxt());
                            }
                            break;
                        //await Nb.Library.Web.Selenium.Work.Run(fStatusN.GetTxt()); break;
                        case "EncodePass": Clipboard.SetText(new NbTools.Crypto.TripleDESStringEncryptor().EncryptBase64(fMainUI.GetTxt().Trim())); break;
                        case "DecodePass": Clipboard.SetText(new NbTools.Crypto.TripleDESStringEncryptor().DecryptBase64(fMainUI.GetTxt().Trim())); break;
                        case "Base64ToFile": CustomFunctions.Base64ToFile(Clipboard.GetText()); break;
                        case "SaveFavIcon": MngDropper.SaveFavIcon(Clipboard.GetText(), Sett.paths?.IconDir); break;

                        default: throw new NbException($"Unsupported local function: {url} in the entry #{rep.Entities.Name[Ind]}");
                    }

                }
                else //Normal Launch
                {
                    var launcher = Sett.Launchers[LauncherId];
                    FileInfo fi = new FileInfo(Environment.ExpandEnvironmentVariables(launcher.path));
                    if (!fi.Exists)
                        throw new NbException($"Launcher '{fi.FullName}' is not found");

                    var resolvedDoc = ResolveVariables(url);
                    fMainUI?.ShowStatus($"Starting {fi.Name}");
                    await Task.Run(() => Process.Start(new ProcessStartInfo { FileName = fi.FullName, Arguments = $"{launcher.cl_params} \"{resolvedDoc}\"" }));
                    fMainUI?.ShowStatus(""); //DfTodo
                }
            }
            else //Launcher is not provided
            {
                var resolvedDoc = ResolveVariables(url);

                fMainUI?.ShowStatus($"Verb for {resolvedDoc}");
                await Task.Run(() =>
                {
                    Process p;
                    int exeLocation = resolvedDoc.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
                    if (exeLocation != -1)
                    {
                        exeLocation = Math.Min(exeLocation + 5, resolvedDoc.Length); //Could end with exe of "my.exe"
                        string exe = resolvedDoc.Substring(0, exeLocation); //+1 if case of "my.exe"
                        string args = resolvedDoc.Substring(exeLocation);
                        p = Process.Start(new ProcessStartInfo { Verb = "open", FileName = $"\"{exe}\"", Arguments = args });
                    }
                    else
                    {
                        p = Process.Start(new ProcessStartInfo { Verb = "open", FileName = $"\"{resolvedDoc}\"" });
                    }
                });
                fMainUI?.ShowStatus("");
            }

            var ctc = rep.Entities.CopyToClipboard[Ind];
            if (!String.IsNullOrWhiteSpace(ctc))
            {
                ctc = ResolveVariables(ctc);
                Clipboard.SetText(ctc);
            }

            rep.Entities.EditLine(Ind);
            rep.Entities.AccessTime.SetValue(DateTime.Now);
            rep.Entities.ReleaseLine();
        }*/

        /// <summary>
        /// Standard Dispose procedure
        /// </summary>
        public override void Dispose() { }
    }

    /// <summary>
    /// Formatter used in BuildWebPage
    /// </summary>
    /*public class ColIdFormatter : IHtmlColumnFormatter<Node>
    {
        /// <remarks/>
        public string Name => "Id";
        /// <remarks/>
        public string CellText(Node nd, NbCss _) => nd.id;
    }

    /// <summary>
    /// Formatter used in BuildWebPage
    /// </summary>
    public class ColNameFormatter : IHtmlColumnFormatter<Node>
    {
        /// <remarks/>
        public string Name => "Name";
        /// <remarks/>
        public string CellText(Node nd, NbCss _) => nd.name;
    }*/
}

#nullable disable
