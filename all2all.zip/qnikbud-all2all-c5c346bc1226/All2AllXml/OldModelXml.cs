﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

using NbTools;
using NbTools.SqlGen.Xml;

using A2aCommands.Xml;
using A2aTypes.Xml;

namespace All2All.Xml
{

    internal class RefResolved
    {
        public Node From;
        public Node To;
        public RefType RefType;

        public override string ToString() => $"'{From.id}' -({RefType.id})-> '{To.id}'";
    }


    /// <summary>
    /// Old model, just nodes references and links, no flavours
    /// </summary>
    public class OldModelXml : NullDataProvider
    {
        private readonly all2all All2All;
        private readonly NbDictionary<string, Node> Nodes;
        private readonly NbDictionary<string, NbDictionary<string, DisplayStyleXml>> NodeTypes;
        private readonly NbDictionary<string, RefType> RefTypes;

        private readonly List<RefResolved> ForwardReferences;
        private readonly HashSet<Node> Roots; //Keep resolved root nodes, not the Ids;

        private readonly IUserInterface Ui;

        public override string ModelName => "All2AllXMl";
        const string IconName = "care-4";

        private static readonly log4net.ILog Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public OldModelXml(IUserInterface ui)
        {
            string fileName = "all2all.xml";

            Ui = ui ?? throw new ArgumentNullException(nameof(ui));

            All2All = all2all.LoadXml(fileName);
            Log.Info("Xml loaded: " + fileName);

            Nodes = All2All.nodes.Items.ToNbDictionary(n => n.id, n => n, StringComparer.OrdinalIgnoreCase, 100, "Nodes");
            RefTypes = All2All.ref_types.Items.ToNbDictionary(n => n.id, n => n, StringComparer.OrdinalIgnoreCase, 100, "RefTypes");
            NodeTypes = All2All.node_types.Items.ToNbDictionary(nt => nt.id,
                nt => nt.field_type.ToNbDictionary(ft => ft.field_name, ft => ft.display_style, StringComparer.OrdinalIgnoreCase, 100, $"Node type '{nt.id}' field types"),
                StringComparer.OrdinalIgnoreCase, 100, "Node types");


            ForwardReferences = new List<RefResolved>(All2All.refs.Items.Length);
            var rootIds = new HashSet<string>(All2All.nodes.Items.Select(n => n.id));

            Log.Info($"Nodes: {Nodes.Count}, RefTypes: {RefTypes.Count}, NodeTypes: {NodeTypes.Count}, Roots: {rootIds.Count}");

            foreach (var r in All2All.refs.Items)
            {
                var refRes = new RefResolved();
                if (!Nodes.TryGetValue(r.from, out refRes.From) || !Nodes.TryGetValue(r.to, out refRes.To))
                    throw new Exception($"Referred node '{r.from}' cannot be found: {r}");

                if (!RefTypes.TryGetValue(r.type, out refRes.RefType))
                    throw new Exception($"Reference type '{r.type}' cannot be found: {r}");

                ForwardReferences.Add(refRes);
                rootIds.Remove(r.to);
            }

            Roots = new HashSet<Node>(rootIds.Select(id => Nodes[id]));
            ForwardReferences.Sort((x, y) => String.Compare(x.From.id, y.From.id));
        }

        //TODO: support reference types - i.e. Show all songs, but not the authors
        IEnumerable<Node> GetChildren(string nodeId, string _, HashSet<string> nodeTypesN) =>
            ForwardReferences.Where(r => r.From.id.Equals(nodeId)).Select(r => r.To) //All children of the parent
                    .Where(n => nodeTypesN?.Contains(n.type) ?? true); //Where children are of the specified nodeType

        bool HasChildren(string nodeId, string nodeType, HashSet<string> nodeTypesN) => GetChildren(nodeId, nodeType, nodeTypesN).Any();

        /*private IEnumerable<(FieldInfo, DisplayStyles)> GetFieldsNode(Node node)
        {
            var ndType = NodeTypes[node.type];

            foreach (var fld in node.GetType().GetFields().Where(f => !f.IsStatic
                && !f.Name.EndsWith("Specified")  //Boolean properties for null
                && !f.Name.EqIC("id") && !f.Name.EqIC("type")))     //Id or type will never be shown on the screen, these are functional fields
            {
                var displayStyleXml = ndType[fld.Name];
                var displayStyle = (DisplayStyles)Enum.Parse(typeof(DisplayStyles), displayStyleXml.ToString()); //DisplayStyle is defined in common interface that doesn't know about the xml schema
                yield return (fld, displayStyle);
            }
        }*/

        /// <summary>
        /// Request to send the child nodes asynchronously to the IDisplaySimple interface
        /// </summary>
        /// <param name="parentIdN">Id of the parent node in the tree, if null - send all root nodes</param>
        /// <param name="nodeTypesN">The type of references to follow from the parent to the child nodes, if null - send all references</param>
        /// <param name="cnc">Cancellation token</param>
        /// <param name="requestId">Request Id that will be sent back to the requester with IDisplaySimple call</param>
        /// <returns></returns>
        public override Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> nodeTypesN, CancellationToken cnc, int requestId)
        {
            var tpHashN = nodeTypesN != null ? new HashSet<string>(nodeTypesN) : null;

            int cntr = 0;
            if (parentIdN == null)
            {
                Log.Debug($"Request #{requestId} GetChildren for root (no parent), types: {String.Join(" ,", tpHashN)}");
                foreach (var n in Roots.Where(n => tpHashN?.Contains(n.type) ?? true))
                {
                    A2aNodeTree node = new A2aNodeTree { id = n.id, type = n.type, name = n.label, icon = IconName, parentId = null, has_children = HasChildren(n.id, n.type, tpHashN) };
                    Ui.UpdateNode(UpdateType.Add, node, requestId);
                    cntr++;
                }
            }
            else
            {
                Log.Debug($"Request #{requestId} GetChildren for parent '{parentIdN}<{parentTypeN}>', types: {String.Join(" ,", tpHashN)}");
                foreach (Node n in GetChildren(parentIdN, parentTypeN, tpHashN)) //Of the selected type
                {
                    A2aNodeTree node = new A2aNodeTree { id = n.id, type = n.type, name = n.label, icon = IconName, parentId = parentIdN, has_children = HasChildren(n.id, n.type, tpHashN) };
                    Ui.UpdateNode(UpdateType.Add, node, requestId);
                    cntr++;
                }
            }
            Log.Debug($"Request #{requestId} GetChildren, {cntr} simple records returned");
            return Task.FromResult(new List<A2aNodeTree>()); //TODO: implement
        }

        //TODO: implement cancel token and cancel if user click too quickly
        public async Task GetDetails(string parentId, string parentType, IEnumerable<string> typesN, CancellationToken _, int requestId)
        {
            var _1 = parentType;

            if (String.IsNullOrEmpty(parentId)) throw new ArgumentException(nameof(parentId));
            var tpHashN = typesN != null ? new HashSet<string>(typesN) : null;

            //bool first = true;
            List<(FieldInfo fi, DisplayStyles ds)> fields = null;
            foreach (Node n in ForwardReferences.Where(r => r.From.id.Equals(parentId)).Select(r => r.To)
                .Where(n => tpHashN?.Contains(n.type) ?? true)) //Of the selected type
            {
                /*if (first) //Should be set by types
                {
                    fields = GetFieldsNode(n).ToList();
                    Ui.SetColumns(fields.Select(f => (f.fi.Name, f.ds)), requestId);
                    first = false;
                }*/

                await Task.Delay(300);

                var lst = fields.Select(f => f.fi.GetValue(n).ToString()).Prepend(n.type).Prepend(n.id).ToArray();
                Ui.AddAllFields(UpdateType.Add, lst, requestId);
            }
        }

        public async Task GetList(NbSqlXml request, int prevRequestId, int requestId, CancellationToken _)
        {
            var _1 = prevRequestId;
            await Task.Delay(1);
            //Log.Debug($"Request #{requestId} GetList, xml: {request.Serialize()}");

            var andFilters = request?.filter;
            if (andFilters == null || andFilters.Length == 0)
                throw new Exception("No filters provided");

            var typesN = new string[] { "File" }; //TODO: pass with the message
            var tpHashN = typesN != null ? new HashSet<string>(typesN) : null;


            //TODO: support in_subtree in_node properly
            Subtree subtreeFltN = request?.filter.SafeOfType<Subtree>().SingleOrDefaultVerbose(who: "in_subtree filter", whats: "request filters");
            IEnumerable<Node> resultNodes = null;


            if (subtreeFltN != null)
            {
                var parentId = subtreeFltN.root_node_id;
                if (String.IsNullOrEmpty(parentId)) throw new ArgumentException(nameof(parentId));
                resultNodes = ForwardReferences.Where(r => r.From.id.Equals(parentId)).Select(r => r.To);
            }
            else //subtreeFltN == null
            {
                resultNodes = Nodes.Values;
            }

            //bool first = true;
            List<(FieldInfo fi, DisplayStyles ds)> fields = null;
            foreach (Node n in resultNodes.Where(n => tpHashN?.Contains(n.type) ?? true)) //Of the selected type) 
            {
                /*if (first) Columns must be provided by type
                {
                    fields = GetFieldsNode(n).ToList();
                    Ui.SetColumns(fields.Select(f => (f.fi.Name, f.ds)), requestId);
                    first = false;
                }*/

                await Task.Delay(300);

                var lst = fields.Select(f => f.fi.GetValue(n).ToString()).Prepend(n.type).Prepend(n.id).ToArray();
                Ui.AddAllFields(UpdateType.Add, lst, requestId);
            }
        }

        public override IEnumerable<A2aCommand> GetCommandsSingle(A2aNode node)
        {
            return NbExt.Yield(new A2aCommand { id = nameof(CommandLabels.Edit), label = nameof(CommandLabels.Edit), hotkey = "F4" },
                new A2aCommand { id = "Cmd1" + node.id, label = "Cmd1 " + node.id, tooltip = "Long tool tip message", hotkey = "Enter" },
                new A2aCommand { id = "Cmd2" + node.id, label = "Cmd2 " + node.id, tooltip = "Long tool tip message" }
            );
        }

        enum CommandLabels { Edit, Move, Associate };

        /// <summary>
        /// Executes command 'name' on the node 'srcNodeId' in relation to 'dst.id', which can be null for some commands
        /// </summary>
        /// <param name="name"></param>
        /// <param name="src.id"></param>
        /// <param name="dst.id"></param>
        /// <returns></returns>
        public override async Task ExecuteCommand(string cmdName, A2aNode src, A2aNode dst, object addObject)
        {
            await Task.Delay(500);
            if (cmdName == nameof(CommandLabels.Edit))
            {
                //Lock object in the DB?
                var n = Nodes[src.id];
                var formPar = new A2aFormParameters
                {
                    Properties = Node2Properties(n).ToList(),
                    FormTitle = $"Edit '{n.label}'"
                };

                var res = await Ui.EditForm(formPar);

                if (res)
                {
                    Ui.SetStatus($"Save the node '{src.id}'");
                    var updates = Properties2Node(formPar.Properties, n);
                    if (updates > 0)
                    {
                        //Save object in DB, raise event

                        var lst = new string[] { n.id, n.type, n.id, "Extra1 " + n.id, "Extra2 " + n.label };
                        Ui.AddAllFields(UpdateType.Update, lst, 0);
                        A2aNodeTree node = new A2aNodeTree { id = n.id, type = n.type, name = n.label, icon = IconName, parentId = null, has_children = HasChildren(n.id, n.type, null) };
                        Ui.UpdateNode(UpdateType.Update, node, requestId: 0);
                    }
                }
                else
                    Ui.SetStatus($"Do not save the node '{src.id}'");
                //Unlock the object from the DB
            }
            else if (cmdName == nameof(CommandLabels.Move))
                Ui.SetStatus($"Move '{src.id}' to be the child of '{dst.id}'");
            else if (cmdName == nameof(CommandLabels.Associate))
                Ui.SetStatus($"Associate '{src.id}' with '{dst.id}'");
            else if (cmdName.StartsWith("Cmd1"))
                Ui.SetStatus($"Command '{cmdName}' on the node '{src.id}'");
            else
            {
                var res = await Ui.ShowDialog($"Command '{cmdName}' on the node '{src.id}'");
                Ui.SetStatus($"Dialog response was '{res}'");
            }
        }

        //Returns the number of updates made to the object
        private int Properties2Node(List<A2aFormProperty> props, Node node)
        {
            var tp = node.GetType();
            var cnt = 0;
            foreach (var fi in tp.GetFields().Where(fi => !fi.IsStatic))
            {
                var prop = props.Where(p => p.Id == fi.Name).SingleEnsure("properties", fi.Name, "property list");
                if (!fi.GetValue(node).ToString().Equals(prop.Value))
                {
                    fi.SetValue(node, Convert.ChangeType(prop.Value, fi.FieldType));
                    cnt++;
                }
            }
            return cnt;
        }

        public static IEnumerable<A2aFormProperty> Node2Properties(Node node)
        {
            var tp = node.GetType();
            var cnt = 0;
            foreach (var fi in tp.GetFields().Where(fi => !fi.IsStatic))
            {
                var custAttr = fi.GetCustomAttributes();

                yield return new A2aFormProperty
                {
                    Id = fi.Name,
                    Label = fi.Name,
                    Type = fi.FieldType.Name.ToString(),
                    Value = fi.GetValue(node)?.ToString() ?? null,
                    Tooltip = fi.Name
                };
                cnt++;
            }

            if (cnt == 0)
                throw new Exception($"There are no fields in type '{tp.Name}'");
        }

        public override IEnumerable<A2aCommand> GetDragCommands(A2aNode src, A2aNode dst, string[] formats)
        {
            if (String.IsNullOrEmpty(dst.id) || src.id.Equals(dst.id))
                return Enumerable.Empty<A2aCommand>();
            else
                return NbExt.Yield(new A2aCommand { id = nameof(CommandLabels.Move), label = nameof(CommandLabels.Move) },
                    new A2aCommand { id = nameof(CommandLabels.Associate), label = nameof(CommandLabels.Associate) }
                    );
        }

        public override void Dispose() { }
    }
}
