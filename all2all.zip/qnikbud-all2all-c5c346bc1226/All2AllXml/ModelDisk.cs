﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using A2aCommands.Xml;
using A2aTypes.Xml;
using NbTools;
using NbTools.SqlGen.Xml;


namespace All2All.Disk
{

    /// <summary>
    /// Shows the contents of a disk directory
    /// </summary>
    public class ModelDisk : NullDataProvider
    {
        private readonly IUserInterface Ui;
        public override string ModelName => "All2AllDisk";
        private const string RootDir = @"D:\Videos";
        const string IconName = "care-4";

        internal enum NodeTypes { Dir, File };

        public ModelDisk(IUserInterface ui)
        {
            Ui = ui ?? throw new ArgumentNullException(nameof(ui));
        }

        public override Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> typesN, CancellationToken canToken, int requestId)
        {
            if (parentIdN == null)
            {
                A2aNodeTree node = new A2aNodeTree { id = RootDir, type = "Dir", name = RootDir, icon = IconName, parentId = null, has_children = true };
                Ui.UpdateNode(UpdateType.Add, node, requestId);
            }
            else
            {   //THINK: send the type of the parent node into this method?
                DirectoryInfo di = new DirectoryInfo(parentIdN);
                if (di.Exists)
                {
                    foreach (string type in typesN.Safe())
                    {
                        switch (type)
                        {
                            case "Dir":
                                foreach (var d in di.GetDirectories())
                                {
                                    A2aNodeTree node = new A2aNodeTree { id = d.FullName, type = "Dir", name = d.Name, icon = IconName, parentId = parentIdN, has_children = false };
                                    Ui.UpdateNode(UpdateType.Add, node, requestId);
                                }
                                break;
                            case "File":
                                //di.GetFiles().ForEachSafe(f => Ui.AddSimple(UpdateType.Add, f.FullName, parentIdN, f.Name, false, requestId));
                                break;
                            default:
                                throw new NbException($"Unsupported type: '{type}'");
                        }

                    }
                }
            }
            return Task.FromResult(new List<A2aNodeTree>()); //TODO: implement
        }

        /*private readonly List<(string, DisplayStyles)> FileColumns = new List<(string, DisplayStyles)>
        {
            ("Name", DisplayStyles.String),
            ("Size", DisplayStyles.FileSize),
        };*/

        private static string[] FileColumnValues(FileInfo f) => new string[] { f.FullName, "File", f.Name, f.Length.ToString() };

        //THINK: Get Details requests full details for a parent, maybe 
        // SetColumns() and AddAllFields() 
        public Task GetDetails(string parentId, string parentType, IEnumerable<string> typesN, CancellationToken _, int requestId)
        {
            //Ui.SetColumns(FileColumns, requestId); columns must be provided by type

            DirectoryInfo di = new DirectoryInfo(parentId);
            if (di.Exists)
            {
                foreach (string type in typesN.Safe())
                {
                    switch (type)
                    {
                        case "Dir":
                            //di.GetDirectories().ForEachSafe(d => Ui.AddSimple(UpdateType.Add, d.FullName, parentId, d.Name, false, requestId));
                            break;
                        case "File":
                            foreach (var f in di.GetFiles())
                            {
                                if (f.Name == "desktop.ini")
                                    continue;
                                Ui.AddAllFields(UpdateType.Add, FileColumnValues(f), requestId); //IconName
                            }
                            break;
                        default:
                            throw new NbException($"Unsupported type: '{type}'");
                    }
                }
            }
            return Task.CompletedTask;
        }

        enum CmdEnum { Play, Rename, SendUpdate }

        private static readonly A2aCommand CmdPlay = new A2aCommand       { id = nameof(CmdEnum.Play),       label = nameof(CmdEnum.Play), hotkey = "LButton", tooltip = "Play file" };
        private static readonly A2aCommand CmdRename = new A2aCommand     { id = nameof(CmdEnum.Rename),     label = nameof(CmdEnum.Rename), hotkey = "F2", tooltip = "Edit file name" };
        private static readonly A2aCommand CmdSendUpdate = new A2aCommand { id = nameof(CmdEnum.SendUpdate), label = "Send Update", tooltip = "Update selected record for testing purposes" };

        public override IEnumerable<A2aCommand> GetCommandsSingle(A2aNode node)
        {
            yield return CmdPlay;
            yield return CmdRename;
            yield return CmdSendUpdate;
        }

        private const string MediaPlayer = @"""C:\Program Files (x86)\K-Lite Codec Pack\MPC-HC64\mpc-hc64.exe""";
        public override async Task ExecuteCommand(string cmdName, A2aNode src, A2aNode dst, object addObject)
        {
            if (!Enum.TryParse(cmdName, out CmdEnum cmd)) throw new NbExceptionEnum<CmdEnum>(cmdName);
            if (!Enum.TryParse(src.type, out NodeTypes tp)) throw new NbExceptionEnum<NodeTypes>(src.type);

            switch (cmd)
            {
                case CmdEnum.Play:
                    switch (tp)
                    {
                        case NodeTypes.Dir:
                            break;
                        case NodeTypes.File:
                            if (File.Exists(src.id))
                            {
                                Ui.SetStatus($"Play file #{src.id} '{src.name}'");
                                await NbProcess.RunAsync(MediaPlayer, null, src.id);
                                Ui.SetStatus($"Finished playing file #{src.id} '{src.name}'");
                            }
                            break;
                        default:
                            throw new NbExceptionEnum<NodeTypes>(tp);
                    }
                    break;
                case CmdEnum.Rename:
                    break;
                case CmdEnum.SendUpdate:
                    var f = new FileInfo(src.id);
                    Ui.AddAllFields(UpdateType.Update,  FileColumnValues(f), 0); //Unsolicited request
                    //IconName
                    break;
                default:
                    throw new NbExceptionEnum<CmdEnum>(cmdName);
            }
        }

        public override void Dispose() { }
    }
}
