﻿using A2aCommands.Xml;
using A2aTypes.Xml;
using All2All;
using log4net;
using NbTools.SqlGen.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace All2AllXml.Blt
{
    public class BltModel : NullDataProvider
    {
        private enum NodeType { Root, Server, Node, Mailbox };

        const string IconName = "care-4";
        private const string TypesXml = @"C:\Repo\All2All\All2AllXml\Blt\Types.xml";
        internal static readonly ILog Log = LogManager.GetLogger(nameof(BltModel));

        private readonly A2aT A2aT;
        public override A2aT GetTypes() => A2aT; //2
        public override string ModelName => nameof(BltModel);    //1

        private readonly IUserInterface Ui;

        public BltModel(IUserInterface ui)
        {
            Ui = ui;
            Log.Info($"Loading {nameof(A2aT)} from '{TypesXml}'");
            A2aT = A2aT.LoadFile(TypesXml);
        }


        public override Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> typesN, CancellationToken canToken, int requestId)
        {
            if (parentIdN == null && parentTypeN == null)
            {
                A2aNodeTree node = new A2aNodeTree { id = nameof(NodeType.Root), type = nameof(NodeType.Root), name = nameof(NodeType.Root), icon = IconName, parentId = null, has_children = true };
                Ui.UpdateNode(UpdateType.Add, node, requestId);
            }
            else if (parentIdN != null && parentTypeN != null)
            {
                switch (parentTypeN)
                {
                    case nameof(NodeType.Root):
                        foreach (string srvName in new[] { "Srv09", "Srv30", "Srv31" })
                        {
                            A2aNodeTree node = new A2aNodeTree { id = srvName, type = nameof(NodeType.Server), name = srvName, icon = IconName, parentId = parentIdN, has_children = true };
                            Ui.UpdateNode(UpdateType.Add, node, requestId);
                        }
                        break;

                    case nameof(NodeType.Server):
                        foreach (int nodeNum in Enumerable.Range(1, 5))
                        {
                            string nodeName = $"{parentIdN}-{nodeNum}";
                            A2aNodeTree node = new A2aNodeTree { id = nodeName, type = nameof(NodeType.Node), name = nodeName, icon = IconName, parentId = parentIdN, has_children = false };
                            Ui.UpdateNode(UpdateType.Add, node, requestId);
                        }
                        break;

                    case nameof(NodeType.Node): //List of mailboxes here
                        break;

                    default:
                        throw new Exception($"Type '{parentTypeN}' is not supported");
                }
            }
            else
                throw new Exception("Either parentIdN or parentTypeN is not specified");

            return Task.FromResult(new List<A2aNodeTree>()); //TODO: implement
        }

        /*public Task ExecuteCommand(string cmdName, A2aNode src, A2aNode dst, object addObject) => throw new NotImplementedException();
        public IEnumerable<A2aCommand> GetCommandsDouble(A2aNode src, A2aNode dst) => throw new NotImplementedException();
        public IEnumerable<A2aCommand> GetCommandsMultiple(A2aNode src, IEnumerable<A2aNode> nodes) => throw new NotImplementedException();
        public IEnumerable<A2aCommand> GetCommandsSingle(string nodeId, string nodeType) { yield break; }
        public IEnumerable<A2aCommand> GetDragCommands(A2aNode src, A2aNode dst, string[] formats) => throw new NotImplementedException();
        public Task GetList(NbSqlXml request, int previousRequestId, int requestId, CancellationToken canToken) => Task.CompletedTask;*/

        public override void Dispose() { }
    }
}
