﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

using NbTools;
using All2All.Model;
using all2allv1.Xml;
using All2All;

namespace All2AllCmd
{
    class ModelDirHierSync : HierSync<Node, FileSystemInfo>
    {
        public readonly FlavoursModel Mdl;
        private readonly Stack<Node> CurrNode;

        public ModelDirHierSync()
        {
            Mdl = new FlavoursModel(new NullUI());
            CurrNode = new Stack<Node>();
        }

        public override IEnumerable<Node> GetChildren(Node a) => a.GetChildren("Contains");

        public override IEnumerable<FileSystemInfo> GetChildren(FileSystemInfo d) =>
            (d as DirectoryInfo)?.EnumerateFileSystemInfos() ?? Enumerable.Empty<FileSystemInfo>();

        public override void OnAdd(FileSystemInfo b) => Debug.WriteLine($"Added: {b}");
        public override void OnRemove(Node a) => Debug.WriteLine($"Removed: {a}");
        public override void OnMatch(Node a, FileSystemInfo b)
        {
            Debug.WriteLine($"Match: {a} = {b}");
            if (CurrNode.Count == 0)
            {
                //Mdl.RootNodes.Add(a);
            }
            else
            {
                //Mdl.LoadFilesAndDirsFromDirectory
            }
        }

        public override void OnPush(Node a)
        {
            Debug.WriteLine($"Push: {a}");
            CurrNode.Push(a);
        }
        public override void OnPop(Node a)
        {
            Debug.WriteLine($"Pop: {a}");
            var res = CurrNode.Pop();
            if (a != res) throw new Exception($"Popped nodes do not match: {a} != {res}");
        }
        public override void OnError(Exception ex) => Debug.WriteLine(NbException.Exception2String(ex));

        public override bool Compare(Node nd, FileSystemInfo fdi)
        {
            if (nd.TryGetFlavour(out FlavFile fileFlav) && fdi is FileInfo fi) //Both are files
            {
                if (fileFlav.file_name + fileFlav.extension == fi.Name)
                    return true;
            }
            else if (nd.TryGetFlavour(out FlavFolder _) && fdi is DirectoryInfo di) //Both are dirs
            {
                if (nd.name == di.Name)
                    return true;
            }
            return false;
        }
    }

}
