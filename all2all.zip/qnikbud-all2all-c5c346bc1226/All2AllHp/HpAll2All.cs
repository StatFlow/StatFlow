﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using Dapper;

using A2aCommands.Xml;
using A2aTypes.Xml;
using All2All;
using NbOrm.Ms;
using NbTools;
using NbTools.Collections;
using NbTools.SqlGen.Xml;

namespace HpModel
{
    public sealed class HpAll2All : NullDataProvider
    {
        private enum A2ATypes { TagType, Tag, Vid }
        const char PathSeparator = '.';

        public const string ConnStr = @"Server=(localdb)\mssqllocaldb;Database=HP;Integrated Security=True";
        public override string ModelName => nameof(HpAll2All);

        private readonly INbConn Conn;

        //const string IconName = "care-4";

        public HpAll2All()
        {
            Conn = new NbMsConn(ConnStr);
        }

        public override A2aT GetTypes() => A2aT.LoadFile("HpAll2AllTypes.xml");

        public override async Task<List<A2aNodeTree>> GetChildren(string parentIdN, string parentTypeN, ICollection<string> typesN, CancellationToken canToken, int requestId)
        {
            if (String.IsNullOrEmpty(parentIdN))
            {
                string sql = @"select IIF(len(TagType) = 0, 'Unknown', TagType), count(*) from Tags
                group by TagType order by 1";

                var names = await Conn.ReadListAsync<string, int>(sql);
                return names.Select(n => new A2aNodeTree { id = $"{nameof(A2ATypes.TagType)}{PathSeparator}{n.Item1}", name = $"{n.Item1} ({n.Item2})", has_children = true, parentId = null, type = nameof(A2ATypes.TagType) }).ToList();
            }
            else
            {
                var path = parentIdN.Split(PathSeparator);
                switch (path[0])
                {
                    case nameof(A2ATypes.TagType):

                        if (path[1] == "Unknown")
                            path[1] = String.Empty;

                        string sql2 = $"select TagName from Tags where TagType = '{path[1]}' order by TagName";
                        var names2 = await Conn.ReadListAsync<string>(sql2);
                        return names2.Select(n => new A2aNodeTree { id = $"{nameof(A2ATypes.Tag)}{PathSeparator}{n}", name = n, has_children = false, parentId = parentIdN, type = nameof(A2ATypes.Tag) }).ToList();

                    case nameof(A2ATypes.Tag):
                        break;
                    default:
                        throw new NbExceptionEnum<A2ATypes>(path[0]);
                }

            }
            return new List<A2aNodeTree>();
        }

        //Id, Type, Name
        public override async Task<List<string>> GetList(NbSqlXml request, int requestId, CancellationToken canToken)
        {
            var names2 = await GetLines(request, requestId, canToken); 
            return names2.Select(n => $"{n.Id},{nameof(A2ATypes.Vid)},{ n.Title}").Prepend("Id,Type,Name").ToList();
        }

        public class Line1 : INbTagGenerator
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string ImgMd5 { get; set; }
            public string Url { get; set; }

            private string ImgPath => $@"file:///{DiskStorePath}\{ImgMd5.Substring(0, 2)}\{ImgMd5}";

            public INbTag Generate(INbTag root)
            {
                root.TAT("div", at => at["style"] = "display: inline-flex;", r1 =>
                    r1.TA("img", at => at["src"] = ImgPath)
                    .TAV("a", at => at["href"] = Url, Title)
                    );
                return root;
            }
        }

        private async Task<List<Line1>> GetLines(NbSqlXml request, int requestId, CancellationToken canToken)
        {
            if (request.filter?.Length > 0)
            {
                if (request.filter[0] is Subtree subtree)
                {
                    var idParts = subtree.root_node_id.Split(PathSeparator);
                    if (idParts[0] == "Tag")
                    {
                        string tagName = idParts[1];

                        string sql = $@"select ip.Id, ip.Title, ip.ImgMd5, ip.Url
from ItemPages ip
	inner join ItemPageTag ipt on ipt.ItemPagesId = ip.Id
	inner join Tags t on ipt.TagsId = t.Id
where t.TagName = '{tagName}' order by Title";

                        using var sqlConn = new SqlConnection(ConnStr);
                        return (await sqlConn.QueryAsync<Line1>(sql)).ToList();
                    }
                }
            }
            return new List<Line1>();
        }

        const string DiskStorePath = @"C:\App\DiskStore\Xh\Thumb";

        public override async Task<string> GetWebPage(NbSqlXml request, int requestId, CancellationToken canToken)
        {
            var lines = await GetLines(request, requestId, canToken);
            //var lines2 = lines.Select(n => (n.Id, n.Title, $@"file:///{DiskStorePath}\{n.ImgMd5.Substring(0, 2)}\{n.ImgMd5}")); //Resolve MD5 into path

            using MemoryStream ms = new MemoryStream(10000);
            using StreamWriter wrtr = new StreamWriter(ms);
            var expFormat = new DfExportFormat { isMergeCells = false, isTableOnly = true, isVertical = false, isRemoveNullColumns = false };
            NbCss css = new NbCss(new DirectoryInfo(@"C:\Users\budan\.freemind\icons"), DfExportHtml.Css);

            //var cols = new List<IHtmlColumnFormatter<(int, string)>> { new ColIdFormatter(), new ColNameFormatter() };
            //QueryResult.WriteFullHtml(wrtr, "Page title", t => TilesFormatter.Generate<Line1>(t, css, lines));

            wrtr.Flush();
            ms.Position = 0;
            using StreamReader rdr = new StreamReader(ms);
            return rdr.ReadToEnd();
        }

        /// <summary>
        /// Formatter used in BuildWebPage
        /// </summary>
        /*public class ColIdFormatter : IHtmlColumnFormatter<(int, string)>
        {
            /// <remarks/>
            public string Name => "Id";
            /// <remarks/>
            public string CellText((int, string) nd, NbCss _) => nd.Item1.ToString();
        }

        /// <summary>
        /// Formatter used in BuildWebPage
        /// </summary>
        public class ColNameFormatter : IHtmlColumnFormatter<(int, string)>
        {
            /// <remarks/>
            public string Name => "Name";
            /// <remarks/>
            public string CellText((int, string) nd, NbCss _) => nd.Item2;
        }*/

        /*public async Task<List<A2aNodeTree>> GetChildrenDirs(string parentIdN, CancellationToken canToken, int requestId)
        {
            string sql = @"select d1.Id
	,d1.ParentDirId
	,d1.Name
	,(select count(*) from Dirs d2 where d2.ParentDirId = d1.id) as ChildrenCount
from Dirs d1
where d1.ParentDirId ";
            sql += String.IsNullOrEmpty(parentIdN) ? "is null" : $"= {Int32.Parse(parentIdN)}"; //to make sure that this is a string

            using (INbReader rdr = Conn.CreateReader(sql))
            {
                while (await rdr.ReadAsync().ConfigureAwait(continueOnCapturedContext: false))
                {
                    if (canToken.IsCancellationRequested)
                        return new List<A2aNodeTree>();

                    int col = 0;
                }
            }
            return new List<A2aNodeTree>();
        }*/


        public override IEnumerable<A2aCommand> GetCommandsSingle(A2aNode node) { yield break; }

        public override void Dispose()
        {
            Conn?.Dispose();
        }
    }
}
