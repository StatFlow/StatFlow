﻿using System.IO;
using System.Linq;
using Xunit;

using All2All;
using All2All.Model;
using all2allv1.Xml;
using NbTools;
using NbTools.Sync;
using System;
using System.Threading;

namespace FlavoursModelTest
{
    public class SyncTests
    {
        private static readonly string refType = FlavoursModel.ContainsRefType.id;

        [Fact]
        public void MergeFromFilesIn_Test()
        {
            Directory.Delete(@"C:\AutoDelete\FlavoursModelTest", recursive: true);
            NbDir dirRoot = NbDir.CreateTimestampedDir(@"C:\AutoDelete\FlavoursModelTest\Test");

            NbDir dirKeep = dirRoot.CreateSubDir(nameof(dirKeep));
            NbDir dirRename = dirRoot.CreateSubDir(nameof(dirRename));
            NbDir dirDelete = dirRoot.CreateSubDir(nameof(dirDelete));

            string fileInRoot = dirRoot.CreateTextFile(nameof(fileInRoot) + ".txt");
            string fileInKeep = dirKeep.CreateTextFile(nameof(fileInKeep) + ".txt");
            string fileInRename = dirRename.CreateTextFile(nameof(fileInRename) + ".txt");
            string fileInDelete = dirDelete.CreateTextFile(nameof(fileInDelete) + ".txt");


            //Loading emtpy modelA from ModelB
            var ModelA = new FlavoursModel(new NullUI());
            ModelA.InitEmptyModel(Path.Combine(dirRoot, "TempModel.xml"), "Root", new FlavFolder());
            {
                var events = ModelA.MergeFileStructureIn(dirRoot, FlavoursModel.ContainsRefType).ToList();
                string printA = ModelA.RootNode.PrintTree(refType);
                Assert.Equal(7, events.Count);
            }


            //Deleting one folder and Renaming another - treated as removal and addidion of the folder and its child file
            NbDir renamedDir = dirRename.Rename("Renamed");
            dirDelete.DirInfo.Delete(recursive: true);
            {   //If dir is renamed the contents of this dir are not maked as removed.
                //TODO: detect rename and change the property
                var events = ModelA.MergeFileStructureIn(dirRoot, FlavoursModel.ContainsRefType).ToList();
                Assert.Equal(6, events.Count); //two folder and two files deletion and two additions: the renamed dir and the file

                string printA = ModelA.RootNode.PrintTree(refType);
            }


            //Creating, Updating and Deleting the files
            Thread.Sleep(1000); //Make sure that the timestamps on the files always change
            File.AppendAllText(fileInKeep, "\r\nNewLine for fileInKeep"); //Updated file
            var renamedDirFile = renamedDir.CreateTextFile(nameof(renamedDir) + ".txt"); //New text file
            File.Delete(fileInRoot); //Delete file in subdir
            {
                var events = ModelA.MergeFileStructureIn(dirRoot, FlavoursModel.ContainsRefType).ToList();
                string printA = ModelA.RootNode.PrintTree(refType);
                Assert.Equal(3, events.Count); //two folder deletion and two additions: the renamed dir and the file

                Assert.Contains(events.OfType<NodeChange<Node, FileSystemInfo>>(), e => e.ChangeType == ChangeType.Add && e.NodeSrc.name == nameof(renamedDir) + ".txt" && e.NodeDst.FullName == renamedDirFile);
                Assert.Contains(events.OfType<NodeChange<Node, FileSystemInfo>>(), e => e.ChangeType == ChangeType.Remove && e.NodeSrc.name == nameof(fileInRoot) + ".txt" && e.NodeDst is null);
                Assert.Contains(events.OfType<NodeChange<Node, FileSystemInfo>>(), e => e.ChangeType == ChangeType.Update && e.NodeSrc.name == nameof(fileInKeep) + ".txt" && e.NodeDst.FullName == fileInKeep);

                //dirRoot.CreateTextFile(nameof(printA) + ".txt", printA);
                //Assert.Equal(printA, printB);
            }
        }

        [Fact]
        public void MergeInTwoModels_Test()
        {
            Directory.Delete(@"C:\AutoDelete\FlavoursModelTest", recursive: true);
            NbDir dirRoot = NbDir.CreateTimestampedDir(@"C:\AutoDelete\FlavoursModelTest\Test");

            NbDir dirKeep = dirRoot.CreateSubDir(nameof(dirKeep));
            NbDir dirRename = dirRoot.CreateSubDir(nameof(dirRename));
            NbDir dirDelete = dirRoot.CreateSubDir(nameof(dirDelete));

            string fileInRoot = dirRoot.CreateTextFile(nameof(fileInRoot) + ".txt");
            string fileInKeep = dirKeep.CreateTextFile(nameof(fileInKeep) + ".txt");
            string fileInRename = dirRename.CreateTextFile(nameof(fileInRename) + ".txt");
            string fileInDelete = dirDelete.CreateTextFile(nameof(fileInDelete) + ".txt");

            var ModelB = new FlavoursModel(new NullUI());
            ModelB.LoadFromFileStructure(dirRoot);

            var mrgPar = new MergeParameters<string>
            {
                ReferencefTypeA = refType,
                ReferencefTypeB = refType,
                MarkForDeletion = false,
                ProduceNoChangeEvents = false,
                KeySelector = n => n.name
            };

            //Loading emtpy modelA from ModelB
            var ModelA = new FlavoursModel(new NullUI());
            ModelA.InitEmptyModel(Path.Combine(dirRoot, "TempModel.xml"), ModelB.RootNode.name, new FlavFolder());
            {
                var events = ModelA.MergeIn(ModelB, mrgPar).ToList();
                Assert.Equal(7, events.Count);

                string printA = ModelA.RootNode.PrintTree(refType);
                string printB = ModelB.RootNode.PrintTree(refType);
                Assert.Equal(printA, printB);
            }

            //Deleting one folder and Renaming another - treated as removal and addidion of the folder and its child file
            NbDir renamedDir = dirRename.Rename("Renamed");
            dirDelete.DirInfo.Delete(recursive: true);

            ModelB.LoadFromFileStructure(dirRoot);
            {   //If dir is renamed the contents of this dir are not maked as removed.
                //TODO: detect rename and change the property
                var events = ModelA.MergeIn(ModelB, mrgPar).ToList();
                Assert.Equal(4, events.Count); //two folder deletion and two additions: the renamed dir and the file

                string printA = ModelA.RootNode.PrintTree(refType);
                string printB = ModelB.RootNode.PrintTree(refType);
                Assert.Equal(printA, printB);
            }


            //Creating, Updating and Deleting the files
            File.AppendAllText(fileInKeep, $"NewLine for {fileInKeep}"); //Updated file
            renamedDir.CreateTextFile(nameof(renamedDir) + ".txt"); //New text file
            File.Delete(fileInRoot); //Delete file in subdir

            ModelB.LoadFromFileStructure(dirRoot);
            {
                var events = ModelA.MergeIn(ModelB, mrgPar).ToList();
                Assert.Equal(3, events.Count); //Update, Delete and Add
                Assert.Single(events.Single(e => e.ChangeType == ChangeType.Update).PropChangesN);

                string printA = ModelA.RootNode.PrintTree(refType);
                string printB = ModelB.RootNode.PrintTree(refType);

                //dirRoot.CreateTextFile(nameof(printA) + ".txt", printA);
                //dirRoot.CreateTextFile(nameof(printB) + ".txt", printB);

                Assert.Equal(printA, printB);
            }
        }
    }
}
