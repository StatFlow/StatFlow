﻿using System.IO;
using System.Linq;
using Xunit;

using All2All;
using All2All.Model;
using all2allv1.Xml;
using NbTools;
using NbTools.Sync;
using System;
using System.Threading;

#pragma warning disable IDE0079 // Remove unnecessary suppression
#pragma warning disable xUnit1004 // Test methods should not be skipped
#pragma warning disable IDE0059 // Unnecessary assignment of a value

namespace FlavoursModelTest
{
    public class RunningCode
    {
        [Fact]
        public void Sync()
        {
            const string xmlDir = @"C:\Repo\All2All\FlavoursModel\Data\ATMW\";
            NbDir dirRoot = new NbDir(@"R:\!Backup\Music22");

            var ModelA = new FlavoursModel(new NullUI());
            if (!File.Exists(xmlDir + "Model.xml"))
                throw new Exception($"{xmlDir} Model.xml doesn't exist");

            ModelA.LoadFromXmlFile(xmlDir + "Model.xml", xmlDir + "Types.xml");


            var SyncNode = ModelA.RootNode.GetChildren(FlavoursModel.ContainsRefType.id, "Sync").SingleEnsure();
            var ZotacNode = SyncNode.GetChildren(FlavoursModel.ContainsRefType.id, "Zotac1").SingleEnsure();
            string fromFile = ZotacNode.PrintTree(FlavoursModel.ContainsRefType.id);

            ModelA.MirrorFilesTo(ZotacNode, @"C:\Temp\Mirror");
        }


        [Fact]
        public void LoadMusic()
        {
            const string xmlDir = @"C:\Repo\All2All\FlavoursModel\Data\ATMW\";
            NbDir dirRoot = new NbDir(@"R:\!Backup\Music22");

            var ModelA = new FlavoursModel(new NullUI());
            if (File.Exists(xmlDir + "Model.xml"))
            {
                ModelA.LoadFromXmlFile(xmlDir + "Model.xml", xmlDir + "Types.xml");

                string fromFile = ModelA.RootNode.PrintTree(FlavoursModel.ContainsRefType.id);
                var events = ModelA.MergeFileStructureIn(dirRoot, FlavoursModel.ContainsRefType).ToList();
                string printA = ModelA.RootNode.PrintTree(FlavoursModel.ContainsRefType.id);
                ModelA.SaveToFile();
            }
            else
            {
                ModelA.InitEmptyModel(xmlDir + "Model.xml", "Music22", new FlavFolder());
                var events1 = ModelA.MergeFileStructureIn(dirRoot, FlavoursModel.ContainsRefType).ToList();
                ModelA.SaveToFile();
            }
        }

        /*[Fact(Skip = "Working Code, not test")]
        public void Music22_Files()
        {
            string modelFilePath = @"C:\Repo\All2All\FlavoursModel\Data\ATMW\Model.xml";
            var srcDir = new DirectoryInfo(@"R:\!Backup\Music22\McCartney, Paul\Live");

            var ModelB = new FlavoursModel(new NullUI());
            ModelB.LoadFromFileStructure(srcDir);

            var mrgPar = new MergeParameters<string>
            {
                ReferencefTypeA = ModelB.ContainsRefType.id,
                ReferencefTypeB = ModelB.ContainsRefType.id,
                MarkForDeletion = false,
                ProduceNoChangeEvents = false,
                KeySelector = n => n.name
            };

            //Loading emtpy modelA from ModelB
            var ModelA = new FlavoursModel(new NullUI());
            ModelA.InitEmptyModel(modelFilePath, ModelB.RootNode.name, new FlavFolder());
            var events = ModelA.MergeIn(ModelB, mrgPar).ToList();
            ModelA.SaveToFile();
        }*/
    }
}

#pragma warning restore IDE0059 // Unnecessary assignment of a value
#pragma warning restore xUnit1004 // Test methods should not be skipped
#pragma warning restore IDE0079 // Remove unnecessary suppression