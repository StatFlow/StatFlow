﻿using NbCore.Crypto;

[Collection("Sequential")]
public sealed class DiskStoreTest : IDisposable
{
    private readonly string StoreRoot;

    public DiskStoreTest() //Init Diskstore for each test
    {
        StoreRoot = NbFs.BaseDir + nameof(DiskStoreTest);
        if (Directory.Exists(StoreRoot))
            Directory.Delete(StoreRoot, recursive: true);
        Directory.CreateDirectory(StoreRoot);
    }



    [Fact]
    public async Task KeyName_Test()
    {
        using NbTempFile tFile = NbTempFile.CreateFromText("Some Text");

        string fileKey = "14256";
        string fileName = "Однажды в студёную зимнюю пору";
        string fileExt = ".txt";
        string type = "poetry";

        DiskStore ds = new(StoreRoot);
#pragma warning disable CS0618 // Not obsoltete for tests
        ds.StoreNameFileByKey(tFile.FileInfo.FullName, type, fileKey, fileName, fileExt, moveFile: true);
#pragma warning restore CS0618 // Type or member is obsolete

        var storeName = ds.FindPathByKey(fileKey, type);

        await NbProcess.Explorer(new DirectoryInfo(StoreRoot));
    }

    [Fact]
    public void Md5Field_Test()
    {
        DiskStore ds = new(StoreRoot);

        {
            using NbTempFile tFile1 = NbTempFile.CreateFromText("Some1 Text");
            var expMd51 = NbCrypto.Md5Safe64(tFile1.FileInfo.FullName);
            var (f1Md5, f1) = ds.StoreFileByMd5_Safe64(tFile1.FileInfo.FullName, move: false, overwrite: false);

            Assert.True(File.Exists(tFile1.FileInfo.FullName)); //move false - src file was copied
            Assert.True(File.Exists(f1.FullName));
            Assert.Equal(expMd51, f1Md5);
        }


        using NbTempFile tFile2 = NbTempFile.CreateFromText("Some2 Text");
        var expMd52 = NbCrypto.Md5Safe64(tFile2.FileInfo.FullName);
        var (f2Md5, f2) = ds.StoreFileByMd5_Safe64(tFile2.FileInfo.FullName, move: true, overwrite: false);

        Assert.False(File.Exists(tFile2.FileInfo.FullName)); //move false - src file was copied
        Assert.True(File.Exists(f2.FullName)); //move false - file was copied
        Assert.Equal(expMd52, f2Md5);

        {
            ds.RestoreFileByMd5_Safe64(f2Md5, tFile2.FileInfo, move: false, overwrite: false); //Restore the file back to its original location
            Assert.True(File.Exists(tFile2.FileInfo.FullName)); //move false - src file was copied
            Assert.Equal(f2Md5, NbCrypto.Md5Safe64(tFile2.FileInfo.FullName));
        }

    }

    public void Dispose()
    {
        if (Directory.Exists(StoreRoot)) //Cleanup after each test
            Directory.Delete(StoreRoot, recursive: true);
    }
}
