﻿namespace NbCoreTest;

public class NcTagTest
{
    [Fact]
    public void NcTag_Test()
    {
        NcTag tg = new NcTag();

        //tg.a.href("someurl").download("somefile")  add img tag and text inside

    }
}
