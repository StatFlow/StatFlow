using NbCore.Crypto;
using System.Diagnostics;
using System.Text;

public class NbCryptoTest
{
    [Fact]
    public void HumanReadablePass_Test2()
    {
        string res = NbCrypto.HumanReadablePass(23);
        Assert.Equal(23, res.Length);

/*        for (int i = 0; i < 100; i++)
        {
            string res = NbCrypto.HumanReadablePass(23);
            Assert.Equal(23, res.Length);
            Debug.WriteLine(res);
        }*/
    }


    [Fact]
    public void ToNbase64_Test2()
    {
        Random rnd = new();
        for (int i = 0; i < 400; i++)
        {
            var num = i % 2 == 0 ? rnd.Next() : -rnd.Next();
            var str = NbExt.ToNbase64Reverse(num);
            var num2 = NbExt.FromNbase64Reverse(str);
            Assert.Equal(num, num2);
            Debug.WriteLine($"{i} = {NbExt.ToNbase64Reverse(i)}");
        }
    }


    [Fact]
    public void ToNbase64_Test1()
    {
        char prev = '\0';
        for (byte b = 0; b < 64; b++)
        {
            int bit = (b + 2) << 2;
            int chars = (bit / 3) - 2;
            Assert.True(chars * 6 >= b * 8);
            Assert.True(chars * 6 - b * 8 < 6);


            char ch = NbExt.ToNbase64Char(b);
            byte back = NbExt.FromNbase64(ch);
            Assert.Equal(b, back);

            if (b < 62) // minus and _ are not in order
            {
                Assert.True(ch > prev); //chars can be sorted by alphabet
                prev = ch;
            }
            Debug.WriteLine($"{b}\t{b * 8}\t{chars * 6}\t{chars}\t{ch}");
        }

        //Assert.Throws<OverflowException>(() => NbCrypto.ToNbase64(64));
        //Assert.Throws<OverflowException>(() => NbCrypto.FromNbase64('!'));
    }

    [Fact]
    public void StandardBase64_Test()
    {
        Random rnd = new();
        string curStr = String.Empty;
        for (int i = 0; i < 24; i++)
        {
            var ch = (char)rnd.Next('A', 'Z');
            curStr += ch;
            var res = Convert.ToBase64String(Encoding.UTF8.GetBytes(curStr));
            var res2 = NbCrypto.Safe64_Base64(NbCrypto.Base64_Safe64(res));

            Debug.WriteLine($"{curStr}\t{res}\t{res.Length}\t{res2}");
            Assert.Equal(res, res2);
        }
    }

    [Fact]
    public void Compress_Test()
    {
        string src = "Some random text";

        {
            byte[] bytes2 = NbCrypto.Shrink(src);
            string res2 = NbCrypto.ExpandFromBytes(bytes2);
            Assert.Equal(src, res2);
        }
        {
            string safe64 = NbCrypto.ShrinkToSafe64(src);
            string res1 = NbCrypto.ExpandFromSafe64(safe64);
            Assert.Equal(src, res1);
        }
    }

    [Fact]
    public void RusEng_Test()
    {
        var res = NbExt.RusEng("������");
        Assert.Equal("thanks", res);
    }

    /*[Fact] Unfinished
    public void ParseHumanTimeSpan_Test()
    {
        var res = NbExt.ParseHumanTimeSpan("21 min");
        Assert.Equal(new TimeSpan(0, 21, 0), res);
    }*/
}