﻿public class NbMathTest
{
    [Fact]
    public void BinSearch_Test()
    {
        var arr2 = new[] { 0, 1 };
        var arr3 = new[] { 0, 1, 2 };
        var arr11 = new[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        var arr10 = new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        BinTest(arr2, 0, 0);
        BinTest(arr2, 1, 1);

        BinTest(arr3, 0, 0);
        BinTest(arr3, 1, 1);
        BinTest(arr3, 2, 2);

        BinTest(new[] { 12, 15, 18 }, 1, 0); //We can't detect if it is outside point to first (matching) element
        BinTest(new[] { 12, 15, 18 }, 20, 3); //The number is outside return (to + 1)

        BinTest(new[] { 12, 15, 18, 19 }, 18, 2);

        BinTest(new int[] { 12 }, 10, 0); //12 > 10 return 0
        BinTest(new int[] { 12 }, 20, 1); //12 < 20, Match lise above to return (to + 1)


        foreach (var ind in arr11)
            BinTest(arr11, ind, ind);
        foreach (var ind in arr10)
            BinTest(arr10, ind + 1, ind);
    }

    private static void BinTest(int[] arr, int numInArr, int expInd) => Assert.Equal(expInd, NbMath.BinSearchPredicate(0, arr.Length - 1, i => arr[i] >= numInArr));

}
