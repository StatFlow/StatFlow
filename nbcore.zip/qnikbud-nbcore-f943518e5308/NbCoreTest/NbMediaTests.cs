﻿using System.Text.RegularExpressions;

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Design", "CA1050:Declare types in namespaces", Justification = "Test classed do not have to be in namespace because they are not useds ouside by other code", Scope = "module")]

public partial class NbMediaTests
{
    [GeneratedRegex("^(GG\\d+)_(.*)$")]
    private static partial Regex TempRegex();

    /*[Fact]
    public async Task FFMpeg_Test2() =>  await NbMedia.Ffmpeg_IndexKeyThumbnails(@"C:\Temp\DDI.mp4", @"C:\App\ffmpeg\bin\ffmpeg.exe");

    [Fact]
    public void BiggestPic()
    {
        //Regex Rgx = new(@"^(.+)_*(\d+)$");  //some file part_1.ext
        Regex Rgx = TempRegex();  //some file part_1.ext

        DirectoryInfo srcDir = new(@"C:\Users\budan\Pictures\Prikol\Со Двора\Neena\Bikini Tops - Triangle, Halter Neck & Bandeau Neena Swim1_files");
        NbDictionary<string, List<FileInfo>> groups = new();
        foreach (FileInfo fl in srcDir.GetFiles())
        {
            var match = Rgx.Match(fl.NameWithoutExtension());
            if (match.Success)
            {
                string grp = match.Groups[1].Value;
                string _ = match.Groups[2].Value;
                if (!groups.TryGetValue(grp, out var list))
                {
                    list = new List<FileInfo>();
                    groups.Add(grp, list);
                }

                list.Add(fl);
            }
        }

        foreach(var (grp, list) in groups)
        {
            string newDir = Path.Combine(srcDir.FullName, grp);
            Directory.CreateDirectory(newDir);
            foreach (var fi in list)
                File.Move(fi.FullName, Path.Combine(newDir, fi.Name));
        }
    }*/
}
