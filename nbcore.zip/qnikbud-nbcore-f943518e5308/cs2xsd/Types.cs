﻿using NbCore;
using System.Xml.Serialization;

namespace NbXsdV1.Xml
{
    public partial class NbXsd
    {
        void Resolve() => root.Resolve(type);
    }

    public abstract partial class XsType
    {
        public XsType() //For serialization
        {
            name = string.Empty;
            Items = null!;
        }

        public XsType(string name, BaseTag[]? tags)
        {
            //name[0].ToString().ToUpper() + name.Substring(1); //Ensure first letter is capital for types - make Xs: out of xs: for build-in types
            this.name = name;
            Items = tags!; //TODO: deal wit nullable types in XSD
        }

        [XmlIgnore]
        internal IEnumerable<Elem> Elems => Items.SafeOfType<Elem>();
        [XmlIgnore]
        internal IEnumerable<Attr> Attribs => Items.SafeOfType<Attr>();
        [XmlIgnore]
        internal Val? Val => Items.SafeOfType<Val>().FirstOrDefault();

        internal abstract void WriteTo(NbTag root);

        public static readonly TypeBuiltIn Long = new("xs:long");
        public static readonly TypeBuiltIn Float = new("xs:float");
        public static readonly TypeBuiltIn Double = new("xs:double");
        public static readonly TypeBuiltIn Int = new("xs:int");
        public static readonly TypeBuiltIn Decimal = new("xs:decimal");

        public static readonly TypeBuiltIn String = new("xs:string");
        public static readonly TypeBuiltIn Bool = new("xs:boolean");
        public static readonly TypeBuiltIn HexBinary = new("xs:hexBinary");
        public static readonly TypeBuiltIn Base64Binary = new("xs:base64Binary");
        public static readonly TypeBuiltIn AnyURI = new("xs:anyURI");

        public static readonly TypeBuiltIn Token = new("xs:token");
        public static readonly TypeBuiltIn NCName = new("xs:NCName");

        public static readonly TypeBuiltIn DateTime = new("xs:dateTime");
        public static readonly TypeBuiltIn Date = new("xs:date");
        public static readonly TypeBuiltIn Time = new("xs:time");
        public static readonly TypeBuiltIn Duration = new("xs:duration");

        /*
         * byte 	A signed 8-bit integer
decimal 	A decimal value
int 	A signed 32-bit integer
integer 	An integer value
long 	A signed 64-bit integer
negativeInteger 	An integer containing only negative values (..,-2,-1)
nonNegativeInteger 	An integer containing only non-negative values (0,1,2,..)
nonPositiveInteger 	An integer containing only non-positive values (..,-2,-1,0)
positiveInteger 	An integer containing only positive values (1,2,..)
short 	A signed 16-bit integer
unsignedLong 	An unsigned 64-bit integer
unsignedInt 	An unsigned 32-bit integer
unsignedShort 	An unsigned 16-bit integer
unsignedByte 	An unsigned 8-bit integer
        */


        /*
        anyURI 	 
        base64Binary 	 
        boolean 	 
        double 	 
        float 	 
        hexBinary 	 
        NOTATION 	 
        QName
         * */


        internal virtual void RegisterSelfAndChildrenTypes(NbDictionary<string, XsType> types)
        {
            if (!types.ContainsKey(name))
                types.Add(name, this);
            Items.ForEachSafe(t => t.RegisterTypeRecur(types));
        }
    }

    public partial class TypeBuiltIn : XsType
    {
        public TypeBuiltIn() { } //For serialization

        public TypeBuiltIn(string name) : base(name, null) { }

        internal override void WriteTo(NbTag root) { } //Do not write for built-in types
    }

    public partial class TypeName : XsType
    {
        public TypeName() { } //For serialization

        public TypeName(string name) : base(name, null) { }

        internal override void WriteTo(NbTag root) { }
    }

    public partial class TypeSequence : XsType
    {
        public TypeSequence() { } //For serialization

        public TypeSequence(string name, params BaseTag[] tag)
            : base(name, tag) { }

        internal override void WriteTo(NbTag root)
        {
            root.TAT("complexType", a => a["name"] = name, t1 =>
            {
                t1.TT("sequence", t2 =>
                {
                    foreach (Elem el in Elems)
                        el.WriteTo(t2);
                });
                foreach (Attr att in Attribs)
                    att.WriteTo(t1);
            });
        }
    }

    public partial class TypeChoice : XsType
    {
        public TypeChoice() { } //For serialization

        public readonly int Min;
        public readonly int Max;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">Name of the type should star with capital letter, becuase it will appear in C# code</param>
        /// <param name="min">-1 means unbounded, -2 means do not include the tag minOccurs</param>
        /// <param name="max">-1 means unbounded, -2 means do not include the tag maxOccurs. If 1 is provided it mean only one choice is allowed (radiobuttons)</param>
        /// <param name="tag">Array of element and attributes</param>
        public TypeChoice(string name, int min = Elem.Default, int max = Elem.Default, params BaseTag[] tag)
            : base(name, tag)
        {
            Min = min;
            Max = max;
        }

        internal override void WriteTo(NbTag root)
        {
            root.TAT("complexType", a => a["name"] = name, t1 =>
            {
                t1.TAT("choice",
                    a =>
                    {
                        if (Min != Elem.Default)
                            a["minOccurs"] = Min == Elem.Unbounded ? "unbounded" : Min.ToString();
                        if (Max != Elem.Default)
                            a["maxOccurs"] = Max == Elem.Unbounded ? "unbounded" : Max.ToString();
                    },
                    t2 => Elems.ForEachSafe(el => el.WriteTo(t2))
                );
                Attribs.ForEachSafe(att => att.WriteTo(t1));
            });
        }
    }


    /// <summary>
    /// List of different elements, which could have or not have common base class
    /// If no attributes the Array of common type is created in the host tag. If attributes are used another layer is created - the list class that contains the attributes as properties and array named Items
    /// </summary>
    public partial class TypeTagList : XsType
    {
        public TypeTagList() { } //For serialization

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">Name of the type should star with capital letter, becuase it will appear in C# code</param>
        /// <param name="min">-1 means unbounded, -2 means do not include the tag minOccurs</param>
        /// <param name="max">-1 means unbounded, -2 means do not include the tag maxOccurs. If 1 is provided it mean only one choice is allowed (radiobuttons)</param>
        /// <param name="elems">Array of element and attributes</param>
        public TypeTagList(string name, params BaseTag[] elems) : base(name, elems) { }

        internal override void WriteTo(NbTag root)
        {
            root.TAT("complexType", a => a["name"] = name, t1 =>
            {

                // TODO: Logic for any number of elements in any order. 
                //This creates generic array of objects. Need to enforce the base class in this case, because casting from object doesn't sound like a good ideam
                //[XmlElement("ffmpeg", typeof(string), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
                //[XmlElement("firefox", typeof(string), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
                //[XmlElement("veracrypt", typeof(VeracryptSettings), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
                //[XmlChoiceIdentifier("ItemsElementName")]
                //public object[] Items;

                t1.TAT("choice",
                    a => a["minOccurs", "0"]["maxOccurs"] = "unbounded",
                    t2 => Elems.ForEachSafe(el => el.WriteTo(t2))
                );


                //These settings on choice make it a single choice, i.e. only one tag of many is allowed
                /*[XmlElement("ffmpeg", typeof(string), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
                [XmlElement("firefox", typeof(string), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
                [XmlElement("veracrypt", typeof(VeracryptSettings), Form = System.Xml.Schema.XmlSchemaForm.Unqualified)]
                [XmlChoiceIdentifier("ItemElementName")]
                public object Item;

                /// <remarks/>
                [XmlIgnore()]
                public ItemChoiceType ItemElementName;

                [XmlType(IncludeInSchema = false)]
                public enum ItemChoiceType
                {
                    ffmpeg,
                    firefox,
                    veracrypt,
                }*/

            /*int Min = 0;
            int Max = 1;

            t1.TAT("choice",
                a =>
                {
                    if (Min != Elem.Default)
                        a["minOccurs"] = Min == Elem.Unbounded ? "unbounded" : Min.ToString();
                    if (Max != Elem.Default)
                        a["maxOccurs"] = Max == Elem.Unbounded ? "unbounded" : Max.ToString();
                },
                t2 => Elems.ForEachSafe(el => el.WriteTo(t2))
            );
            */

        Attribs.ForEachSafe(att => att.WriteTo(t1));
            });
        }
    }

    /// <summary>
    /// All tags must be present once
    /// </summary>
    public partial class TypeAll : XsType
    {
        public readonly int Min;
        public readonly int Max;

        public TypeAll() { } //For serialization

        public TypeAll(string name, int min = Elem.Default, int max = Elem.Default, params BaseTag[] tag)
            : base(name, tag)
        {
            Min = min;
            Max = max;
        }

        internal override void WriteTo(NbTag root)
        {
            root.TAT("complexType", a => a["name"] = name, t1 =>
            {
                t1.TAT("all",
                    a =>
                    {
                        if (Min != Elem.Default)
                            a["minOccurs"] = Min == Elem.Unbounded ? "unbounded" : Min.ToString();
                        if (Max != Elem.Default)
                            a["maxOccurs"] = Max == Elem.Unbounded ? "unbounded" : Max.ToString();
                    },
                    t2 =>
                    {
                        foreach (Elem el in Elems)
                            el.WriteTo(t2);
                    }
                );
                foreach (Attr att in Attribs)
                    att.WriteTo(t1);
            }
            );
        }
    }

    /// <summary>
    /// complexType that only has attributes
    /// </summary>
    public partial class TypeAttrOnly : XsType
    {
        public TypeAttrOnly() { } //For serialization

        public TypeAttrOnly(string name, params BaseTag[] tag)
            : base(name, tag)
        {
            if (tag.SafeOfType<Elem>().Any())
                throw new Exception($"{nameof(TypeAttrOnly)} '{name}' doesn't support elements");

            if (tag.SafeOfType<Val>().Count() > 1)
                throw new Exception($"{nameof(TypeAttrOnly)} '{name}' only one Val is allowed");
        }

        internal override void WriteTo(NbTag root) => root.TAT("complexType", a => a["name"] = name, Content);

        private void Content(NbTag t1)
        {
            var val = Val;
            if (val != null)
            {
                t1.TT("simpleContent",
                    t2 => t2.TAT("extension", a2 => a2["base"] = val.type, t3 =>
                    {
                        foreach (Attr att in Attribs)
                            att.WriteTo(t3);
                    }
                ));
            }
            else
                foreach (Attr att in Attribs)
                    att.WriteTo(t1);
        }
    }

    public partial class TypeDerived : XsType
    {
        public TypeDerived() { } //For serialization

        public TypeDerived(string name, XsType baseType, params BaseTag[] tag)
            : base(name, tag)
        {
            BaseType = baseType;
            //if (tag.SafeOfType<Elem>().Any())
            //    throw new Exception($"{nameof(TypeDerived)} '{name}' doesn't support elements");
        }

        internal override void WriteTo(NbTag root)
        {
            root.TAT("complexType", a => a["name"] = name, t1 =>
            {
                t1.TT("complexContent", t2 =>
                {
                    t2.TAT("extension", a => a["base"] = BaseType.name, t3 =>
                    {
                        var elems = Elems.ToList();
                        if (elems.Count > 0)
                        {
                            t3.TT("sequence", t4 => Elems.ForEachSafe(el => el.WriteTo(t4)));
                        }
                        Attribs.ForEachSafe(att => att.WriteTo(t3));
                    });
                });
            });
        }

        internal override void RegisterSelfAndChildrenTypes(NbDictionary<string, XsType> types)
        {
            BaseType.RegisterSelfAndChildrenTypes(types);
            base.RegisterSelfAndChildrenTypes(types);
        }
    }


    /// <summary>
    /// List of build-in values such as xs:int, divided by spaces
    /// https://learn.microsoft.com/en-us/previous-versions/dotnet/netframework-4.0/ms256162(v=vs.100)
    /// </summary>
    public partial class TypeValuesList : XsType
    {
        //public TypeList() { } //For serialization

        public TypeValuesList(string name, TypeBuiltIn listOf, int minLength = -1)
            : base(name, null)
        {
            ListOfType = listOf;
            MinLength = minLength;
        }

        internal override void WriteTo(NbTag root)
        {
            root.TAT("simpleType", a => a["name"] = name, t1 =>
            {
                t1.TT("restriction", t2 =>
                {
                    t2.TT("simpleType",
                        t3 => t3.TA("list", a => a["itemType"] = ListOfType.name));
                    if (MinLength != -1)
                        t2.TA("minLength", a => a["value"] = MinLength.ToString());
                });
            });
        }
    }


    public partial class TypeEnum : XsType
    {
        //Don't really need to resolve type name, becuase during export there is the first step with registration in the dictionary, so the type will be available to lookup by name
        private NbDictionary<string, string>? Values;

        public TypeEnum() { } //For serialization

        public TypeEnum(string name, TypeBuiltIn listOf, params (string key, string? val)[] items)
            : base(name, null)
        {
            ListOfType = listOf;
            this.items = items.Select(p => new EnumItem() { key = p.key, value = p.val! }).ToArray(); //TODO: deal with nullable items in xsd
        }

        /*public TypeEnum(string name, TypeBuiltIn listOf, (string key, string val)[] items)
            : base(name, null)
        {
            ListOfType = listOf;
            this.items = items.Select(p => new EnumItem() {  key = p.key, value = p.val }).ToArray();
        }*/

        public TypeEnum(string name, TypeBuiltIn listOf, EnumItem[] items)
            : base(name, null)
        {
            ListOfType = listOf;
            this.items = items;
        }

        internal override void WriteTo(NbTag root)
        {
            if (Values == null)
            {
                if (items == null)
                    throw new Exception($"Both values parameter and items Xml tag were empty for TypeEnum: '{name}'");
                Values = items.ToNbDictionary(i => i.key, i => i.value);
            }

            root.TAT("simpleType", a => a["name"] = name, t1 =>
            {
                t1.TAT("restriction", a => a["base"] = ListOfType.name, t2 =>
                    {
                        foreach (var pair in Values)
                        {
                            t2.TA("enumeration", a => a["value"] = pair.Key);
                        }
                    });
            });
        }
    }
}
