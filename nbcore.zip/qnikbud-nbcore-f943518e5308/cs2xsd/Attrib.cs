﻿using NbCore;
using System.Xml.Serialization;

namespace NbXsdV1.Xml;

public abstract partial class BaseTag
{
    public BaseTag() : this(String.Empty, null) { } //For serialization

    public BaseTag(string name, string? doc)
    {
        Name = name;
        Doc = doc!; //TODO: How to deal with nullable types in XSD?
    }

    public void AddDoc(NbTag tg)
    {
        if (!String.IsNullOrWhiteSpace(Doc))
            tg.TT("annotation", an => an.TV("documentation", Doc));
    }

    internal abstract void RegisterTypeRecur(NbDictionary<string, XsType> types);
}

public partial class Attr : BaseTag
{
    [XmlIgnore]
    private XsType TypeObj;

    public Attr() { TypeObj = XsType.Bool; } //For serialization

    public Attr(string name, XsType type, Uses use = Uses.None, string? deflt = null, string? doc = null) : base(name, doc)
    {
        if (use == Uses.Required && deflt != null) //Keep with NULL then if forces "" as default value for strings
            throw new ArgumentException($"Default value should not be provided if use is Required in '{name}' attribute");

        TypeObj = type;
        this.type = type.name;
        this.use = use;
        dflt = deflt!;
    }

    internal override void RegisterTypeRecur(NbDictionary<string, XsType> types) => TypeObj.RegisterSelfAndChildrenTypes(types);

    internal void WriteTo(NbTag root)
    {
        root.TAT("attribute", a =>
        {
            a["name"]= Name;
            a["type"] = TypeObj.name;
            switch (use)
            {
                case Uses.None: break;
                case Uses.Key: break;
                default:
                    a["use"] = use.ToString().ToLower();
                    break;
            }

            if (dflt != null)
                a["default"] = dflt;
        },
        AddDoc);
    }

    internal void Resolve(XsType[] types)
    {
        TypeObj = types.SingleOrDefault(t => t.name == this.type) ?? throw new Exception($"Can't find type '{this.type}' during resolution");
    }
}

//Value is mimiking the attribute for now, but should create mixed type instead
public partial class Val : BaseTag
{
    [XmlIgnore]
    private XsType? TypeObj;

    public Val() { } //For serialization

    public Val(string name, XsType type, Uses use = Uses.None, string? deflt = null, string? doc = null) : base(name, doc)
    {
        TypeObj = type;
        this.type = type.name;
        this.use = use;
        dflt = deflt!;
    }

    internal override void RegisterTypeRecur(NbDictionary<string, XsType> types) => TypeObj?.RegisterSelfAndChildrenTypes(types);

    internal void WriteTo(NbTag root)
    {
        root.TAT("attribute", a =>
        {
            a["name"] = Name;
            a["type"] = TypeObj?.name ?? "Type was not initialized";
            if (use != Uses.None)
                a["use"] = use.ToString().ToLower();
            if (dflt != null)
                a["default"] = dflt;
        },  
        AddDoc);
    }

    internal void Resolve(XsType[] types)
    {
        TypeObj = types.SingleOrDefault(t => t.name == this.type) ?? throw new Exception($"Can't find type '{this.type}' during resolution");
    }
}
