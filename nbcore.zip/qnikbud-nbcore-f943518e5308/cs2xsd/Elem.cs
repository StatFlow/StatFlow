﻿using NbCore;
using System.Xml.Serialization;

namespace NbXsdV1.Xml;

public partial class Elem : BaseTag
{
    public const int Unbounded = -1;
    public const int Default = -2;

    [XmlIgnore]
    public XsType TypeObj;

    public Elem(string name, XsType type, int min = 0, int max = Default, string? doc = null)
        : base(name, doc)  //int min = 0, int max = -2,  string? doc = null
    {
        TypeObj = type ?? throw new Exception($"XsType was not provided in element {name}");
        this.type = type.name;
        this.min = min;
        this.max = max;
    }

    internal override void RegisterTypeRecur(NbDictionary<string, XsType> types) => TypeObj.RegisterSelfAndChildrenTypes(types);

    internal void WriteTo(NbTag root)
    {
        root.TAT("element", a =>
        {
            a["name"] = Name;
            a["type"] = TypeObj.name; //TODO: Count the uses of each type and if the type is used only once - embed it here, instead of using the named reference

            if (min != -2)
                a["minOccurs"] = min == -1 ? "unbounded" : min.ToString();
            if (max != -2)
                a["maxOccurs"] = max == -1 ? "unbounded" : max.ToString();
        },
        t =>
        {
            AddDoc(t);
            foreach (var key in keys.Safe())  //Automatic handling based on searching of the key fields doesn't work, because it creates unpredicted names for keys
            {
                AddXsKeyTag(t, key.name, key.selector, key.field);
            }
            //HandleKeyAttributesInTheChildTags(t); 
        });
    }

    /*public void HandleKeyAttributesInTheChildTags(INbTag tg)
    {
        var elTagPairs = TypeObj.Elems.SelectMany(el => el.TypeObj.Attribs.Where(a => a.use == Uses.Key).Select(att => (el, att))).ToList(); //The elements and their attributes marked with Use.Key

        foreach (var grp in elTagPairs.GroupBy(p => p.att.Name))
        {
            string selector = String.Join("|", grp.Select(p => p.el.Name));
            AddXsKeyTag(tg, selector, grp.Key, Name);
        }
    }*/

    //The key group must be defined in the element tag which is the collection of the tags containing the key attributes
    public static void AddXsKeyTag(NbTag tg, string keyName, string selector, string field)
    {
        tg.TAT("key", a => a["name"] = keyName, t1 =>
            t1.TA("selector", a => a["xpath"] = selector)
              .TA("field", a => a["xpath"] = field)
        );
    }

    /*      		<xs:key name="IconName"  >
                        <xs:selector xpath="icon" />
                        <xs:field xpath="@name" />
                    </xs:key>
    */

    internal void Resolve(XsType[] types)
    {
        TypeObj = types.SingleOrDefault(t => t.name == this.type) ?? throw new Exception($"Can't find type '{this.type}' during resolution");
    }
}

/// <summary>
/// The element, which creates a collection tag with single type nodes inside
/// </summary>
public partial class ListSingle : Elem
{
    public ListSingle() { }

    public ListSingle(string listName, string elementName, XsType type, bool allowEmpty = false)
        : base(listName,
              new TypeSequence("ListOf" + type.name.Replace(":", ""), new Elem(elementName, type, allowEmpty ? 0 : 1, Unbounded)),
               min: 0, max: 1)
    { }
}
