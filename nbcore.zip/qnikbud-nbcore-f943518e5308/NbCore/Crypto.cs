﻿using System.Text;
using System.IO.Compression;
using System.Security.Cryptography;

namespace NbCore.Crypto;

/*public interface IStringEncryptor
{
    string EncryptString(string plainText);
    string DecryptString(string encryptedText);
}*/

public class NbCrypto //: IStringEncryptor
{
    private readonly byte[] _k;
    private readonly byte[] _iv;
    private static byte[] K => Instance.Value._k;
    private static byte[] Iv => Instance.Value._iv;

    private readonly TripleDESCryptoServiceProvider _provider;
    private static TripleDESCryptoServiceProvider Prov => Instance.Value._provider;

    private readonly static Lazy<MD5> Md5Alg = new(() => MD5.Create());
    private readonly static Lazy<NbCrypto> Instance = new(() => new());

    public NbCrypto()
    {
        const int keyLength = 3;
        var seed = Math.PI;
        _iv = BitConverter.GetBytes(seed);
        _k = new byte[keyLength * sizeof(double)];
        for (int i = 0; i < keyLength; ++i)
        {
            seed *= Math.E;
            Array.Copy(BitConverter.GetBytes(seed), 0, _k, i * sizeof(double), sizeof(double));
        }
        //var a = TripleDES.Create() - use this instead
        _provider = new TripleDESCryptoServiceProvider();
    }

    public static string EncryptString(string plainText) => Encoding.Default.GetString(Transform(Encoding.Default.GetBytes(plainText), Prov.CreateEncryptor(K, Iv)));
    public static string DecryptString(string encryptedText) => Encoding.Default.GetString(Transform(Encoding.Default.GetBytes(encryptedText), Prov.CreateDecryptor(K, Iv)));

    public static string EncryptBase64(string plainText) => Convert.ToBase64String(Transform(Encoding.Default.GetBytes(plainText), Prov.CreateEncryptor(K, Iv)), Base64FormattingOptions.None); //Do not insert \r\n
    public static string DecryptBase64(string encryptedText) => Encoding.Default.GetString(Transform(Convert.FromBase64String(encryptedText), Prov.CreateDecryptor(K, Iv)));

    public static byte[] EncryptBytes(byte[] bytes) => Transform(bytes, Prov.CreateEncryptor(K, Iv));
    public static byte[] DecryptBytes(byte[] bytes) => Transform(bytes, Prov.CreateDecryptor(K, Iv));

    private static byte[] Transform(byte[] input, ICryptoTransform transform)
    {
        if (input.Length == 0)
            return Array.Empty<byte>();

        using MemoryStream stream = new();
        using CryptoStream cryptoStream = new(stream, transform, CryptoStreamMode.Write);
        cryptoStream.Write(input, 0, input.Length);
        cryptoStream.FlushFinalBlock();
        return stream.ToArray();
    }

    public static string Md5Safe64(string fileName) => Bytes_Safe64(Md5Bytes(fileName));
    public static string Md5Hex(string fileName) => Convert.ToHexString(Md5Bytes(fileName));
    public static byte[] Md5Bytes(string fileName)
    {
        using FileStream fileStream = new(fileName, FileMode.Open, FileAccess.Read);
        return Md5Alg.Value.ComputeHash(fileStream);
    }

    public static string Md5Safe64(Stream strm) => Bytes_Safe64(Md5Bytes(strm));
    public static string Md5Hex(Stream strm) => Convert.ToHexString(Md5Bytes(strm));
    public static byte[] Md5Bytes(Stream strm)
    {
        strm.Position = 0;
        return Md5Alg.Value.ComputeHash(strm);
    }

    //Amazon descriptions Can only contain alphanumeric characters, or any of the following: +=,.@-_
    //Http reserved: :/?#[]@ and !$&'()*+,;=   UNRESERVED chars: -._~     
    //WARNING!   _ used to be ~
    public static string Base64_Safe64(string str) => str.Replace('+', '-').Replace('/', '_').Replace("=", String.Empty);
    public static string Safe64_Base64(string str)
    {
        str = str.Replace('-', '+').Replace('_', '/').Replace('~', '/'); //'~' for backwards compatibility
        str += new String('=', 3 - ((str.Length - 1) % 4));
        return str;
    }

    public static string Bytes_Safe64(byte[] bts) => Base64_Safe64(Convert.ToBase64String(bts, Base64FormattingOptions.None));
    public static byte[] Safe64_Bytes(string str) => Convert.FromBase64String(Safe64_Base64(str));

    //   Table 1: The Base64 Alphabet
    //Value Encoding Value Encoding Value Encoding Value Encoding
    //    0 A            17 R            34 i            51 z
    //    1 B            18 S            35 j            52 0
    //    2 C            19 T            36 k            53 1
    //    3 D            20 U            37 l            54 2
    //    4 E            21 V            38 m            55 3
    //    5 F            22 W            39 n            56 4
    //    6 G            23 X            40 o            57 5
    //    7 H            24 Y            41 p            58 6
    //    8 I            25 Z            42 q            59 7
    //    9 J            26 a            43 r            60 8
    //   10 K            27 b            44 s            61 9
    //   11 L            28 c            45 t            62 +
    //   12 M            29 d            46 u            63 /
    //   13 N            30 e            47 v
    //   14 O            31 f            48 w         (pad) =
    //   15 P            32 g            49 x
    //   16 Q            33 h            50 y


    /*public static string Bytes2HexStr(byte[] bytes)
    {
        StringBuilder bld = new(bytes.Length * 2);
        foreach (byte b in bytes)
            bld.AppendFormat("{0:x2}", b);

        if (bld.Length != bytes.Length * 2)
            throw new Exception("Unexpected length in Bytes to Hex conversion");
        return bld.ToString();
    }*/

    //Convert.FromHexString - use in > .Net 5 
    /*public static string ByteToHexBitFiddle(byte[] bytes)
    {
        char[] c = new char[bytes.Length * 2];
        int b;
        for (int i = 0; i < bytes.Length; i++)
        {
            b = bytes[i] >> 4;
            c[i * 2] = (char)(55 + b + (((b - 10) >> 31) & -7));
            b = bytes[i] & 0xF;
            c[i * 2 + 1] = (char)(55 + b + (((b - 10) >> 31) & -7));
        }
        return new string(c);
    }*/

    public static string Ldr
    {
        get
        {
            int num = 0x26b66a5; //40593061;
            var arr1 = num.ToString().ToArray();
            var str = new String(arr1.Append(arr1[0]).Select((b, i) => (char)(2 + b + b + (i % 5 == 0 ? 1 : 0))).ToArray());
            return char.ToUpper(str[0]) + str[1..];
        }
    }

    //PseudoRandom Compress
    public static string ShrinkToSafe64(string src) => Bytes_Safe64(Shrink(src));

    public static byte[] Shrink(string src)
    {
        using var dstStream = new MemoryStream();
        using var compressor = new DeflateStream(dstStream, CompressionLevel.SmallestSize, leaveOpen: true);

        using var srcStream = src.ToMemoryStream();
        srcStream.CopyTo(compressor);
        compressor.Close();

        var bytes = dstStream.ToArray();
        using var rnd = RandBytes(bytes.Length).GetEnumerator();
        for (int i = 0; i < bytes.Length; i++)
        {
            bytes[i] ^= rnd.Current;
            rnd.MoveNext();
        }
        return bytes;
    }

    public static string ExpandFromSafe64(string src) => Encoding.UTF8.GetString(Expand(Safe64_Bytes(src)));

    public static string ExpandFromBytes(byte[] src) => Encoding.UTF8.GetString(Expand(src));

    public static byte[] Expand(byte[] src)
    {
        using var rnd = RandBytes(src.Length).GetEnumerator();
        for (int i = 0; i < src.Length; i++)
        {
            src[i] ^= rnd.Current;
            rnd.MoveNext();
        }

        using MemoryStream compressedStream = new(src);
        using DeflateStream zipStream = new(compressedStream, CompressionMode.Decompress);

        MemoryStream output = new();
        zipStream.CopyTo(output);
        zipStream.Close();

        //output.Position = 0;

        var bytes = output.ToArray();
        return bytes;
    }

    /// <summary>
    /// Simple implementation for pseudo-random bytes
    /// </summary>
    public static IEnumerable<byte> RandBytes(int seed)
    {
        while (true)
        {
            seed ^= seed >> 13;
            seed ^= seed << 18;
            seed &= 0x7fffffff;

            yield return (byte)(seed & 0xff);
            int ret = seed >> 8;
            yield return (byte)(ret & 0xff);
            ret >>= 8;
            yield return (byte)(ret & 0xff);
            ret >>= 8;
            yield return (byte)(ret & 0xff);
        }
    }


    static char[]? Cons = null;
    static char[]? Vow = null;

    public static string HumanReadablePass(int len, char div = '.')
    {
        char[] res = new char[len];
        Random rand = new();

        if (Cons == null || Vow == null)
        {
            Cons = new char[] { 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't', 'v', 'w', 'x', 'z' }; //q
            Vow = new char[] { 'a', 'e', 'i', 'o', 'u', 'y' };
        }

        for(int i = 0; i < len; ++i )
        {
            res[i] = (char)((i % 6) switch
            {
                0 => rand.OneOf(Cons) - 0x20,
                1 => rand.OneOf(Vow),
                2 => rand.OneOf(Cons),
                3 => rand.Next(10) + '0',
                4 => rand.Next(10) + '0',
                5 => div,
                _ => throw new ArithmeticException("Unexpected division result")
            }); 
        }
        return new string(res);
    }
}

public class GeorgeConverter
{
    private readonly Dictionary<char, char> MapAll;

    public GeorgeConverter()
    {
        MapAll = new Dictionary<char, char>();
        foreach (var triple in Letters)
        {
            MapAll[triple.Item1] = triple.Item2;
            MapAll[triple.Item2] = triple.Item1;
        }
    }

    public (string, int) Convert(string text)
    {
        StringBuilder bld = new(text.Length);

        int counter = 0;
        foreach (var ch in text.ToLowerInvariant())
        {
            if (MapAll.TryGetValue(ch, out char gr))
            {
                counter++;
                bld.Append(gr);
            }
            else
                bld.Append(ch); //No converstion for english letters, digits and symbols
        }
        return (bld.ToString(), counter);
    }


    enum LetterType { None = 0, Glas, Soglas }
    static readonly (char, char, LetterType)[] Letters =
    {
        ('й', 'ღ', LetterType.None),
        ( 'ц', 'ჯ' , LetterType.Soglas),
        ( 'у', 'უ' , LetterType.Glas),
        ( 'к', 'კ' , LetterType.Soglas),
        ( 'е', 'ე' , LetterType.Glas),
        ( 'н', 'ნ' , LetterType.Soglas),
        ( 'г', 'გ' , LetterType.Soglas),
        ( 'ш', 'შ' , LetterType.Soglas),
        ( 'щ', 'წ' , LetterType.Soglas),
        ( 'з', 'ზ' , LetterType.Soglas),
        ( 'х', 'ხ' , LetterType.Soglas),
        ( 'ъ', 'ც' , LetterType.None),

        ( 'ф', 'ფ' , LetterType.Soglas),
        ( 'ы', 'ძ' , LetterType.Glas),
        ( 'в', 'ვ' , LetterType.Soglas),
        ( 'а', 'თ' , LetterType.Glas),
        ( 'п', 'ა' , LetterType.Soglas),
        ( 'р', 'პ' , LetterType.Soglas),
        ( 'о', 'რ' , LetterType.Glas),
        ( 'л', 'ო' , LetterType.Soglas),
        ( 'д', 'ლ' , LetterType.Soglas),
        ( 'ж', 'დ' , LetterType.Soglas),
        ( 'э', 'ჟ' , LetterType.Glas),

        ( 'я', 'ჭ' , LetterType.Glas),
        ( 'ч', 'ჩ' , LetterType.Soglas),
        ( 'с', 'ყ' , LetterType.Soglas),
        ( 'м', 'ს' , LetterType.Soglas),
        ( 'и', 'მ' , LetterType.Glas),
        ( 'т', 'ი' , LetterType.Soglas),
        ( 'ь', 'ტ' , LetterType.None),
        ( 'б', 'ქ' , LetterType.Soglas),
        ( 'ю', 'ბ' , LetterType.Glas)
    };
}
