﻿namespace NbCore;

public class NcTag
{
}
