﻿using System.Text;
using NbCore.Crypto;

//using Serilog.Core;

namespace NbCore;

public class DiskStore
{
    const char KeyNameSeparator = '_';
    public readonly string StoreRoot;
    //public readonly Logger? Log;

    public DiskStore(string rootDir/*, Logger? log = null*/)
    {
        if (!Directory.Exists(rootDir))
            throw new Exception($"DiskStore root directory '{rootDir}' doesn't exist");
        StoreRoot = rootDir;
        //Log = log;
    }



    public (string, FileInfo) StoreFileByMd5_Safe64(string srcFile, bool move = false, bool overwrite = false)  //Doesn't have type - use many DiskStores instead
    {
        string md5base = NbCrypto.Md5Safe64(srcFile);

        var dst = new FileInfo(Path.Combine(DirByKey(md5base), md5base));
        if (!dst.Exists || overwrite)
        {
            NbFs.CreateDirRecursive(dst);
            if (move)
                File.Move(srcFile, dst.FullName, overwrite);
            else
                File.Copy(srcFile, dst.FullName, overwrite);
        }
        return (md5base, dst);
    }

    public void RestoreFileByMd5_Safe64(string md5safe64, FileInfo dstFi, bool move = false, bool overwrite = false)
    {
        var srcFile = PathByKey(md5safe64);
        if (!File.Exists(srcFile))
            throw new Exception($"File with key '{md5safe64}' was not found in DiskStore '{StoreRoot}'");

        NbFs.CreateDirRecursive(dstFi.DirSafe());
        if (move)
            File.Move(srcFile, dstFi.FullName, overwrite);
        else
            File.Copy(srcFile, dstFi.FullName, overwrite);
    }

    public void DeleteFileByMd5_Safe64(string md5safe64)
    {
        FileInfo srcFile = new(PathByKey(md5safe64));
        if (srcFile.Exists)
        {
            string trashDir = DeletedPathByKey(String.Empty);
            if (!Directory.Exists(trashDir))
                Directory.CreateDirectory(trashDir);

            string trashPath = DeletedPathByKey(md5safe64);

            if (File.Exists(trashPath)) //Already exists in Trash
                srcFile.Delete();
            else
                srcFile.MoveTo(trashPath);

            DirectoryInfo srcDir = srcFile.DirSafe(); //Delete the directory if it was the last file
            if (!srcDir.EnumerateFiles().Any())
                srcDir.Delete();
        }
    }

    public  Task<(string, FileInfo)> StoreStreamByMd5_Safe64(Stream ms, bool overwrite = false)  //Doesn't have type - use many DiskStores instead
    {
        throw new NotImplementedException();
        /*string md5base = NbCrypto.Md5Safe64(ms);

        var dst = new FileInfo(Path.Combine(DirByKey(md5base), md5base));
        if (!dst.Exists || overwrite)
        {
            NbFs.CreateDirRecursive(dst);
            FileMode access = dst.Exists && overwrite ? FileMode.Truncate : FileMode.CreateNew;
            using FileStream file = new(dst.FullName, access, FileAccess.Write);
            ms.Position = 0;
            await ms.CopyToAsync(file);
        }

        return (md5base, dst);*/
    }

    /// <summary>
    /// Saves file in the Directory like this:  TestStore\\poetry\\14\\14256_Однажды в студёную зимнюю пору.txt
    /// </summary>
    /// <param name="srcFileName">The name of the existing file on disk to be used as a source</param>
    /// <param name="type">poetry - the type of the file (its own directory will be used)</param>
    /// <param name="key">14256 - the key will be in the beginning of the file and will be used for subdir</param>
    /// <param name="name">Однажды в студёную зимнюю пору - the name of the file</param>
    /// <param name="ext">.txt - extension of the file</param>
    /// <param name="moveFile">true if file should be moved from its location, otherwise it will be copied</param>
    /// <exception cref="NbExceptionInfo"></exception>
    [Obsolete("Thing about removing the type from parameters and having many DiskStored instead")]
    public void StoreNameFileByKey(string srcFileName, string type, string key, string name, string ext, bool moveFile = false)
    {
        if (!File.Exists(srcFileName))
            throw new NbExceptionInfo($"Source file '{srcFileName}' was not found");

        string dstDir = DirByKey(key, type);
        var di = new DirectoryInfo(dstDir);
        if (!di.Exists) //Only if such dir doesn't exist. otherwise the file is guaranteed not to be there
        {
            NbFs.CreateDirRecursive(dstDir);
            var existing = FindPathByKey(key, type);
            if (existing != null)
                throw new NbExceptionInfo($"File with key '{key}' and type {type} already exists in the store '{StoreRoot}'");
        }

        string newPath = Path.Combine(dstDir, key + KeyNameSeparator + name + ext);
        if (moveFile)
            File.Move(srcFileName, newPath);
        else
            File.Copy(srcFileName, newPath);
    }

    /// <summary>
    /// Must be public because some applications may need direct link to the file (to use in html page for instance)
    /// </summary>
    /// <param name="key"></param>
    /// <param name="type"></param>
    /// <returns></returns>
    /// <exception cref="NbExceptionInfo"></exception>
    public string? FindPathByKey(string key, string type)
    {
        DirectoryInfo di = new(DirByKey(key, type));
        if (!di.Exists)
            return null;

        var files = di.GetFiles(key + '*');
        return files.Length switch
        {
            0 => null,
            1 => files[0].FullName,
            _ => throw new NbExceptionInfo($"There are {files.Length} files with the type '{type}' and key '{key}': {String.Join(",", files.Take(5).Select(f => f.Name))}")
        };
    }

    protected string DirByKey(string key, string type, int prefLen = 1) => Path.Combine(StoreRoot, type, key[0..prefLen]);  //uri.Host is not useful, because it is usually CDN service URL
    protected string DirByKey(string key, int prefLen = 1) => Path.Combine(StoreRoot, key[0..prefLen]);  //uri.Host is not useful, because it is usually CDN service URL
    public string PathByKey(string key, int prefLen = 1) => Path.Combine(StoreRoot, key[0..prefLen], key);
    public string DeletedPathByKey(string key) => Path.Combine(StoreRoot, "deleted", key);

    public static string Bytes2HexStr(byte[] bytes)
    {
        StringBuilder bld = new(bytes.Length * 2);
        foreach (byte b in bytes)
            bld.AppendFormat("{0:x2}", b);

        if (bld.Length != bytes.Length * 2)
            throw new Exception("Unexpected length in Bytes to Hex conversion");
        return bld.ToString();
    }
}
