﻿using System.Text.RegularExpressions;

namespace NbCore;

public static class NbMedia
{
    public enum FileMediaTypes { None, Video, Photo, Audio, Subtitle, Document, Other }

    public static readonly string[] VideoExtensions = { ".mpg", ".mpeg", ".avi", ".asf", ".wmv", ".m2v", ".mp4", ".mkv", ".avi", ".ts", ".flv", ".mov", ".webm", ".vob" };
    public static readonly string[] PhotoExtensions = { ".jpg", ".jpeg", ".png", ".webp", ".gif", ".jfif" };
    public static readonly string[] AudioExtensions = { ".mp3", ".m4a", ".wav", ".ogg", ".opus" };
    public static readonly string[] SubtitlesExtensions = { ".ass", ".srt" };
    public static readonly string[] DocumentExtensions = { ".pdf", ".docx" };
    public static readonly string[] LinkExtensions = { ".url" };

    public static FileMediaTypes GetFileMediaType(FileInfo fi) => GetFileMediaType(fi.Extension);
    public static FileMediaTypes GetFileMediaType(string extension)
    {
        if (String.IsNullOrWhiteSpace(extension))
            return FileMediaTypes.None;
        else if (VideoExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
            return FileMediaTypes.Video;
        else if (PhotoExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
            return FileMediaTypes.Photo;
        else if (AudioExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
            return FileMediaTypes.Audio;
        else if (SubtitlesExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
            return FileMediaTypes.Subtitle;
        else if (DocumentExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
            return FileMediaTypes.Document;
        else
            return FileMediaTypes.Other;
    }

    public static (string url, string name) ProcessUrlLinkFile(FileInfo fi)
    {
        if (!fi.Extension.EqIC(".url"))
            throw new NbExceptionInfo("File provided for URl parsing doesn't have .url extension: " + fi.FullName);

        var lines = File.ReadAllLines(fi.FullName);
        try
        {   //Simplified Parse Ini
            if (lines.Length == 0) throw new Exception("No lines in URL file");
            if (lines[0].Trim() != "[InternetShortcut]") throw new Exception("URL file doesn't start with [InternetShortcut]");
            var dict = new NbDictionary<string, string>(lines.Length - 1, StringComparer.InvariantCultureIgnoreCase, $"Lines of {fi.Name} file");
            foreach (var line in lines.Skip(1))
            {
                int eqInd = line.IndexOf("=");

                if (eqInd == -1) throw new Exception($"Line '{line}' doesn't contain '='");
                var key = line[..eqInd];
                var val = line[(eqInd + 1)..];
                dict.Add(key, val);
            }

            return (dict["url"], fi.NameWithoutExtension());
        }
        catch (Exception ex) { throw new Exception($"Error processing URL file '{fi.FullName}'\r\n{String.Join(Environment.NewLine, lines)}", ex); }
    }


    public static string? GetNewFileInSequenceN(string aMediaDir)
    {
        string? ext = null;
        foreach (var fi in new DirectoryInfo(aMediaDir).GetFiles().Where(f => !f.Name.Equals("Thumbs.db") && !f.Name.Equals("desktop.ini")).OrderBy(fi => fi.Name))
        {
            if (ext == null && VideoExtensions.Any(ex => ex.Equals(fi.Extension, StringComparison.OrdinalIgnoreCase))) //If the first file in the list with video extension
            {
                ext = fi.Extension;
                fi.MoveTo(fi.FullName[..^fi.Extension.Length]); // Remove extension from the current file
            }
            else if (ext != null)
            {
                string newName = fi.FullName + ext;
                fi.MoveTo(newName);
                return newName;
            }
        }
        return null;
    }

    /// <summary>
    /// Created directory next to the source file with the %NAME% + _keyframes.
    /// Then the files are renamed to contain the timestamps in mm.ss.fff format: Frame_01.12.347.png
    /// </summary>
    /// <param name="srcVideoFile"></param>
    /// <param name="ffmpeg"></param>
    /// <returns></returns>
    /// <exception cref="ArgumentException"></exception>
    /// <exception cref="Exception"></exception>
    public static async Task Ffmpeg_IndexKeyThumbnails(string srcVideoFile, string ffmpeg)
    {
        if (!File.Exists(srcVideoFile))
            throw new ArgumentException($"Can't find source file: '{srcVideoFile}'");
        if (!File.Exists(ffmpeg))
            throw new ArgumentException($"Can't find ffmpeg executable: '{ffmpeg}'");

        FileInfo srcFile = new(srcVideoFile);
        DirectoryInfo dir = srcFile.DirSafe();
        DirectoryInfo keyframeDir = Directory.CreateDirectory(Path.Combine(dir.FullName, srcFile.Name + "_keyframes"));

        //C:\App\ffmpeg\bin\ffmpeg.exe -i DDI.mp4 -f image2 -vf "select='eq(pict_type,PICT_TYPE_I)'" -vsync vfr String%%03d.png -loglevel debug 2>log.txt
        (int exitCode, string _, string errOut) = await NbProcess.RunAsync(ffmpeg, null, "-i", srcFile.FullName, "-f", "image2", "-vf", "select='eq(pict_type,PICT_TYPE_I)'",
            "-vsync", "vfr", $@"{keyframeDir}\Frame%03d.png", "-loglevel", "debug");

        if (exitCode != 0)
            throw new Exception(errOut);

        List<TimeSpan> keyStamps = ParseFFmpegDebug(errOut);
        FileInfo[] frames = keyframeDir.GetFilesSafe();  //Rename the files according to timestamps
        if (frames.Length != keyStamps.Count)
            throw new Exception($"The number of frame files '{frames.Length}' and the key frame timestamps read from the log '{keyStamps.Count}' are different");

        for (int i = 0; i < frames.Length; i++)
        {
            //https://learn.microsoft.com/en-us/dotnet/standard/base-types/custom-timespan-format-strings
            string newFileName = $"Frame_{keyStamps[i]:mm\\.ss\\.fff}.png";
            File.Move(frames[i].FullName, Path.Combine(keyframeDir.FullName, newFileName));
        }
    }

    /// <summary>
    /// TODO: this must be using ffprobe -select_streams v -show_frames \ -show_entries frame = pict_type \ -of csv bbb480.avi \ | grep -n I | cut -d ':' -f 1
    /// https://superuser.com/questions/885452/extracting-the-index-of-key-frames-from-a-video-using-ffmpeg
    /// Now it creates unnecessary png file in the temp dir
    /// </summary>
    /// <param name="srcFile"></param>
    /// <param name="ffmpeg"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private static async Task<List<TimeSpan>> TimeStampsOutOfFile(FileInfo srcFile, string ffmpeg)
    {
        await using var tempDir = NbTempDir.CreateInTemp();
        //tempPng will be deleted
        //C:\App\ffmpeg\bin\ffmpeg.exe -i DDI.mp4 -f image2 -vf "select='eq(pict_type,PICT_TYPE_I)'" -vsync vfr String%%03d.png -loglevel debug 2>log.txt
        (int exitCode2, string _, string errOut2) = await NbProcess.RunAsync(ffmpeg, null, "-i", srcFile.FullName, "-f", "image2", "-vf", "select='eq(pict_type,PICT_TYPE_I)'",
            "-vsync", "vfr", $@"{tempDir}\Frame%03d.png", "-loglevel", "debug");
        if (exitCode2 != 0)
            throw new Exception(errOut2);
        return ParseFFmpegDebug(errOut2);
    }


    private static List<TimeSpan> ParseFFmpegDebug(string errOut)
    {
        List<TimeSpan> keyStamps = new();
        using StringReader rdr = new(errOut);
        Regex parsedSElectLine = new(@"\st\:(\d+\.\d+)\s"); //[Parsed_select_0 @ 000001f57cf37d40] n:0.000000 pts:0.000000 t:0.000000 key:1 interlace_type:P pict_type:I scene:nan -> select:1.000000 select_out:0
        string? curr;
        while ((curr = rdr.ReadLine()) != null)
        {
            if (curr.Contains("key:1"))
            {
                var res = parsedSElectLine.Match(curr);
                if (!res.Success)
                    throw new Exception($"key:1 line doesn't have timestamp: '{curr}'");

                if (!Decimal.TryParse(res.Groups[1].Value, out decimal seconds))
                    throw new Exception($"Can't parse timestamp: '{curr}'");

                keyStamps.Add(new TimeSpan((long)(seconds * 10_000_000)));
            }
        }
        return keyStamps;
    }

    private static readonly TimeSpan epsilon = new(50 * TimeSpan.TicksPerMillisecond); //100ms - 100 ms before the key frame, otherwise doesn't start with keyframe

    public static async Task<string> Ffmpeg_CutByTimestamps(string srcVideoFile, string ffmpeg, TimeSpan from, TimeSpan to)
    {
        if (!File.Exists(srcVideoFile))
            throw new ArgumentException($"Can't find source file: '{srcVideoFile}'");
        if (!File.Exists(ffmpeg))
            throw new ArgumentException($"Can't find ffmpeg executable: '{ffmpeg}'");
        FileInfo srcFile = new(srcVideoFile);

        List<TimeSpan> keys = await TimeStampsOutOfFile(srcFile, ffmpeg);
        int ind = ~keys.BinarySearch(from) - 1;
        if (ind >= 0)
            from = keys[ind].Subtract(epsilon); //Adjusting from to the previous closest key frame
        if (from.Ticks < 0)
            from = TimeSpan.Zero;

        string fr = from.ToString("hh\\:mm\\:ss\\.fff");
        //string t = (to - from).ToString("hh\\:mm\\:ss\\.fff"); //Was used when -ss preceded -i
        string t = to.ToString("hh\\:mm\\:ss\\.fff"); // 
        string dstFile = Path.Combine(srcFile.DirSafe().FullName, srcFile.NameWithoutExtension() + ".part" + srcFile.Extension);
        //C:\App\ffmpeg\bin\ffmpeg.exe  -ss 00:00:42.900 -i ddi.mp4 -to 00:01:01.044 -c:v copy -c:a copy slice_output.mp4
        //With -ss repreceding -i, it will interpret the -to as a length of the video
        (int exitCode, string _, string errOut) = await NbProcess.RunAsync(ffmpeg, null, "-i", srcFile.FullName, "-ss", fr, "-to", t, "-c:v", "copy", "-c:a", "copy", dstFile);

        if (exitCode != 0)
            throw new Exception(errOut);

        return dstFile;
    }


    /*private static Regex DateTakenRegex
    {
        get
        {
            if (fDateTakenRegex == null)
                fDateTakenRegex = new Regex(":");
            return fDateTakenRegex;
        }
    }
    private static Regex fDateTakenRegex;

    public static DateTime GetDateTakenFromImage(FileInfo fi)
    {
        try
        {
            using (FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read))
            using (Image myImage = Image.FromStream(fs, false, false))
            {
                PropertyItem propItem = myImage.GetPropertyItem(36867);
                string dateTaken = DateTakenRegex.Replace(Encoding.UTF8.GetString(propItem.Value), "-", 2);
                return DateTime.Parse(dateTaken);
            }
        }
        catch (ArgumentException)
        {
            return fi.LastWriteTime;
        }
    }*/
}
