﻿using System.Collections;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;

using NbCore.NbNullable;

namespace NbCore
{
    public class CsvFieldInfo
    {
        public enum SpecialFunction { Exclude = -1, None = 0, FileName = 1, FileLine = 2 };
        protected const char GenTypeSeparator = '`';

        public readonly string Name;
        public readonly Type FieldType;
        public readonly SpecialFunction SpecFunc;

        protected CsvFieldInfo(MemberInfo mi, SpecialFunction specFunc)
        {
            Name = mi.Name;
            SpecFunc = specFunc;

            FieldType = mi switch
            {
                FieldInfo fi => fi.FieldType,
                PropertyInfo pi => pi.PropertyType,
                _ => throw new NbExceptionEnum<MemberTypes>(mi.MemberType),
            };

            // other options: MemberTypes.Constructor:  MemberTypes.Event:  MemberTypes.Method:    MemberTypes.TypeInfo:   MemberTypes.Custom:
            // MemberTypes.NestedType: MemberTypes.All:
        }

        private static string? GetFormatFromAttribute(IEnumerable<Attribute> customAttrib, string fldName) =>
            customAttrib.OfType<CsvFormat>().SingleOrDefaultVerbose(_ => true, i => $"Field {fldName} has {i} {nameof(CsvFormat)} attributes. At most one is extected.")?.Format;

        private static SpecialFunction GetSpecialFunction(IEnumerable<Attribute> customAttrib, Type fldType, string fldName)
        {
            var attrib = customAttrib.ToList();
            if (attrib.OfType<CsvIgnore>().Any())
                return SpecialFunction.Exclude; //Ignore CsvIgnore

            SpecialFunction sFunc = SpecialFunction.None;
            if (attrib.OfType<CsvFileName>().Any())
            {
                if (fldType.Name == nameof(String))
                    sFunc = SpecialFunction.FileName;
                else
                    throw new NbExceptionInfo($"Attribute {nameof(CsvFileName)} must be assigned to String field or property, '{fldName}' fields is of type '{fldType.Name}'");
            }

            if (attrib.OfType<CsvFileLineNum>().Any())
            {
                if (sFunc == SpecialFunction.None)
                {
                    sFunc = fldType.Name switch
                    {
                        nameof(Int16) or nameof(Int32) or nameof(Int64) => SpecialFunction.FileLine,
                        _ => throw new NbExceptionInfo($"Attribute {nameof(CsvFileName)} must be assigned to String field or property, '{fldName}' fields is of type '{fldType.Name}'"),
                    };
                }
                else
                    throw new NbExceptionInfo($"Both {nameof(CsvFileName)} and {nameof(CsvFileLineNum)} attributes allied to the same field '{fldName}'");
            }
            return sFunc;
        }


        //TODO: How is it different to the next Create?
        protected static List<T> CreateFieldInfos<T>(Type type, Action<string>? _, Func<FieldInfo, SpecialFunction, string?, T> fi2t, Func<PropertyInfo, SpecialFunction, string?, T> pi2t)
        {
            try
            {
                List<T> list = new(10);
                //Properties firs so that Id can be first
                foreach (var pi in type.GetProperties())
                {
                    var specFunc = GetSpecialFunction(pi.GetCustomAttributes(), pi.PropertyType, pi.Name);
                    if (specFunc == SpecialFunction.Exclude)
                        continue;

                    var fmt = GetFormatFromAttribute(pi.GetCustomAttributes(), pi.Name);
                    list.Add(pi2t(pi, specFunc, fmt));
                }

                foreach (var fi in type.GetFields().Where(fi => !fi.IsStatic))
                {
                    var specFunc = GetSpecialFunction(fi.GetCustomAttributes(), fi.FieldType, fi.Name);
                    if (specFunc == SpecialFunction.Exclude)
                        continue;

                    string? fmt = GetFormatFromAttribute(fi.GetCustomAttributes(), fi.Name);
                    list.Add(fi2t(fi, specFunc, fmt));
                }

                if (list.Count == 0)
                    throw new CsvException($"Object type '{type.Name}' doesn't have any fields or properties in {nameof(CreateFieldInfos)}() method");
                return list;
            }
            catch (Exception ex)
            {
                throw new CsvException("Error mapping fields for '{0}' type: {1}", type.Name, NbException.Exception2String(ex));
            }
        }

        protected static FLD_INF[] Create<FLD_INF>(Type type, ICollection<string> headers, CsvParameters? csvParamN,
            Func<FieldInfo, int, SpecialFunction, string?, FLD_INF> fi2t, Func<PropertyInfo, int, SpecialFunction, string?, FLD_INF> pi2t)
                where FLD_INF : CsvFieldInfo
        {
            try
            {
                //Mapping of the header name to its column number (starting with 0)
                Dictionary<string, int> headerIndexes = new(StringComparer.OrdinalIgnoreCase);
                int counter = 0;
                foreach (string header in headers)
                {
                    if (headerIndexes.ContainsKey(header))
                        throw new NbException($"Header '{header}' has multiple occurences");

                    headerIndexes.Add(header, counter);
                    counter++;
                }

                SortedList<int, FLD_INF> fldAndProp = new(10);
                List<string> fieldPropNamesInSource = new(10);
                foreach (var fi in type.GetFields().Where(fi => !fi.IsStatic))
                {
                    var custAttrib = fi.GetCustomAttributes();
                    var specFunc = GetSpecialFunction(custAttrib, fi.FieldType, fi.Name);
                    if (specFunc == SpecialFunction.None) //TODO: special function fields are ignored
                    {
                        CsvNameInSource? nisAttr = custAttrib.OfType<CsvNameInSource>().SingleOrDefaultVerbose(_ => true,
                            i => $"Multiple CsvNameInSource attributes are not allowed. {i} found on {fi.Name} field");
                        string nameInSource = nisAttr?.SourceColumn ?? fi.Name;
                        fieldPropNamesInSource.Add(nameInSource);

                        var fmt = GetFormatFromAttribute(custAttrib, fi.Name);
                        if (headerIndexes.TryGetValue(nameInSource, out int index))
                            fldAndProp.Add(index, fi2t(fi, index, SpecialFunction.None, fmt)); //TODO: special function fields are ignored);
                        else
                        { }//NbEwiMessage.Warning(csvParamN?.LoggerN, $"Field '{fi.Name}' of the object '{type.Name}' doesn't have a corresponding column in the datasource '{String.Join(", ", headers)}'");
                    }
                }

                foreach (var pi in type.GetProperties())
                {
                    var custAttrib = pi.GetCustomAttributes();
                    var specFunc = GetSpecialFunction(custAttrib, pi.PropertyType, pi.Name);
                    if (specFunc == SpecialFunction.None)  //TODO: special function fields are ignored
                    {
                        CsvNameInSource? nisAttr = custAttrib.OfType<CsvNameInSource>().SingleOrDefaultVerbose(_ => true,
                             i => $"Multiple CsvNameInSource attributes are not allowed. {i} found on {pi.Name} property");
                        string nameInSource = nisAttr?.SourceColumn ?? pi.Name;
                        fieldPropNamesInSource.Add(nameInSource);

                        var fmt = GetFormatFromAttribute(custAttrib, pi.Name);
                        if (headerIndexes.TryGetValue(nameInSource, out int index))
                            fldAndProp.Add(index, pi2t(pi, index, SpecialFunction.None, fmt)); //TODO: special function fields are ignored
                        else
                        { }//NbEwiMessage.Warning(csvParamN?.LoggerN, $"Property '{pi.Name}' of the object '{type.Name}' doesn't have a corresponding column in the datasource '{String.Join(", ", headers)}'");
                    }
                }

                //Warning section
                //TODO: give series of warnings about specific fields and don't use case in warnings
                //var fieldPropNames = fldAndProp.Where(fp => fp.Value.SpecFunc == SpecialFunction.None).Select(fp => fp.Value.Name).ToList();

                fieldPropNamesInSource.AddRange(csvParamN?.IgnoreSourceFieldN ?? Enumerable.Empty<string>()); //Top up with the fields to ignore
                if (headers.NotIn(fieldPropNamesInSource, (a, b) => a.EqIC(b)).Any())
                {
                    //NbEwiMessage.Warning(csvParamN?.LoggerN, "Headers '{0}' of the datasource didn't match object's '{1}' fields and properties '{2}'",
                    //String.Join(", ", headers.NotIn(fieldPropNamesInSource)), type.Name, String.Join(", ", fieldPropNamesInSource));
                }

                return fldAndProp.Values.ToArray();
            }
            catch (Exception ex)
            {
                throw new CsvException(ex, "Error mapping fields using headers for '{0}' type.", type.Name);
            }
        }
    }

    public class CsvObjectToText : CsvFieldInfo
    {
        private const char quote = '"';
        private const string singleQuote = "\"";
        private const string doubleQuotes = "\"\"";

        protected readonly Func<object?, object?> Getter;
        protected Func<object, CsvParameters?, string?>? Converter;
        protected readonly char separator;

        protected CsvObjectToText(FieldInfo fi, SpecialFunction specFunc, char sep, string? formatN = null)
            : base(fi, specFunc)
        {
            Getter = fi.GetValue;
            Converter = GetConverter(FieldType);
            separator = sep;
            _ = formatN; //TODO: Use format when writing
        }

        protected CsvObjectToText(PropertyInfo pi, SpecialFunction specFunc, char sep, string? formatN = null)
            : base(pi, specFunc)
        {
            Getter = pi.GetValue;
            Converter = GetConverter(FieldType);
            separator = sep;
            _ = formatN; //TODO: Use format when writing
        }

        public string? GetText(object obj, CsvParameters? csvParam)
        {
            object? propObj = Getter(obj);
            return (propObj != null) ? Converter?.Invoke(propObj, csvParam) : null;
        }

        public static List<CsvObjectToText> Create(Type type, Action<string>? log, char sep)
        {
            return CreateFieldInfos(type, log, (fi, specFunc, fmt) => new CsvObjectToText(fi, specFunc, sep, fmt), (pi, specFunc, fmt) => new CsvObjectToText(pi, specFunc, sep, fmt));
        }

        private Func<object, CsvParameters?, string?>? GetConverter(Type type)
        {
            if (!type.IsGenericType)
            {
                if (type.IsSubclassOf(typeof(IdHolder)))
                {
                    return ConverterIdHolder;
                }

                switch (type.Name)
                {
                    case nameof(String): return ConverterString;

                    case nameof(Int64):
                        return (o, _) => (Int64)o == Int64.MinValue ? null : o.ToString();
                    case nameof(Int32):
                        return (o, _) => (Int32)o == Int32.MinValue ? null : o.ToString();
                    case nameof(Decimal):
                        return (o, _) => (Decimal)o == Decimal.MinValue ? null : o.ToString();
                    case nameof(Double):
                        return (o, _) => (Double)o == Double.MinValue ? null : o.ToString();
                    case nameof(Boolean):
                        return (o, _) => o.ToString();

                    case nameof(DateTime): return ConverterDateTime;
                    case nameof(TimeSpan): return ConverterTimeSpan;
                    default:
                        if (type.BaseType?.Name == nameof(Enum))
                            return ConverterEnum;
                        else
                            throw new CsvException($"Unsupported type '{type.Name ?? "Base Type is not provided"}' in Csv serialization");
                }
            }

            Type underlyingType1 = type.GetGenericArguments()[0]; //Generic must have at least one type parameter

            string name = type.Name;
            if (name.Contains(GenTypeSeparator))
                name = name[..name.IndexOf(GenTypeSeparator)];

            return name switch
            {
                nameof(Nullable) => GetConverter(underlyingType1),//Recursive
                "ObservableCollection" or "List" or "ObservableList" => GetConverterForCollection(GetConverter(underlyingType1)),//Recursive
                _ => throw new NbExceptionInfo($"Unsupported generic type '{name}' in FromCsv"),
            };
        }

        private static Func<object, CsvParameters?, string?>? GetConverterForCollection(Func<object, CsvParameters?, string?>? underlyingTypeConverter)
        {
            return (obj, csvParam) =>
            {
                if (obj is not IEnumerable coll)
                    return null;

                StringBuilder bld = new();
                int counter = 0;
                foreach (object el in coll)
                {
                    if (counter > 0)
                        bld.Append('|');
                    if (el != null)
                        bld.Append(underlyingTypeConverter?.Invoke(el, csvParam));
                    counter++;
                }
                return bld.ToString();
            };
        }

        private string? ConverterEnum(object propObj, CsvParameters? csvParam)
        {
            string? str = propObj.ToString();
            if ("NULL".Equals(str, StringComparison.OrdinalIgnoreCase)) //Don't write NULLs
                return null;

            return propObj.ToString();
        }

        private string ConverterDateTime(object propObj, CsvParameters? csvParam)
        {
            DateTime dt = (DateTime)propObj;
            if (dt.Hour == 0 && dt.Minute == 0 && dt.Second == 0 && dt.Millisecond == 0)
                return dt.ToString(csvParam?.DefaultDateTimeFormatN ?? "yyyy-MM-dd");
            else
                return dt.ToString(csvParam?.DefaultDateTimeFormatN ?? "yyyy-MM-dd HH:mm:ss.fff");
        }

        private string? ConverterIdHolder(object propObj, CsvParameters? csvParam)
        {
            IdHolder? idHolder = propObj as IdHolder;
            return idHolder?.Id;
        }

        private string ConverterTimeSpan(object propObj, CsvParameters? csvParam)
        {
            TimeSpan ts = (TimeSpan)propObj;
            if (ts.Days != 0)
                throw new CsvException("Timespans with days are not supported");
            return ts.ToString("c");
        }

        private string? ConverterString(object propObj, CsvParameters? csvParam)
        {
            if (csvParam?.QuoatedFields ?? false)
            {
                string st = propObj.ToString()?.Replace(singleQuote, doubleQuotes) ?? String.Empty;
                if (st.Contains(separator) || st.Contains(quote))
                    return $"{singleQuote}{st}{singleQuote}";
                else
                    return st;
            }
            else
                return propObj.ToString();
        }

        public override string ToString() => $"{FieldType.Name} {Name};  {Converter?.Method} ({Name})";
    }


    public abstract class CsvObjectSetter<TInfoLine> : CsvFieldInfo
    {
        public readonly int Index;

        public readonly Action<object?, object?> FldPropSetter; //instance of the object to set and the value (of object type)
        protected readonly Func<TInfoLine, object?>? SavedConverter; //Takes InfoLine and index int it and returns the object to set to the property or field
        protected readonly Func<string, IdHolder>? Resolve;

        protected readonly CsvParameters? csvParamN;

        protected CsvObjectSetter(FieldInfo fi, int index, SpecialFunction specFunc, CsvParameters? csvParamN, string? formatN)
            : base(fi, specFunc)
        {
            this.csvParamN = csvParamN;
            FldPropSetter = fi.SetValue;
            Index = index;
            Resolve = GetResolvingAction(FieldType, csvParamN?.ResolversN);
            SavedConverter = GetGonverter(FieldType, formatN);
        }

        protected CsvObjectSetter(PropertyInfo pi, int index, SpecialFunction specFunc, CsvParameters? csvParamN, string? formatN)
            : base(pi, specFunc)
        {
            this.csvParamN = csvParamN;
            FldPropSetter = pi.SetValue;
            Index = index;
            Resolve = GetResolvingAction(FieldType, csvParamN?.ResolversN);
            SavedConverter = GetGonverter(FieldType, formatN);
        }

        public void SetField(object obj, TInfoLine infoLine)
        {
            try
            {
                var setObj = SavedConverter?.Invoke(infoLine); //Saved converter called on the new line with info
                FldPropSetter(obj, setObj); //Using field or prop setter for a given instance to set the result returned from the converter
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Error parsing '{infoLine}'");
            }
        }

        public string? ValidateN(TInfoLine infoLine)
        {
            try
            {
                var setObj = SavedConverter?.Invoke(infoLine); //Saved converter called on the new line with info
                return null;
            }
            catch (Exception e)
            {
                return NbException.Exception2String(e);
            }
        }

        //protected abstract Action<object, TInfoLine> GetSettingAction(Type fldType);
        protected abstract Func<TInfoLine, object?>? GetGonverter(Type fldType, string? formatN);

        //Enumerable here because is allows covariance (Various IdHolders subtypes are allowed)
        private Func<string, IdHolder>? GetResolvingAction(Type fldType, IEnumerable<Func<string, IdHolder>>? resolversN)
        {
            if (fldType.IsGenericType) //Find resolver for the collections of IdHolders
                return GetResolvingAction(fldType.GetGenericArguments()[0], resolversN);

            if (fldType.IsSubclassOf(typeof(IdHolder)))
            {
                Func<string, IdHolder>? converter = null;
                foreach (var conv in resolversN.Safe())
                {
                    Type t = conv.GetType().GenericTypeArguments[1];
                    if (t.Equals(typeof(IdHolder)))
                        throw new NbException($"Resolver '{conv}' has generic argument set to IdHolder instead of derived class. Instantiate the delegate explicitly.");
                    if (t.Equals(fldType))
                    {
                        if (converter == null)
                            converter = conv;
                        else
                            throw new NbException($"Two resolvers for the same type '{fldType.Name}' has been found: '{conv}', '{converter}'");
                    }
                }
                if (converter != null)
                    return converter;
                else
                    throw new CsvException($"Resolver for the type '{fldType.Name}' was not found");
            }
            return null;
        }

        public override string ToString() => $"{FieldType.Name} {Name}";
    }



    public class CsvTextToObject : CsvObjectSetter<string>
    {
        protected CsvTextToObject(FieldInfo fi, int index, SpecialFunction specFunc, string? formatN, CsvParameters? csvParamN = null)
            : base(fi, index, specFunc, csvParamN, formatN)
        { }

        protected CsvTextToObject(PropertyInfo pi, int index, SpecialFunction specFunc, string? formatN, CsvParameters? csvParamN = null)
            : base(pi, index, specFunc, csvParamN, formatN)
        { }

        public static CsvTextToObject[] Create(Type type, ICollection<string> headers, CsvParameters? csvParamN)
        {
            return CsvFieldInfo.Create<CsvTextToObject>(type, headers, csvParamN,
                (fi, ind, specFunc, fmt) => new CsvTextToObject(fi, ind, specFunc, fmt, csvParamN),
                (pi, ind, specFunc, fmt) => new CsvTextToObject(pi, ind, specFunc, fmt, csvParamN));
        }

        protected override Func<string, object?>? GetGonverter(Type fldType, string? formatN)
        {
            string mainTypeName = fldType.Name;
            if (!fldType.IsGenericType)
            {   //Not generic
                if (fldType.IsSubclassOf(typeof(IdHolder)))
                {
                    return IdHolderConv;
                }
                switch (mainTypeName)
                {
                    case nameof(TimeSpan): return TimeSpanConv;
                    case nameof(DateTime):
                        if (csvParamN?.DefaultDateTimeFormatN != null)
                            return v => DateTimeConvFormat(v, csvParamN.DefaultDateTimeFormatN);
                        if (!String.IsNullOrEmpty(formatN))
                            return v => DateTimeConvFormat(v, formatN);
                        else
                            return DateTimeConv;

                    case nameof(Int32):
                        if (String.IsNullOrEmpty(formatN))
                            return Int32Conv;
                        else
                            return Int32ClearConv;

                    case nameof(Decimal):
                        if (String.IsNullOrEmpty(formatN))
                            return DecimalConv;
                        else
                            return DecimalClearConv;

                    case nameof(Boolean): return BooleanConv;
                    default:
                        {
                            if (fldType.BaseType?.Name == nameof(Enum))
                                return s => EnumConv(s, fldType);
                            else
                                return s => Convert.ChangeType(s, fldType);
                        }
                }
            }
            else //Generic
            {
                if (mainTypeName.Contains(GenTypeSeparator))
                    mainTypeName = mainTypeName[..mainTypeName.IndexOf(GenTypeSeparator)];

                //Recursive converter getter
                var underlyingConv = GetGonverter(FieldType.GetGenericArguments()[0], formatN) ?? throw new Exception("Underlying converter returned null");

                return mainTypeName switch
                {
                    nameof(Nullable) => s => String.IsNullOrEmpty(s) ? null : underlyingConv(s),
                    "List" => s => ListConv(s, underlyingConv),
                    "ObservableList" => s => ListConv(s, underlyingConv),
                    _ => throw new NbExceptionInfo($"Unsupported generic type '{mainTypeName}' for field '{Name}' in FromCsv"),
                };
            }
        }

        //Only supports removing the ',' thousand separator in the numbers 
        private object Int32ClearConv(string str)
        {
            str = str.Replace(",", String.Empty);
            return Int32Conv(str);
        }
        private object Int32Conv(string str)
        {
            if (str == "None" || String.IsNullOrEmpty(str)) //TODO: pass null value in source - empty space is default
                return -1; //TODO: pass null value in destination

            if (!Int32.TryParse(str, out var val))
                throw new Exception($"Can't convert {nameof(Int32)} out of '{str}'");
            else
                return val;
        }

        //Only supports removing the ',' thousand separator in the numbers 
        private object DecimalClearConv(string str)
        {
            str = str.Replace(",", String.Empty);
            return DecimalConv(str);
        }
        private object DecimalConv(string str)
        {
            if (!Decimal.TryParse(str, out var val))
                throw new Exception($"Can't convert {nameof(Decimal)} out of '{str}'");
            else
                return val;
        }


        private static object EnumConv(string fldVal, Type fldType)
        {
            try
            {
                object val = String.IsNullOrWhiteSpace(fldVal) ? 0 : Enum.Parse(fldType, fldVal); //Support for NULL, assuming NULL = 0
                return val;
            }
            catch (Exception ex)
            {
                throw new Exception($"Can't parse '{fldType.FullName}' enum out of '{fldVal}': '{ex.Message}'");
            }
        }

        private object IdHolderConv(string fldVal)
        {
            if (String.IsNullOrWhiteSpace(fldVal)) //Allow null pointers //TODO: Make attribute to throw exceptions on NULL pointers
                throw new ArgumentNullException(nameof(fldVal));

            if (Resolve == null)
                throw new CsvException("No resolver available for type '{0}'", this.FieldType);

            IdHolder idHolderN = Resolve(fldVal);
            if (idHolderN == null)
                throw new CsvException("Can't resolve '{0}' for Id='{1}'", this.FieldType, fldVal);

            return idHolderN;
        }

        private object TimeSpanConv(string fldVal)
        {
            if (!TimeSpan.TryParseExact(fldVal, "c", null, out TimeSpan interval))
                throw new CsvException("Can't parse time stamp out of '{0}'", fldVal);
            return interval;
        }

        private object DateTimeConv(string fldVal)
        {
            if (!NbExt.TryParseDate(fldVal, out DateTime dt)) //Try different datetime formats
                throw new CsvException($"Can't parse time stamp out of '{fldVal}'");
            return dt;
        }

        private static object DateTimeConvFormat(string fldVal, string format)
        {
            if (!DateTime.TryParseExact(fldVal, format, null, DateTimeStyles.None, out DateTime dt)) //Try different datetime formats
                throw new CsvException($"Can't parse time stamp out of '{fldVal}'");
            return dt;
        }
        private object BooleanConv(string fldVal)
        {
            bool booVal = "true".Equals(fldVal, StringComparison.OrdinalIgnoreCase) ||
                "1".Equals(fldVal, StringComparison.OrdinalIgnoreCase) ||
                "Y".Equals(fldVal, StringComparison.OrdinalIgnoreCase);
            return booVal;
        }

        private object ListConv(string fldVal, Func<string, object?> underlyingAction)
        {
            IList instance = Activator.CreateInstance(FieldType) as IList ?? throw new ArgumentNullException($"Can't create Activator for '{FieldType}'");
            if (String.IsNullOrEmpty(fldVal))
                return instance;

            foreach (string val in fldVal.Split('|').Select(s => s.Trim()))
                instance.Add(underlyingAction?.Invoke(val));
            return instance;
        }
    }
}
