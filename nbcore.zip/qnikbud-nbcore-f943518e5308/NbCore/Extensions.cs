﻿using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO.Compression;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;

//#pragma warning disable IDE0090 // Use 'new(...)'
namespace NbCore;

public static partial class NbExt
{
    public const string mm_ss = "mm:ss";
    public const string yyyyMMdd = "yyyyMMdd";
    public const string yyyy_MM_dd = "yyyy-MM-dd";
    public const string ddMMMyyyy = "dd-MMM-yyyy";
    public const string ddMMMyy = "dd-MMM-yy";
    public const string ddMMMyyyyHHmmss = "dd-MMM-yyyy HH:mm:ss";
    public const string ddMMMyyHHmmss = "dd-MMM-yy HH:mm:ss";
    public const string dd_MM_yyyyHHmmss = "dd/MM/yyyy HH:mm:ss";
    public const string Excel_dd_MM_yyyyHHmm = "dd/MM/yyyy HH:mm";
    public const string yyyyMMddHHmmss = "yyyy-MM-dd HH:mm:ss";
    public const string yyyyMMddHHmmss2 = "yyyy:MM:dd HH:mm:ss";
    public const string yyyyMMdd_HHmmss = "yyyyMMdd-HHmmss";
    public const string ebayDate = "dd MMM, yyyy HH:mm:ss";

    public static string FileTimeStamp => DateTime.Now.ToString(yyyyMMdd_HHmmss);

    public static string[] DateFormats { get; } = new string[] { yyyyMMdd, yyyy_MM_dd, ddMMMyyyy, ddMMMyy, ddMMMyyyyHHmmss, ddMMMyyHHmmss, dd_MM_yyyyHHmmss, Excel_dd_MM_yyyyHHmm, yyyyMMddHHmmss, yyyyMMddHHmmss2, yyyyMMdd_HHmmss, ebayDate };

    public static DateTime ParseDate(this string dtStt)
    {
        if (!TryParseDate(dtStt, out DateTime ret))
            throw new Exception($"Can't parse a date out of '{dtStt}'");
        else
            return ret;
    }
    public static bool TryParseDate(this string dtStt, out DateTime date)
    {
        foreach (var dFormat in DateFormats)
        {
            if (DateTime.TryParseExact(dtStt, dFormat, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out date))
                return true;
        }
        date = default;
        return false;
    }

    #region NBase
    /// <summary>
    /// 6-bit mask is applied internally
    /// </summary>
    /// <param name="bt"></param>
    /// <returns></returns>
    public static char ToNbase64Char(int bt) //bitwise operations cast to Int anyway, so we might as well use int
    {
        bt &= 0b0011_1111; //Apply mask in one place
        if (bt <= 9)
            return (char)('0' + bt); //0 = 48
        if (bt <= 35)
            return (char)('A' + bt - 10); //A = 81
        if (bt <= 61)
            return (char)('a' + bt - 36); //a = 113
        if (bt == 62)
            return '-'; //45
        if (bt == 63)
            return '_'; //95
        throw new OverflowException("Unreachable");
    }

    public static byte FromNbase64(char ch)
    {
        if ('0' <= ch && ch <= '9')
            return (byte)(ch - '0');
        if ('A' <= ch && ch <= 'Z')
            return (byte)(ch - 'A' + 10);
        if ('a' <= ch && ch <= 'z')
            return (byte)(ch - 'a' + 36);
        if (ch == '-') //45
            return 62;
        if (ch == '_') //95
            return 63;
        throw new OverflowException("Char to be converted should be [0-9A-Za-z-_]");
    }


    public static string ToNbase64(this DateTime dt) => String.Create(6, dt, (span, dt) =>
    {
        int cnt = 0;
        span[cnt++] = ToNbase64Char(dt.Year % 100);
        span[cnt++] = ToNbase64Char(dt.Month);
        span[cnt++] = ToNbase64Char(dt.Day);
        span[cnt++] = ToNbase64Char(dt.Hour);
        span[cnt++] = ToNbase64Char(dt.Minute);
        span[cnt++] = ToNbase64Char(dt.Second);
    });

    public static void BytesToSpan(Span<char> span, byte[] bytes)
    {
        int remainder = 0;
        int curByte = 0;

        int state = 0;
        int i = 0;
        for (; i < span.Length - 1; i++)
        {
            byte bt = bytes[curByte++];
            if (state == 0)
            {
                span[i] = ToNbase64Char(bt);
                remainder = bt >> 6;
            }
            else if (state == 1)
            {
                remainder |= bt << 2; //10 bits
                span[i] = ToNbase64Char(remainder);
                remainder >>= 6; //4 bits
            }
            else if (state == 2)
            {
                remainder |= bt << 4; //12 bits
                span[i] = ToNbase64Char(remainder);
                remainder >>= 6; //6 bits remaining
            }
            else //state == 3
            {
                span[i] = ToNbase64Char(remainder);
                state = -1; //Reset to 0
                curByte--; //Don't move to next byte, we only used the remainder
            }
            state++;
        }
        span[i] = ToNbase64Char(remainder);
    }

    public static string ToNbase64Reverse(this int num)
    {
        string a = String.Create(6, BitConverter.GetBytes(num), BytesToSpan).TrimEnd('0');
        return String.Create(a.Length, a, (span, str) =>
        {
            for (int i = str.Length - 1; i >= 0; i--)
                span[i] = str[str.Length - i - 1];
        });
    }

    public static int FromNbase64Reverse(string str)
    {
        if (str.Length > 6)
            throw new OverflowException($"String too long: '{str}'");

        int res = 0;
        foreach (char c in str)
        {
            res <<= 6;
            res |= FromNbase64(c);
        }
        return res;
    }

    public static string ToNbase64(this byte[] bytes)
    {
        if (bytes.Length >= (Int32.MaxValue >> 2))
            throw new OverflowException($"Byte array is too long: {bytes.Length}");

        int bit = (bytes.Length + 2) << 3;
        int chLen = (bit / 6) - 2;
        return String.Create(chLen, bytes, BytesToSpan);
    }


    #endregion NBase
















    public static T ParseEnum<T>(this string str) where T : struct
    {
        if (!Enum.TryParse<T>(str, ignoreCase: true, out T res))
            throw new Exception($"Can't parse {typeof(T).Name} out of '{str}'. Valid options are: {String.Join(", ", Enum.GetNames(typeof(T)).Take(10))}.");
        return res;
    }

    public static string? FirstNonEmptyString(string? str1, string? str2 = null, string? str3 = null, string? str4 = null, string? str5 = null)
    {
        if (!String.IsNullOrWhiteSpace(str1))
            return str1;
        if (!String.IsNullOrWhiteSpace(str2))
            return str2;
        if (!String.IsNullOrWhiteSpace(str3))
            return str3;
        if (!String.IsNullOrWhiteSpace(str4))
            return str4;
        return str5;
    }

    public static byte[] Gzip(this string str)
    {
        var bytes = Encoding.UTF8.GetBytes(str);

        using var msi = new MemoryStream(bytes);
        using var mso = new MemoryStream();
        using (var gs = new GZipStream(mso, CompressionMode.Compress))
            msi.CopyTo(gs);

        return mso.ToArray();
    }

    public static string Unzip(this byte[] bytes)
    {
        using var msi = new MemoryStream(bytes);
        using var mso = new MemoryStream();
        using (var gs = new GZipStream(msi, CompressionMode.Decompress))
            gs.CopyTo(mso);

        return Encoding.UTF8.GetString(mso.ToArray());
    }

    public static MemoryStream ToMemoryStream(this string str)
    {
        MemoryStream mem = new();
        StreamWriter wrtr = new(mem);
        wrtr.Write(str);
        wrtr.Flush();
        mem.Seek(0, SeekOrigin.Begin);
        return mem;
    }


    public static string ToNykLdn(this DateTime? dt)
    {
        if (!dt.HasValue || dt.Value == DateTime.MinValue)
            return String.Empty;
        var utc = dt.Value.ToUniversalTime();
        string easternZoneId = "Eastern Standard Time";
        try
        {
            TimeZoneInfo easternZone = TimeZoneInfo.FindSystemTimeZoneById(easternZoneId);
            var est = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(utc, "Eastern Standard Time");
            return "";
        }
        catch (TimeZoneNotFoundException)
        {
            return dt.Value.ToLongDateString();
        }
    }
    public static string ToString(this DateTime? dt, string format) => (!dt.HasValue || dt.Value == DateTime.MinValue) ? String.Empty : dt.Value.ToString(format);

    public static DateTime ToSecondsPrecision(this DateTime dt) => new(dt.Ticks / TimeSpan.TicksPerSecond * TimeSpan.TicksPerSecond);

    //public static DateTime FromFileTime(int aHigh, int aLow) => DateTime.FromFileTime((long)aHigh << 32 | (long)aLow);

    public static string FileInOneLine(string fileName)
    {
        StringBuilder bld = new();
        foreach (var line in File.ReadLines(fileName))
        {
            bld.Append(line);
        }
        return bld.ToString();
    }

    //Helpers for ? operator
    //public static void Do<T>(this T obj, Action<T> act) { if (obj != null && act != null) act(obj); }
    //public static void AddTo<T>(this T obj, ICollection<T> coll) => coll.Add(obj);
    //public static void AddTo<K, T>(this T obj, IDictionary<K, T> dict, K key) => dict.Add(key, obj);
    //public static void AddTo<K, T>(this T obj, NbDictionary<K, T> dict, K key) where K : notnull => dict.Add(key, obj); //NbDictionari uses new and the call on the interface uses the base component's method

    //public static void Call<T>(this T obj, Action<T> action) => action(obj);


    public static bool ContainsAny<T>(this IEnumerable<T> src, IEnumerable<T>? toCheck)
    {
        if (toCheck == null)
            return false;
        return src.Any(s => toCheck.Any(tc => tc?.Equals(s) ?? false));
    }
    public static bool ContainsAnyIC(this IEnumerable<string> src, IEnumerable<string>? toCheck)
    {
        if (toCheck == null)
            return false;
        return src.Any(s => toCheck.Any(tc => tc?.EqIC(s) ?? false));
    }

    public static bool ContainsIC(this string source, string toCheck) => source.Contains(toCheck, StringComparison.OrdinalIgnoreCase);
    public static bool EqIC(this string? source, string? other) => String.Equals(source, other, StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Convert word typed in wrong layout such as Ерфтлы (eng -> rus), (rus -> eng)
    /// Using the String.Create Method taking span from this video: https://www.youtube.com/watch?v=Kd8oNLeRc2c
    /// </summary>
    /// <param name="src"></param>
    /// <returns></returns>
    public static string RusEng(string src) => String.Create(src.Length, src, (span, str) =>
    {
        for (int i = 0; i < span.Length; i++)
            span[i] = RusEng(str[i]);
    });

    public static char RusEng(char src) => Char.ToLowerInvariant(src) switch
    {
        'й' => 'q',
        'ц' => 'w',
        'у' => 'e',
        'к' => 'r',
        'е' => 't',
        'н' => 'y',
        'г' => 'u',
        'ш' => 'i',
        'щ' => 'o',
        'з' => 'p',

        'ф' => 'a',
        'ы' => 's',
        'в' => 'd',
        'а' => 'f',
        'п' => 'g',
        'р' => 'h',
        'о' => 'j',
        'л' => 'k',
        'д' => 'l',

        'я' => 'z',
        'ч' => 'x',
        'с' => 'c',
        'м' => 'v',
        'и' => 'b',
        'т' => 'n',
        'ь' => 'm',
        'б' => ',',
        'ю' => '.',

        'q' => 'й',
        'w' => 'ц',
        'e' => 'у',
        'r' => 'к',
        't' => 'е',
        'y' => 'н',
        'u' => 'г',
        'i' => 'ш',
        'o' => 'щ',
        'p' => 'з',

        'a' => 'ф',
        's' => 'ы',
        'd' => 'в',
        'f' => 'а',
        'g' => 'п',
        'h' => 'р',
        'j' => 'о',
        'k' => 'л',
        'l' => 'д',

        'z' => 'я',
        'x' => 'ч',
        'c' => 'с',
        'v' => 'м',
        'b' => 'и',
        'n' => 'т',
        'm' => 'ь',
        ',' => 'б',
        '.' => 'ю',
        _ => src,
    };

    public static string Truncate(this string value, int maxLength)
    {
        if (!string.IsNullOrEmpty(value) && value.Length > maxLength)
            return value[..maxLength];
        else
            return value;
    }

    public static string Limit(this string aStr, int aLength)
    {
        if (String.IsNullOrEmpty(aStr) || aStr.Length <= aLength)
            return aStr;
        else if (aLength > 3)
            return string.Concat(aStr.AsSpan(0, aLength - 3), "...");
        else
            return aStr[..aLength];
    }

    public static string FirstCharToUpper(this string input) => input switch
    {
        null => throw new ArgumentNullException(nameof(input)),
        "" => throw new ArgumentException($"{nameof(input)} cannot be empty", nameof(input)),
        _ => string.Concat(input[0].ToString().ToUpper(), input.AsSpan(1))
    };


    /// <summary>
    /// Formats the list of string as a message to users in the format:  Prefix 'string', 'long string....'
    /// </summary>
    /// <param name="strs"></param>
    /// <param name="prefix"></param>
    /// <returns></returns>
    public static string ListStrings(this IEnumerable<string> strs, string? prefix = null, int maxEntries = 5)
    {
        StringBuilder sb = new(String.IsNullOrWhiteSpace(prefix) ? "'" : prefix + " '");

        int i = 0;
        foreach (var str in strs)
        {
            if (i > 0)
                sb.Append("', '");
            if (i == maxEntries)
            {
                sb.Append("...");
                break;
            }

            sb.Append(str.Limit(20));
            ++i;
        }
        sb.Append('\'');
        return sb.ToString();
    }

    public static void AssertNotNull(object obj, string objname, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string membName = "")
    {
        if (obj == null)
            throw new NullReferenceException($"{filePath}({lineNum}): parameter '{objname}' is null in '{membName}'");
    }

    public static string ToCsvString(string str) //TODO: Speedup?
    {
        if (!String.IsNullOrEmpty(str))
        {
            str = str.Replace("\"", "\"\""); //Double quotes
            if (str.Contains(',') || str.Contains('"'))
                return "\"" + str + "\"";
        }
        return str;
    }

    [Obsolete("Use NbFs.CreateDirRecursive")]
    public static bool DirCreateRecursive(string dirName) => DirCreateRecursive(new DirectoryInfo(dirName));
    [Obsolete("Use NbFs.CreateDirRecursive")]
    public static bool DirCreateRecursive(this DirectoryInfo? di) //Recursive
    {
        if (di != null && !di.Exists)
        {
            if (di.Root.FullName == di.FullName) //We are in the root and it doens't exist
                throw new NbException($"The root dir '{di.Root.FullName}' doens't exist");

            DirCreateRecursive(di.Parent);
            Directory.CreateDirectory(di.FullName);
            return true;
        }
        else
            return false;
    }

    public static string EnvVariable(string aVarName)
    {
        IDictionary env = Environment.GetEnvironmentVariables();
        if (!env.Contains(aVarName))
            throw new NbException($"Can't find {aVarName} environment variable");
        else
            return env[aVarName] as String ?? throw new Exception($"Environment variable '{aVarName}' is not a string");
    }

    public static string EnvFileInPath(string aFileName)
    {
        foreach (var path in NbExt.EnvVariable("Path").Split(Path.PathSeparator).Select(s => Environment.ExpandEnvironmentVariables(s)))
        {
            var fi = new FileInfo(Path.Combine(path, aFileName));
            //NbMessageBox.Show(fi.FullName);
            if (fi.Exists && fi.Length > 0) //Get rid of symlinks
            {
                //NbMessageBox.Show("Found: " + fi.FullName);
                return fi.FullName;
            }
            //NbMessageBox.Show("Not Found: " + fi.FullName);
        }
        throw new NbException($"Can't find file '{aFileName}' in PATH");
    }

    public static void ScanBackAndRemove<T>(this List<T> list, Func<T, bool> action)
    {
        for (int i = list.Count - 1; i >= 0; i--)
        {
            var dir = list[i];
            if (action(dir))
                list.RemoveAt(i);
        }
    }


    /// <summary>
    /// Check if the array is sorted in the acsending order
    /// </summary>
    /// <param name="a"></param>
    /// <returns></returns>
    public static bool IsSorted<T>(this T[] a) where T : IComparable<T>
    {
        for (int i = 1; i < a.Length; i++)
            if (a[i - 1].CompareTo(a[i]) > 0)  //Calling compare might cause performance delays
                return false;

        return true;
    }

    /// <summary>
    /// Checks whether the sequence is sorted
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="seq"></param>
    /// <returns></returns>
    public static bool IsSorted<T>(IEnumerable<T> seq) where T : IComparable<T>
    {
        IEnumerator<T> enm = seq.GetEnumerator();
        if (enm.MoveNext())
            return true; //Empty sequence is considered sorted

        T prev = enm.Current;
        while (enm.MoveNext())
        {
            if (prev.CompareTo(enm.Current) > 0)
                return false;
            prev = enm.Current;
        }
        return true;
    }

    /// <summary>
    /// Swaps two cells in the array if the indices are different
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="array"></param>
    /// <param name="l"></param>
    /// <param name="r"></param>
    public static void Swap<T>(this T[] array, int l, int r) where T : struct
    {
        if (l != r)
            (array[l], array[r]) = (array[r], array[l]);
    }

    /*public static T ArrayFindOrAppend<T>(ref T[] array, Func<T, bool> aPredicate, Func<T> aCreator)
    {
        if (array == null)
        {
            T elem = aCreator();
            array = new T[] { elem };
            return elem;
        }
        else
        {
            T? elem = array.SingleOrDefault(aPredicate);
            if (elem == null)
            {
                elem = aCreator();
                T[] newArr = new T[array.Length + 1];
                Array.Copy(array, newArr, array.Length);
                newArr[^1] = elem;
                array = newArr;
            }
            return elem;
        }
    }

    public static T GetItemOrCreateNew<T>(ref T[] arr, Predicate<T> aSearchPredicate)
        where T : new()
    {
        arr ??= Array.Empty<T>();

        foreach (T el in arr)
        {
            if (aSearchPredicate(el))
                return el;
        }

        T col = new();
        T[] newArr = new T[arr.Length + 1];
        arr.CopyTo(newArr, 0);
        newArr[newArr.GetUpperBound(0)] = col;
        arr = newArr;
        return col;
    }

    public static T? GetItemOrCreateNew<A, T>(ref A[] arr, Predicate<T> aSearchPredicate)
        where A : class
        where T : class, A, new()
    {
        if (arr == null)
            arr = Array.Empty<A>();

        foreach (A el in arr)
        {
            if (el is T && aSearchPredicate(el as T))
                return el as T;
        }

        T col = new();
        A[] newArr = new A[arr.Length + 1];
        arr.CopyTo(newArr, 0);
        newArr[newArr.GetUpperBound(0)] = col as A;
        arr = newArr;
        return col;
    }*/

    public static bool StartsWith(this string aStr, char chr) => !String.IsNullOrEmpty(aStr) && aStr.Length > 0 && aStr[0] == chr;

    public static string LegalizeForFilename(this string aStr, int limit = 256) => aStr.Replace("?", String.Empty).Replace(':', '-').Replace('/', '-').Replace('\\', '-').Replace("\"", "''")
        .Replace('*', '-').Replace('?', '-').Replace('|', '-').Limit(limit);

    public static string NameWithoutExtension(this FileSystemInfo fd) => fd.Name[..^fd.Extension.Length];

    public static string ExtensionWithoutDot(this FileInfo fi) => fi.Extension.Length > 0 ? fi.Extension[1..] : String.Empty;

    public static bool IsContinuous(this IEnumerable<int> aSequence)
    {
        int prevKey = -1;
        bool first = true;
        foreach (int key in aSequence.OrderBy(i => i))
        {
            if (first)
            {
                prevKey = key;
                first = false;
                continue;
            }

            if (key != prevKey + 1)
                return false;

            prevKey = key;
        }
        return true;
    }

    public static IEnumerable<int> Duplicates(this IEnumerable<int> aSequence) => aSequence.GroupBy(el => el).Where(g => g.Count() > 1).Select(g => g.Key);

    public static T OneOf<T>(this Random aRnd, IList<T> aList)
    {
        if (aList.Count == 0)
            throw new NbException("Empty list in OneOf");

        return aList[aRnd.Next(aList.Count)];
    }

    /// <summary>
    /// TryGetValue that can be used with Arrays
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="aCollection"></param>
    /// <param name="aPredicate"></param>
    /// <param name="aValue"></param>
    /// <returns></returns>
    public static bool TryGetValue<T>(this IEnumerable<T> aCollection, Func<T, bool> aPredicate, [NotNullWhen(true)] out T? aValue) where T : notnull
    {
        foreach (T item in aCollection)
        {
            if (aPredicate(item))
            {
                aValue = item;
                return true;
            }
        }
        aValue = default;
        return false;
    }

    public const int TicksInSecond = 10000000;
    /// <summary>
    /// Compare two DateTimes with a second precision
    /// </summary>
    public static int CompareToSec(this DateTime dt, DateTime other) => (dt.Ticks / TicksInSecond).CompareTo(other.Ticks / TicksInSecond);

    /// <summary>
    /// Equal two DateTimes with a second precision
    /// </summary>
    public static bool EqualsToSec(this DateTime dt, DateTime other) => (dt.Ticks / TicksInSecond).Equals(other.Ticks / TicksInSecond);

    public static void ForEachSafe<T>(this IEnumerable<T>? aCollection, Action<T> aAction)
    {
        if (aCollection == null)
            return;
        foreach (T item in aCollection.OfType<T>())
            aAction(item);
    }

    public static IEnumerable<T> WhereNotNull<T>(this IEnumerable<T?> aCollection) => aCollection.Where(t => t != null).Select(t => t!);
    public static IEnumerable<T> WhereNotNull<T>(this IEnumerable<T?> aCollection, Func<T, bool> predicate) => aCollection.Where(t => t != null && predicate(t)).Select(t => t!);
    public static IEnumerable<R> SelectNotNull<T, R>(this IEnumerable<T?> source, Func<T, R> selector) => source.Where(t => t != null).Select(t => selector(t!));

    public static void ForEachSafe2<T, U>(this IEnumerable<T>? aCollection, Action<U> aAction) where U : T //U must be a derivative of T
    {
        if (aCollection == null)
            return;
        foreach (U item in aCollection.OfType<U>())
            aAction(item);
    }


    /// <summary>
    /// Adds an item to the collection only if it is not yet in there. Not smart, useful for small collections only.
    /// </summary>
    /// <returns>True if the item was added, False if this item already existed in the collection</returns>
    public static bool AddUnique<T>(this ICollection<T> coll, T item)
    {
        if (coll.Contains(item))
            return false;

        coll.Add(item);
        return true;
    }

    public static IEnumerable<T> NotIn<T, K>(this IEnumerable<T> thisCollection, ICollection<K> thatCollection, Func<T, K, bool> aNameComparator) =>
         thisCollection.Where(t1 => !thatCollection.Any(t2 => aNameComparator(t1, t2)));

    public static IEnumerable<T> NotIn<T>(this IEnumerable<T> thisCollection, ICollection<T> thatCollection) where T : IEquatable<T> =>
        thisCollection.Where(t1 => !thatCollection.Any(t2 => t1.Equals(t2)));

    public static IEnumerable<KeyValuePair<T, T>> BothIn<T>(this IEnumerable thisCollection, ICollection thatCollection, Func<T, T, bool> aNameComparator)
        where T : class
    {
        foreach (object ob in thisCollection)
        {
            if (ob is not T obj)
                continue;

            bool found = false;
            foreach (object oth in thatCollection)
            {
                if (oth is not T other)
                    continue;

                if (aNameComparator(obj, other))
                {
                    if (found == true)
                        throw new NbException($"Object '{obj}' is equal to two or more objects in the other collection in BothIn()");
                    else
                        yield return new KeyValuePair<T, T>(obj, other);
                }
            }
        }
    }

    /// <summary>
    /// Calls Add and Remove methods for differenced in two collections. The new Collection (this) will be changed.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="newCollection">Collection with new elements - will be changed</param>
    /// <param name="oldColletion">Enumerable of old elements</param>
    /// <param name="addAction">Action to create new element</param>
    /// <param name="removeAction">Action to remove an element</param>
    /// <returns>The number of changes made (calls to add or remove)</returns>
    public static int SynchronizeCollections<T>(this IEnumerable<T> oldColletion, IEnumerable<T> newCollection, Action<T> addAction, Action<T> removeAction)
    {
        int numOfChanges = 0;
        var oldCopy = oldColletion.ToList();
        foreach (T v in newCollection)
        {
            int ind = oldCopy.IndexOf(v);
            if (ind == -1) //Didn't exist before, but in the new list => Add
            {
                addAction(v);
                numOfChanges++;
            }
            else //Exists in both lists - doen't do anything, remove from newCollection, so it is not used for addition
                oldCopy.RemoveAt(ind);
        }

        foreach (T v in oldCopy) //Remaining entries are not found in the newList and should be deleted
        {
            removeAction(v);
            numOfChanges++;
        }
        return numOfChanges;
    }

    public static List<KeyValuePair<K, int>> Histogram<K, V>(this IEnumerable<V> files, Func<V, K> getKey) where K : notnull =>
        files.GroupBy(getKey).ToDictionary(g => g.Key, g => g.Count()).OrderByDescending(p => p.Value).ToList();

    public static Dictionary<K, List<V>> NonUnique<K, V>(this IEnumerable<V> files, Func<V, K> getKey) where K : notnull =>
        files.GroupBy(getKey).Where(g => g.Count() > 1).ToDictionary(g => g.Key, g => g.ToList());

    public static TSource? SingleOrDefaultVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool>? predicateN = null, string who = "Sequence", string whats = "Element",
        [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
    {
        if (source == null) throw new ArgumentException(null, nameof(source));
        TSource? result = default;
        long count = 0;

        foreach (TSource element in source ?? throw new ArgumentException(null, nameof(source)))
        {
            if (predicateN?.Invoke(element) ?? true) //If predicate is not specified - apply to all
            {
                result = element;
                checked { count++; }
            }
        }

        return count switch
        {
            0 => default,
            1 => result,
            _ => throw new NbExceptionInfo($"{who} contained {count} {whats} when only 1 was expected", filePath, lineNum, name),
        };
    }

    public static TSource? SingleOrDefaultVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicate, Func<long, string> multipleError)
    {
        if (source == null) throw new ArgumentException(null, nameof(source));
        if (predicate == null) throw new ArgumentException(null, nameof(predicate));
        TSource? result = default;
        long count = 0;
        foreach (TSource element in source)
        {
            if (predicate(element))
            {
                result = element;
                checked { count++; }
            }
        }

        return count switch
        {
            0 => default,
            1 => result,
            _ => throw new Exception(multipleError?.Invoke(count) ?? "There are more than one element in the sequence"),
        };
    }

    public static TSource SingleEnsure<TSource>(this IEnumerable<TSource> source, string whats = "Elements", string id = "'N/A'", string where = "Sequence",
        [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
    {
        TSource? result = default;
        long count = 0;
        foreach (TSource element in source ?? throw new ArgumentException(null, nameof(source)))
        {
            result = element;
            checked { count++; }
        }
        return count switch
        {
            0 => throw new NbExceptionInfo($"{where} didn't contain any {whats} with Id {id} when 1 was expected", filePath, lineNum, name),
            1 => result!,
            _ => throw new NbExceptionInfo($"{where} contained {count} {whats} with Id {id} when only 1 was expected", filePath, lineNum, name),
        };
    }

    public static TSource SingleVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicateN, Func<string> noMatchError, Func<long, string> multipleError)
    {
        TSource? result = default;
        long count = 0;
        foreach (TSource element in source ?? throw new ArgumentException(null, nameof(source)))
        {
            if (predicateN?.Invoke(element) ?? true) //If predicate is not specified - apply to all
            {
                result = element;
                checked { count++; }
            }
        }
        return count switch
        {
            0 => throw new Exception(noMatchError() ?? "Element in the sequence was not found"),
            1 => result!,
            _ => throw new Exception(multipleError(count) ?? "There are more than one element in the sequence"),
        };
    }

    public static TSource SingleVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool>? predicateN = null, string who = "Sequence", string whats = "Element",
        [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
    {
        TSource? result = default;
        long count = 0;
        foreach (TSource element in source ?? throw new ArgumentException(null, nameof(source)))
        {
            if (predicateN?.Invoke(element) ?? true) //If predicate is not specified - apply to all
            {
                result = element;
                checked { count++; }
            }
        }
        return count switch
        {
            0 => throw new NbExceptionInfo($"{who} didn't contain any {whats} when 1 was expected", filePath, lineNum, name),
            1 => result!,
            _ => throw new NbExceptionInfo($"{who} contained {count} {whats} when only 1 was expected", filePath, lineNum, name),
        };
    }


    //[Obsolete("Use Enumerable.Empty<T>() instead")]
    //public static IEnumerable<T> Nothing<T>() => Enumerable.Empty<T>();

    public static IEnumerable<T> Yield<T>(params T[] arg) => arg;
    public static IEnumerable<T> Yield<T>(T arg)
    {
        if (arg == null)
            yield break;
        else
            yield return arg;
    }

    public static IEnumerable<T?> Defaults<T>()
    {
        while (true) { yield return default; }
    }

    public static IEnumerable<T> Safe<T>(this IEnumerable<T>? enumer) => enumer ?? Enumerable.Empty<T>();
    public static IEnumerable<T> Safe<T>(this Lazy<List<T>> enumer) => (enumer != null && enumer.IsValueCreated) ? enumer.Value : Enumerable.Empty<T>();
    public static IEnumerable<T> SafeOfType<T>(this IEnumerable enumer) => (enumer == null) ? Enumerable.Empty<T>() : enumer.OfType<T>();

    public static NbDictionary<TKey, TValue> ToNbDictionary<TKey, TValue>(this IEnumerable<TValue> sequence, Func<TValue, TKey> keyGetter, IEqualityComparer<TKey>? comparer = null,
        int capacity = 0, [CallerMemberName] string description = "", Func<TKey, TValue>? creator = null, Action<TKey, TValue, TValue>? dupeHandler = null, [CallerMemberName] string caller = "") where TKey : notnull
    {
        if (sequence == null) throw new ArgumentNullException(nameof(sequence), caller);
        if (keyGetter == null) throw new ArgumentNullException(nameof(keyGetter), caller);

        NbDictionary<TKey, TValue> dict = new(capacity, comparer, description, creator, keyGetter, dupeHandler);
        foreach (var tVal in sequence)
            dict.Add(tVal);
        return dict;
    }

    //[Obsolete("Try using the method without value getter (above)")]
    public static NbDictionary<TKey, TValue> ToNbDictionary<TObj, TKey, TValue>(this IEnumerable<TObj> sequence, Func<TObj, TKey> keyGetter, Func<TObj, TValue> valueGetter,
        IEqualityComparer<TKey>? comparer = null, int capacity = 0, [CallerMemberName] string description = "", Func<TKey, TValue>? creator = null, Action<TKey, TValue, TValue>? dupeHandler = null, [CallerMemberName] string caller = "") where TKey : notnull
    {
        if (sequence == null) throw new ArgumentNullException(nameof(sequence), caller);
        if (keyGetter == null) throw new ArgumentNullException(nameof(keyGetter), caller);
        if (valueGetter == null) throw new ArgumentNullException(nameof(valueGetter), caller);

        NbDictionary<TKey, TValue> dict = new(capacity, comparer, description, creator, null, dupeHandler);
        foreach (var obj in sequence)
            dict.Add(keyGetter(obj), valueGetter(obj));
        return dict;
    }
    public static NbDictionary<string, string?> ToNbDictionary(this NameValueCollection coll) => coll.OfType<string>().ToNbDictionary(i => i, i => coll[i], capacity: coll.Count);

    public static SortedList<TKey, TValue> ToSortedList<TObj, TKey, TValue>(this IEnumerable<IGrouping<TKey, TObj>> sequence, Func<IGrouping<TKey, TObj>, TValue> valueGetter) where TKey : notnull
    {
        SortedList<TKey, TValue> dict = new();
        foreach (var grp in sequence)
        {
            dict.Add(grp.Key, valueGetter(grp));
        }
        return dict;
    }
    public static T CastVerbose<T>(this object val, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        where T : class
    {
        if (val == null)
            throw new Exception($"Null value passed to NotNull class in {filePath}({lineNum}) method: '{name}'");
        if (val is not T t)
            throw new Exception($"Object of type '{val.GetType().Name}' can't be cast to type '{typeof(T).Name}' in {filePath}({lineNum}) method: '{name}'");
        return t;
    }


    public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty));
    public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num, string otherLine) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty)).Concat(Yield(otherLine));
    public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num, IEnumerable<string> otherLines) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty)).Concat(otherLines);

    public static T[] Merge<T>(this T[] arr, T[] otherN) where T : IMergeableByName<T>
    {
        Debug.Assert(arr != null, "Merge this must no be null");

        if (otherN == null)
            return arr;

        var dic = otherN.ToDictionary(t => t.MergeName, StringComparer.OrdinalIgnoreCase);
        var res = new List<T>(arr.Length + otherN.Length);

        foreach (var from in arr)
        {
            if (dic.TryGetValue(from.MergeName, out T? to)) //Table already exists
            {
                res.Add(from.MergeTo(to));
                dic.Remove(from.MergeName); //Used for merging - remove from dictionary
            }
            else
                res.Add(from);
        }

        res.AddRange(dic.Values); //Add entries not used for merging (new ones)
        return res.ToArray();
    }

    /*public static void Deconstruct<T1, T2>(this KeyValuePair<T1, T2> tuple, out T1 key, out T2 value)
    {
        key = tuple.Key;
        value = tuple.Value;
    }*/

    public static T RunWithMessage<T>(Func<T> action, string mess)
    {
        Console.Write(mess);
        Stopwatch sw = new();
        sw.Start();
        var res = action();
        Console.WriteLine($"done in {sw.ElapsedMilliseconds / 1000:f1} sec.");
        return res;
    }

    public static string GetEmbeddedResourceTextFile(string resourceName)
    {
        Assembly assem = typeof(NbExt).Assembly;
        try
        {
            using var reader = new StreamReader(assem.GetManifestResourceStream(resourceName) ?? throw new Exception($"Can't find '{resourceName}' resource stream"));
            return reader.ReadToEnd();
        }
        catch (Exception ex)
        {
            throw new NbException(ex, $"Available resources are {String.Join(", ", assem.GetManifestResourceNames())}");
        }
    }

    public static string UserFriendlyFileSize(long aSize, int aPrecision)
    {
        string[] units = new string[] { "B", "KB", "MB", "GB", "TB" };

        if (aSize == 0)
            return "0 B";

        aSize = Math.Max(aSize, 0);
        int powUnits = Convert.ToInt16(Math.Floor(((aSize != 0) ? Math.Log(aSize) : 0) / Math.Log(1024)));
        powUnits = Math.Min(powUnits, units.GetLength(0) - 1);

        double res = aSize / Math.Pow(1024, powUnits);

        int digitsAbovePoint = (int)Math.Ceiling(Math.Log10(res));
        var divider = Math.Pow(10, digitsAbovePoint); //(res / divider) will be the number between 0.1 and 1.0
        decimal res1 = (decimal)(Math.Round(res / divider, aPrecision) * divider);

        return res1.ToString() + ' ' + units[powUnits];
    }

    private static readonly Lazy<NbDictionary<string, Regex>> CachedRegex = new(() => new(10, description: "Cached regexes", creator: s => new Regex(s)));

    public static bool IsMatch(this string reg, string input)
    {
        var res = CachedRegex.Value[reg].Match(input);
        return res.Success;
    }

    public static bool IsMatch<T>(this string reg, string input, [NotNullWhen(returnValue: true)] out T? val1)
    {
        val1 = default;
        var res = CachedRegex.Value[reg].Match(input);
        if (res.Success)
        {
            val1 = (T)Convert.ChangeType(res.Groups[1].Value, typeof(T));
        }
        return res.Success;
    }

    public static bool IsMatch<T, U>(this string reg, string input, [NotNullWhen(returnValue: true)] out T? val1, [NotNullWhen(returnValue: true)] out U? val2)
    {
        val1 = default;
        val2 = default;
        var res = CachedRegex.Value[reg].Match(input);
        if (res.Success)
        {
            val1 = (T)Convert.ChangeType(res.Groups[1].Value, typeof(T));
            val2 = (U)Convert.ChangeType(res.Groups[2].Value, typeof(U));
        }
        return res.Success;
    }

    public static bool IsMatch<T, U, V>(this string reg, string input, [NotNullWhen(returnValue: true)] out T? val1, [NotNullWhen(returnValue: true)] out U? val2, [NotNullWhen(returnValue: true)] out V? val3)
    {
        val1 = default;
        val2 = default;
        val3 = default;
        var res = CachedRegex.Value[reg].Match(input);
        if (res.Success)
        {
            val1 = (T)Convert.ChangeType(res.Groups[1].Value, typeof(T));
            val2 = (U)Convert.ChangeType(res.Groups[2].Value, typeof(U));
            val3 = (V)Convert.ChangeType(res.Groups[3].Value, typeof(V));
        }
        return res.Success;
    }

    public static DirectoryInfo Dir(this FileInfo fi) => fi.Directory ?? throw new Exception($"File '{fi.FullName}' doesn't have a directory.");
}

public interface IMergeableByName<T>
{
    T MergeTo(T other);
    string MergeName { get; }
}

public class ArrComparer : IEqualityComparer<IList<int>>
{
    public static readonly ArrComparer Instance = new();

    public bool Equals(IList<int>? x, IList<int>? y)
    {
        if (x == null || y == null)
            return false;
        return Enumerable.SequenceEqual(x, y);
    }

    public int GetHashCode([DisallowNull] IList<int> obj)
    {
        int accum = 0;
        return obj.Aggregate(accum, (a, x) => a ^= x.GetHashCode());
    }
}



/// <summary>
/// Fastest way to send a single item as an enumerable according to this:
/// https://stackoverflow.com/questions/1577822/passing-a-single-item-as-ienumerablet
/// </summary>
/// <typeparam name="T"></typeparam>
public struct SingleSequence<T> : IEnumerable<T> where T : notnull
{
    public struct SingleEnumerator : IEnumerator<T>
    {
        private readonly SingleSequence<T> _parent;
        private bool _couldMove;
        public SingleEnumerator(ref SingleSequence<T> parent)
        {
            _parent = parent;
            _couldMove = true;
        }
        public T Current => _parent._value;
        object IEnumerator.Current => Current;
        public void Dispose() { }

        public bool MoveNext()
        {
            if (!_couldMove) return false;
            _couldMove = false;
            return true;
        }
        public void Reset() => _couldMove = true;
    }

    private readonly T _value;
    public SingleSequence(T value) => _value = value;

    public IEnumerator<T> GetEnumerator() => new SingleEnumerator(ref this);
    IEnumerator IEnumerable.GetEnumerator() => new SingleEnumerator(ref this);
}

public class NbDictionary<TKey, TValue> : Dictionary<TKey, TValue>
    where TKey : notnull
{
    private readonly string Description;
    private readonly Func<TKey, TValue>? CreatorN;
    private readonly Func<TValue, TKey>? KeyGetterN;
    private readonly Action<TKey, TValue, TValue>? DupeHandlerN;

    public NbDictionary(int capacity = 0, IEqualityComparer<TKey>? comparer = null, [CallerMemberName] string? description = "", Func<TKey, TValue>? creator = null, Func<TValue, TKey>? keyGetter = null, Action<TKey, TValue, TValue>? dupeHandler = null)
        : base(capacity, comparer)
    {
        Description = description ?? "Unnamed";
        CreatorN = creator;
        KeyGetterN = keyGetter;
        DupeHandlerN = dupeHandler;
    }

    public new TValue this[TKey key]
    {
        get
        {
            if (TryGetValue(key, out TValue? res))
                return res;
            else if (CreatorN != null)
            {
                res = CreatorN(key);
                Add(key, res);
                return res;
            }
            else
            {
                TKey key1 = key;
                throw new Exception($"Key '{key1}' is not found in the '{Description}' dictionary and creator function was not supplied");
            }
        }
        set { base[key] = value; }
    }

    public new void Add(TKey key, TValue value)
    {
        if (TryGetValue(key, out TValue? oldVal))
        {
            if (DupeHandlerN == null)
                throw new NbException($"Key '{key}' already exists in the '{Description}' dictionary");
            DupeHandlerN(key, oldVal, value);
        }
        else
            base.Add(key, value);
    }

    public void Add(TValue value)
    {
        if (KeyGetterN == null)
            throw new ArgumentException("Attempt to use Add(value) without setting key getter in constructor");
        Add(KeyGetterN(value), value);
    }

    public TValue? GetOrNull(TKey key)
    {
        TryGetValue(key, out TValue? existing);
        return existing;
    }

    public void AddRange(IEnumerable<TValue> values, Func<TValue, TKey> keyGetter)
    {
        foreach (var v in values)
            Add(keyGetter(v), v);
    }
}

public class NbPairList<K, V> : List<(K, V)> where K : notnull
{
    public V this[K key]
    {
        get { return this.FirstOrDefault(p => key.Equals(p.Item1)).Item2; }
        set { Add((key, value)); }
    }

    public NbPairList<K, V> this[K key, V val]
    {
        get { Add((key, val)); return this; }
    }
}

//#pragma warning restore IDE0090 // Use 'new(...)'