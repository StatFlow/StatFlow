﻿using System.Runtime.CompilerServices;
using System.Text;

namespace NbCore;

public class NbException : Exception
{
    public NbException(string aMessage)
        : base(aMessage)
    { }

    [Obsolete("Use string interpolation: $ ")]
    public NbException(string aFormat, params object[] args)
        : base(String.Format(aFormat, args))
    { }

    public NbException(Exception ex, string mess)
        : base(mess, ex)
    { }

    public static string Exception2String(Exception ex, Action<Exception, StringBuilder>? extraHandler = null)
    {
        StringBuilder bld = new();
        ProcException(ex, bld, 0, extraHandler);
        return bld.ToString();
    }

    private static void ProcException(Exception ex, StringBuilder bld, int margin, Action<Exception, StringBuilder>? extraHandler = null)
    {
        for (int i = margin; i > 0; --i) //Margin without new string allocations
            bld.Append("  ");

        bld.Append(ex.Message);
        bld.Append(" {");
        bld.Append(ex.GetType().Name);
        bld.AppendLine("}");

        extraHandler?.Invoke(ex, bld);

        if (ex is AggregateException aggEx)
        {
            foreach (Exception ex1 in aggEx.InnerExceptions)
                ProcException(ex1, bld, margin + 1);
        }
        else
        {
            if (ex.InnerException != null)
                ProcException(ex.InnerException, bld, margin + 1);
        }
    }

    public override string ToString() => Exception2String(this);
}

public class NbExceptionUserCancelled : NbException
{
    public NbExceptionUserCancelled() : base("User canceled the operation") { }
}

public class NbExceptionCmdLine : NbException
{
    public NbExceptionCmdLine(string mess) : base(mess) { }
}

public class NbExceptionBadType : NbException
{
    public NbExceptionBadType(string agnName, string expectedType, object actObj, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        : base($"{filePath}({lineNum}): Argument '{agnName}' of type '{expectedType}' was expected. " +
              (actObj != null ? $"The type '{actObj.GetType().Name}' was received in {name}" : $"Null reference was received"))
    { }
}

public class NbExceptionInfo : NbException
{
    public NbExceptionInfo(string mess, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        : base($"{filePath}({lineNum}): {mess} in {name}")
    { }

    public NbExceptionInfo(Exception ex, string mess, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        : base(ex, $"{filePath}({lineNum}): {mess} in {name}")
    { }
}

public class NbExceptionEnum<T> : NbException
    where T : notnull
{
    public NbExceptionEnum(String enumStr, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        : base($"{filePath}({lineNum}): Unsupported {EnumName()} enum value: {enumStr} in {name}. Supported values are: {String.Join(", ", Enum.GetValues(typeof(T)).Cast<T>().Select(e => e.ToString()))}")
    { }

    private static string EnumName()
    {
        string res = typeof(T).Name;
        return res.EndsWith("s") ? res[0..^1] : res; //Use singular form
    }

    public NbExceptionEnum(T enumVal, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        : this(enumVal.ToString() ?? "Unknown enum val", filePath, lineNum, name)
    { }
}

public class NbExceptionPatternMatching : NbException
{
    public NbExceptionPatternMatching(object obj, string whatIsIt, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        : base($"{filePath}({lineNum}): Unsupported type '{obj.GetType().Name}' of {whatIsIt} in {name}")
    { }
}