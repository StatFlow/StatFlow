﻿using System.Diagnostics;
using System.Text;

namespace NbCore;

/// <summary>
/// Подумать о том, чтобы сделать Fluent API для вызова NbProcess
/// https://visualstudiomagazine.com/articles/2013/12/01/best-practices-for-designing-a-fluent-api.aspx
/// </summary>
public class NbProcess
{
    public static Task<(int exitCode, string stdOut, string errOut)> RunAsync(string exeName, DirectoryInfo? workDir = null, params string[] arguments)
    {
        var tsc = new TaskCompletionSource<(int exitCode, string stdOut, string errOut)>();

        ProcessStartInfo psi = new()
        {
            FileName = PutInQuotes(exeName),
            Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
            WorkingDirectory = workDir?.FullName,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = true,
            CreateNoWindow = true
        };

        StringBuilder outBld = new();
        StringBuilder errBld = new();

        Process pc = new() { StartInfo = psi, EnableRaisingEvents = true };
        pc.OutputDataReceived += (s, e) => outBld.AppendLine(e.Data);
        pc.ErrorDataReceived += (s, e) => errBld.AppendLine(e.Data);
        
        pc.Exited += (s, e) =>
        {
            int exitCode = pc.ExitCode;
            tsc.SetResult((exitCode, outBld.ToString(), errBld.ToString()));
            pc.Dispose();
        };

        pc.Start();
        pc.BeginOutputReadLine();
        pc.BeginErrorReadLine();
        return tsc.Task;
    }

    public static string PutInQuotes(string str)
    {
        if (!str.Contains(' '))
            return str;
        else if (str.StartsWith('\"') && str.EndsWith("\""))
            return str;
        else if (str.Contains('\"'))  //For   amix=inputs=2:duration=first:weights="1 0.10"   parameter in ffmpeg
            return str;
        else
            return '\"' + str + '\"';
    }

    /// <summary>
    /// use this clas: var pars = new NbPairList<string, string>();
    /// </summary>
    /// <param name="exeName"></param>
    /// <param name="pars"></param>
    /// <param name="workDir"></param>
    /// <param name="parPref"></param>
    /// <returns></returns>
    public static Task<(int exitCode, string stdOut, string errOut)> RunAsync(string exeName, IEnumerable<(string Key, string Value)> pars, DirectoryInfo? workDir = null, char parPref = '/')
    {
        List<string> parList = new();
        foreach (var (Key, Value) in pars)
        {
            parList.Add(parPref + Key);

            if (!String.IsNullOrEmpty(Value))
                parList.Add(Value);
        }
        return RunAsync(exeName, workDir, parList.ToArray());
    }

    public static (string stdOut, string errOut) RunSyncFail(string exeName, DirectoryInfo? workDir = null, params string[] arguments)
    {
        var (exitCode, stdOut, errOut) = RunSync(exeName, workDir, arguments);
        if (exitCode != 0)
            throw new Exception($"Proces {exeName} returned {exitCode}{Environment.NewLine}{errOut}");

        return (stdOut, errOut);
    }

    public static void FireAndForget(string exeName, DirectoryInfo? workDir = null, params string[] arguments)
    {
        ProcessStartInfo psi = new()
        {
            FileName = PutInQuotes(exeName),
            Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
            WorkingDirectory = workDir?.FullName,
            UseShellExecute = false,
            /*RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = true,*/
            CreateNoWindow = true
        };
        Process.Start(psi);
    }

    public static async Task BeyoncCompare(string fileLeft, string fileRight) => await RunAsync(@"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe", null, fileLeft, fileRight);
    public static async Task Explorer(FileInfo fi) => await RunAsync("explorer.exe", null, "/select,", fi.FullName);
    public static async Task Explorer(DirectoryInfo dir) => await RunAsync("explorer.exe", null, "/root,", dir.FullName);

    public static async Task Browser(string url) => await RunAsync(@"C:\Program Files\Mozilla Firefox\firefox.exe", null, url);
    public static async Task Browser(string url, string profile) => await RunAsync(@"C:\Program Files\Mozilla Firefox\firefox.exe", null, "-P", profile, url);

    public static (int exitCode, string stdOut, string errOut) RunSync(string exeName, DirectoryInfo? workDir = null, params string[] arguments)
    {
        ProcessStartInfo psi = new()
        {
            FileName = PutInQuotes(exeName),
            Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
            WorkingDirectory = workDir?.FullName,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = true,
            CreateNoWindow = true
        };

        string stdOut, stdErr;

        using Process pc = Process.Start(psi) ?? throw new Exception($"The process '{psi.FileName}' couldn't start");
        stdOut = pc.StandardOutput.ReadToEnd();
        stdErr = pc.StandardError.ReadToEnd();
        int exitCode = pc.ExitCode;
        pc.WaitForExit();

        return (exitCode, stdOut, stdErr);
    }

    public static int RunDosCommandSync(string cmdName, DirectoryInfo workDir, params string[] arguments)
    {
        string args = String.Join(" ", arguments.Safe().Select(a => PutInQuotes(a)).Prepend(cmdName).Prepend("/C"));
        ProcessStartInfo psi = new()
        {
            FileName = "cmd.exe",
            Arguments = args,
            WorkingDirectory = workDir?.FullName,
            UseShellExecute = true,
        };

        using Process pc = Process.Start(psi) ?? throw new Exception($"The process '{psi.FileName}' couldn't start");
        pc.WaitForExit();
        return pc.ExitCode;
    }



    public static int RunDosWindowSync(string exeName, DirectoryInfo? workDir = null, params string[] arguments)
    {
        ProcessStartInfo psi = new()
        {
            FileName = PutInQuotes(exeName),
            Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
            WorkingDirectory = workDir?.FullName,
            UseShellExecute = true,
        };

        using Process pc = Process.Start(psi) ?? throw new Exception($"The process '{psi.FileName}' couldn't start");
        pc.WaitForExit();
        return pc.ExitCode;
    }


    internal static void SvnSubmit(string dir)
    {
        var submitComment = DateTime.Now.ToString("yyMMdd - HHmmss");

        ProcessStartInfo psi = new()
        {
            FileName = "svn.exe",
            Arguments = $"commit -m \"{submitComment}\"",
            WorkingDirectory = dir,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = true
        };

        string stdOut, stdErr;
        using Process pc = Process.Start(psi) ?? throw new Exception($"The process '{psi.FileName}' couldn't start");
        stdOut = pc.StandardOutput.ReadToEnd();
        stdErr = pc.StandardError.ReadToEnd();
        pc.WaitForExit();
        int exitCode = pc.ExitCode;
        if (exitCode != 0)
            throw new Exception($"Svn exited with code: {exitCode}");
    }
}
