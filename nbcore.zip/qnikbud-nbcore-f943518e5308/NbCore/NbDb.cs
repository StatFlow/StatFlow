﻿using System.Data;

namespace NbCore;

//Has to be in NbTool for DfCollections to use the interface, Ora and MsSql implementations are in NbOrm

public enum ConnectionType { None, Oracle, MsSql }

/// <summary>
/// Gets connection from connection manager by its name - useful when queries specify which connection to use, or run on multiple connections (comparison between DBs)
/// </summary>
public interface INbConnGetter
{
    INbConn GetConnection(string envName, string connName);
}

public interface INbConn : IDisposable
{
    INbCommand CreateCommand(string sql);
    INbReader CreateReader(string sql);
    INbTrans BeginTransaction();

    ConnectionType ConnType { get; }

    Task<T?> ReadSingleAsync<T>(string sql);
    Task<(T?, U?)> ReadSingleAsync<T, U>(string sql);
    Task<(T?, U?, V?)> ReadSingleAsync<T, U, V>(string sql);

    Task<List<T?>> ReadListAsync<T>(string sql);
    Task<List<(T?, U?)>> ReadListAsync<T, U>(string sql);
    Task<List<(T?, U?, V?)>> ReadListAsync<T, U, V>(string sql);
    Task<NbDictionary<K, V?>> ReadDictionaryAsync<K, V>(string sql, bool ignoreDupes = false, string? dictDecr = null) where K : notnull;
}

public interface INbTrans
{
    void Commit();
}

public interface INbReader : IDisposable
{
    Task<bool> ReadAsync();
    DataTable FillDataTable();

    Type GetFieldType(int ordinal);
    bool IsDBNull(int ordinal);
    T? GetValue<T>(int index);
    int FieldCount();

    string GetBlob(int index);
    byte[] GetBytes(int index);
    string GetString(int index);
    string? GetNullableString(int index);

    char GetChar(int index);
    char? GetNullableChar(int index);

    Int16 GetInt16(int index);
    Int16? GetNullableInt16(int index);
    int GetInt32(int index);
    int? GetNullableInt32(int index);
    string GetName(int index);
    long GetInt64(int index);
    long? GetNullableInt64(int index);

    decimal GetDecimal(int index);
    decimal? GetNullableDecimal(int index);

    double GetDouble(int index);
    double? GetNullableDouble(int index);

    DateTime GetDateTime(int index);
    DateTime? GetNullableDateTime(int index);

    bool GetBoolean(int index);
    bool? GetNullableBoolean(int index);
}

public interface INbCommand : IDisposable
{
    void AddParam(string name, object value);
    void AddParam(string name, bool value);
    void AddParam(string name, bool? value);
    void AddBlob(string name, byte[] value);
    Task RunAsync();
    Task<int> RunGetInt32Async();
}
