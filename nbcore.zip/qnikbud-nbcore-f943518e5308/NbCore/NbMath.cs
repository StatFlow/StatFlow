﻿using System.Data;

namespace NbCore;

public static class NbMath
{
    /// <summary>
    /// Binary Search with boolean Predicate (tester function). Searched for the lowest number where checker() becomes true.
    /// If checker never becomes true() returns (top + 1) i.e. the change is somewhere above the given range
    /// If checker is always true, returns the "from" because it can't detect whether "from" is first match or the false->true change happens below from
    /// </summary>
    /// <param name="from">The lowest value to test (inclusive)</param>
    /// <param name="to">The highest value to Test (exclusive)</param>
    /// <param name="predicate">The Checker function must return true at the top and false at the bottom</param>
    /// <returns>The number in [from..to+1] range where false->true switch happens. Points to lowest true.</returns>
    /// <exception cref="ArgumentException"></exception>
    public static int BinSearchPredicate(int from, int to, Func<int, bool> predicate)
    {
        if (to == Int32.MaxValue)
            throw new ArgumentException("Argument is out of range, is has to be smaller than Int32.MaxValue", nameof(to));
        if (from > to)
            throw new ArgumentException("from > to in " + nameof(BinSearchPredicate));
        else if (from == to)
            return predicate(from) ? from : from + 1; //if the only cell if false the match is outside (from + 1)

        int mdl = 0;
        while (from <= to)
        {
            mdl = (to + from + 1) / 2;  // 1-1 -> 1  1-2 -> 2  Pick higher bound in case of rounding
            if (predicate(mdl))
                to = mdl - 1; //If the last run the answer is mdl
            else
                from = ++mdl; //False if this is the last run the answer is one above mdl
        }
        return mdl;
    }

    public static IEnumerable<T> RandomizeList<T>(this IList<T> thisCollection)
    {
        Random rand = new();
        for (int i = thisCollection.Count - 1; i >= 0; --i)
        {
            int ind = rand.Next(0, i);
            yield return thisCollection[ind];
            thisCollection.RemoveAt(ind);
        }
    }

    /// <summary>
    /// Properly ordered permutations as 0-based integers
    /// For 3 will return: "012", "021", "102", "120", "201", "210"
    /// </summary>
    /// <param name="n"></param>
    /// <param name="stack"></param>
    /// <returns></returns>
    public static IEnumerable<int[]> OrderedPermutations(int n, Stack<int>? stack = null)
    {
        stack ??= new();

        if (stack.Count == n) //If stack is as long as the n, we have a combination inside - print or count it
            yield return stack.Reverse().ToArray();

        for (int i = 0; i < n; i++) //The main cycle to go over the number in descending order (because the stack will reverse it)
        {
            if (stack.Contains(i))  //Skip a number if we already use in the the stack - the place, where the current combination is constructed
                continue;

            stack.Push(i);  //Use and block a number, then do the permutations for the remaining numbers
            foreach (var p in OrderedPermutations(n, stack))
                yield return p;
            stack.Pop();
        }
    }


    public static int Factorial(int i)
    {
        if (i > 31)
            throw new ArgumentOutOfRangeException(nameof(i), "Factorials of 32 and more do not fit into integer");
        return Enumerable.Range(1, i).Aggregate((a, b) => a * b);
    }

    #region Sorting

    public static void InsertionSort<T>(IList<T> a) where T : IComparable<T>
    {
        if (a == null || a.Count < 2) //No need to sort
            return;

        for (int j = 1; j < a.Count; j++) //First card in already in hand, add next cards one by one
        {
            T key = a[j];

            int i = j - 1;
            while (i >= 0 && a[i].CompareTo(key) > 0)
            {
                a[i + 1] = a[i];
                i--;
            }
            a[i + 1] = key;
        }
    }


    public static int[] CountingSort(int[] a)
    {
        if (a.Length <= 1)
            return a;

        int max = a.Max();
        int[] c = new int[max + 1]; //Counting array (0-based)

        for (int i = 0; i < a.Length; i++) //Each cell will contain how many time a given number was seen in the source
        {
            int num = a[i];
            c[num]++;
        }

        int runningCount = c[0];
        for (int i = 1; i <= max; i++) //Converting C to cummulative sum - how many numbers are to the left of this one. 1-based position
        {
            runningCount += c[i];
            c[i] = runningCount;
        }

        if (runningCount != a.Length)
            throw new Exception("Cumulative sum in the last cell must be equal to the length of the source array");
        //It has a meaning: the place in the resulting array of the biggest number in the source and so it should point to the last cell in the result.

        int[] b = new int[a.Length]; //Result
        for (int i = b.Length - 1; i >= 0; i--) //Going from the end to the begigging to preserve the order of elements with the same number (stable sorting)
        {
            int num = a[i];
            int pos = c[num] - 1; //Position of this number in the result (0-based)
            b[pos] = num; //Write the result
            c[num]--; //Next time write this number to the left of this one 
        }

        return b;
    }

    public static uint[] RadixSort(IReadOnlyList<uint> src) // Digit is 4 bit long (0-15)
    {
        var dig = (int)Math.Ceiling(src.Select(a => Math.Log(a, 16)).Max()); //Calculate the number of hex digits in the biggest number
        uint[]? res = null;
        for (int d = 0; d < dig; d++) //For each digit sort the array by that digig using stable sorting (CountingSort)
        {
            res = CountingSortByDigit(src, d);
            src = res;
        }
        return res ?? throw new Exception("No digits were allocated");
    }

    private static uint[] CountingSortByDigit(IReadOnlyList<uint> a, int d)
    {
        int shift = 4 * d; //Shift required to bring the masked value to the lowest location
        uint mask = 0xfU << shift;

        var max = a.Select(n => (n & mask) >> shift).Max();
        int[] c = new int[max + 1]; //Counting array (0-based)

        for (int i = 0; i < a.Count; i++) //Each cell will contain how many time a given number was seen in the source
        {
            var num = (a[i] & mask) >> shift; //Get digit
            c[num]++;
        }

        int runningCount = c[0];
        for (int i = 1; i <= max; i++) //Converting C to cummulative sum - how many numbers are to the left of this one. 1-based position
        {
            runningCount += c[i];
            c[i] = runningCount;
        }

        if (runningCount != a.Count)
            throw new Exception("Cumulative sum in the last cell must be equal to the length of the source array");
        //It has a meaning: the place in the resulting array of the biggest number in the source and so it should point to the last cell in the result.

        uint[] b = new uint[a.Count]; //Result
        for (int i = b.Length - 1; i >= 0; i--) //Going from the end to the begigging to preserve the order of elements with the same number (stable sorting)
        {
            var dig = (a[i] & mask) >> shift; //Get digit
            int pos = c[dig] - 1; //Position of this number in the result (0-based)
            b[pos] = a[i]; //Write the full number from the current cell into the result
            c[dig]--; //Next time write this number to the left of this one 
        }

        return b;
    }
    #endregion Sorting
}
