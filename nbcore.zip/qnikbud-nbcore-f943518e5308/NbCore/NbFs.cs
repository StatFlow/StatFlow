﻿using NbCore.Crypto;
using System.Text.RegularExpressions;

namespace NbCore;

public static class NbFs
{
    public static string BaseDir => AppDomain.CurrentDomain.BaseDirectory;

    /// <summary>
    /// Returns obfuctated filename without path
    /// </summary>
    /// <param name="file">Source file</param>
    /// <param name="dstFolder">Destination Folder</param>
    /// <param name="md5">MD5 of the file</param>
    /// <returns></returns>
    public static string ObfuscateFileToDst(FileInfo file, DirectoryInfo dstFolder, string? md5 = null)
    {
        md5 ??= NbCrypto.Md5Safe64(file.FullName);

        string fileName = md5 + file.Extension;
        string dstFullName = Path.Combine(dstFolder.FullName, fileName);
        if (!File.Exists(dstFullName))
            File.Copy(file.FullName, dstFullName);

        return fileName;
    }

    public static string TimeStampFileToDst(FileInfo file, DirectoryInfo dstFolder, DateTime timeStamp = default)
    {
        string ts = (timeStamp == default ? DateTime.UtcNow : timeStamp).ToNbase64();

        string fileName = $"{file.NameWithoutExtension}-{ts}{file.Extension}";
        string dstFullName = Path.Combine(dstFolder.FullName, fileName);
        File.Copy(file.FullName, dstFullName, overwrite: true);

        return fileName;
    }


    public static DirectoryInfo CreateDirRecursive(string aDirName) => CreateDirRecursive(new DirectoryInfo(aDirName));
    public static DirectoryInfo CreateDirRecursive(FileInfo fi) => CreateDirRecursive(fi.Directory ?? throw new NbExceptionInfo($"File '{fi.FullName}' doesn't have parent directory"));

    public static DirectoryInfo DirSafe(this FileInfo fileInfo) => fileInfo.Directory ?? throw new Exception($"File '{fileInfo.FullName}' doesn't have a directory");

    public static DirectoryInfo[] GetDirsSafe(this DirectoryInfo dirInfo) => dirInfo.GetDirectories() ?? Array.Empty<DirectoryInfo>();
    public static FileInfo[] GetFilesSafe(this DirectoryInfo dirInfo) => dirInfo.GetFiles() ?? Array.Empty<FileInfo>();

    /// <summary>
    /// </summary>
    /// <returns>DirectoryInfo if directory was created, null if directory already existed</returns>
    public static DirectoryInfo CreateDirRecursive(DirectoryInfo di) //Recursive
    {
        if (!di.Exists)
        {
            if (di.Root.FullName == di.FullName) //We are in the root and it doens't exist
                throw new Exception($"The root dir '{di.Root.FullName}' doens't exist");

            CreateDirRecursive(di.Parent ?? throw new NbExceptionInfo($"Directory '{di.FullName}' doesn't have a parent"));
            di.Create();
        }
        return di;
    }

    public static void CopyFileSafe(FileInfo srcFile, FileInfo dstFile, bool deleteSource = false)
    {
        if (!srcFile.Exists) throw new Exception($"Source file '{srcFile}' doesn't exist");
        NbFs.CreateDirRecursive(dstFile.DirSafe());
        string dstDirName = dstFile.DirSafe().FullName;

        int cnt = 1;
        string dstFileName = Path.Combine(dstDirName, dstFile.Name);
        while (File.Exists(dstFileName)) //Ensure we are not overwriting the file
        {
            dstFileName = Path.Combine(dstDirName, Path.GetFileNameWithoutExtension(dstFile.Name) + $" ({cnt})" + dstFile.Extension);
            cnt++;
            if (cnt++ > 6000)
                throw new Exception($"There are over 6000 files named '{dstFile.Name}' in the directory '{dstDirName}'");
        }
        File.Copy(srcFile.FullName, dstFileName);

        if (deleteSource)
            File.Delete(srcFile.FullName);
    }

    public static void MoveDirSelectively(DirectoryInfo dirFrom, DirectoryInfo dirTo, HashSet<string> extensions)
    {
        TraverseDirs(dirFrom,
            parentDir: dirTo,
            dirAction: (di, dstDir) =>
            {
                if (di.Parent == null) //If the destination dir is the root (D:) do not add this nae
                    return dstDir;
                else
                    return new DirectoryInfo(Path.Combine(dstDir.FullName, di.Name));
            },
            fileAction: (fl, dstDir) =>
            {
                if (!extensions.Contains(fl.Extension))
                    return;

                var dstFl = Path.Combine(dstDir.FullName, fl.Name);
                NbFs.CreateDirRecursive(dstDir);
                File.Move(fl.FullName, dstFl);
                Console.WriteLine(fl.FullName);
            });
    }

    public static DirectoryInfo DirFirstExistingParent(this DirectoryInfo di) => di.Exists ? di : DirFirstExistingParent(di.Parent ?? throw new NbException($"The dir '{di.FullName}' doens't have parent dir"));

    public static readonly string[] DirsToIgnore = { "$RECYCLE.BIN", "RECYCLER", "Recycled", "System Volume Information" };
    public static readonly string[] FilesToIgnoreSystem = { "Thumbs.db" };

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T">The type representing the Dir in the client code, it is passed from Dir creation to the FileCreation and the Subdir creation actions</typeparam>
    /// <param name="di">DirectoryInfo of the directory to visit first</param>
    /// <param name="parentDir">User object representing root dir, could be set to null in the root call</param>
    /// <param name="dirAction">Action called on directory visit. Takes the directoryInfo, the parent user directory object and retruns new directory user object</param>
    /// <param name="fileAction">Action called on file fisit. Takes the FileInfo and the current User directory object</param>
    public static void TraverseDirs<T>(DirectoryInfo di, T parentDir, Func<DirectoryInfo, T, T> dirAction, Action<FileInfo, T> fileAction)
    {
        var currDir = dirAction(di, parentDir);

        try
        {
            foreach (var fl in di.GetFiles())
            {
                if (FilesToIgnoreSystem.Contains(fl.Name))
                    continue;

                fileAction(fl, currDir);
            }

            foreach (var subDi in di.GetDirectories())
            {
                if (DirsToIgnore.Contains(subDi.Name))
                    continue;

                TraverseDirs(subDi, currDir, dirAction, fileAction);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(NbException.Exception2String(ex));
        }
    }

    public static void DeleteByRegex(this DirectoryInfo di, string regex, string? exceptForN = null)
    {
        var reg = new Regex(regex);
        foreach (var dir in di.GetDirectories().Where(d => reg.IsMatch(d.Name)))
        {
            if (!String.IsNullOrEmpty(exceptForN) && dir.Name.EqIC(exceptForN))
                continue;
            try { dir.Delete(recursive: true); }
            catch (Exception ex) { Console.WriteLine($"Can't delete old snapshot folder: '{dir.FullName}'. {NbException.Exception2String(ex)}"); }
        }
    }

    //The list of files by the search pattern, including the directory
    //public static IEnumerable<FileInfo> ListFiles(string aSearchWithPath) => new DirectoryInfo(Path.GetDirectoryName(aSearchWithPath)).GetFiles(Path.GetFileName(aSearchWithPath)).OrderBy(fi => fi.Name);

    public static IEnumerable<FileInfo> ListFilesRecursively(this DirectoryInfo di) => FlattenDir(di).SelectMany(d =>
    {
        try { return d.GetFiles(); }
        catch (UnauthorizedAccessException) { return Enumerable.Empty<FileInfo>(); }
    });

    public static IEnumerable<FileInfo> ListFilesRecursively(DirectoryInfo di, string aSearchPattern) => ListFilesRecursively(di, aSearchPattern.Split(Path.PathSeparator));
    public static IEnumerable<FileInfo> ListFilesRecursively(DirectoryInfo di, IEnumerable<string> aSearchPatterns)
    {
        return aSearchPatterns.SelectMany(ptrn => FlattenDir(di).SelectMany(d =>
        {
            try { return d.GetFiles(ptrn); }
            catch (UnauthorizedAccessException) { return Enumerable.Empty<FileInfo>(); }
        }));
    }

    public static IEnumerable<DirectoryInfo> FlattenDir(DirectoryInfo aDir)
    {
        if (aDir == null || !aDir.Exists)
            return Enumerable.Empty<DirectoryInfo>();

        try
        {
            return NbExt.Yield(aDir).Concat(aDir.GetDirectories().SelectMany(e => FlattenDir(e)));
        }
        catch (UnauthorizedAccessException) { return Enumerable.Empty<DirectoryInfo>(); }
    }

    /// <summary>
    /// Deletes existing old file and moves the current dstFile if it exist to .old file.
    /// </summary>
    /// <param name="dstFile">Full file name to be moved to old file</param>
    /// <returns>The old file name (useful for comparison with current verion in beyond compare)</returns>
    public static string MoveToOldFile(string dstFile)
    {
        var oldName = dstFile + ".old";

        if (File.Exists(oldName)) File.Delete(oldName);
        if (File.Exists(dstFile)) File.Move(dstFile, oldName);
        return oldName;
    }
}

public sealed record NbTempDir(string FullName) : IDisposable, IAsyncDisposable
{
    public static NbTempDir CreateInTemp()
    {
        string newDir = Path.GetTempPath() + Guid.NewGuid();
        Directory.CreateDirectory(newDir);
        return new NbTempDir(newDir);
    }

    public override string ToString() => FullName;

    public void Dispose()
    {
        if (Directory.Exists(FullName))
            Directory.Delete(FullName, recursive: true);
    }

    public async ValueTask DisposeAsync()
    {
        await Task.Run(() =>
        {
            if (Directory.Exists(FullName))
                Directory.Delete(FullName, recursive: true);
        });

        /*await Task.Factory.StartNew(() =>
        {
            if (Directory.Exists(FullName))
                Directory.Delete(FullName, recursive: true);
        });*/
    }
}

/// <summary>
/// Creates temporary file in system's temp directory or directory provided in constructor
/// </summary>
/// <param name="FullName"></param>
public sealed record NbTempFile(FileInfo FileInfo) : IDisposable
{
    /// <summary>
    /// Creates 0-length file in Temp directory. The user need to delete of Append to this file. On disposing the file will be deleted
    /// </summary>
    /// <returns></returns>
    public static NbTempFile FileInTemp()
    {
        var fileName = Path.GetTempFileName();
        File.Delete(fileName);
        return new(new FileInfo(fileName));
    }

    /// <summary>
    /// Creates new temp files and saves text into it. If PathName is provided the file will be created in this diretory
    /// </summary>
    /// <param name="text"></param>
    /// <param name="pathName"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public static NbTempFile CreateFromText(string text, string? pathName = null)
    {
        if (pathName == null)
        {
            pathName = Path.GetTempFileName(); //Creates the file
            File.AppendAllText(pathName, text);
        }
        else
        {
            FileInfo fi = new(pathName);
            if (fi.Exists)
                throw new Exception($"File {pathName} already exists");

            NbFs.CreateDirRecursive(fi);
            File.WriteAllText(fi.FullName, text);
        }
        return new NbTempFile(new FileInfo(pathName));
    }

    public void Dispose()
    {
        if (FileInfo.Exists)
            FileInfo.Delete();
    }
}
