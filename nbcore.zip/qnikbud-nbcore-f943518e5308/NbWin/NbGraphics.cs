﻿using System.Drawing.Imaging;
using System.Text;
using System.Text.RegularExpressions;

namespace NbWin;

public class NbGraphics
{
    private static readonly Lazy<Regex> ImgRegex = new(() => new Regex(@"^data:image/(\w+);base64,(.+)$"));
    public static Image ImageFromBase64(string base64)
    {
        var match = ImgRegex.Value.Match(base64);
        if (!match.Success)
            throw new Exception($"Can't parse image out of given string: {base64.Limit(20)}");

        string _ = match.Groups[1].Value;
        string base64only = match.Groups[2].Value;
        byte[] data = Convert.FromBase64String(base64only);
        using var ms = new MemoryStream(data);
        Image img = Image.FromStream(ms);
        return img;
    }

    //https://exiv2.org/tags.html
    public static DateTime? GetExifDate(string filename)
    {
        const int Exif_Image_DateTimeOriginal = 0x9003;

        using Image image = new Bitmap(filename);

        Dictionary<string, string> map = new();
        // Get the PropertyItems property from image.
        PropertyItem[] propItems = image.PropertyItems;
        if (propItems != null)
        {
            foreach (PropertyItem item in propItems)
            {
                if (item.Id == Exif_Image_DateTimeOriginal)
                {
                    if (item.Value == null)
                        return null;

                    string str = Encoding.ASCII.GetString(item.Value).TrimEnd('\0');

                    if (NbExt.TryParseDate(str, out DateTime dt))
                        return dt;
                    else
                        throw new Exception($"Can't parse DateTime out of '{str}' string");
                }
            }
        }
        return null;

        /*using (FileStream fs = new FileStream(f.FullName, FileMode.Open, FileAccess.Read, FileShare.Read))
        {
            BitmapSource img = BitmapFrame.Create(fs);
            BitmapMetadata md = (BitmapMetadata)img.Metadata;
            string date = md.DateTaken;
            Console.WriteLine(date);
            return date;
        }*/
    }
}
