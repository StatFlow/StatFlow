﻿using NbFormV1.Xml;

namespace NbWpfLib;

public partial class NbDialogForm : Form
{
    internal bool Result = false;
    const int vertStep = 22;
    const int buttSpaceHor = 8;

    private readonly Image FakeImage;
    private readonly Graphics FakeGraphics;

    public NbDialogForm()
    {
        InitializeComponent();
        FakeImage = new Bitmap(1, 1); //As we cannot use CreateGraphics() in a class library, so the fake image is used to load the Graphics.
        FakeGraphics = Graphics.FromImage(FakeImage);
    }

    private NbDialogForm(string title, string label, string? defaultTxt = null)
        : this()
    {
        //InitializeComponent();
        Text = title;
        label1.Text = label;
        if (defaultTxt != null)
        {
            textBox1.Text = defaultTxt;
            textBox1.SelectAll();
        }
        textBox1.Focus();
    }

    public NbDialogForm(NbFormDesc formDesc)
    {
        FakeImage = new Bitmap(1, 1);
        FakeGraphics = Graphics.FromImage(FakeImage);

        SuspendLayout();

        AutoScaleDimensions = new SizeF(6F, 13F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(440, 91);

        int currTop = 10;
        int cnt = 1;
        foreach (FieldDescBase fld in formDesc.fields.Safe())
        {
            switch (fld)
            {
                case FieldText fldText:
                    TextBox tb = new()
                    {
                        Location = new Point(15, currTop),
                        Name = $"textBox{cnt}",
                        Size = new Size(403, 20),
                        TabIndex = cnt,
                        Tag = fld
                    };
                    Controls.Add(tb);
                    break;

                case FieldNum fldNum:
                    throw new NotImplementedException("FieldNums are not implemented");

                case FieldDate fldDate:
                    throw new NotImplementedException("FieldDates are not implemented");

                default:
                    throw new NbException($"Unsupported {nameof(FieldDescBase)} type: {fld.GetType().Name}");
            }

            cnt++;
            currTop += vertStep;
        }


        ProcButtons(formDesc.buttons.Safe(), ref currTop);

        ResumeLayout();
    }

    private void ProcButtons(IEnumerable<ButtonDesc> btnDescs, ref int currTop)
    {
        int buttCount = 0;
        int buttWidthSum = 0;
        List<Button> btns = new();

        //Create and cals width
        foreach (ButtonDesc btnDesc in btnDescs)
        {
            int textWidth = TextWidth(btnDesc.label) + 6;

            DialogResult dr = (DialogResult)btnDesc.dialog_result;

            Button btn = new() { Name = btnDesc.name, Text = btnDesc.label, Top = currTop, Width = textWidth, DialogResult = dr, Tag = btnDesc };
            btn.Click += Btn_Click;
            //AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, AutoEllipsis = false 

            /*switch (btnDesc.func)
            {
                case ButtonFunc.Enter:
                    AcceptButton = btn;
                    break;
                case ButtonFunc.Esc:
                    CancelButton = btn;
                    break;
                default:
                    break;
            }*/

            btns.Add(btn);
            buttCount++;
            buttWidthSum += btn.Width;
        }
        if (buttCount == 0)
            throw new Exception("No buttons of the form!");

        int wWithSpaces = buttWidthSum + buttSpaceHor * buttCount + 1;
        if (Width < wWithSpaces)
            Width = wWithSpaces;

        //Calc left and add to controls
        int currLeft = (Width - wWithSpaces) / 2;
        foreach (var btn in btns)
        {
            currLeft += buttSpaceHor;
            btn.Left = currLeft;
            Controls.Add(btn);
            currLeft += btn.Width;
        }
    }

    private int TextWidth(string txt) => Convert.ToInt32(FakeGraphics.MeasureString(txt, Font).Width);

    public static (bool, string) Show(string title, string label, string? defaultTxt = null)
    {
        var dlg = new NbDialogForm(title, label, defaultTxt);
        dlg.ShowDialog();
        return (dlg.Result, dlg.textBox1.Text);
    }

    public static DialogResult Show(NbFormDesc formDesc)
    {
        var dlg = new NbDialogForm(formDesc);
        return dlg.ShowDialog(); //TODO how to show async?
    }

    private void BtOK_Click(object sender, EventArgs e)
    {
        Result = true;
        Close();
    }

    private void BtCancel_Click(object sender, EventArgs e)
    {
        Result = false;
        Close();
    }

    private void Btn_Click(object? sender, EventArgs e)
    {
        Button btn = sender as Button ?? throw new ArgumentNullException("Btn_Click sender is not a button");

        foreach (var cntrl in Controls)
        {
            switch (cntrl)
            {
                case TextBox tb:
                    var desc = (tb.Tag as FieldText) ?? throw new Exception("TextBox doesn't have Tag set");
                    desc.new_val = tb.Text;
                    break;

                case Button: //Do not process buttons here
                    break;

                default:
                    throw new Exception($"Unsupported control: {cntrl} on form closing");
            }
        }
        DialogResult = btn.DialogResult;
        Close();
    }


    private void NbDialogForm_FormClosing(object sender, FormClosingEventArgs e)
    {

    }
}
