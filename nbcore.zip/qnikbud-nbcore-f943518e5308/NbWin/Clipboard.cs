using System.Diagnostics.CodeAnalysis;

namespace NbCore;

/// <summary>
/// FxCop requires all Marshalled functions to be in a class called NativeMethods.
/// </summary>
public static class ClipboardTools
{
    //Text-related
    public const string CL_Text = "Text";
    public const string CL_UnicodeText = "UnicodeText";
    public const string CL_SystemString = "System.String";

    //File-related
    public const string CL_FileGroupDescriptorW = "FileGroupDescriptorW";
    public const string CL_FileGroupDescriptor = "FileGroupDescriptor";
    public const string CL_FileDrop = "FileDrop";
    public const string CL_FileNameW = "FileNameW";
    public const string CL_FileName = "FileName";

    public static bool TryGetTextFromClipboard([MaybeNullWhen(false)] out string? text)
    {
        if (Clipboard.ContainsText())
        {
            text = Clipboard.GetText();
            return true;
        }
        text = null;
        return false;
    }

    public static bool TryGetFileDescriptors(this IDataObject dataObj, [MaybeNullWhen(false)] out List<NativeMethods.FILEDESCRIPTORW>? fileList)
    {
        if (dataObj.GetDataPresent(CL_FileGroupDescriptorW))
        {
            fileList = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORW>((MemoryStream)dataObj.GetData(CL_FileGroupDescriptorW)).ToList();
            return true;
        }
        else if (dataObj.GetDataPresent(CL_FileGroupDescriptor))
        {
            var _ = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORA>((MemoryStream)dataObj.GetData(CL_FileGroupDescriptor)).ToList();
            throw new Exception($"FileGroupDescriptorW is not available while FileGroupDescriptor is available = non-Unicone Windows?");
        }
        fileList = null;
        return false;
    }

    public static bool TryGetText(this IDataObject dataObj, [NotNullWhen(true)] out string? text)
    {
        bool res = dataObj.GetDataPresent(CL_UnicodeText);
        text = res ? (string?)dataObj.GetData(CL_UnicodeText) : null;
        return res;
    }

    public static bool TryGetFileNames(this IDataObject dataObj, [NotNullWhen(true)] out string[]? fileList)
    {
        if (dataObj.GetDataPresent(CL_FileDrop))
        {
            fileList = dataObj.GetData(CL_FileDrop) as string[] ?? throw new Exception($"{CL_FileDrop} output is not string[]");
            return true;
        }
        else if (dataObj.GetDataPresent(CL_FileNameW))
        {
            fileList = dataObj.GetData(CL_FileNameW) as string[] ?? throw new Exception($"{CL_FileNameW} output is not string[]");
            return true;
        }
        else if (dataObj.GetDataPresent(CL_FileName))
        {
            fileList = dataObj.GetData(CL_FileName) as string[] ?? throw new Exception($"{CL_FileName} output is not string[]");
            return true;
        }
        fileList = null;
        return false;
    }
}

/*public sealed class ClipboardNotificationFormExample
{
    static void Main(string[] args)
    {
        var f = new NotificationForm();

        Console.ReadKey();
    }

    /// <summary>
    /// Occurs when the contents of the clipboard is updated.
    /// </summary>
    public static event EventHandler ClipboardUpdate;

    private static readonly NotificationForm _form = new();

    /// <summary>
    /// Raises the <see cref="ClipboardUpdate"/> event.
    /// </summary>
    /// <param name="e">Event arguments for the event.</param>
    private static void OnClipboardUpdate(EventArgs e)
    {
        ClipboardUpdate?.Invoke(null, e);
    }

    /// <summary>
    /// Hidden form to recieve the WM_CLIPBOARDUPDATE message.
    /// </summary>
    private class NotificationForm : Form
    {
        public NotificationForm()
        {
            NativeMethods.SetParent(Handle, NativeMethods.HWND_MESSAGE); //Makes the window hidden (message-only window)
            NativeMethods.AddClipboardFormatListener(Handle);
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == NativeMethods.WM_CLIPBOARDUPDATE)
            {
                OnClipboardUpdate(null);
            }
            base.WndProc(ref m);
        }
    }
}*/

//Filedrop sample
/*byte[] moveEffect = { 2, 0, 0, 0 };
MemoryStream dropEffect = new MemoryStream();
dropEffect.Write(moveEffect, 0, moveEffect.Length);

StringCollection filestToCut = new StringCollection {"D:\\test.txt"};
DataObject data = new DataObject("Preferred DropEffect", dropEffect);
data.SetFileDropList(filestToCut);

//or execute default constructor and uncomment line below:
//data.SetData("Preferred DropEffect", dropEffect);

Clipboard.Clear();
Clipboard.SetDataObject(data, true);
*/
