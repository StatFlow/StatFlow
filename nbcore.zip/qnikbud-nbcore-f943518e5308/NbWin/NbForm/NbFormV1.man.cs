﻿namespace NbFormV1.Xml;

public partial class NbFormDesc
{
    public NbFormDesc() { } //For Serialization
    public NbFormDesc(string title, FieldDescBase[] fields, ButtonDesc[] buttons) => (this.title, this.fields, this.buttons) = (title, fields, buttons);

    private void Resolve() { }
}
