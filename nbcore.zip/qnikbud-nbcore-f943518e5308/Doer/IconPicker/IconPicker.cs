﻿using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using NbWin;
using TsudaKageyu;

namespace Doer.IconPicker
{
    public partial class Form1 : Form
    {
        private string? IcoSrcFileN;
        public Icon? FullIconN { get; set; }

        private class IconListViewItem : ListViewItem
        {
            public Icon Icon { get; set; }
            internal IconListViewItem(Icon icon) =>  Icon = icon;
        }

        public Form1() => InitializeComponent();

        private void ClearAllIcons()
        {
            FullIconN?.Dispose();

            foreach (var item in lvwIcons.Items)
                ((IconListViewItem)item).Icon.Dispose();

            lvwIcons.Items.Clear();
        }

        private void Form1_FormClosing(object _, FormClosingEventArgs _1) => ClearAllIcons();

        private void BtnPickFile_Click(object sender, EventArgs e)
        {
            var result = iconPickerDialog.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                var fileName = iconPickerDialog.FileName;
                if (String.IsNullOrEmpty(fileName))
                    return;

                var index = iconPickerDialog.IconIndex;
                txtFileName.Text = String.Format("{0}, {1}", fileName, index);
                ShowIconFromFile(fileName, index);
            }
        }


        private void Png_Click(object sender, EventArgs e)
        {
            const string path = @"C:\Repo\Sync.svn\Data\FavIcons";  //TODO: get from settings
            using var dlg = new OpenFileDialog
            {
                Filter = "Icon file (*.ico)|*.ico|Png file (*.png)|*.png",
                FilterIndex = 2, //1-based
                InitialDirectory = path,
                Multiselect = false
            };
            var dlgResult = dlg.ShowDialog();
            if (dlgResult == DialogResult.Cancel)
                return;

            ShowPngFromFile(dlg.FileName);
        }

        private void ShowPngFromFile(string fileName)
        {
            using Nconvert nconv = new();
            var tmpIcon = nconv.Png2Icon(fileName);
            var icon = new Icon(tmpIcon);

            txtFileName.Text = fileName;

            FullIconN?.Dispose(); //Dispose old icon
            FullIconN = icon;

            ShowIconFromFile(tmpIcon, 0);
        }

        private void ShowIconFromFile(string fileName, int index)
        {
            Icon? icon = null;
            Icon[]? splitIcons = null;
            try
            {
                var ext = Path.GetExtension(fileName).ToLower();
                if (ext == ".ico" || ext == ".tmp") //Nconvert uses tmp files
                {
                    icon = new Icon(fileName);
                }
                else
                {
                    var extractor = new IconExtractor(fileName);
                    icon = extractor.GetIcon(index);
                }

                splitIcons = IconUtil.Split(icon);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            finally
            {
                Icon = icon; //Current window icon
                FullIconN?.Dispose(); //Dispose old icon
                FullIconN = icon;
            }
            // Update icons.


            //icon.Dispose();

            lvwIcons.BeginUpdate();
            ClearAllIcons();

            foreach (var i in splitIcons)
            {
                lvwIcons.Items.Add(new IconListViewItem(i)
                {
                    ToolTipText = String.Format("{0}x{1}, {2}bits", i.Width, i.Height, IconUtil.GetBitCount(i)),
                });
            }
            lvwIcons.EndUpdate();
        }

        /// <summary>
        /// DrawListViewItemEventHandler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LvwIcons_DrawItem(object sender, DrawListViewItemEventArgs e)
        {
            var item = e.Item as IconListViewItem ?? throw new Exception($"Item is not {nameof(IconListViewItem)}");

            // Draw item

            e.DrawBackground();

            int w, h;
            if (item.Icon.Width <= 128 && item.Icon.Height <= 128)
            {
                w = item.Icon.Width;
                h = item.Icon.Height;
            }
            else
            {
                w = 128;
                h = 128;
            }

            int x = e.Bounds.X + (e.Bounds.Width - w) / 2;
            int y = e.Bounds.Y + (e.Bounds.Height - h) / 2;
            var dstRect = new Rectangle(x, y, w, h);
            var srcRect = new Rectangle(Point.Empty, item.Icon.Size);

            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            e.Graphics.CompositingQuality = CompositingQuality.HighQuality;
            e.Graphics.Clip = new Region(e.Bounds);

            using (var bmp = IconUtil.ToBitmap(item.Icon))
            {
                e.Graphics.DrawImage(bmp, dstRect, srcRect, GraphicsUnit.Pixel);
            }

            var textRect = new Rectangle(
                e.Bounds.Left, e.Bounds.Bottom - Font.Height - 4,
                e.Bounds.Width, Font.Height + 2);
            //SystemColorsChanged
            TextRenderer.DrawText(e.Graphics, item.ToolTipText, Font, textRect, item.Selected ? Color.Blue : ForeColor);

            e.Graphics.Clip = new Region();
            e.Graphics.DrawRectangle(SystemPens.ControlLight, e.Bounds);
        }

        private void BtnSelectedIcon(object sender, EventArgs e)
        {
            try
            {
                if (lvwIcons.SelectedItems.Count == 0)
                {
                    MessageBox.Show("No icons selected");
                    return;
                }

                var entry = lvwIcons.SelectedItems[0] as IconListViewItem ?? throw new Exception("Selected icon is not IconListViewItem");
                NbSaveIconDialog(entry.Icon, asPng: false);
            }
            catch (Exception ex)
            { MessageBox.Show("Error: " + ex.Message); }
        }

        private void BtnAllIconsAsOne(object sender, EventArgs e)
        {
            try
            {
                if (FullIconN == null)
                    MessageBox.Show("Icon is not loaded");
                else
                    NbSaveIconDialog(FullIconN, asPng: false);
            }
            catch (Exception ex)
            { MessageBox.Show("Error: " + ex.Message); }
        }

        private void NbSaveIconDialog(Icon ico, bool asPng)
        {
            string suggName = IcoSrcFileN != null ? Path.GetFileNameWithoutExtension(IcoSrcFileN) : "icon";

            string path = Environment.ExpandEnvironmentVariables(@"%USERPROFILE%\.freemind\icons");  //TODO: get from settings
            using var dlg = new SaveFileDialog
            {
                Filter = "Icon file (*.ico)|*.ico|Png file (*.png)|*.png",
                FilterIndex = asPng ? 2 : 1, //1-based
                FileName = suggName[..1].ToUpperInvariant() + suggName[1..] + (asPng ? ".png" : ".ico"),
                InitialDirectory = path
            };
            if (dlg.ShowDialog() == DialogResult.Cancel)
                return;

            using Stream wtrt = new FileStream(dlg.FileName, FileMode.CreateNew);
            if (dlg.FileName.EndsWith(".png"))
                ico.ToBitmap().Save(wtrt, ImageFormat.Png); //System.Drawing.Imaging.
            else
                ico.Save(wtrt);
        }


        private void LvwIcons_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data?.GetDataPresent(ClipboardTools.CL_FileDrop) ?? false)
                e.Effect = DragDropEffects.Copy;
        }

        private void LvwIcons_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                if (e.Data?.TryGetFileNames(out var fileLst) ?? false)
                {
                    var pngFile = fileLst.FirstOrDefault(f => Path.GetExtension(f).EqIC(".png"));
                    if (pngFile != null)
                    {
                        ShowPngFromFile(pngFile);
                        return;
                    }

                    for (int i = 0; i < fileLst.Length; ++i) //If  any lnk files encountered - resolve them to underlying files.
                    {
                        var lnkFile = fileLst[i];
                        if (Path.GetExtension(lnkFile).EqIC(".lnk"))
                            fileLst[i] = LnkResolver.GetLnkTarget(lnkFile);
                    }

                    string[] otherIconContainingFiles = new string[] { ".ico", ".exe", ".dll" };
                    IcoSrcFileN = fileLst.FirstOrDefault(f => otherIconContainingFiles.Any(ext => Path.GetExtension(f).EqIC(ext)));
                    if (IcoSrcFileN != null)
                    {
                        iconPickerDialog.FileName = IcoSrcFileN;
                        var result = iconPickerDialog.ShowDialog(this);
                        if (result == DialogResult.OK)
                        {
                            var fileName = iconPickerDialog.FileName;
                            var index = iconPickerDialog.IconIndex;
                            txtFileName.Text = String.Format("{0}, {1}", fileName, index);
                            ShowIconFromFile(fileName, index);
                        }

                        //ShowIconFromFile(icoFile, 0);
                        return;
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex), ex.Message);
            }
        }
    }
}
