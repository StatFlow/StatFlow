﻿using System.Text;
using System.Text.RegularExpressions;

namespace Doer;

public partial class ActionMoveMediaFiles : IDoerAction
{
    public string Name => "Move media files";

    public async Task Run(IMainForm form)
    {
        var fileCnt = ClearDesktop();

        HashSet<DirectoryInfo> emptyDirCandidates = new();
        await Task.Run(() =>
        {
            var files = ClearJd().ToList();
            foreach ((FileInfo srcFi, string dst) in files)
            {
                try
                {
                    emptyDirCandidates.Add(srcFi.DirSafe()); //Must be before MoveTo, because it will update the path
                    NbFs.CopyFileSafe(srcFi, new FileInfo(dst), deleteSource: true);  //was srcFi.MoveTo(dst, overwrite: false);
                    fileCnt++;
                }
                catch (IOException ex) { throw new NbException(ex, $"Error moving file '{srcFi.FullName}'"); }
            }
        }).ConfigureAwait(false);

        await Task.Delay(1000); //Timeout for fileoperations to finish
        StringBuilder bld = new();
        foreach (DirectoryInfo parDir in emptyDirCandidates)
        {
            try
            {
                if (parDir.Exists && !parDir.EnumerateFileSystemInfos().Any())
                    parDir.Delete();
            }
            catch (Exception ex)
            {
                bld.AppendLine();
                bld.Append(ex.ToString());
            }
        }

        form.SetStatus($"{fileCnt} files copied to the Pictures, Video, Audio, Document and Links directories");
        form.Dialog($"{fileCnt} files copied to the Pictures, Video, Audio, Document and Links directories, {bld}", MessageBoxButtons.OK);
    }

    internal static IEnumerable<(FileInfo oldPath, string newPath)> ClearJd()
    {
        DirectoryInfo dnlDir = new(Environment.ExpandEnvironmentVariables(@"%USERPROFILE%\Downloads\Jd"));
        if (!dnlDir.Exists)
            yield break;

        NbDictionary<string, DirectoryInfo> dstDirs = new(10, null, "Lazy Destination dirs", d =>
        {
            string resDir = Environment.ExpandEnvironmentVariables(d);
            return NbFs.CreateDirRecursive(resDir);
        });

        var fileList = NbFs.ListFilesRecursively(dnlDir).ToList();
        foreach (var fi in fileList)
            switch (NbMedia.GetFileMediaType(fi))
            {
                case NbMedia.FileMediaTypes.Video:


                    var m1 = YouTubeVidRegex().Match(fi.Name);
                    if (m1.Success)
                        yield return (fi, Path.Combine(dstDirs[@"%USERPROFILE%\Videos\YouTube"].FullName, $"{m1.Groups[1].Value}{fi.Extension}"));

                    var m2 = TikTokRegex().Match(fi.Name);
                    if (m2.Success)
                        yield return (fi, Path.Combine(dstDirs[@"%USERPROFILE%\Videos\TikTok"].FullName, $"{m2.Groups[2].Value}. {m2.Groups[1].Value}{fi.Extension}"));

                    foreach (Regex rg in Xhs)
                    {
                        var m4 = rg.Match(fi.Name);
                        if (m4.Success)
                        {
                            yield return (fi, Path.Combine(dstDirs[@"C:\Temp\PCast\xH"].FullName, fi.Name)); //Do not change the name, it will be processed in FilerModel
                            break; //Return for only one regex
                        }
                    }
                    break;

                case NbMedia.FileMediaTypes.Audio:
                    var match3 = YouTubeAudRegex().Match(fi.Name);
                    if (match3.Success)
                        yield return (fi, Path.Combine(dstDirs[@"%USERPROFILE%\Music\YouTube"].FullName, $"{match3.Groups[1].Value}{fi.Extension}"));
                    break;

                default:
                    break;
            }
    }

    private static int ClearDesktop()
    {
        var srcDir = Environment.ExpandEnvironmentVariables(@"%USERPROFILE%\Desktop");
        int fileCnt = CopyMediaFiles(srcDir, @"%USERPROFILE%\Pictures", NbMedia.PhotoExtensions);
        fileCnt += CopyMediaFiles(srcDir, @"%USERPROFILE%\Videos", NbMedia.VideoExtensions);
        fileCnt += CopyMediaFiles(srcDir, @"%USERPROFILE%\Music", NbMedia.AudioExtensions);
        fileCnt += CopyMediaFiles(srcDir, @"%USERPROFILE%\Documents", NbMedia.DocumentExtensions);
        fileCnt += CopyMediaFiles(srcDir, @"%USERPROFILE%\Links", NbMedia.LinkExtensions);
        return fileCnt;
    }

    private static int CopyMediaFiles(string srcDir, string dstPicDir, IEnumerable<string> extensions)
    {
        int fileCnt = 0;
        foreach (var fl in new DirectoryInfo(srcDir).GetFiles().Where(fl => extensions.Contains(fl.Extension.ToLowerInvariant())))
        {
            try
            {
                var dstFile = Path.Combine(Environment.ExpandEnvironmentVariables(dstPicDir), "From Desktop", fl.Name);
                NbFs.CopyFileSafe(fl, new FileInfo(dstFile), deleteSource: true);
                fileCnt++;
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
        }
        return fileCnt;
    }

    [GeneratedRegex("^(.+) (\\(.+_AAC\\)).mp4$")]
    private static partial Regex YouTubeVidRegex();

    [GeneratedRegex(@"^(.+) \(.+_.+\)\.[^\.]+$")]
    private static partial Regex YouTubeAudRegex();

    [GeneratedRegex(@"^.+@(.+)_(\d+)\.mp4$")]
    private static partial Regex TikTokRegex();

    [GeneratedRegex(@"^!*(\d{5,})_(.+)$")]
    private static partial Regex XhNumFirst();

    [GeneratedRegex(@"^!*(.+)_(\d{5,})$")]
    private static partial Regex XhNumLast();

    [GeneratedRegex(@"^!*(.+)_(xh\S+)$")]
    private static partial Regex Xh_xhLast();

    [GeneratedRegex(@"^(xh\S+)_(.+)$")]
    private static partial Regex Xh_xhLast2();

    [GeneratedRegex(@"^(.*)_(\d+)p\.mp4$")]
    private static partial Regex Ph();

    private static readonly Regex[] Xhs = { XhNumFirst(), XhNumLast(), Xh_xhLast(), Xh_xhLast2(), Ph() };
}
