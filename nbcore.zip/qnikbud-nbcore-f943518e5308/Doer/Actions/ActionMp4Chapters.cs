﻿using System.Text.RegularExpressions;

namespace Doer;

internal partial class ActionMp4Chapters : IDoerAction
{
    //private static readonly string Mp4v2Chap = @"Exec\mp4chaps.exe";
    private readonly FileInfo[] Files;
    private ActionMp4Chapters(FileInfo[] files) => Files = files;

    internal static ActionMp4Chapters? Create(FileInfo[] files)
    {
        if (files.Any(f => ChapterMinSnapshotRegex().IsMatch(f.Name) || ChapterHourSnapshotRegex().IsMatch(f.Name)))
            return new ActionMp4Chapters(files);
        else
            return null;
    }

    public string Name => "Mp4Chapters";

    public async Task Run(IMainForm form)
    {
        NbDictionary<string, List<(int Hours, int Minutes, int Seconds, int SubSeconds, string ChapName, FileInfo File)>> chaps = new(creator: _ => new List<(int, int, int, int, string, FileInfo)>());
        foreach (FileInfo file in Files)
        {
            Match mm = ChapterMinSnapshotRegex().Match(file.Name);
            if (mm.Success)
            {
                chaps[mm.Groups[1].Value].Add((0, Int32.Parse(mm.Groups[2].Value), Int32.Parse(mm.Groups[3].Value), Int32.Parse(mm.Groups[4].Value), mm.Groups[5].Value, file));
                continue;
            }

            Match mh = ChapterHourSnapshotRegex().Match(file.Name);
            if (mh.Success)
                chaps[mh.Groups[1].Value].Add((Int32.Parse(mh.Groups[2].Value), Int32.Parse(mh.Groups[3].Value), Int32.Parse(mh.Groups[4].Value), Int32.Parse(mh.Groups[5].Value), mh.Groups[6].Value, file));
        }

        foreach (var (mp4, list) in chaps) try //For each mp4 file
        {
            var flName = Path.Combine(list[0].File.DirSafe().FullName, $"{mp4}.chapters.txt");
            using var wrtr = new StreamWriter(flName);
            foreach (var t in list.OrderBy(i => i.Hours).ThenBy(i => i.Minutes).ThenBy(i => i.Seconds))
            {
                await wrtr.WriteLineAsync($"{t.Hours:d2}:{t.Minutes:d2}:{t.Seconds:d2}.{t.SubSeconds:d3} {t.ChapName}");
            }
        }
        catch (Exception ex)
        {
            if (form.Dialog(NbException.Exception2String(ex), MessageBoxButtons.OKCancel) == DialogResult.Cancel)
                break;
        }
    }

    [GeneratedRegex(@"^(.+)\.mp4_snapshot_(\d{2})\.(\d{2})\.(\d{3})\.jpg(.+)\.jpg$")]
    public static partial Regex ChapterMinSnapshotRegex();

    [GeneratedRegex(@"^(.+)\.mp4_snapshot_(\d{2})\.(\d{2})\.(\d{2})\.(\d{3})\.jpg(.+)\.jpg$")]
    public static partial Regex ChapterHourSnapshotRegex();
}
