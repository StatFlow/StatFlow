﻿using NbCore.Crypto;
using System.Security.Cryptography;
using System.Text;

namespace Doer;

public record MessageAction(string Mess) : IDoerAction
{
    public string Name => "Message Action";
    public Task Run(IMainForm form) { form.MessageInfo(Mess); return Task.CompletedTask; }
}

public class ContPassAction : IDoerAction
{
    private readonly Lazy<GeorgeConverter> GeorConv = new(new GeorgeConverter());
    private readonly Lazy<SHA1> Sha = new(SHA1.Create());
    private readonly string Message;
    public ContPassAction(string mess) => Message = mess;

    public string Name => "Container Code";

    public Task Run(IMainForm form)
    {
        var (res, count) = GeorConv.Value.Convert(Message);
        string pass2 = Convert.ToHexString(Sha.Value.ComputeHash(Encoding.UTF8.GetBytes(res + NbCrypto.Ldr))).ToLowerInvariant();

        Clipboard.SetText($"{res}, {pass2}");
        form.SetStatus($"{count} symbols converted. Result is in the clipboard");
        return Task.CompletedTask;
    }
}

public class ShaAction : IDoerAction
{
    private readonly Lazy<SHA1> Sha = new(SHA1.Create());
    private readonly string Message;
    public ShaAction(string mess) => Message = mess;

    public string Name => "SHA160";

    public Task Run(IMainForm form)
    {
        string res = Convert.ToHexString(Sha.Value.ComputeHash(Encoding.UTF8.GetBytes(Message))).ToLowerInvariant();

        Clipboard.SetText($"{res}");
        form.SetStatus($"{Message.Length} symbols converted. Result is in the clipboard");
        return Task.CompletedTask;
    }
}