﻿using System.Diagnostics;

namespace Doer
{
    public sealed class Nconvert : IDisposable
    {
        private readonly List<string> tempFiles = new();
        private const string Nconv = "Nconvert.exe";

        /// <summary>
        /// Converts PNG icon into temporaty Icon icon and returns the temporarty file Name
        /// </summary>
        /// <param name="pngFileName"></param>
        /// <returns></returns>
        public string Png2Icon(string src)
        {
            var dst = TempFile;
            RunConv(src, dst, "-out ico");
            return dst;
        }

        private static void RunConv(string src, string dst, string options)
        {
            if (!File.Exists(src))
                throw new Exception($"File '{src}' doesn't exist when calling Nconvert");

            string args = $"{options} -overwrite -o \"{dst}\" \"{src}\"";  //Overwrite because temp file is created by the system -overwrite 


            ProcessStartInfo psi = new()
            {
                FileName = $@"{Nconv}",
                Arguments = args,
                //WorkingDirectory = ipScannerFile.DirectoryName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };

            string stdOut, stdErr;
            using Process pc = Process.Start(psi) ?? throw new Exception("Process failed to start");
            stdOut = pc.StandardOutput.ReadToEnd();
            stdErr = pc.StandardError.ReadToEnd();
            int exitCode = pc.ExitCode;
            pc.WaitForExit();
            if (pc.ExitCode != 0)
                throw new Exception($"{Nconv} tool returned: {pc.ExitCode}.\r\n{stdErr}");

            if (!File.Exists(dst))
                throw new Exception($"Temp file '{dst}' was not created as a result of {Nconv} run");

            //TODO: forward std output
        }

        private string TempFile
        {
            get
            {
                var res = Path.GetTempFileName();
                tempFiles.Add(res);
                return res;
            }
        }


        public void Dispose()
        {
            foreach (var tempFile in tempFiles)
            {
                try { File.Delete(tempFile);  }
                catch { } //Do nothing
            }
        }
    }
}
