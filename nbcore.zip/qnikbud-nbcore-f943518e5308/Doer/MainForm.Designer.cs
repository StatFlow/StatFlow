﻿namespace Doer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            ToolStripButton btGoogleCal;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            ToolStrip mainTs1;
            ts1IconPicker = new ToolStripButton();
            ts1MinecraftTools = new ToolStripButton();
            ts1Dictophone = new ToolStripButton();
            ts1George = new ToolStripButton();
            ts1Sansa = new ToolStripButton();
            tbGit = new ToolStripButton();
            btn_Key = new ToolStripButton();
            ddVeraMount = new ToolStripDropDownButton();
            toolStripButton1 = new ToolStripButton();
            mainTs2 = new ToolStrip();
            ts2TextBox = new ToolStripTextBox();
            mainTs3 = new ToolStrip();
            statusStrip1 = new StatusStrip();
            sbText = new ToolStripStatusLabel();
            splitContainer1 = new SplitContainer();
            tabControl1 = new TabControl();
            tpActions = new TabPage();
            lvActions = new ListView();
            imageList1 = new ImageList(components);
            tpClipboard = new TabPage();
            lvClipboardContent = new ListView();
            tpCreds = new TabPage();
            lvCreds = new ListView();
            leftTs1 = new ToolStrip();
            tbCredSearch = new ToolStripTextBox();
            webView = new Microsoft.Web.WebView2.WinForms.WebView2();
            rightTs1 = new ToolStrip();
            colorDialog1 = new ColorDialog();
            btGoogleCal = new ToolStripButton();
            mainTs1 = new ToolStrip();
            mainTs1.SuspendLayout();
            mainTs2.SuspendLayout();
            statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            tabControl1.SuspendLayout();
            tpActions.SuspendLayout();
            tpClipboard.SuspendLayout();
            tpCreds.SuspendLayout();
            leftTs1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)webView).BeginInit();
            SuspendLayout();
            // 
            // btGoogleCal
            // 
            btGoogleCal.DisplayStyle = ToolStripItemDisplayStyle.Image;
            btGoogleCal.Image = (Image)resources.GetObject("btGoogleCal.Image");
            btGoogleCal.ImageTransparentColor = Color.Magenta;
            btGoogleCal.Name = "btGoogleCal";
            btGoogleCal.Size = new Size(23, 22);
            btGoogleCal.Text = "toolStripButton3";
            btGoogleCal.Click += BtGoogleCal_Click_1;
            // 
            // mainTs1
            // 
            mainTs1.Items.AddRange(new ToolStripItem[] { ts1IconPicker, ts1MinecraftTools, ts1Dictophone, ts1George, ts1Sansa, tbGit, btn_Key, btGoogleCal, ddVeraMount, toolStripButton1 });
            mainTs1.Location = new Point(0, 0);
            mainTs1.Name = "mainTs1";
            mainTs1.Size = new Size(716, 25);
            mainTs1.TabIndex = 3;
            mainTs1.Text = "ts1";
            // 
            // ts1IconPicker
            // 
            ts1IconPicker.DisplayStyle = ToolStripItemDisplayStyle.Image;
            ts1IconPicker.Image = (Image)resources.GetObject("ts1IconPicker.Image");
            ts1IconPicker.ImageTransparentColor = Color.Magenta;
            ts1IconPicker.Name = "ts1IconPicker";
            ts1IconPicker.Size = new Size(23, 22);
            ts1IconPicker.Text = "IconPicker";
            ts1IconPicker.Click += IconPicker_Click;
            // 
            // ts1MinecraftTools
            // 
            ts1MinecraftTools.DisplayStyle = ToolStripItemDisplayStyle.Image;
            ts1MinecraftTools.Image = (Image)resources.GetObject("ts1MinecraftTools.Image");
            ts1MinecraftTools.ImageTransparentColor = Color.Magenta;
            ts1MinecraftTools.Name = "ts1MinecraftTools";
            ts1MinecraftTools.Size = new Size(23, 22);
            ts1MinecraftTools.Tag = "0";
            ts1MinecraftTools.Text = "TradeCarrots1";
            ts1MinecraftTools.ToolTipText = "Minecraft Tools Window";
            ts1MinecraftTools.Click += TradeCarrots_Click;
            // 
            // ts1Dictophone
            // 
            ts1Dictophone.DisplayStyle = ToolStripItemDisplayStyle.Image;
            ts1Dictophone.Image = (Image)resources.GetObject("ts1Dictophone.Image");
            ts1Dictophone.ImageTransparentColor = Color.Magenta;
            ts1Dictophone.Name = "ts1Dictophone";
            ts1Dictophone.Size = new Size(23, 22);
            ts1Dictophone.Text = "Dictophone";
            ts1Dictophone.ToolTipText = "Download files from Dictophone";
            ts1Dictophone.Click += Dictophone_Click;
            // 
            // ts1George
            // 
            ts1George.DisplayStyle = ToolStripItemDisplayStyle.Image;
            ts1George.Image = (Image)resources.GetObject("ts1George.Image");
            ts1George.ImageTransparentColor = Color.Magenta;
            ts1George.Name = "ts1George";
            ts1George.Size = new Size(23, 22);
            ts1George.Text = "btGeorge";
            ts1George.ToolTipText = "George Tools";
            ts1George.Click += GeorgeTest_Click;
            // 
            // ts1Sansa
            // 
            ts1Sansa.DisplayStyle = ToolStripItemDisplayStyle.Image;
            ts1Sansa.Image = (Image)resources.GetObject("ts1Sansa.Image");
            ts1Sansa.ImageTransparentColor = Color.Magenta;
            ts1Sansa.Name = "ts1Sansa";
            ts1Sansa.Size = new Size(23, 22);
            ts1Sansa.Text = "Sandisk Sansa logic";
            ts1Sansa.ToolTipText = "Sandisk Sansa Tools";
            ts1Sansa.Click += Sansa_Click;
            // 
            // tbGit
            // 
            tbGit.DisplayStyle = ToolStripItemDisplayStyle.Image;
            tbGit.Image = (Image)resources.GetObject("tbGit.Image");
            tbGit.ImageTransparentColor = Color.Magenta;
            tbGit.Name = "tbGit";
            tbGit.Size = new Size(23, 22);
            tbGit.Text = "Git";
            tbGit.ToolTipText = "Check that all Git repos are committed";
            tbGit.Click += TbGit_Click;
            // 
            // btn_Key
            // 
            btn_Key.Image = (Image)resources.GetObject("btn_Key.Image");
            btn_Key.ImageTransparentColor = Color.Magenta;
            btn_Key.Name = "btn_Key";
            btn_Key.Size = new Size(54, 22);
            btn_Key.Text = "Press";
            btn_Key.ToolTipText = "Key Press tool";
            btn_Key.Click += ToolStripButton3_Click;
            // 
            // ddVeraMount
            // 
            ddVeraMount.DisplayStyle = ToolStripItemDisplayStyle.Image;
            ddVeraMount.Image = (Image)resources.GetObject("ddVeraMount.Image");
            ddVeraMount.ImageTransparentColor = Color.Magenta;
            ddVeraMount.Name = "ddVeraMount";
            ddVeraMount.Size = new Size(29, 22);
            ddVeraMount.Text = "toolStripDropDownButton1";
            ddVeraMount.DropDownOpening += DdVeraMount_DropDownOpening;
            ddVeraMount.DropDownItemClicked += DdVeraMount_DropDownItemClicked;
            // 
            // toolStripButton1
            // 
            toolStripButton1.DisplayStyle = ToolStripItemDisplayStyle.Image;
            toolStripButton1.Image = (Image)resources.GetObject("toolStripButton1.Image");
            toolStripButton1.ImageTransparentColor = Color.Magenta;
            toolStripButton1.Name = "toolStripButton1";
            toolStripButton1.Size = new Size(23, 22);
            toolStripButton1.Text = "toolStripButton1";
            // 
            // mainTs2
            // 
            mainTs2.Items.AddRange(new ToolStripItem[] { ts2TextBox });
            mainTs2.Location = new Point(0, 50);
            mainTs2.Name = "mainTs2";
            mainTs2.Size = new Size(716, 25);
            mainTs2.TabIndex = 0;
            mainTs2.TabStop = true;
            mainTs2.Text = "ts2";
            // 
            // ts2TextBox
            // 
            ts2TextBox.MaxLength = 1000;
            ts2TextBox.Name = "ts2TextBox";
            ts2TextBox.Size = new Size(200, 25);
            ts2TextBox.KeyDown += Ts2TextBox_KeyDown;
            // 
            // mainTs3
            // 
            mainTs3.Location = new Point(0, 25);
            mainTs3.Name = "mainTs3";
            mainTs3.Size = new Size(716, 25);
            mainTs3.TabIndex = 4;
            mainTs3.Text = "Installed programs";
            // 
            // statusStrip1
            // 
            statusStrip1.Items.AddRange(new ToolStripItem[] { sbText });
            statusStrip1.Location = new Point(0, 538);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Padding = new Padding(1, 0, 16, 0);
            statusStrip1.Size = new Size(716, 22);
            statusStrip1.TabIndex = 4;
            statusStrip1.Text = "statusStrip1";
            // 
            // sbText
            // 
            sbText.Name = "sbText";
            sbText.Size = new Size(59, 17);
            sbText.Text = "Loading...";
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(0, 75);
            splitContainer1.Margin = new Padding(4, 3, 4, 3);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(webView);
            splitContainer1.Panel2.Controls.Add(rightTs1);
            splitContainer1.Size = new Size(716, 463);
            splitContainer1.SplitterDistance = 237;
            splitContainer1.SplitterWidth = 5;
            splitContainer1.TabIndex = 3;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tpActions);
            tabControl1.Controls.Add(tpClipboard);
            tabControl1.Controls.Add(tpCreds);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(4, 3, 4, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.Padding = new Point(0, 0);
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(237, 463);
            tabControl1.TabIndex = 0;
            tabControl1.TabStop = false;
            // 
            // tpActions
            // 
            tpActions.Controls.Add(lvActions);
            tpActions.Location = new Point(4, 24);
            tpActions.Margin = new Padding(4, 3, 4, 3);
            tpActions.Name = "tpActions";
            tpActions.Padding = new Padding(4, 3, 4, 3);
            tpActions.Size = new Size(229, 435);
            tpActions.TabIndex = 9;
            tpActions.Text = "Actions";
            tpActions.UseVisualStyleBackColor = true;
            // 
            // lvActions
            // 
            lvActions.AllowDrop = true;
            lvActions.Dock = DockStyle.Fill;
            lvActions.Location = new Point(4, 3);
            lvActions.Margin = new Padding(4, 3, 4, 3);
            lvActions.Name = "lvActions";
            lvActions.Size = new Size(221, 429);
            lvActions.SmallImageList = imageList1;
            lvActions.TabIndex = 1;
            lvActions.UseCompatibleStateImageBehavior = false;
            lvActions.View = View.List;
            lvActions.DragDrop += LvActions_DragDrop;
            lvActions.DragEnter += LvActions_DragEnter;
            lvActions.DragOver += LvActions_DragOver;
            lvActions.DragLeave += LvActions_DragLeave;
            lvActions.KeyUp += LvActions_KeyUp;
            lvActions.MouseDoubleClick += LvActions_MouseDoubleClick;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // tpClipboard
            // 
            tpClipboard.Controls.Add(lvClipboardContent);
            tpClipboard.Location = new Point(4, 24);
            tpClipboard.Margin = new Padding(4, 3, 4, 3);
            tpClipboard.Name = "tpClipboard";
            tpClipboard.Padding = new Padding(4, 3, 4, 3);
            tpClipboard.Size = new Size(229, 435);
            tpClipboard.TabIndex = 1;
            tpClipboard.Text = "Clipboard";
            tpClipboard.UseVisualStyleBackColor = true;
            // 
            // lvClipboardContent
            // 
            lvClipboardContent.AllowDrop = true;
            lvClipboardContent.Dock = DockStyle.Fill;
            lvClipboardContent.LabelEdit = true;
            lvClipboardContent.Location = new Point(4, 3);
            lvClipboardContent.Margin = new Padding(4, 3, 4, 3);
            lvClipboardContent.MultiSelect = false;
            lvClipboardContent.Name = "lvClipboardContent";
            lvClipboardContent.Size = new Size(221, 429);
            lvClipboardContent.TabIndex = 11;
            lvClipboardContent.UseCompatibleStateImageBehavior = false;
            lvClipboardContent.View = View.List;
            lvClipboardContent.SelectedIndexChanged += LvClipboardContent_SelectedIndexChanged;
            lvClipboardContent.DragDrop += LvContent_DragDrop;
            lvClipboardContent.DragOver += LvContent_DragOver;
            // 
            // tpCreds
            // 
            tpCreds.Controls.Add(lvCreds);
            tpCreds.Controls.Add(leftTs1);
            tpCreds.Location = new Point(4, 24);
            tpCreds.Margin = new Padding(4, 3, 4, 3);
            tpCreds.Name = "tpCreds";
            tpCreds.Padding = new Padding(4, 3, 4, 3);
            tpCreds.Size = new Size(229, 435);
            tpCreds.TabIndex = 12;
            tpCreds.Text = "Cred";
            tpCreds.UseVisualStyleBackColor = true;
            // 
            // lvCreds
            // 
            lvCreds.Dock = DockStyle.Fill;
            lvCreds.Location = new Point(4, 28);
            lvCreds.Margin = new Padding(4, 3, 4, 3);
            lvCreds.Name = "lvCreds";
            lvCreds.Size = new Size(221, 404);
            lvCreds.TabIndex = 13;
            lvCreds.UseCompatibleStateImageBehavior = false;
            lvCreds.View = View.List;
            lvCreds.MouseDoubleClick += LvCreds_MouseDoubleClick;
            // 
            // leftTs1
            // 
            leftTs1.Items.AddRange(new ToolStripItem[] { tbCredSearch });
            leftTs1.Location = new Point(4, 3);
            leftTs1.Name = "leftTs1";
            leftTs1.Size = new Size(221, 25);
            leftTs1.TabIndex = 14;
            leftTs1.Text = "toolStrip2";
            // 
            // tbCredSearch
            // 
            tbCredSearch.Name = "tbCredSearch";
            tbCredSearch.Size = new Size(116, 25);
            // 
            // webView
            // 
            webView.AllowExternalDrop = false;
            webView.CreationProperties = null;
            webView.DefaultBackgroundColor = Color.Silver;
            webView.Dock = DockStyle.Fill;
            webView.Location = new Point(0, 25);
            webView.Name = "webView";
            webView.Size = new Size(474, 438);
            webView.TabIndex = 17;
            webView.ZoomFactor = 1D;
            // 
            // rightTs1
            // 
            rightTs1.Location = new Point(0, 0);
            rightTs1.Name = "rightTs1";
            rightTs1.Size = new Size(474, 25);
            rightTs1.TabIndex = 16;
            rightTs1.Text = "toolStrip1";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(716, 560);
            Controls.Add(splitContainer1);
            Controls.Add(mainTs2);
            Controls.Add(mainTs3);
            Controls.Add(statusStrip1);
            Controls.Add(mainTs1);
            HelpButton = true;
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            Name = "MainForm";
            Text = "Doer";
            TopMost = true;
            FormClosing += MainForm_FormClosing;
            FormClosed += MainForm_FormClosed;
            Load += MainForm_Load;
            KeyDown += MainForm_KeyDown;
            mainTs1.ResumeLayout(false);
            mainTs1.PerformLayout();
            mainTs2.ResumeLayout(false);
            mainTs2.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            tabControl1.ResumeLayout(false);
            tpActions.ResumeLayout(false);
            tpClipboard.ResumeLayout(false);
            tpCreds.ResumeLayout(false);
            tpCreds.PerformLayout();
            leftTs1.ResumeLayout(false);
            leftTs1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)webView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolStrip mainTs2;
        private System.Windows.Forms.ToolStrip mainTs3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel sbText;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView lvActions;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ToolStripButton ts1MinecraftTools;
        private System.Windows.Forms.ToolStripButton ts1Dictophone;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpActions;
        private System.Windows.Forms.TabPage tpClipboard;
        private System.Windows.Forms.ListView lvClipboardContent;
        private System.Windows.Forms.ToolStripButton ts1IconPicker;
        private System.Windows.Forms.ToolStripButton ts1George;
        private System.Windows.Forms.ToolStripButton ts1Sansa;
        private System.Windows.Forms.ToolStripButton tbGit;
        private System.Windows.Forms.ToolStripButton btn_Key;
        private System.Windows.Forms.TabPage tpCreds;
        private System.Windows.Forms.ListView lvCreds;
        private System.Windows.Forms.ToolStrip leftTs1;
        private System.Windows.Forms.ToolStripTextBox tbCredSearch;
        private System.Windows.Forms.ToolStripDropDownButton ddVeraMount;
        private System.Windows.Forms.ToolStrip rightTs1;
        private System.Windows.Forms.ToolStripTextBox ts2TextBox;
        private System.Windows.Forms.ToolStrip rightTs2;
        private ToolStripButton toolStripButton1;
        private Microsoft.Web.WebView2.WinForms.WebView2 webView;
        private ColorDialog colorDialog1;
    }
}

