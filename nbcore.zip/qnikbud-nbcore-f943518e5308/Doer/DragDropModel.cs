﻿using Doer.Logic;

namespace Doer;

class DragDropModel : IDisposable
{
    private DoerConfV1.Xml.DoerConfV1? _conf;
    private DoerConfV1.Xml.DoerConfV1 Conf => _conf ?? throw new Exception("Configuration was not initialised");

    public static IEnumerable<(string key, string text, string imageKey)> ClipBoardUpdated() { yield return ("Key", "Text", "image"); }

    internal void Init(DoerConfV1.Xml.DoerConfV1 conf)
    {
        _conf = conf;
    }

    internal void OnDataObjectUpdate(ListView.ListViewItemCollection items, IDataObject? dataObjN) //Called from WindProc
    {
        //items.Clear(); Cleared in the caller
        if (dataObjN == null)
            return;

        var list = CreateActions(dataObjN).SelectNotNull(a => new ListViewItem(a.Name) { Tag = a }).ToArray();
        items.AddRange(list);
    }

    public IEnumerable<IDoerAction?> CreateActions(IDataObject dataObjN)
    {
        try
        {
            if (dataObjN is null)
                return Enumerable.Empty<IDoerAction?>();
            var formats = dataObjN.GetFormats();

            if (dataObjN.TryGetFileNames(out var fileDescs))
                return ProcessFileDirList(fileDescs);
            if (dataObjN.TryGetText(out var txt))
            {
                var trunc = txt.Trim();
                if (trunc.StartsWith("http", StringComparison.InvariantCultureIgnoreCase) &&
                    Uri.TryCreate(trunc, UriKind.Absolute, out var uri))
                {
                    return ProcessUrl(uri);
                }
                else
                    return ProcessText(txt);
            }
        }
        catch (Exception ex) { MessageBox.Show(NbException.Exception2String(ex)); }

        return Enumerable.Empty<IDoerAction>(); //Not to make this method enumerator
    }

    private static IEnumerable<IDoerAction> ProcessUrl(Uri uri) //Non-Url
    {
        switch (uri.Host)
        {
            case "www.youtube.com":
                if (uri.AbsolutePath != "/feeds/videos.xml") //Skip if this is already an rss link
                    yield return new YoutubeRss(uri);
                break;
            default:
                yield return new MessageAction($"URL detected:\r\n{uri.AbsoluteUri}");
                break;
        }
    }

    private static IEnumerable<IDoerAction> ProcessText(string txt) //Non-Url
    {
        yield return new ShaAction(txt);
        yield return new ContPassAction(txt);
        yield return new MessageAction($"Clipboard contained text:\r\n{txt}");
    }

    public IEnumerable<IDoerAction?> ProcessFileDirList(IList<string> filesAndDirs)
    {
        var files = filesAndDirs.Where(File.Exists).ToArray();
        var dirs = filesAndDirs.Where(Directory.Exists).ToArray();

        if (files.Length == 0 && dirs.Length == 0)
            throw new Exception($"Neither files nor dirs exist: " + String.Join(", ", filesAndDirs));

        if (dirs.Length == 0)
        { //Just dirs
            if (files.Length == 1)
                return ProcessSingleFile(new FileInfo(files[0]));
            else
                return ProcessManyFiles(files.Select(f => new FileInfo(f)).ToList());
        }
        else if (files.Length == 0)
        {
            if (dirs.Length == 1)
                return ProcessSingleDir(new DirectoryInfo(dirs[0]));
            else
                throw new Exception($"Multibple dirs are not supported");
        }
        else
            throw new Exception($"Mixture of files and dirs is not supported");
    }

    private IEnumerable<IDoerAction?> ProcessManyFiles(IList<FileInfo> fis)
    {
        List<NbMedia.FileMediaTypes> types = fis.Select(f => NbMedia.GetFileMediaType(f.Extension)).Distinct().ToList();
        if (types.Count == 1)
        {
            if (types[0] == NbMedia.FileMediaTypes.Video)
                return ProcessVideoFiles(fis);
        }
        return Enumerable.Empty<IDoerAction?>();
    }

    private IEnumerable<IDoerAction?> ProcessVideoFiles(IList<FileInfo> fis)
    {
        yield return new VideoConcat(fis, Conf.settings.ffmpeg);
    }

    public static IEnumerable<IDoerAction?> ProcessSingleDir(DirectoryInfo di)
    {
        var dirs = di.GetDirectories();
        if (dirs.Any())
        {
            yield return new RemoveEmptyDirs(di);
        }

        var files = di.GetFiles();
        var extensions = new HashSet<string>(files.Select(f => f.Extension.ToLowerInvariant()));
        var mediaTypes = new HashSet<NbMedia.FileMediaTypes>(extensions.Select(e => NbMedia.GetFileMediaType(e)));

        if (files.Length > 0)
        {
            yield return new FileToDatedFoldersAction(files);
            yield return new FilesChangeExtensions(files);
            yield return new FilesGroupByNumber(files);
        }

        if (mediaTypes.Contains(NbMedia.FileMediaTypes.Photo))
        {
            yield return new JpegResizeAction50(di);
            yield return new JpegResizeAction33(di);
            yield return new JpegResizeAction25(di);
        }

        yield return ActionMp4Chapters.Create(files);
    }

    public IEnumerable<IDoerAction> ProcessSingleFile(FileInfo fi)
    {
        var mediaType = NbMedia.GetFileMediaType(fi.Extension);

        switch (mediaType)
        {
            case NbMedia.FileMediaTypes.Video:
                yield return new VideoKeyFrames(fi, Conf.settings.ffmpeg);
                yield return new VideoCut(fi, Conf.settings.ffmpeg);
                break;

            case NbMedia.FileMediaTypes.Photo:
                yield return new Image2Base64(fi);
                break;

            default:
                yield break;
        }
    }

    /*private string ConvertPayload(IDataObject dataObj, string format)
    {

        switch (format)
        {
            case "FileGroupDescriptor":
                var a = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORA>((MemoryStream)dataObj.GetData("FileGroupDescriptor")).ToList();
                return "'" + String.Join("', '", a.Select(d => d.cFileName)) + "'";

            case "FileGroupDescriptorW":
                var a1 = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORW>((MemoryStream)dataObj.GetData("FileGroupDescriptorW")).ToList();
                return "'" + String.Join("', '", a1.Select(d => d.cFileName)) + "'";

            /*case "FileContents":
                //TODO: show image on the screen without saving it to the disk
                OutlookDataObject odo = new OutlookDataObject(dataObj);
                using (MemoryStream ms = (MemoryStream)odo.GetData("FileContents", 0))
                {
                    using (var fileStream = new FileStream(@"c:\Temp\tempfile.png", FileMode.Create))
                    {
                        ms.WriteTo(fileStream);
                    }
                }
                return @"Saved to c:\Temp\tempfile.png";*/

    /*case "application/x-moz-nativeimage":
    case "MetaFilePict": //Selection from paint
    case "DeviceIndependentBitmap": //Selection from paint
        return "Ignored";

    default:
        break;
}

object obj = dataObj.GetData(format);
switch (obj.GetType().Name)
{
    case "String":
        return obj as String;

    case "String[]":
        string[] strs = obj as String[];
        return "'" + String.Join("', '", strs) + "'";

    case "MemoryStream":
        using (StreamReader sr = new StreamReader(obj as MemoryStream, Encoding.Unicode))
        {
            string mess = sr.ReadToEnd().Replace("\0", " ");
            return mess;
        }

    default:
        return "Unsupported DropObject Type: " + obj.GetType().Name;
}
}

internal void ReleaseAwareServer()
{
const string srcRootDir = @"C:\Repo\Aware\AwareServer\bin\Release\netcoreapp3.0";
const string dstRootDir = @"\\K325\Shared\Aware";

string[] extensions = new[] { ".json", ".exe", ".dll" };

if (!Directory.Exists(dstRootDir))
    throw new Exception($"Shared directory '{dstRootDir}' doesn't exist");

string dstDir = Path.Combine(dstRootDir, "AwareServer." + DateTime.Now.ToString("yyMMdd.HHmmss"));
Directory.CreateDirectory(dstDir);

foreach(var fl in new DirectoryInfo(srcRootDir).GetFiles())
{
    if (extensions.Contains(Path.GetExtension(fl.Name)))
        File.Copy(fl.FullName, Path.Combine(dstDir, fl.Name));
}

new[] { @"runtimes\win", @"runtimes\win-x86" }.ForEachSafe(d => NbDir.CopyDir(Path.Combine(srcRootDir, d), Path.Combine(dstDir, d)));

const string projectRoot = @"C:\Repo\Aware\AwareServer";
new[] { @"wwwroot\lib\signalr\dist\browser", @"wwwroot\js", @"wwwroot\css" }.ForEachSafe(d => NbDir.CopyDir(Path.Combine(projectRoot, d), Path.Combine(dstDir, d)));
}*/

    public void Dispose()
    {
        //throw new NotImplementedException();
    }
}

public interface IMainForm
{
    void MessageInfo(string Message);
    void SetStatus(string Message);
    void CloseForm();
    DialogResult Dialog(string Message, MessageBoxButtons btns);
}

public interface IDoerAction
{
    string Name { get; }
    Task Run(IMainForm form);
}
