﻿using System.Data;
using System.Text;
using System.Security.Cryptography;
using Wf = System.Windows.Forms;

using NbWpfLib;
using Doer.Logic;
using DoerConfV1.Xml;
using NbCore.Crypto;
using System.Diagnostics;
using System.Windows.Interop;
using Microsoft.Web.WebView2.Core;
using Doer.Properties;

namespace Doer
{
    public partial class MainForm : Form, IMainForm
    {
        private DoerConfV1.Xml.DoerConfV1? _conf;
        private DoerConfV1.Xml.DoerConfV1 Conf => _conf ?? throw new Exception("DoerConfV1 is not initialized");

        private readonly DragDropModel ModelDd;
        private readonly ToolbarsModel ModelTb;

        private readonly Wf.Timer StatusTimer;
        private readonly Wf.Timer SearchTimer;

        private readonly Cred CredManager;
        private readonly Action? ClosingAction;
        private readonly Dictionary<Keys, ToolStripItem> ShortCuts = new();

        public MainForm(Action act) : this()
        {
            ClosingAction = act;
        }

        public MainForm()
        {
            InitializeComponent();

            StatusTimer = new() { Interval = 5000 };//5 sec
            StatusTimer.Tick += (object? _, EventArgs _) =>
            {
                sbText.Text = null;
                StatusTimer.Stop();
            };

            SearchTimer = new() { Interval = 500 };//0.5 sec
            SearchTimer.Tick += (object? _, EventArgs _) =>
            {
                RedrawActionsList(ts2TextBox.Text);
                SearchTimer.Stop();
            };

            ModelDd = new DragDropModel();
            ModelTb = new ToolbarsModel(this);
            NativeMethods.AddClipboardFormatListener(Handle);
            CredManager = new Cred(lvCreds);

            Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
        }

        private void ShowDialog(string header, string exMessage) => MessageBox.Show(this, exMessage, header, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        private void Application_ThreadException(object? sender, ThreadExceptionEventArgs e) => ShowDialog(sender?.ToString() ?? "Doer", NbException.Exception2String(e.Exception));
        private void CurrentDomain_UnhandledException(object? sender, UnhandledExceptionEventArgs e) => ShowDialog($"Unhandled Exception from {sender}", e.ExceptionObject?.ToString() ?? "Unknown exception");


        private void WebView21_CoreWebView2InitializationCompleted(object? sender, CoreWebView2InitializationCompletedEventArgs e)
        {
        }

        //async
        private void MainForm_Load(object sender, EventArgs e)
        {
            webView.CoreWebView2InitializationCompleted += WebView21_CoreWebView2InitializationCompleted;
            webView.EnsureCoreWebView2Async(null);

            string confFileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Conf\DoerConf.xml");
            _conf = DoerConfV1.Xml.DoerConfV1.LoadFile(confFileName);
            ModelDd.Init(Conf);
            ModelTb.Init(Conf);
            RedrawContentList(Clipboard.GetDataObject());
            CredManager.PopulateList();

            const int margin = -5;
            if (Screen.PrimaryScreen is Screen scr)
            {
                int x = scr.WorkingArea.Right - Width - margin;
                int y = scr.WorkingArea.Bottom - Height - margin;
                Location = new Point(x, y);
            }
            else
                Location = new Point(10, 10);

            Version ver = typeof(MainForm).Assembly.GetName().Version ?? throw new Exception("Assembly doesn't have version");
            Text = $"Doer {ver.Major}.{ver.Minor}.{ver.Build}";
            sbText.Text = String.Empty;

            //Build toolbars
            CreateToolbarButtons(Conf.toolbar_search, mainTs2);
            CreateToolbarButtons(Conf.toolbar_links, mainTs3);
            Activate();
        }

        private readonly Keys[] bannedKeys = { Keys.C, Keys.V, Keys.Z, Keys.X };
        private void AddShortcut(string letterN, ToolStripItem btnOrMenu)
        {
            if (String.IsNullOrWhiteSpace(letterN))
                return;
            if (letterN.Length != 1)
                throw new Exception("Only 1 letter is allowed in shortcut field");

            Keys key = Enum.Parse<Keys>(letterN.ToUpperInvariant());
            if (bannedKeys.Contains(key))
                throw new Exception($"Keys {String.Join(", ", bannedKeys)} are used by clipboard and not allowed");

            if (ShortCuts.TryGetValue(key, out var existing))
                throw new Exception($"Two buttons try to use the same shortcut '{key}': {existing.Name} and {btnOrMenu.Name}");

            ShortCuts.Add(key, btnOrMenu);
        }

        private void CreateToolbarButtons(IEnumerable<ToolbarItem> butDescs, ToolStrip ts)
        {
            foreach (var btnBaseDesc in butDescs.Safe())
            {
                try
                {
                    if (btnBaseDesc is ToolbButton btnDesc)
                    {
                        //System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
                        var btn = new ToolStripButton
                        {
                            DisplayStyle = ToolStripItemDisplayStyle.Image,
                            Image = btnDesc.IconObj,
                            ImageTransparentColor = Color.Transparent,
                            Name = btnDesc.tooltip,
                            Size = new Size(23, 22),
                            Tag = btnDesc,
                            ToolTipText = btnDesc.tooltip + (!String.IsNullOrWhiteSpace(btnDesc.shortcut) ? $" (Ctrl-{btnDesc.shortcut.ToUpperInvariant()})" : String.Empty),
                        };
                        btn.Click += GenericButton_Click;
                        ts.Items.Add(btn); //AddRange
                        AddShortcut(btnDesc.shortcut, btn);
                    }
                    else if (btnBaseDesc is DropDownButton ddBtnDesc) //Contains sum-buttons
                    {
                        ToolStripMenuItem[] menu = ddBtnDesc.btn.Safe().Select(i =>
                        {
                            ToolStripMenuItem menuItem = new()
                            {
                                Name = i.tooltip,
                                Image = btnBaseDesc.IconObj, //TODO: process menu specific icon
                                Tag = i,
                                Size = new Size(180, 22),
                                Text = i.tooltip,
                                ToolTipText = i.tooltip,
                            };
                            menuItem.Click += GenericButton_Click;
                            AddShortcut(i.shortcut, menuItem);
                            return menuItem;
                        }).ToArray();

                        ToolStripDropDownButton ts3DropDown = new()
                        {
                            DisplayStyle = ToolStripItemDisplayStyle.Image,
                            Image = btnBaseDesc.IconObj,
                            ImageTransparentColor = Color.Transparent,
                            Name = ddBtnDesc.tooltip,
                            Size = new Size(29, 22),
                            ToolTipText = "DropDownButton",
                        };
                        ts3DropDown.DropDownItems.AddRange(menu);
                        //ts3DropDown.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {this.sdfToolStripMenuItem});

                        ts3DropDown.Click += GenericButton_Click;
                        ts.Items.Add(ts3DropDown); //AddRange
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, $"Can't add toolbar button '{btnBaseDesc}' from config: {NbException.Exception2String(ex)}", "Error processing config", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private async void GenericButton_Click(object? sender, EventArgs e)
        {
            try
            {
                await ModelTb.GenericButton(sender, ts2TextBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, NbException.Exception2String(ex), "Error performing an action", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private async void LvCreds_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ListViewItem? item = WinFormsHelpers.ListViewItemByXyN(lvCreds, e.X, e.Y);
            if (item != null)
                await CredManager.Invoke(item.Text);
        }

        //[System.Security.Permissions.PermissionSet(System.Security.Permissions.SecurityAction.Demand, Name = "FullTrust")]
        protected override void WndProc(ref Message m)  //Async can't have ref out paraters
        {
            switch (m.Msg)
            {
                case NativeMethods.WM_CLIPBOARDUPDATE:
                    lvActions.SuspendLayout();
                    lvActions.Items.Clear();
                    var dObj = Clipboard.GetDataObject();
                    RedrawContentList(dObj);
                    ModelDd.OnDataObjectUpdate(lvActions.Items, dObj);
                    lvActions.ResumeLayout();
                    break;
            }
            base.WndProc(ref m);
        }

        /*protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if ((uint)msg.WParam == 0x5d) //WM_KEYDOWN  //&& (uint)m.WParam == 0x5d
            {
                Debug.WriteLine("ProcessCmdKey captured" + msg.ToString());
                return true;
            }

            Debug.WriteLine("ProcessCmdKey " + msg.ToString() + " " + keyData);
            return base.ProcessCmdKey(ref msg, keyData);
        }


        protected override void DefWndProc(ref Message m)
        {
            Debug.WriteLine("DefWndProc " + m.ToString());
            base.DefWndProc(ref m);
        }

        public override bool PreProcessMessage(ref Message msg)
        {
            Debug.WriteLine("PreProcessMessage " + msg.ToString());
            return base.PreProcessMessage(ref msg);
        }

        protected override bool ProcessKeyMessage(ref Message m)
        {
            Debug.WriteLine("ProcessKeyMessage " + m.ToString());
            return base.ProcessKeyMessage(ref m);
        }

        protected override bool ProcessKeyPreview(ref Message m)
        {
            //msg = 0x100(WM_KEYDOWN) hwnd = 0xe0496 wparam = 0x5d lparam = 0x15d0001 result = 0x0
            //msg = 0x101(WM_KEYUP) hwnd = 0xe0496 wparam = 0x5d lparam = 0xc15d0001 result = 0x0
            if ((m.Msg == 0x100 || m.Msg == 0x101) && (uint)m.WParam == 0x5d) //WM_KEYDOWN  //&& (uint)m.WParam == 0x5d
            {
                Debug.WriteLine("ProcessKeyPreview Captured" + m.ToString());
                return true;
            }

            Debug.WriteLine("ProcessKeyPreview " + m.ToString());
            return base.ProcessKeyPreview(ref m);
        }*/


        private void RedrawActionsList(string searchText)
        {
            if (InvokeRequired)
                Invoke(RedrawActionsList, searchText);

            lvActions.SuspendLayout();
            lvActions.Items.Clear();
            if (!String.IsNullOrWhiteSpace(searchText))
                ModelTb.OnSearchTextUpdate(lvActions.Items, searchText);

            if (lvActions.SelectedItems.Count == 0 && lvActions.Items.Count > 0)
                lvActions.Items[0].Selected = true;

            lvActions.ResumeLayout();
        }


        private void RedrawContentList(IDataObject? dataObj)
        {
            lvClipboardContent.SuspendLayout();
            lvClipboardContent.Items.Clear();
            if (dataObj != null)
                lvClipboardContent.Items.AddRange(dataObj.GetFormats().Select(f => new ListViewItem(f)).ToArray());

            lvClipboardContent.ResumeLayout();
        }

        private void LvContent_DragDrop(object _, DragEventArgs e) => RedrawContentList(e.Data);
        private void LvContent_DragOver(object _, DragEventArgs e) => e.Effect = DragDropEffects.All;

        private async void TradeCarrots_Click(object sender, EventArgs e)
        {
            using MinecraftForm mf = new();
            await mf.ShowAsync(this);
        }

        private async void Dictophone_Click(object sender, EventArgs e)
        {
            try
            {
                var drv = DriveInfo.GetDrives().Where(d => d.IsReady).FirstOrDefault(d => d.VolumeLabel == "DICT") ?? throw new Exception("Can't find dictophone drive with volume label DICT");

                string dstPath = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
                var dstDir = new DirectoryInfo(Path.Combine(dstPath, "Dictophone", DateTime.Now.ToString("yyyyMMdd-HHmmss")));
                NbFs.CreateDirRecursive(dstDir);

                var srcDir = new DirectoryInfo(Path.Combine(drv.RootDirectory.FullName, "RECORD", "VOICE"));
                if (!srcDir.Exists)
                    throw new Exception($"Can't find dictophone recordings directory '{srcDir.FullName}'");

                int count = 0;
                foreach (var f in srcDir.GetFiles())
                {
                    File.Move(f.FullName, Path.Combine(dstDir.FullName, f.Name));
                    count++;
                }
                MessageBox.Show(this, $"{count} files were copied", "Dictophone copying", MessageBoxButtons.OK, MessageBoxIcon.Information);
                await NbProcess.Explorer(dstDir);
            }
            catch (NbExceptionCmdLine ex)
            {
                MessageBox.Show(this, ex.Message, "Dictophone copying", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, NbException.Exception2String(ex), "Dictophone copying", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public delegate DialogResult DoDialog(Wf.IWin32Window wnd, string Message, MessageBoxButtons btns);
        private static readonly DoDialog DlgDelegate = (Wind, Message, btns) => MessageBox.Show(Wind, Message, "Doer", btns, MessageBoxIcon.Information);

        public DialogResult Dialog(string Message, MessageBoxButtons btns)
        {
            if (InvokeRequired)
                return (DialogResult) Invoke(DlgDelegate, this, Message, btns);
            else
                return DlgDelegate(this, Message, btns);
        }
        public void MessageInfo(string Message) => MessageBox.Show(this, Message, "Doer", MessageBoxButtons.OK, MessageBoxIcon.Information);

        public void SetStatus(string Message)
        {
            sbText.Text = Message;
            StatusTimer.Start();
        }

        public void CloseForm()
        {
            if (ClosingAction != null) //Close if called from the tray icon
                Close();
        }

        private void GeorgeTest_Click(object sender, EventArgs e) => Dialog<GeorgeTest.GeorgeTest>();
        private void Sansa_Click(object sender, EventArgs e) => Dialog<Sansa>();
        private void IconPicker_Click(object sender, EventArgs e) => Dialog<IconPicker.Form1>();
        private void ToolStripButton3_Click(object sender, EventArgs e) => Dialog<Key>();
        private void BtGoogleCal_Click_1(object sender, EventArgs e) { /*Dialog<GoogleCalAdd>();*/} //TODO call separate application

        private void Dialog<F>() where F : Form, new()
        {
            using F form = new();
            form.ShowDialog(this);
        }

        private void LvActions_DragOver(object sender, DragEventArgs e)
        {
            Point targetPoint = lvActions.PointToClient(new Point(e.X, e.Y)); // Retrieve the client coordinates of the drop location.
            var targetNodeN = lvActions.GetItemAt(targetPoint.X, targetPoint.Y); // Retrieve the node at the drop location.
            if (targetNodeN == null)
                return;

            lvActions.SelectedItems.Clear();
            targetNodeN.Selected = true;
        }

        private async void LvActions_DragDrop(object sender, DragEventArgs e)
        {
            //Detect which entry it is falling on
            Point targetPoint = lvActions.PointToClient(new Point(e.X, e.Y)); // Retrieve the client coordinates of the drop location.
            var targetNodeN = lvActions.GetItemAt(targetPoint.X, targetPoint.Y); // Retrieve the node at the drop location.
            if (targetNodeN == null)
                return;

            if (targetNodeN.Tag is IDoerAction act)
            {
                await act.Run(this);
                lvClipboardContent.Items.Clear(); //Clear the list
                ModelDd.OnDataObjectUpdate(lvActions.Items, null);
            }
        }

        private void LvActions_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.All;

            lvActions.Items.Clear();
            RedrawContentList(e.Data);
            ModelDd.OnDataObjectUpdate(lvActions.Items, e.Data);
        }

        private void LvActions_DragLeave(object sender, EventArgs e)
        {
            lvActions.Items.Clear();
            lvClipboardContent.Items.Clear();
        }

        private const string RepoRoot = @"C:\Repo";
        private const string GitExt = @"C:\Program Files (x86)\GitExtensions\GitExtensions.exe";

        private async void TbGit_Click(object sender, EventArgs e)
        {
            try
            {
                SetStatus("Scanning git directories in " + RepoRoot);

                int count = 0;
                foreach (var dir in new DirectoryInfo(RepoRoot).GetDirectories())
                {
                    if (!dir.GetFileSystemInfos().Any(d => d.Name == ".git")) //Dirs or Files
                        continue;

                    var (exitCode, stdOut, errOut) = await NbProcess.RunAsync("git", dir, "status", "--porcelain");
                    if (exitCode != 0)
                        throw new Exception($"git status failed with {exitCode}\r\n" + errOut);

                    count++;
                    if (String.IsNullOrWhiteSpace(stdOut)) //No files to commit
                        continue;

                    var (exitCode1, _, errOut1) = await NbProcess.RunAsync(GitExt, dir, "commit");
                    if (exitCode1 != 0)
                        throw new Exception($"git status failed with {exitCode}\r\n" + errOut1);

                    var archBat = Path.Combine(dir.FullName, "arch.bat");
                    if (File.Exists(archBat))
                        var (exitCode2, _, _) = await NbProcess.RunAsync(archBat, dir, dir.FullName);

                }
                SetStatus($"Finished scanning {count} git directories");
                if (ClosingAction != null) //Close if called from the tray icon
                    Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                SetStatus("Error:" + ex.Message);
            }
        }

        private async void Ts2TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Apps:
                    e.Handled = true; //Do not show context menu on App button (used in Hook)
                    return;

                case Keys.Up:
                    MoveSelection(lvActions, up: true);
                    return;

                case Keys.Down:
                    MoveSelection(lvActions, up: false);
                    return;

                case Keys.Enter:
                    await LvActionsRunSelected();
                    return;
            }

            if (e.Control)
            {
                switch (e.KeyCode)
                {
                    //Clipboard actions
                    case Keys.C:
                    case Keys.V:
                    case Keys.X:
                    case Keys.Z:
                    case Keys.ControlKey:
                        return;

                    default:
                        if (ShortCuts.TryGetValue(e.KeyCode, out var btn))
                            GenericButton_Click(btn, EventArgs.Empty);
                        else
                            SetStatus($"Ctrl-{e.KeyCode} is not mapped to anything");
                        return;
                }
            }

            SearchTimer.Start();
        }

        private void MoveSelection(ListView lv, bool up)
        {
            if (lv.SelectedItems.Count == 0)
                return;

            int selInd = lvActions.SelectedItems.OfType<ListViewItem>().Min(a => a.Index);
            if ((up && selInd > 0) || (!up && selInd > lvActions.Items.Count - 2)) //At the border
                return;

            selInd += (up ? -1 : 1); //New selection index
            for (int i = 0; i < lvActions.Items.Count; i++)
            {
                lvActions.Items[i].Selected = (i == selInd);
            }
        }


        private async void LvActions_MouseDoubleClick(object sender, MouseEventArgs _) => await LvActionsRunSelected();

        private async void LvActions_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                await LvActionsRunSelected();
        }

        private async Task LvActionsRunSelected()
        {
            foreach (ListViewItem sel in lvActions.SelectedItems)
            {
                if (sel.Tag is IDoerAction act)
                    await act.Run(this);
            }
        }

        //Logic fof Vera mounting
        //static readonly DirectoryInfo ContDir = new(@"D:\Cont"); //TODO: keep in the config file

        private void DdVeraMount_DropDownOpening(object sender, EventArgs e)
        {
            ddVeraMount.DropDownItems.Clear();

            foreach (var path in Conf.settings.veracrypt.Items)
            {
                var ContDir = new DirectoryInfo(path);
                if (!ContDir.Exists)
                {
                    SetStatus($"Directory '{ContDir.FullName}' doesn't exist");
                    continue;
                }

                foreach (FileInfo fi in ContDir.GetFiles())
                {
                    if (fi.Length > 1_000_000) //TODO: make a parameter
                        ddVeraMount.DropDownItems.Add(fi.FullName);
                }
            }
        }

        private readonly Lazy<SHA1> Sha = new(() => SHA1.Create());

        private async void DdVeraMount_DropDownItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem is null)
                throw new Exception("Clicked item is null");

            string name = Path.GetFileNameWithoutExtension(e.ClickedItem.Text);
            name = name[..Math.Min(11, name.Length)];
            string ext = Path.GetExtension(e.ClickedItem.Text)[1..].ToUpperInvariant();

            string pass2 = Convert.ToHexString(Sha.Value.ComputeHash(Encoding.UTF8.GetBytes(name + NbCrypto.Ldr))).ToLowerInvariant();

            var pars = new NbPairList<string, string>();
            if (ext.EndsWith("-")) //readonly mode
            {
                pars["m"] = "ro"; //mountoption  readonly
                ext = ext[0..^1];
            }
            pars["m"] = $"label={name}"; //mountoption
            pars["volume", e.ClickedItem.Text]["letter", ext]["password", pass2]["quit"] = String.Empty;

            await NbProcess.RunAsync(Conf.settings.veracrypt.exec, pars);
            await NbProcess.Explorer(new FileInfo(@$"{ext}:\"));
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e) => NativeMethods.RemoveClipboardFormatListener(Handle);

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            ClosingAction?.Invoke();
            ModelDd.Dispose();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
                ModelDd.Dispose();
                StatusTimer.Dispose();
                SearchTimer.Dispose();
            }
            base.Dispose(disposing);
            Debug.WriteLine("Doer Form disposed");
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Apps)
                e.Handled = true;
        }


        //https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/working-with-local-content?tabs=dotnetcsharp
        private void LvClipboardContent_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvClipboardContent.SelectedItems.Count > 0)
            {
                webView.NavigateToString($"<html><body><h1>{lvClipboardContent.SelectedItems[0].Text}</h1></body></html>");
            }

        }
    }
}
