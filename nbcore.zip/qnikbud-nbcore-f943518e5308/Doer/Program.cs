﻿using System.IO.Pipes;
using System.Xml.Serialization;
using WinCopies.Util;
using Doer.Properties;
using Doer.Logic;
using System.Security.Principal;
using System.Security.AccessControl;

[assembly: System.Runtime.Versioning.SupportedOSPlatform("windows")]

//Register the file Fn-F12  instead of calculator: 
//Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\AppKey\18
//ShellExecute  REG_SZ   C:\Repo\NbCore\Doer\bin\Debug\net6.0-windows\Doer.exe main


namespace Doer
{
    static class Program
    {
        public const string PipeName = "PIPE_DOER";
        private const string MutexName = "MUTEX_DOER";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] arg)
        {
            using Mutex mutexApplication = new(initiallyOwned: true, MutexName, out bool isNewMutex);
            if (!isNewMutex)
            {   //Second instance
                //NamedPipeXmlPayload namedPipeXmlPayload = new() { CommandLineArguments = arg.ToList() };
                //NamedPipeClientSendOptions(namedPipeXmlPayload);// Send the message

                return;
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetHighDpiMode(HighDpiMode.SystemAware);
                Application.SetCompatibleTextRenderingDefault(false);
                Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

                var sys32 = Environment.ExpandEnvironmentVariables(@"%SystemRoot%\system32");
                if (Directory.GetCurrentDirectory().EqIC(sys32))
                {
                    MainForm = new MainForm(() =>
                    {
                        MainForm?.Dispose();
                        MainForm = null;
                    });
                    Application.Run(MainForm);
                }
                else if (arg.Length == 1)
                {
                    switch (arg[0].ToLowerInvariant())
                    {
                        case "main":
                        case "mainform":
                            MainForm = new MainForm();
                            break;
                        case "iconpicker":
                            MainForm = new IconPicker.Form1();
                            break;
                    }

                    Application.Run(MainForm);
                }
                else
                {
                    using var appCont = new MyApplicationContext();
                    //Application.AddMessageFilter(new MyMessageFilter(appCont));
                    Application.Run(appCont);
                }

                // Create a new pipe - it will return immediately and async wait for connections
                //NamedPipeServerCreateServer();
            }
            /*else
            {
                var namedPipeXmlPayload = new NamedPipeXmlPayload  // We are not the first instance, send the named pipe message with our payload and stop loading
                {
                    SignalQuit = false,
                    CommandLineArguments = Environment.GetCommandLineArgs().ToList()
                };
                NamedPipeClientSendOptions(namedPipeXmlPayload); // Send the message
                Close(); // Stop loading form and quit
            }*/
        }

        /*private static void NamedPipeClientSendOptions(NamedPipeXmlPayload namedPipePayload)
        {
            try
            {
                using var namedPipeClientStream = new NamedPipeClientStream(serverName: ".", PipeName, PipeDirection.Out);
                namedPipeClientStream.Connect(3000); // Maximum wait 3 seconds

                var xmlSerializer = new XmlSerializer(typeof(NamedPipeXmlPayload));
                xmlSerializer.Serialize(namedPipeClientStream, namedPipePayload);
            }
            catch (Exception)
            {
                // Error connecting or sending
            }
        }*/

        private static Form? MainForm;
        private static void ShowDialog(string header, string exMessage) => MessageBox.Show(MainForm, exMessage, header, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        private static void Application_ThreadException(object? sender, ThreadExceptionEventArgs e) => ShowDialog(sender?.ToString() ?? "Doer", NbException.Exception2String(e.Exception));
        private static void CurrentDomain_UnhandledException(object? sender, UnhandledExceptionEventArgs e) => ShowDialog($"Unhandled Exception from {sender}", e.ExceptionObject?.ToString() ?? "Unknown exception");
    }




    /*internal class MyMessageFilter : IMessageFilter
    {
        private readonly MyApplicationContext AppCont;
        internal MyMessageFilter(MyApplicationContext appCont)
        {
            AppCont = appCont;
        }

        public bool PreFilterMessage(ref System.Windows.Forms.Message m)
        {
            WM msgType = (WM)m.Msg;

            if (msgType == WM.USER)
            {
                AppCont.ShowForm();
                return true;
            }

            return false;
        }
    }*/

    public class MyApplicationContext : ApplicationContext
    {
        private MainForm? Form = null;
        private readonly NotifyIcon TrayIcon;
        readonly KeyboardHook Hook;

        //private NamedPipeServerStream? NamedPipe;
        //private readonly object _namedPiperServerThreadLock = new();
        //private readonly XmlSerializer NamedPipeSerializer = new(typeof(NamedPipeXmlPayload));
        //private readonly uint ThreadId;

        public MyApplicationContext()
        {
            //ThreadId = (uint)GetCurrentWin32ThreadId();

            ContextMenuStrip cms = new();
            cms.Items.Add(new ToolStripMenuItem("Exit", null, Exit));

            TrayIcon = new NotifyIcon() { Icon = Resources.Desktop909, ContextMenuStrip = cms, Visible = true };
            TrayIcon.MouseDown += TrayIcon_MouseDown;

            Hook = new();
            Hook.RegisterHotKey(ModifierKeys.Control, Keys.Apps, () => TrayIcon_MouseDown(null, new MouseEventArgs(MouseButtons.Left, 0, 0, 0, 0)));

            // Create a new pipe for next connection
            //NamedPipe = NamedPipeServerCreateServer();
            //NamedPipe.BeginWaitForConnection(NamedPipeServerConnectionCallback, NamedPipe);
        }

        internal void Test() => MessageBox.Show("App button pressed");


        private static NamedPipeServerStream NamedPipeServerCreateServer()
        {
            // Create a new pipe accessible by local authenticated users, disallow network
            //var sidAuthUsers = new SecurityIdentifier(WellKnownSidType.AuthenticatedUserSid, null);
            var sidNetworkService = new SecurityIdentifier(WellKnownSidType.NetworkServiceSid, null);
            var sidWorld = new SecurityIdentifier(WellKnownSidType.WorldSid, null);

            var pipeSecurity = new PipeSecurity();

            // Deny network access to the pipe
            var accessRule = new PipeAccessRule(sidNetworkService, PipeAccessRights.ReadWrite, AccessControlType.Deny);
            pipeSecurity.AddAccessRule(accessRule);

            // Alow Everyone to read/write
            accessRule = new PipeAccessRule(sidWorld, PipeAccessRights.ReadWrite, AccessControlType.Allow);
            pipeSecurity.AddAccessRule(accessRule);

            // Current user is the owner
            SecurityIdentifier? sidOwner = WindowsIdentity.GetCurrent().Owner;
            if (sidOwner != null)
            {
                accessRule = new PipeAccessRule(sidOwner, PipeAccessRights.FullControl, AccessControlType.Allow);
                pipeSecurity.AddAccessRule(accessRule);
            }

            //public NamedPipeServerStream(string pipeName, PipeDirection direction, int maxNumberOfServerInstances, PipeTransmissionMode transmissionMode, PipeOptions options, int inBufferSize, int outBufferSize)
            // Create pipe and start the async connection wait
            return new NamedPipeServerStream(
                Program.PipeName,
                PipeDirection.In,
                1,
                PipeTransmissionMode.Byte,
                PipeOptions.Asynchronous,
                0,
                0
                //,pipeSecurity
                );
        }

         /*[return: MarshalAs(UnmanagedType.Bool)]
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool PostThreadMessage(uint threadId, uint msg, IntPtr wParam, IntPtr lParam);

        [DllImport("Kernel32", EntryPoint = "GetCurrentThreadId", ExactSpelling = true)]
        public static extern Int32 GetCurrentWin32ThreadId();

        private void NamedPipeServerConnectionCallback(IAsyncResult iAsyncResult)
        {
            if (NamedPipe == null)
                return;

            NamedPipeServerStream np = NamedPipe;

            try
            {
                // End waiting for the connection
                NamedPipe.EndWaitForConnection(iAsyncResult);

                // Read data and prevent access to _namedPipeXmlPayload during threaded operations
                lock (_namedPiperServerThreadLock)
                {
                    // Read data from client
                    NamedPipeXmlPayload payload = (NamedPipeXmlPayload?)NamedPipeSerializer.Deserialize(np) ?? throw new Exception("NamedPipeSerializer failed");
                    PostThreadMessage(ThreadId, (uint)WM.USER, IntPtr.Zero, IntPtr.Zero);

                    // Need to signal quit?
                    //if (_namedPipeXmlPayload.SignalQuit)
                    //{
                    //    NamedPipeThreadEvent_Close();
                    //    return;
                    //}
                }
            }
            catch (ObjectDisposedException)
            {
                // EndWaitForConnection will exception when someone calls closes the pipe before connection made
                // In that case we dont create any more pipes and just return
                // This will happen when app is closing and our pipe is closed/disposed
                return;
            }
            catch (Exception)
            {
                // ignored
            }
            finally
            {
                // Close the original pipe (we will create a new one each time)
                NamedPipe.Dispose();
            }

            // Create a new pipe for next connection
            NamedPipe = NamedPipeServerCreateServer();
            NamedPipe.BeginWaitForConnection(NamedPipeServerConnectionCallback, NamedPipe);
        }*/


        private void TrayIcon_MouseDown(object? _, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
                return;

            lock (this)
            {
                if (Form == null)
                {
                    Form = new MainForm(() =>
                    {
                        Form?.Dispose();
                        Form = null;
                    }); //TODO: Do we need the action, or we can just pass a bool?
                    Form.ShowDialog();
                    Form = null;
                }
                else
                {
                    Form.Close();
                    Form.Dispose();
                    Form = null;
                }
            }
        }

        /*public void ShowForm()
        {
            if (Form == null)
            {
                Form = new MainForm(() => Form = null);
                Form.ShowDialog();
            }
        }*/

        void Exit(object? sender, EventArgs arg)
        {
            TrayIcon.Visible = false;
            Application.Exit();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {   //Dispose managed variables
                TrayIcon?.Dispose();
                Hook?.Dispose();
            }
            //Dispose unmanaged variables

            //Call base class
            base.Dispose(disposing);
        }

        ~MyApplicationContext() => Dispose(false);
    }

    public class NamedPipeXmlPayload
    {
        /// <summary>
        ///     If set to true this is simply a request to terminate
        /// </summary>
        [XmlElement("SignalQuit")]
        public bool SignalQuit { get; set; }

        /// <summary>
        ///     A list of command line arguments.
        /// </summary>
        [XmlElement("CommandLineArguments")]
        public List<string> CommandLineArguments { get; set; } = new List<string>();
    }
}
