﻿namespace Doer.Logic
{
    partial class Sansa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sansa));
            this.btPlaylist = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btPlaylist
            // 
            this.btPlaylist.Location = new System.Drawing.Point(180, 24);
            this.btPlaylist.Name = "btPlaylist";
            this.btPlaylist.Size = new System.Drawing.Size(120, 23);
            this.btPlaylist.TabIndex = 0;
            this.btPlaylist.Text = "Create Playlists";
            this.btPlaylist.UseVisualStyleBackColor = true;
            this.btPlaylist.Click += new System.EventHandler(this.BtRun_Click);
            // 
            // Sansa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 170);
            this.Controls.Add(this.btPlaylist);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Sansa";
            this.Text = "Sansa";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btPlaylist;
    }
}