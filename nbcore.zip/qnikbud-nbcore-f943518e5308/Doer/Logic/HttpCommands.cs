﻿using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Channels;

namespace Doer.Logic
{
    public partial class YoutubeRss : IDoerAction
    {
        public string Name => "Youtube channel Rss";
        private readonly Uri Url;
        public YoutubeRss(Uri url) => Url = url;

        [GeneratedRegex(@"""http:\\\/\\\/www.youtube.com\\\/channel\\\/(UC.+?)""")]   // ?  - for lazy
        public static partial Regex Channel1();
        [GeneratedRegex(@"""http:\/\/www.youtube.com\/channel\/(UC.+?)""")]   // ?  - for lazy
        public static partial Regex Channel2();
        [GeneratedRegex(@"""url"":""\/channel\/(.+?)""")]   // ?  - for lazy
        public static partial Regex Channel3();

        private static readonly Regex[] Chan = new Regex[] { Channel1(), Channel2(), Channel3() };

        public static async Task<string> YoutubeRssLink_HttpClient(string youtubeUrl)
        {
            using HttpClient cln = new();
            string res = await cln.GetStringAsync(youtubeUrl) ?? throw new Exception($"No string was loaded from '{youtubeUrl}'");

            List<string> Links = new();
            foreach (var rg in Chan)
            {
                Match match = rg.Match(res);
                if (match.Success)
                    Links.Add(match.Groups[1].Value);
            }

            if (Links.Count > 0)
                return @$"https://www.youtube.com/feeds/videos.xml?channel_id={Links[0]}";

            const string htmlFile = @"C:\AutoDelete\1.html";
            File.WriteAllText(htmlFile, res);
            throw new Exception($"Can't fild channel link. Check the file: '{htmlFile}'");
        }

        public async Task Run(IMainForm form)
        {
            using HttpClient cln = new();
            string res = await cln.GetStringAsync(Url) ?? throw new Exception($"No string was loaded from '{Url}'");

            List<string> Links = new();
            foreach (var rg in Chan)
            {
                Match match = rg.Match(res);
                if (match.Success)
                    Links.Add(match.Groups[1].Value);
            }

            if (Links.Count == 0)
            {
                const string htmlFile = @"C:\AutoDelete\1.html";
                File.WriteAllText(htmlFile, res);
                throw new Exception($"Can't fild channel link. Check the file: '{Url}'");
            }

            var rssLink = @$"https://www.youtube.com/feeds/videos.xml?channel_id={Links[0]}";
            Clipboard.SetText(rssLink);
            form.MessageInfo($"Rss link is saved into the clipboard: '{rssLink}'");
        }
    }
}
