﻿using System.Diagnostics;
using System.Text.RegularExpressions;
using NbFormV1.Xml;
using NbWpfLib;

namespace Doer.Logic;

internal class VideoKeyFrames : IDoerAction
{
    private readonly FileInfo Fi;
    private readonly string Ffmpeg;

    public VideoKeyFrames(FileInfo fi, string ffmpeg) => (Fi, Ffmpeg) = (fi, ffmpeg);
    public string Name => $"Generate keyframe thumbnails for video";

    public Task Run(IMainForm form) => NbMedia.Ffmpeg_IndexKeyThumbnails(Fi.FullName, Ffmpeg);
}

internal partial class VideoCut : IDoerAction
{
    private readonly FileInfo Fi;
    private readonly string Ffmpeg;

    public VideoCut(FileInfo fi, string ffmpeg) => (Fi, Ffmpeg) = (fi, ffmpeg);
    public string Name => $"Cut without repackaging";

    [GeneratedRegex(@"_(\d{2})\.(\d{2})\.(\d{2})\.(\d{3})(\.jpg)*$")]
    private static partial Regex HoursLong();

    [GeneratedRegex(@"_(\d{2})\.(\d{2})\.(\d{3})(\.jpg)*$")]
    private static partial Regex MinutesLong();

    [GeneratedRegex(@"_(\d{2})\.(\d{3})(\.jpg)*$")]
    private static partial Regex SecondsLong();


    private static TimeSpan SnapshotFileNameParse(string fileName)
    {
        Match mMatch = MinutesLong().Match(fileName); //Minutest format is more propable
        if (mMatch.Success)
            return new TimeSpan(0, 0, Int32.Parse(mMatch.Groups[1].Value), Int32.Parse(mMatch.Groups[2].Value), Int32.Parse(mMatch.Groups[3].Value), 0);

        Match hMatch = HoursLong().Match(fileName);
        if (hMatch.Success)
            return new TimeSpan(0, Int32.Parse(hMatch.Groups[1].Value), Int32.Parse(hMatch.Groups[2].Value), Int32.Parse(hMatch.Groups[3].Value), Int32.Parse(hMatch.Groups[4].Value), 0);

        Match sMatch = SecondsLong().Match(fileName);
        if (sMatch.Success)
            return new TimeSpan(0, 0, 0, Int32.Parse(sMatch.Groups[2].Value), Int32.Parse(sMatch.Groups[3].Value), 0);

        throw new Exception($"Can't parse time span out of '{fileName}'");
    }


    public async Task Run(IMainForm form)
    {
        /*var (yes, res) = NbDialogForm.Show("Cut fragment of a video", "Provide two timestamps in '00.00.00.528 00.00.14.542' format");
        if (!yes)
            return;

        //TODO: replace with proper fields in the NbDialogForm*/

        var fromFld = new FieldText() { label = "Snapshot file from", name = "From" };
        var toFld = new FieldText() { label = "Snapshot file to", name = "From" };
        var dstDir = new FieldText() { label = "Destination Dir", name = "DstDir" };  //TODO: use to save file in proper dir

        NbFormDesc desc = new()
        {
            title = "Cut video without recompression by snapshot files",
            fields = new FieldText[] { fromFld, toFld, dstDir },
            buttons = new ButtonDesc[]
            {
                    new ButtonDesc(){ label = "Ok", dialog_result = DlgResult.OK, func = ButtonFunc.Enter },
                    new ButtonDesc(){ label = "Cancel", dialog_result = DlgResult.Cancel, func = ButtonFunc.Esc },
            }
        };

        var dlg = new NbDialogForm(desc);
        if (DialogResult.OK != await Task.Run(() => dlg.ShowDialog()))
            return;
        //dlg.ShowDialog();

        TimeSpan from = SnapshotFileNameParse(fromFld.new_val);
        TimeSpan to = SnapshotFileNameParse(toFld.new_val);

        /*var twoStamps = res.Split(' ').Where(l => !string.IsNullOrEmpty(l)).ToArray();
        if (twoStamps.Length != 2)
            throw new Exception($"Can't find two timestamps in '{res}'");

        if (!TimeSpan.TryParseExact(twoStamps[0], "hh\\.mm\\.ss\\.fff", null, System.Globalization.TimeSpanStyles.None, out TimeSpan from))
            throw new Exception($"Can't find timestamp in '{twoStamps[0]}'");

        if (!TimeSpan.TryParseExact(twoStamps[1], "hh\\.mm\\.ss\\.fff", null, System.Globalization.TimeSpanStyles.None, out TimeSpan to))
            throw new Exception($"Can't find timestamp in '{twoStamps[1]}'");*/

        var dstFile = await NbMedia.Ffmpeg_CutByTimestamps(Fi.FullName, Ffmpeg, from, to);
        await NbProcess.Explorer(new FileInfo(dstFile));
    }
}


public class VideoConcat : IDoerAction
{
    private readonly IList<FileInfo> Files;
    private readonly string Ffmpeg;

    public VideoConcat(IList<FileInfo> fis, string ffmpeg) => (Files, Ffmpeg) = (fis, ffmpeg);

    public string Name => $"Concatenate {Files.Count} videos";

    public async Task Run(IMainForm form)
    {
        string dstFile = Path.Combine(Files[0].DirSafe().FullName, Path.GetFileNameWithoutExtension(Files[0].Name) + "_combined" + Files[0].Extension.ToLowerInvariant());

        //Create file for parameters
        var listFile = Path.GetTempFileName();
        await File.AppendAllLinesAsync(listFile, Files.Select(f => $"file '{f.FullName}'"));

        ProcessStartInfo psi = new()
        {
            FileName = NbProcess.PutInQuotes(Ffmpeg),
            Arguments = @$"-f concat -safe 0 -i ""{listFile}"" -c copy ""{dstFile}""",
            RedirectStandardOutput = true,
            UseShellExecute = false
        };

        var prc = Process.Start(psi);
        if (prc == null)
            throw new Exception("Could not start the ffmpeg process");

        StreamReader reader = prc.StandardOutput;
        string output = reader.ReadToEnd();
        prc.WaitForExit();


        form.Dialog($"ffmpeg returned: {prc.ExitCode}", MessageBoxButtons.OK);

        if (File.Exists(listFile))
            File.Delete(listFile);
    }
}