﻿namespace Doer.Logic
{
    partial class MinecraftForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.Windows.Forms.Label lbPlantAndHoe;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MinecraftForm));
            this.bt_PlaceBlockLeft = new System.Windows.Forms.Button();
            this.btWrBooks = new System.Windows.Forms.Button();
            this.bt_PlaceBlockRight = new System.Windows.Forms.Button();
            this.bt_PlaceBlockBack = new System.Windows.Forms.Button();
            this.tb1Times = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ch_TwoBlocks = new System.Windows.Forms.CheckBox();
            this.cbBlockPlaceDelay = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btMoveBack = new System.Windows.Forms.Button();
            this.btMoveForw = new System.Windows.Forms.Button();
            this.tbStepRepeat = new System.Windows.Forms.TextBox();
            this.tbStepStayTime = new System.Windows.Forms.TextBox();
            this.tbStepTime = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btTrade3 = new System.Windows.Forms.Button();
            this.btTrade2 = new System.Windows.Forms.Button();
            this.btTrade1 = new System.Windows.Forms.Button();
            this.tbTradeCells = new System.Windows.Forms.TextBox();
            this.tbTradeDelay = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tbPlantAndHoe = new System.Windows.Forms.TextBox();
            this.btPlantAndHoe = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            lbPlantAndHoe = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(10, 37);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(65, 15);
            label1.TabIndex = 1;
            label1.Text = "Use button";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(111, 37);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(70, 15);
            label2.TabIndex = 3;
            label2.Text = "times, delay";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(10, 25);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(56, 15);
            label3.TabIndex = 15;
            label3.Text = "StepTime";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(119, 25);
            label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(56, 15);
            label4.TabIndex = 16;
            label4.Text = "Stay time";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(227, 25);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(43, 15);
            label5.TabIndex = 19;
            label5.Text = "Repeat";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(12, 55);
            label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(32, 15);
            label6.TabIndex = 19;
            label6.Text = "Cells";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(10, 25);
            label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(36, 15);
            label7.TabIndex = 15;
            label7.Text = "Delay";
            // 
            // bt_PlaceBlockLeft
            // 
            this.bt_PlaceBlockLeft.Location = new System.Drawing.Point(266, 22);
            this.bt_PlaceBlockLeft.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bt_PlaceBlockLeft.Name = "bt_PlaceBlockLeft";
            this.bt_PlaceBlockLeft.Size = new System.Drawing.Size(48, 27);
            this.bt_PlaceBlockLeft.TabIndex = 6;
            this.bt_PlaceBlockLeft.Text = "Left";
            this.toolTip1.SetToolTip(this.bt_PlaceBlockLeft, "Ctrl-X");
            this.bt_PlaceBlockLeft.UseVisualStyleBackColor = true;
            this.bt_PlaceBlockLeft.Click += new System.EventHandler(this.BtnPlaceBlocks_Click);
            // 
            // btWrBooks
            // 
            this.btWrBooks.Location = new System.Drawing.Point(404, 157);
            this.btWrBooks.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btWrBooks.Name = "btWrBooks";
            this.btWrBooks.Size = new System.Drawing.Size(188, 27);
            this.btWrBooks.TabIndex = 10;
            this.btWrBooks.Text = "Craft Written Books";
            this.btWrBooks.UseVisualStyleBackColor = true;
            this.btWrBooks.Click += new System.EventHandler(this.Button2_Click);
            // 
            // bt_PlaceBlockRight
            // 
            this.bt_PlaceBlockRight.Location = new System.Drawing.Point(321, 22);
            this.bt_PlaceBlockRight.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bt_PlaceBlockRight.Name = "bt_PlaceBlockRight";
            this.bt_PlaceBlockRight.Size = new System.Drawing.Size(48, 27);
            this.bt_PlaceBlockRight.TabIndex = 11;
            this.bt_PlaceBlockRight.Text = "Right";
            this.toolTip1.SetToolTip(this.bt_PlaceBlockRight, "Ctrl-C");
            this.bt_PlaceBlockRight.UseVisualStyleBackColor = true;
            this.bt_PlaceBlockRight.Click += new System.EventHandler(this.BtnPlaceBlocks_Click);
            // 
            // bt_PlaceBlockBack
            // 
            this.bt_PlaceBlockBack.Location = new System.Drawing.Point(292, 55);
            this.bt_PlaceBlockBack.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.bt_PlaceBlockBack.Name = "bt_PlaceBlockBack";
            this.bt_PlaceBlockBack.Size = new System.Drawing.Size(48, 27);
            this.bt_PlaceBlockBack.TabIndex = 12;
            this.bt_PlaceBlockBack.Text = "Back";
            this.bt_PlaceBlockBack.UseVisualStyleBackColor = true;
            this.bt_PlaceBlockBack.Click += new System.EventHandler(this.BtnPlaceBlocks_Click);
            // 
            // tb1Times
            // 
            this.tb1Times.Location = new System.Drawing.Point(79, 33);
            this.tb1Times.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tb1Times.Name = "tb1Times";
            this.tb1Times.Size = new System.Drawing.Size(25, 23);
            this.tb1Times.TabIndex = 13;
            this.tb1Times.Text = "32";
            this.tb1Times.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ch_TwoBlocks);
            this.groupBox1.Controls.Add(this.cbBlockPlaceDelay);
            this.groupBox1.Controls.Add(this.bt_PlaceBlockBack);
            this.groupBox1.Controls.Add(label1);
            this.groupBox1.Controls.Add(this.tb1Times);
            this.groupBox1.Controls.Add(label2);
            this.groupBox1.Controls.Add(this.bt_PlaceBlockLeft);
            this.groupBox1.Controls.Add(this.bt_PlaceBlockRight);
            this.groupBox1.Location = new System.Drawing.Point(14, 14);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(383, 93);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Place blocks";
            // 
            // ch_TwoBlocks
            // 
            this.ch_TwoBlocks.AutoSize = true;
            this.ch_TwoBlocks.Location = new System.Drawing.Point(14, 61);
            this.ch_TwoBlocks.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.ch_TwoBlocks.Name = "ch_TwoBlocks";
            this.ch_TwoBlocks.Size = new System.Drawing.Size(128, 19);
            this.ch_TwoBlocks.TabIndex = 16;
            this.ch_TwoBlocks.Text = "Two block at a time";
            this.ch_TwoBlocks.UseVisualStyleBackColor = true;
            // 
            // cbBlockPlaceDelay
            // 
            this.cbBlockPlaceDelay.FormattingEnabled = true;
            this.cbBlockPlaceDelay.Items.AddRange(new object[] {
            "0.19",
            "0.23"});
            this.cbBlockPlaceDelay.Location = new System.Drawing.Point(190, 33);
            this.cbBlockPlaceDelay.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbBlockPlaceDelay.Name = "cbBlockPlaceDelay";
            this.cbBlockPlaceDelay.Size = new System.Drawing.Size(68, 23);
            this.cbBlockPlaceDelay.TabIndex = 15;
            this.cbBlockPlaceDelay.Text = "0.23";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btMoveBack);
            this.groupBox2.Controls.Add(this.btMoveForw);
            this.groupBox2.Controls.Add(this.tbStepRepeat);
            this.groupBox2.Controls.Add(label5);
            this.groupBox2.Controls.Add(this.tbStepStayTime);
            this.groupBox2.Controls.Add(this.tbStepTime);
            this.groupBox2.Controls.Add(label3);
            this.groupBox2.Controls.Add(label4);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox2.Location = new System.Drawing.Point(14, 126);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(383, 76);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Step";
            // 
            // btMoveBack
            // 
            this.btMoveBack.Location = new System.Drawing.Point(328, 43);
            this.btMoveBack.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btMoveBack.Name = "btMoveBack";
            this.btMoveBack.Size = new System.Drawing.Size(48, 27);
            this.btMoveBack.TabIndex = 21;
            this.btMoveBack.Text = "Back";
            this.toolTip1.SetToolTip(this.btMoveBack, "Ctrl-V");
            this.btMoveBack.UseVisualStyleBackColor = true;
            this.btMoveBack.Click += new System.EventHandler(this.BtStepForwBack_Click);
            // 
            // btMoveForw
            // 
            this.btMoveForw.Location = new System.Drawing.Point(329, 13);
            this.btMoveForw.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btMoveForw.Name = "btMoveForw";
            this.btMoveForw.Size = new System.Drawing.Size(48, 27);
            this.btMoveForw.TabIndex = 15;
            this.btMoveForw.Text = "Forw";
            this.toolTip1.SetToolTip(this.btMoveForw, "Ctrl-F");
            this.btMoveForw.UseVisualStyleBackColor = true;
            this.btMoveForw.Click += new System.EventHandler(this.BtStepForwBack_Click);
            // 
            // tbStepRepeat
            // 
            this.tbStepRepeat.Location = new System.Drawing.Point(276, 22);
            this.tbStepRepeat.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbStepRepeat.Name = "tbStepRepeat";
            this.tbStepRepeat.Size = new System.Drawing.Size(45, 23);
            this.tbStepRepeat.TabIndex = 20;
            this.tbStepRepeat.Text = "16";
            this.tbStepRepeat.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbStepStayTime
            // 
            this.tbStepStayTime.Location = new System.Drawing.Point(177, 22);
            this.tbStepStayTime.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbStepStayTime.Name = "tbStepStayTime";
            this.tbStepStayTime.Size = new System.Drawing.Size(45, 23);
            this.tbStepStayTime.TabIndex = 18;
            this.tbStepStayTime.Text = "0.25";
            this.tbStepStayTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbStepTime
            // 
            this.tbStepTime.Location = new System.Drawing.Point(71, 22);
            this.tbStepTime.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbStepTime.Name = "tbStepTime";
            this.tbStepTime.Size = new System.Drawing.Size(45, 23);
            this.tbStepTime.TabIndex = 17;
            this.tbStepTime.Text = "0.17";
            this.tbStepTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btTrade3);
            this.groupBox3.Controls.Add(this.btTrade2);
            this.groupBox3.Controls.Add(this.btTrade1);
            this.groupBox3.Controls.Add(this.tbTradeCells);
            this.groupBox3.Controls.Add(label6);
            this.groupBox3.Controls.Add(this.tbTradeDelay);
            this.groupBox3.Controls.Add(label7);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox3.Location = new System.Drawing.Point(404, 14);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(188, 136);
            this.groupBox3.TabIndex = 21;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Trade";
            // 
            // btTrade3
            // 
            this.btTrade3.Location = new System.Drawing.Point(102, 85);
            this.btTrade3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btTrade3.Name = "btTrade3";
            this.btTrade3.Size = new System.Drawing.Size(76, 27);
            this.btTrade3.TabIndex = 22;
            this.btTrade3.Text = "Row 3";
            this.toolTip1.SetToolTip(this.btTrade3, "Ctrl-Z");
            this.btTrade3.UseVisualStyleBackColor = true;
            this.btTrade3.Click += new System.EventHandler(this.BtTrade_Click);
            // 
            // btTrade2
            // 
            this.btTrade2.Location = new System.Drawing.Point(102, 52);
            this.btTrade2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btTrade2.Name = "btTrade2";
            this.btTrade2.Size = new System.Drawing.Size(76, 27);
            this.btTrade2.TabIndex = 21;
            this.btTrade2.Text = "Row 2";
            this.toolTip1.SetToolTip(this.btTrade2, "Ctrl-A");
            this.btTrade2.UseVisualStyleBackColor = true;
            this.btTrade2.Click += new System.EventHandler(this.BtTrade_Click);
            // 
            // btTrade1
            // 
            this.btTrade1.Location = new System.Drawing.Point(102, 18);
            this.btTrade1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btTrade1.Name = "btTrade1";
            this.btTrade1.Size = new System.Drawing.Size(76, 27);
            this.btTrade1.TabIndex = 15;
            this.btTrade1.Text = "Row 1";
            this.toolTip1.SetToolTip(this.btTrade1, "Ctrl-Q");
            this.btTrade1.UseVisualStyleBackColor = true;
            this.btTrade1.Click += new System.EventHandler(this.BtTrade_Click);
            // 
            // tbTradeCells
            // 
            this.tbTradeCells.Location = new System.Drawing.Point(49, 52);
            this.tbTradeCells.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbTradeCells.Name = "tbTradeCells";
            this.tbTradeCells.Size = new System.Drawing.Size(45, 23);
            this.tbTradeCells.TabIndex = 20;
            this.tbTradeCells.Text = "9";
            this.tbTradeCells.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbTradeDelay
            // 
            this.tbTradeDelay.Location = new System.Drawing.Point(49, 22);
            this.tbTradeDelay.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbTradeDelay.Name = "tbTradeDelay";
            this.tbTradeDelay.Size = new System.Drawing.Size(45, 23);
            this.tbTradeDelay.TabIndex = 17;
            this.tbTradeDelay.Text = "50";
            this.tbTradeDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbPlantAndHoe
            // 
            this.tbPlantAndHoe.Location = new System.Drawing.Point(73, 217);
            this.tbPlantAndHoe.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbPlantAndHoe.Name = "tbPlantAndHoe";
            this.tbPlantAndHoe.Size = new System.Drawing.Size(45, 23);
            this.tbPlantAndHoe.TabIndex = 23;
            this.tbPlantAndHoe.Text = "16";
            this.tbPlantAndHoe.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbPlantAndHoe
            // 
            lbPlantAndHoe.AutoSize = true;
            lbPlantAndHoe.Location = new System.Drawing.Point(24, 220);
            lbPlantAndHoe.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lbPlantAndHoe.Name = "lbPlantAndHoe";
            lbPlantAndHoe.Size = new System.Drawing.Size(43, 15);
            lbPlantAndHoe.TabIndex = 22;
            lbPlantAndHoe.Text = "Repeat";
            // 
            // btPlantAndHoe
            // 
            this.btPlantAndHoe.Location = new System.Drawing.Point(126, 217);
            this.btPlantAndHoe.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btPlantAndHoe.Name = "btPlantAndHoe";
            this.btPlantAndHoe.Size = new System.Drawing.Size(99, 27);
            this.btPlantAndHoe.TabIndex = 22;
            this.btPlantAndHoe.Text = "Plant And Hoe";
            this.toolTip1.SetToolTip(this.btPlantAndHoe, "Ctrl-F");
            this.btPlantAndHoe.UseVisualStyleBackColor = true;
            this.btPlantAndHoe.Click += new System.EventHandler(this.BtPlantAndHoe_Click);
            // 
            // MinecraftForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(596, 263);
            this.Controls.Add(this.btPlantAndHoe);
            this.Controls.Add(this.tbPlantAndHoe);
            this.Controls.Add(lbPlantAndHoe);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btWrBooks);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "MinecraftForm";
            this.Text = "Minecraft";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button bt_PlaceBlockLeft;
        private System.Windows.Forms.Button btWrBooks;
        private System.Windows.Forms.Button bt_PlaceBlockRight;
        private System.Windows.Forms.Button bt_PlaceBlockBack;
        private System.Windows.Forms.TextBox tb1Times;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btMoveForw;
        private System.Windows.Forms.TextBox tbStepRepeat;
        private System.Windows.Forms.TextBox tbStepStayTime;
        private System.Windows.Forms.TextBox tbStepTime;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btTrade1;
        private System.Windows.Forms.TextBox tbTradeCells;
        private System.Windows.Forms.TextBox tbTradeDelay;
        private System.Windows.Forms.Button btTrade3;
        private System.Windows.Forms.Button btTrade2;
        private System.Windows.Forms.Button btMoveBack;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ComboBox cbBlockPlaceDelay;
        private System.Windows.Forms.CheckBox ch_TwoBlocks;
        private TextBox tbPlantAndHoe;
        private Button btPlantAndHoe;
    }
}