﻿using System.Diagnostics;
using System.Text.RegularExpressions;

using Microsoft.WindowsAPICodePack.Dialogs;
using NbWpfLib;
using NbWin;

namespace Doer
{
    public partial class FileToDatedFoldersAction : IDoerAction
    {
        private readonly FileInfo[] Files;
        public FileToDatedFoldersAction(FileInfo[] files) => Files = files;

        public string Name => $"Move files ({Files.Length}) to dated Folders";

        [GeneratedRegex("^IMG_(\\d{8})_(\\d+)\\..+$")]
        private static partial Regex ImgRegex1();

        public Task Run(IMainForm form)
        {
            //HashSet<string> subDirs = new HashSet<string>();
            var subDirs = new NbDictionary<string, List<FileInfo>>(100, null, "Files grouped by date", _ => new List<FileInfo>());

            foreach (FileInfo fl in Files)
            {
                DateTime? dt = null;
                var medType = NbMedia.GetFileMediaType(fl.Extension);
                if (medType == NbMedia.FileMediaTypes.Photo)  //Try EXIF first for photo files
                {
                    dt = NbGraphics.GetExifDate(fl.FullName);
                }

                if (dt == null) //Then try file format
                {
                    var match1 = ImgRegex1().Match(fl.Name);
                    if (match1.Success) //Parse the date out of the file name if possible, the file attributes could be lost while copying
                    {
                        if (DateTime.TryParseExact(match1.Groups[1].Value, "yyyyMMdd", null, System.Globalization.DateTimeStyles.AssumeLocal, out var dt1))
                            dt = dt1;
                        else
                            throw new Exception($"Can't parse date out of the second section of the file '{fl.FullName}'");
                    }
                }

                if (dt == null) //Lastly - file write datetime
                    dt = fl.LastWriteTime;

                var subDir = dt.ToString("yyyy.MM.dd");
                subDirs[subDir].Add(fl); //Will create new cell
            }

            foreach (var (dir, list) in subDirs)
            {
                if (list.Count > 1) //Create dir
                {
                    foreach (var fl in list)
                    {
                        string dirPath = Path.Combine(fl.Dir().FullName, dir);
                        if (!Directory.Exists(dirPath)) //The directory might have been created by a previous process
                            Directory.CreateDirectory(dirPath);

                        File.Move(fl.FullName, Path.Combine(dirPath, fl.Name));
                    }
                }
                else if (list.Count == 1)//Rename the file adding the date to the front. No need to create a folder
                {
                    var fl = list[0];

                    string newname = Path.Combine(fl.Dir().FullName, dir + " " + fl.Name);
                    File.Move(fl.FullName, newname); //
                }
            }
            form.MessageInfo($"{Files.Length} files have been moved to {subDirs.Count} directories");
            return Task.CompletedTask;
        }
    }

    public class RemoveEmptyDirs : IDoerAction
    {
        private readonly DirectoryInfo RootDir;

        public string Name => "Remove empty diretories";
        internal RemoveEmptyDirs(DirectoryInfo rootDir) => RootDir = rootDir;

        public Task Run(IMainForm form)
        {
            try { SearchEmptyDirRec(RootDir, form); }
            catch (NbExceptionUserCancelled) { } //Ignore - expected
            return Task.CompletedTask;
        }

        private void SearchEmptyDirRec(DirectoryInfo root, IMainForm form)
        {
            var dirs = root.GetDirectories();
            var files = root.GetFiles();

            if (dirs.Length == 0 && files.Length == 0)
            {
                switch (form.Dialog($"Delete empty dir '{root.FullName}'?", MessageBoxButtons.YesNoCancel))
                {
                    case DialogResult.Yes: root.Delete(); break;
                    case DialogResult.Cancel: throw new NbExceptionUserCancelled();
                    default: break;
                }
                return;
            }

            foreach (var dir in dirs)
                SearchEmptyDirRec(dir, form); //Recurcise
        }
    }

    public partial class FilesGroupByNumber : IDoerAction
    {
        private readonly FileInfo[] Files;
        public FilesGroupByNumber(FileInfo[] files) => Files = files;


        [GeneratedRegex("^(.+)_*(\\d+)$")]
        private static partial Regex MyRegex(); //some file part_1.ext

        public string Name => "Group files by number at the end";

        public Task Run(IMainForm form)
        {
            NbDictionary<string, List<FileInfo>> groups = new();
            foreach (FileInfo fl in Files)
            {
                var match = MyRegex().Match(fl.NameWithoutExtension());
                if (match.Success)
                {
                    string grp = match.Groups[1].Value;
                    string _ = match.Groups[2].Value;
                    if (!groups.TryGetValue(grp, out var list))
                    {
                        list = new List<FileInfo>();
                        groups.Add(grp, list);
                    }

                    list.Add(fl);
                }
            }

            string mess = "The following groups will be created: " + string.Join(", ", groups.Keys);
            form.Dialog(mess, MessageBoxButtons.OK);
            return Task.CompletedTask;
        }
    }

    public class FilesChangeExtensions : IDoerAction
    {
        private readonly FileInfo[] Files;
        public FilesChangeExtensions(FileInfo[] files) => Files = files;

        public string Name => $"Change extension for files ({Files.Length})";
        //private readonly Regex ImgRegex = new(@"^IMG_(\d{8})_(\d+)\..+$");  //IMG_20171122_111349639.jpg


        public Task Run(IMainForm form)
        {
            var (cont, from) = NbDialogForm.Show("Changing extensions", "Extension from (without dot). Empty extensions are allowed");
            if (!cont)
                return Task.CompletedTask; ;

            var (cont2, to) = NbDialogForm.Show("Changing extensions", "Extension from (without dot). Empty extensions are allowed");
            if (!cont2)
                return Task.CompletedTask;

            foreach (FileInfo fl in Files)
            {
                if (fl.Extension.TrimStart('.') == from)
                {
                    var newpath = Path.Combine(fl.Dir().FullName, fl.NameWithoutExtension() + '.' + to);
                    fl.MoveTo(newpath);
                }
            }
            return Task.CompletedTask;

            /*foreach (var (dir, list) in subDirs)
            {
                if (list.Count > 1) //Create dir
                {
                    foreach (var fl in list)
                    {
                        string dirPath = Path.Combine(fl.Directory.FullName, dir);
                        if (!Directory.Exists(dirPath)) //The directory might have been created by a previous process
                            Directory.CreateDirectory(dirPath);

                        File.Move(fl.FullName, Path.Combine(dirPath, fl.Name));
                    }
                }
                else if (list.Count == 1)//Rename the file adding the date to the front. No need to create a folder
                {
                    var fl = list[0];

                    File.Move(fl.FullName, Path.Combine(fl.DirectoryName, dir + " " + fl.Name)); //
                }
            }
            form.MessageInfo($"{Files.Length} files have been moved to {subDirs.Count} directories");*/
        }
    }

    public class Image2Base64 : IDoerAction
    {
        private readonly FileInfo Fi;

        public Image2Base64(FileInfo fi) => Fi = fi;
        public string Name => "Convert to Base64";

        public Task Run(IMainForm form)
        {
            byte[] data = File.ReadAllBytes(Fi.FullName);
            string ext = Fi.Extension.TrimStart('.').ToLowerInvariant();
            string res = @$"data:image/{ext};base64,{Convert.ToBase64String(data)}";
            Clipboard.SetText(res);
            form.SetStatus($"{data.Length} bytes of image {Fi.Name} has been converted and saved in the clipboard");
            return Task.CompletedTask;
        }
    }


    //TODO; think about parametrization instead of derivation
    public class JpegResizeAction50 : JpegResizeAction
    {
        public JpegResizeAction50(DirectoryInfo dir) : base(dir) { }
        public override int Percent => 50;
    }
    public class JpegResizeAction33 : JpegResizeAction
    {
        public JpegResizeAction33(DirectoryInfo dir) : base(dir) { }
        public override int Percent => 33;
    }
    public class JpegResizeAction25 : JpegResizeAction
    {
        public JpegResizeAction25(DirectoryInfo dir) : base(dir) { }
        public override int Percent => 25;
    }

    public abstract class JpegResizeAction : IDoerAction
    {
        private readonly DirectoryInfo Dir;

        protected JpegResizeAction(DirectoryInfo dir) => Dir = dir;

        public string Name => $"Reduce Jpeg to {Percent}%";
        public abstract int Percent { get; }

        public Task Run(IMainForm form)
        {
            ReduceJpegSize(Dir.FullName, Percent);
            return Task.CompletedTask;
        }

        private static void ReduceJpegSize(string aSrcDir, int aPercentage)  //IReportProgress aProg
        {
            //#pragma warning disable CA1416 // Validate platform compatibility
            CommonOpenFileDialog dialog = new()
            {
                InitialDirectory = "C:\\",
                IsFolderPicker = true
            };
            if (dialog.ShowDialog() != CommonFileDialogResult.Ok)
                return;

            string DestDir = dialog.FileName;
            //#pragma warning restore CA1416 // Validate platform compatibility

            string otherDestDir = $"{DestDir}.others";
            string vidDestDir = $"{DestDir}.vid";

            List<FileInfo> jpgFiles = new(1000);
            List<string> otherFiles = new(1000);
            List<string> videoFiles = new(1000);

            int prefixLength = aSrcDir.Length;
            foreach (FileInfo fl in new DirectoryInfo(aSrcDir).GetFiles("*.*", SearchOption.AllDirectories))
            {
                if (fl.Name.Equals("Thumbs.db", StringComparison.OrdinalIgnoreCase)) //Skip thumbnails
                    continue;

                if (NbMedia.VideoExtensions.Contains(fl.Extension.ToLower()))
                    videoFiles.Add(fl.FullName[prefixLength..]);
                else if (fl.Extension.Equals(".jpg", StringComparison.OrdinalIgnoreCase))
                    jpgFiles.Add(fl);
                else
                    otherFiles.Add(fl.FullName[prefixLength..]);
            }

            int totalFiles = videoFiles.Count + jpgFiles.Count + otherFiles.Count;
            //foreach (string file in files)
            ParallelOptions parrOpt = new() { MaxDegreeOfParallelism = 1 }; //TODO change to 6

            Parallel.For(0, jpgFiles.Count, parrOpt, i =>
            {
                var srcFi = jpgFiles[i];
                string destFile = Path.Combine(DestDir, srcFi.Name);
                FileInfo dstFi = new(destFile);
                if (!dstFi.Exists)
                {
                    NbFs.CreateDirRecursive(dstFi);

                    string pars = String.Format(@"-out jpeg -ratio -resize {2}% 0 -o ""{0}"" ""{1}""", destFile, srcFi.FullName, aPercentage);
                    ProcessStartInfo psi = new("nconvert.exe", pars) { CreateNoWindow = true };

                    Process p = Process.Start(psi) ?? throw new Exception($"Process {psi.FileName} start returned null");
                    p.WaitForExit();

                    File.SetCreationTime(destFile, srcFi.CreationTime);
                    File.SetLastWriteTime(destFile, srcFi.LastWriteTime);
                    File.SetLastAccessTime(destFile, srcFi.LastAccessTime);

                    //aProg.ReportProgress(i, totalFiles);
                    //aProg.CancelIfRequested();
                }
            }
            );

            CopyFilesWithProgress(videoFiles, totalFiles, aSrcDir, vidDestDir);
            CopyFilesWithProgress(otherFiles, totalFiles, aSrcDir, otherDestDir);

            /*for (int i = 0; i < otherFiles.Count; ++i)
            {
                var otherFile = otherFiles[i];
                string destFile = otherDestDir + otherFile;      //otherFile contains the slash
                FileInfo fi = new FileInfo(destFile);
                if (!fi.Exists)
                {
                    NbDir.CreateDirRecursive(fi.Directory);
                    File.Copy(aSrcDir + otherFile, destFile);
                }

                aProg.ReportProgress(i, totalFiles);
                aProg.CancelIfRequested();
            }*/
        }

        private static void CopyFilesWithProgress(IList<string> aFileList, int _, string aSrcDir, string aDstDir) //, IReportProgress aProg
        {
            for (int i = 0; i < aFileList.Count; ++i)
            {
                var otherFile = aFileList[i];
                string destFile = aDstDir + otherFile;      //otherFile contains the slash
                FileInfo fi = new(destFile);
                if (!fi.Exists)
                {
                    NbFs.CopyFileSafe(new FileInfo(Path.Combine(aSrcDir, otherFile)), new FileInfo(destFile));
                }

                //aProg.ReportProgress(i, totalFiles);
                //aProg.CancelIfRequested();
            }
        }

    }

}
