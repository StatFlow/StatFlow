﻿using static Doer.Logic.MinecraftLogic;

namespace Doer.Logic
{
    public partial class MinecraftForm : Form
    {
        readonly KeyboardHook hook = new();

        public MinecraftForm()
        {
            InitializeComponent();

            // register the control + alt + F12 combination as hot key.
            hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.Q, () => BtTrade_Click(btTrade1, EventArgs.Empty));
            hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.A, () => BtTrade_Click(btTrade2, EventArgs.Empty));
            hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.Z, () => BtTrade_Click(btTrade3, EventArgs.Empty));
            hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.F, () => BtStepForwBack_Click(btMoveForw, EventArgs.Empty));
            hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.V, () => BtStepForwBack_Click(btMoveBack, EventArgs.Empty));

            hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.X, () => BtnPlaceBlocks_Click(bt_PlaceBlockLeft, EventArgs.Empty));
            hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.C, () => BtnPlaceBlocks_Click(bt_PlaceBlockRight, EventArgs.Empty));

            //hook.RegisterHotKey(Logic.ModifierKeys.Control, Keys.Apps, () => Test()); //Hook for App button (context menu)
        }

        public Task ShowAsync(IWin32Window owner)
        {
            var tcs = new TaskCompletionSource<bool>();
            this.FormClosed += (snd, arg) => tcs.SetResult(true);
            Show(owner);
            return tcs.Task;
        }

        private void BtTrade_Click(object sender, EventArgs e)
        {
            if (!Int32.TryParse(tbTradeDelay.Text, out int delay)) //TODO: Check how to use validation
                throw new Exception("Provide delay in milliseconds");

            var btnText = (sender as Button)?.Text ?? throw new Exception("Sender is not button");
            if (!Int32.TryParse(btnText.AsSpan(btnText.Length - 1, 1), out int row))
                throw new Exception("Can't parse a row out of button name");

            if (!Int32.TryParse(tbTradeCells.Text, out int cells))
                throw new Exception("Delay cell should have a number");

            MinecraftLogic.TradeCarrots(delay, row - 1, cells - 1);
        }

        private async void BtnPlaceBlocks_Click(object sender, EventArgs e)
        {
            if (!Int32.TryParse(tb1Times.Text, out int times)) //TODO: Check how to use validation
                throw new Exception("Times cell should have a number");

            if (!Double.TryParse(cbBlockPlaceDelay.Text, out double delay))
                throw new Exception("Delay cell should have a number");

            if (sender is not Button btn)
                throw new Exception($"Sender is not a button in {nameof(BtnPlaceBlocks_Click)}");

            var dir = (MinecraftLogic.Direction)Enum.Parse(typeof(MinecraftLogic.Direction), btn.Text, ignoreCase: true);
            if (ch_TwoBlocks.Checked)
            {
                delay /= 2;
                times *= 2;
            }
            int startDelay = e == null ? 500 : 2500; //If EventArgs is not null - the button was pressed, otherwise the shortcut
            await MinecraftLogic.PlaceBlock(times, delay, dir, startDelay);
        }

        private void Button2_Click(object sender, EventArgs e) => MinecraftLogic.CraftWrittenBooks();

        private async void BtStepForwBack_Click(object sender, EventArgs e)
        {
            var btnText = (sender as Button)?.Text ?? throw new ArgumentException("Sender is not a button");
            bool isForward = btnText == "Forw";

            if (!Double.TryParse(tbStepTime.Text, out double stepTime)) //TODO: Check how to use validation
                throw new Exception("Step time should have a number");

            if (!Double.TryParse(tbStepStayTime.Text, out double stepStay))
                throw new Exception("Stay cell should have a number");

            if (!Int32.TryParse(tbStepRepeat.Text, out var repeat))
                throw new Exception("Delay cell should have a number");


            await Step(stepTime, stepStay, repeat, isForward);
        }

        private async void BtPlantAndHoe_Click(object sender, EventArgs e)
        {
            if (!Int32.TryParse(tbPlantAndHoe.Text, out int loopCnt)) //TODO: Check how to use validation
                throw new Exception("Plant and how cell should have a number");

            await Task.Delay(3000);

            using (var walk = new HoldButton(InpSim.Value, WindowsInput.Native.VirtualKeyCode.VK_D))
            {
                for (int i = 0; i < loopCnt; ++i)
                {
                    await Task.Delay(700);
                    InpSim.Value.Mouse.LeftButtonClick();
                }
            }
            await Task.Delay(700);
        }
    }
}
