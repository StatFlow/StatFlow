﻿using Wf = System.Windows.Forms;

namespace Doer.Logic
{
    public partial class Key : Form
    {
        private readonly Wf.Timer Down4;
        private readonly Random Rnd;
        readonly KeyboardHook hook = new KeyboardHook();
        private readonly NbWpfLib.NbSpeech Speech;

        public Key()
        {
            InitializeComponent();

            Speech = new NbWpfLib.NbSpeech();
            Rnd = new Random();
            Down4 = new Wf.Timer();
            Down4.Tick += Down4_Tick;

            // Configure the audio output.   
            //synth.SetOutputToDefaultAudioDevice();

            // register the event that is fired after the key press.
            //hook.KeyPressed += new EventHandler<KeyPressedEventArgs>(Hook_KeyPressed);
            // register the control + alt + F12 combination as hot key.
            try
            {
                hook.RegisterHotKey(Logic.ModifierKeys.Control | Logic.ModifierKeys.Alt, Keys.F12, async () => await FlipKeyPress());
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
        }

        async Task FlipKeyPress()
        {
            if (checkBox1.Checked)
            {
                checkBox1.Checked = false;
                await Speech.Say("Key Press disabled"); // Create a prompt from a string.  
            }
            else
            {
                checkBox1.Checked = true;
                await Speech.Say("Key Press enabled"); // Create a prompt from a string.  
            }
        }

        private void CheckBox1_CheckedChanged(object? sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Down4.Interval = (Rnd.Next(0, 60) + 200) * 1000;
                Down4.Start();
            }
            else
            {
                Down4.Stop();
            }

        }

        private void Down4_Tick(object? sender, EventArgs e)
        {
            Down4.Interval = (Rnd.Next(0, 60) + 200) * 1000;
            Down4.Start();

            MinecraftLogic.PressButton(WindowsInput.Native.VirtualKeyCode.NEXT, 100);
        }


        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            Down4.Dispose();
            hook.Dispose();
            Speech.Dispose();
        }
    }
}
