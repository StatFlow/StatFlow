﻿using System.Runtime.InteropServices;
using System.Diagnostics;

using WindowsInput;
using WindowsInput.Native;

namespace Doer.Logic
{
    internal class McClicker
    {
        public readonly InputSimulator InpS;
        public int Pause { get; set; } = 50;

        internal McClicker()
        {
            InpS = new InputSimulator();
        }

        internal void Transfer(Point cell, Point dst)
        {
            InpS.Mouse.MoveMouseToPxHd(cell.X, cell.Y).LeftButtonClick().Sleep(Pause)
                      .MoveMouseToPxHd(dst.X, dst.Y).LeftButtonClick().Sleep(Pause);
        }

        internal void Click(Point cell)
        {
            InpS.Mouse.MoveMouseToPxHd(cell.X, cell.Y).LeftButtonClick().Sleep(Pause);
        }

        /// <summary>
        /// If ShiftClick is the first command - initialize the UI with simple click at 50-50 first
        /// </summary>
        /// <param name="cell"></param>
        internal void ShiftClick(Point cell)
        {
            InpS.Keyboard.KeyDown(VirtualKeyCode.LSHIFT) //.Sleep(Pause)
                .Mouse.MoveMouseToPxHd(cell.X, cell.Y).LeftButtonClick().Sleep(Pause)
                .Keyboard.KeyUp(VirtualKeyCode.LSHIFT); //.Sleep(pauseMs)
        }
    }

    public class HoldButton : IDisposable
    {
        public readonly VirtualKeyCode Button;
        public readonly IInputSimulator Inp;

        public HoldButton(IInputSimulator inp, VirtualKeyCode button)
        {
            Button = button;
            Inp = inp;
            switch (Button)
            {
                case VirtualKeyCode.LBUTTON:
                    Inp.Mouse.LeftButtonDown();
                    break;
                case VirtualKeyCode.RBUTTON:
                    Inp.Mouse.RightButtonDown();
                    break;
                default:
                    Inp.Keyboard.KeyDown(Button);
                    break;
            }
        }

        public void Dispose()
        {
            switch (Button)
            {
                case VirtualKeyCode.LBUTTON:
                    Inp.Mouse.LeftButtonUp();
                    break;
                case VirtualKeyCode.RBUTTON:
                    Inp.Mouse.RightButtonUp();
                    break;
                default:
                    Inp.Keyboard.KeyUp(Button);
                    break;
            }

        }
    }

    /*public class HoldMouseButton : IDisposable
    {
        public readonly MouseButtons Button;
        public readonly IInputSimulator Inp;

        public HoldMouseButton(IInputSimulator inp, MouseButtons mouseButtons)
        {
            Button = mouseButtons;
            Inp = inp;
            switch (mouseButtons)
            {
                case MouseButtons.Left:
                    Inp.Mouse.LeftButtonDown();
                    break;
                case MouseButtons.Right:
                    Inp.Mouse.RightButtonDown();
                    break;
                default:
                    throw new Exception($"Unsupported mouse button: {mouseButtons}");
            }
        }

        public void Dispose()
        {
            switch (Button)
            {
                case MouseButtons.Left:
                    Inp.Mouse.LeftButtonUp();
                    break;
                case MouseButtons.Right:
                    Inp.Mouse.RightButtonUp();
                    break;
                default:
                    throw new Exception($"Unsupported mouse button: {Button}");
            }
        }
    }*/


    public static class MinecraftLogic
    {
        const int InventoryCellSize = 75;
        const int RecipeBookCellSize = 100;

        static Point TradeDst = new(1319, 387);
        static Point TradeSrc = new(990, 387);
        static Point TradeInventoryTopLeft = new(879, 572);

        static Point CraftTableTopLeft = new(1068, 305);
        static Point CraftDst = new(1444, 376);
        static Point CraftInventoryTopLeft = new(980, 572);
        static Point CraftInventoryBottomRight = new(CraftInventoryTopLeft.X + 8 * InventoryCellSize, CraftInventoryTopLeft.Y + 3 * InventoryCellSize);

        static Point RecipeBookTopLeft = new(415, 375);

        public static Lazy<IInputSimulator> InpSim = new(() => new InputSimulator());
        internal static Lazy<McClicker> McClick = new(() => new McClicker());

        internal enum Direction { Left, Right, Forward, Back };
        internal static VirtualKeyCode DirectionToKey(Direction dir)
        {
            return dir switch
            {
                Direction.Left => VirtualKeyCode.VK_A,
                Direction.Right => VirtualKeyCode.VK_S,
                Direction.Forward => VirtualKeyCode.RBUTTON,//Mouse button
                Direction.Back => VirtualKeyCode.VK_V,
                _ => throw new NbExceptionEnum<Direction>(dir),
            };
            ;
        }

        internal static async Task PlaceBlock(int times, double delay, Direction dir, int startDelay)
        {
            await Task.Delay(startDelay); //Wait before start
            int delInt = (int)(delay * 1000);

            using var walk = new HoldButton(InpSim.Value, DirectionToKey(dir));
            for (int i = 0; i < times; i++)
            {
                PressButton(VirtualKeyCode.VK_D);
                await Task.Delay(delInt);
            }
        }

        internal static async Task Step(double stepTime, double stepStay, int repeat, bool isForward)
        {
            await Task.Delay(500); //Wait before start
            int stepStayInt = (int)(stepStay * 1000);
            int stepTimeInt = (int)(stepTime * 1000);

            for (int i = 0; i < repeat; i++)
            {
                using (var walk = new HoldButton(InpSim.Value, DirectionToKey(isForward  ? Direction.Forward : Direction.Back)))
                {
                    Thread.Sleep(stepTimeInt);
                }
                await Task.Delay(stepStayInt);
                Debug.WriteLine("Stop wating");
            }
        }

        public static IEnumerable<Point> ScanInventory(Point start)
        {
            return Enumerable.Range(0, 4).SelectMany(r => Enumerable.Range(0, 9)
                .Select(c => new Point(c * InventoryCellSize + start.X, r * InventoryCellSize + start.Y)));
        }

        public static IEnumerable<Point> ScanCraftingTable()
        {
            return Enumerable.Range(0, 3).SelectMany(r => Enumerable.Range(0, 3)
                .Select(c => new Point(c * InventoryCellSize + CraftTableTopLeft.X, r * InventoryCellSize + CraftTableTopLeft.Y)));
        }

        internal static void CraftWrittenBooks()
        {
            Thread.Sleep(500);
            //Start with book in the bottom left corner

            var Clk = McClick.Value;
            Clk.Click(new Point(50, 50));
            Clk.ShiftClick(RecipeBookTopLeft);  //Shift-click first recipe
            Clk.ShiftClick(CraftDst);           //Shift-click target

            //Right bottom corner to the top left crafting spot
            Clk.Transfer(CraftInventoryBottomRight, CraftTableTopLeft);

            CraftWrittenBooks1Cycle();
        }

        internal static void CraftWrittenBooks1Cycle()
        {
            var invEnum = ScanInventory(CraftInventoryTopLeft).Reverse().GetEnumerator();
            var Clk = McClick.Value;

            bool inventoryRemaining = invEnum.MoveNext(); //Skip first cell for convenience
            do
            {
                foreach (var craftPlace in ScanCraftingTable().Skip(1)) //One is left for the original
                {
                    inventoryRemaining = invEnum.MoveNext();
                    if (!inventoryRemaining)
                        break;

                    Clk.Transfer(invEnum.Current, craftPlace);
                }
                Clk.ShiftClick(CraftDst);
            } while (inventoryRemaining);
        }


        /// <summary>
        /// Trades all items from the row (1-3), collecting the emeralds in the bottom left cell
        /// </summary>
        /// <param name="rowToUse"></param>
        public static void TradeCarrots(int delay, int rowToUse, int cells)
        {
            for (int i = 0; i <= cells; ++i) //How many cells in the row to use
            {
                TradeCell(delay, TradeInventoryTopLeft + new Size(InventoryCellSize * i, InventoryCellSize * rowToUse));
            }
        }

        public static void TradeCell(int pauseMs, Point cell)
        {
            var Clk = McClick.Value;
            Clk.Pause = pauseMs;
            Clk.Transfer(cell, TradeSrc);
            Clk.ShiftClick(TradeDst);
            Clk.ShiftClick(TradeSrc);

            //InpSim.Value
            //.Mouse.MoveMouseToPxHd(cell.X, cell.Y).LeftButtonClick().Sleep(pauseMs)
            //      .MoveMouseToPxHd(TradeSrc.X, TradeSrc.Y).LeftButtonClick().Sleep(pauseMs)

            //.Keyboard.KeyDown(VirtualKeyCode.LSHIFT)//.Sleep(pauseMs)
            //.Mouse.MoveMouseToPxHd(TradeDst.X, TradeDst.Y).LeftButtonClick().Sleep(pauseMs)
            //.Keyboard.KeyUp(VirtualKeyCode.LSHIFT)//.Sleep(pauseMs)

            //.Mouse.MoveMouseToPxHd(TradeSrc.X, TradeSrc.Y).LeftButtonClick().Sleep(pauseMs)
            //      .MoveMouseToPxHd(cell.X, cell.Y).LeftButtonClick().Sleep(pauseMs);
        }

        /*private static int SendKey(string procName, string fileWith)
{
    // Get a handle to the Calculator application. The window class
    // and window name were obtained using the Spy++ tool.
    //SunAwtCanvas  SunAwtComponent SunAwtFrame
    IntPtr calculatorHandle = FindWindow("SunAwtFrame", null);

    // Verify that Calculator is a running process.
    if (calculatorHandle == IntPtr.Zero)
    {
        Console.WriteLine("Calculator is not running.");
        return -1;
    }

    //IntPtr calculatorHandle = FindWindow("WindowsForms10.Window.8.app.0.2b89eaa_r16_ad1", "LDNDWM473437 - Desktop Viewer");

    Process[] processes = Process.GetProcessesByName(procName);
    foreach (Process proc in processes)
    {
        var res = SetForegroundWindow(proc.MainWindowHandle);  //proc.MainWindowHandle
        for (int i = 0; i < 5; ++i)
        {
            SendKeys.SendWait("1");
            Thread.Sleep(500);
            SendKeys.SendWait("{BACKSPACE}");


            Thread.Sleep(3000);
        }

    return 0;
}*/


        /*
            Key	     Make  Break		Key    Make  Break

            Backspace     0E    8E			F1	3B    BB
            Caps Lock     3A    BA			F2	3C    BC
            Enter	      1C    9C			F3	3D    BD
            Esc	          01    81			F4	3E    BE
            Left Alt      38    B8			F7	41    C1
            Left Ctrl     1D    9D			F5	3F    BF
            Left Shift    2A    AA			F6	40    C0
            Num Lock      45    C5			F8	42    C2
            Right Shift   36    B6			F9	43    C3
            Scroll Lock   46    C6			F10	44    C4
            Space	      39    B9			F11	57    D7
            Sys Req (AT)  54    D4			F12	58    D8
            Tab	          0F    8F

                    Keypad Keys		       Make   Break

                    Keypad 0  (Ins)		52	D2
                    Keypad 1  (End) 		4F	CF
                    Keypad 2  (Down arrow)	50	D0
                    Keypad 3  (PgDn)		51	D1
                    Keypad 4  (Left arrow)	4B	CB
                    Keypad 5			4C	CC
                    Keypad 6  (Right arrow)	4D	CD
                    Keypad 7  (Home)		47	C7
                    Keypad 8  (Up arrow)	48	C8
                    Keypad 9  (PgUp)		49	C9
                    Keypad .  (Del) 		53	D3
                    Keypad *  (PrtSc)		37	B7
                    Keypad -			4A	CA
                    Keypad +			4E	CE

                   Key    Make  Break	       Key    Make  Break

                A      1E    9E 		N      31    B1
                B      30    B0 		O      18    98
                C      2E    AE 		P      19    99
                D      20    A0 		Q      10    90
                E      12    92 		R      13    93
                F      21    A1 		S      1F    9F
                G      22    A2 		T      14    94
                H      23    A3 		U      16    96
                I      17    97 		V      2F    AF
                J      24    A4 		W      11    91
                K      25    A5 		X      2D    AD
                L      26    A6 		Y      15    95
                M      32    B2 		Z      2C    AC

                   Key    Make  Break	       Key    Make  Break

                1      02    82 		-      0C    8C
                2      03    83 		=      0D    8D
                3      04    84 		[      1A    9A
                4      05    85 		]      1B    9B
                5      06    86 		;      27    A7
                6      07    87 		'      28    A8
                7      08    88 		`      29    A9
                8      09    89 		\      2B    AB
                9      0A    8A 		,      33    B3
                0      0B    8B 		.      34    B4
                                        /      35    B5

        */

        // Get a handle to an application window.
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        // Activate an application window.
        [DllImport("USER32.DLL")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

#pragma warning disable IDE0066 // Convert switch statement to expression
        public static byte ScanCode(VirtualKeyCode vk)
        {

            switch (vk)
            {
                case VirtualKeyCode.VK_A: return 0x1E;
                case VirtualKeyCode.VK_B: return 0x30;
                case VirtualKeyCode.VK_C: return 0x2E;
                case VirtualKeyCode.VK_D: return 0x20;
                case VirtualKeyCode.VK_E: return 0x12;
                case VirtualKeyCode.VK_F: return 0x21;
                case VirtualKeyCode.VK_G: return 0x22;
                case VirtualKeyCode.VK_H: return 0x23;
                case VirtualKeyCode.VK_I: return 0x17;
                case VirtualKeyCode.VK_J: return 0x24;
                case VirtualKeyCode.VK_K: return 0x25;
                case VirtualKeyCode.VK_L: return 0x26;
                case VirtualKeyCode.VK_M: return 0x32;
                case VirtualKeyCode.VK_N: return 0x31;
                case VirtualKeyCode.VK_O: return 0x18;
                case VirtualKeyCode.VK_P: return 0x19;
                case VirtualKeyCode.VK_Q: return 0x10;
                case VirtualKeyCode.VK_R: return 0x13;
                case VirtualKeyCode.VK_S: return 0x1F;
                case VirtualKeyCode.VK_T: return 0x14;
                case VirtualKeyCode.VK_U: return 0x16;
                case VirtualKeyCode.VK_V: return 0x2F;
                case VirtualKeyCode.VK_W: return 0x11;
                case VirtualKeyCode.VK_X: return 0x2D;
                case VirtualKeyCode.VK_Y: return 0x15;
                case VirtualKeyCode.VK_Z: return 0x2C;

                case VirtualKeyCode.ESCAPE: return 0x1;
                case VirtualKeyCode.VK_1: return 0x2;
                case VirtualKeyCode.VK_2: return 0x3;
                case VirtualKeyCode.VK_3: return 0x4;
                case VirtualKeyCode.VK_4: return 0x5;
                case VirtualKeyCode.VK_5: return 0x6;
                case VirtualKeyCode.VK_6: return 0x7;
                case VirtualKeyCode.VK_7: return 0x8;
                case VirtualKeyCode.VK_8: return 0x9;
                case VirtualKeyCode.VK_9: return 0x0A;
                case VirtualKeyCode.VK_0: return 0x0B;
                case VirtualKeyCode.OEM_MINUS: return 0x0C;
                case VirtualKeyCode.OEM_PLUS: return 0x0D;
                case VirtualKeyCode.BACK: return 0x0E;
                case VirtualKeyCode.TAB: return 0x0F;


                /*case VirtualKeyCode.VK_[: return 0x1A;
                case VirtualKeyCode.VK_]: return 0x1B;
                case VirtualKeyCode.VK_;: return 0x27;
                case VirtualKeyCode.VK_': return 0x28;
                case VirtualKeyCode.VK_`: return 0x29;
                case VirtualKeyCode.VK_\: return 0x2B;
                case VirtualKeyCode.VK_,: return 0x33;
                case VirtualKeyCode.VK_.: return 0x34;
                case VirtualKeyCode.VK_Enter: return 0x      1C;
                case VirtualKeyCode.VK_Left Alt: return 0x38;*/
                case VirtualKeyCode.LCONTROL: return 0x1D;
                case VirtualKeyCode.LSHIFT: return 0x2A;
                /*case VirtualKeyCode.VK_Num Lock: return 0x45;
                case VirtualKeyCode.VK_Right Shift: return 0x36;
                case VirtualKeyCode.VK_Scroll Lock: return 0x46;
                case VirtualKeyCode.VK_Space: return 0x39;
                case VirtualKeyCode.VK_Sys Req (AT) : return 0x54;*/

                case VirtualKeyCode.CAPITAL: return 0x3A;
                case VirtualKeyCode.F1: return 0x3B;
                case VirtualKeyCode.F2: return 0x3C;
                case VirtualKeyCode.F3: return 0x3D;
                case VirtualKeyCode.F4: return 0x3E;
                case VirtualKeyCode.F7: return 0x41;
                case VirtualKeyCode.F5: return 0x3F;
                case VirtualKeyCode.F6: return 0x40;
                case VirtualKeyCode.F8: return 0x42;
                case VirtualKeyCode.F9: return 0x43;
                case VirtualKeyCode.F10: return 0x44;
                case VirtualKeyCode.F11: return 0x57;
                case VirtualKeyCode.F12: return 0x58;

                case VirtualKeyCode.HOME: return 0x47;
                case VirtualKeyCode.UP: return 0x48;
                case VirtualKeyCode.PRIOR: return 0x49; //Page Up
                //-  4A
                case VirtualKeyCode.LEFT: return 0x4B;
                //Center 4B
                case VirtualKeyCode.RIGHT: return 0x4D;
                //+ 4E
                case VirtualKeyCode.END: return 0x4F;
                case VirtualKeyCode.DOWN: return 0x50;
                case VirtualKeyCode.NEXT: return 0x51; //Page Down
                case VirtualKeyCode.INSERT: return 0x52;
                case VirtualKeyCode.DELETE: return 0x53;
                case VirtualKeyCode.OEM_102: return 0x35; //Backlash?


                default: throw new Exception($"No scan code for '{vk}'");
            }
        }
#pragma warning restore IDE0066 // Convert switch statement to expression

        /// <summary>
        /// The dx and dy parameters contain normalized absolute coordinates.
        /// If not set, those parameters contain relative data: the change in position since the last reported position.
        /// This flag can be set, or not set, regardless of what kind of mouse or mouse-like device, if any, is connected to the system.
        /// For further information about relative mouse motion, see the following Remarks section.
        /// </summary>
        //private const UInt32 MOUSEEVENTF_ABSOLUTE = 0x8000;

        private const UInt32 MOUSEEVENTF_LEFTDOWN = 0x0002; //The left button is down.
        private const UInt32 MOUSEEVENTF_LEFTUP = 0x0004; //The left button is up.
        /*private const UInt32 MOUSEEVENTF_MIDDLEDOWN = 0x0020; //The middle button is down.
        private const UInt32 MOUSEEVENTF_MIDDLEUP = 0x0040; //The middle button is up.
        private const UInt32 MOUSEEVENTF_MOVE = 0x0001; //Movement occurred.
        private const UInt32 MOUSEEVENTF_RIGHTDOWN = 0x0008; //The right button is down.
        private const UInt32 MOUSEEVENTF_RIGHTUP = 0x0010; //The right button is up.
        private const UInt32 MOUSEEVENTF_WHEEL = 0x0800; //The wheel has been moved, if the mouse has a wheel.The amount of movement is specified in dwData
        private const UInt32 MOUSEEVENTF_XDOWN = 0x0080; //An X button was pressed.
        private const UInt32 MOUSEEVENTF_XUP = 0x0100; //An X button was released.
        private const UInt32 MOUSEEVENTF_HWHEEL = 0x01000; //The wheel button is tilted.*/

#pragma warning disable IDE1006 // Naming Styles

        [DllImport("user32.dll")]
        private static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, uint dwExtraInf);

        /*private static void ClickMouse(Point point)
        {
            Cursor.Position = point;
            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);//make left button down
            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);//make left button up
        }*/


        public static void PressButton(VirtualKeyCode keyCode, int timeout = 0)
        {
            byte scCode = ScanCode(keyCode);
            keybd_event((byte)keyCode, scCode, 0, 0);
            if (timeout > 0)
                Thread.Sleep(timeout);
            keybd_event((byte)keyCode, scCode, KEYEVENTF_KEYUP, 0);
        }

        [DllImport("user32.dll", SetLastError = true)]
        static extern void keybd_event(byte bVk, byte bScan, int dwFlags, int dwExtraInfo);

        public const int KEYEVENTF_EXTENDEDKEY = 0x0001; //Key down flag
        public const int KEYEVENTF_KEYUP = 0x0002; //Key up flag
        public const int VK_LCONTROL = 0xA2; //Left Control key code
        public const int A = 0x41; //A key code
        public const int C = 0x43; //C key code

#pragma warning restore IDE1006 // Naming Styles
    }
}
