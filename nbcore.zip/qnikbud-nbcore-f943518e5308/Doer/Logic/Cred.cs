﻿using WindowsInput;
using WindowsInput.Native;
using NbCore.Crypto;

namespace Doer.Logic
{
    class Cred
    {
        private readonly ListView Lv;

        internal Cred(ListView lvCreds)
        {
            Lv = lvCreds;
        }

        internal void PopulateList()
        {
            Lv.Items.Add("AWS Training"); //https://www.aws.training/SignIn?returnUrl=%2F
        }

        internal async Task Invoke(string _)
        {
            var pss = NbCrypto.DecryptBase64("aoOzvgi8ulj63aA3MziHXEsAsDulISET");

            await Task.Delay(2000);
            var inpS = new InputSimulator();
            inpS.Keyboard.TextEntry("1120uc@gmail.com").KeyPress(VirtualKeyCode.TAB)
                .TextEntry(pss).KeyPress(VirtualKeyCode.RETURN);

        }
    }
}
