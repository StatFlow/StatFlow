﻿using System.Data;
using System.Text.RegularExpressions;

namespace Doer.Logic;

public partial class Sansa : Form
{
    public Sansa()
    {
        InitializeComponent();
    }

    private void BtRun_Click(object sender, EventArgs e)
    {
        new SansaLogic().Run();
    }
}

public class SansaLogic
{
    private readonly string DiskInner;
    private readonly string DiskSd;

    private readonly string MainPath;
    private readonly string Playlists;

    private const string MicroSdSubDir = @"/<microSD1>/";
    private readonly Random fRnd = new();

    private static readonly string[] AudioFiles = new string[] { "*.mp3", "*.m4a", "*.ogg" };

    public SansaLogic()
    {
        var drv = DriveInfo.GetDrives().Where(d => d.IsReady && d.VolumeLabel.StartsWith("Sansa", StringComparison.OrdinalIgnoreCase)).ToList();
        switch (drv.Count)
        {
            case 0: throw new Exception("No sansa drived found");
            case 1: throw new Exception("Only sansa drive found");
            case 2: break;
            default: throw new Exception($"Too many ({drv.Count}) sansa drives found:");
        }
        DiskInner = drv[0].Name;
        DiskSd = drv[1].Name;
        MainPath = DiskInner + @"MUSIC\";
        Playlists = DiskInner + @"Playlists\";
    }


    public void Run()
    {
        var list = LoadSongs();
        //CreateAerostatPlaylists(list);
        CreateRandomPlaylists(songs: list, number: 100, numOfSongs: 30);
    }


    private void CreateRandomPlaylists(List<string> songs, int number, int numOfSongs)
    {
        for (int i = 1; i <= number; ++i)
        {
            string playlistFile = Path.Combine(Playlists, $"rand_{i:d2}.m3u8");
            SavePlayList(playlistFile, Enumerable.Range(0, numOfSongs).Select(_ => FetchRandom(songs)));
        }
    }

    /*private static readonly Regex AeroNumberRegex = new(@"(\d+).*\.mp3$");

    private bool CreateAerostatPlaylists(List<string> songs)
    {
        string aerostat = DiskInner + @"Aerostat\";
        string playlists = DiskInner + @"Playlists\";

        if (!Directory.Exists(aerostat))
            return false;

        int cnt = 0;
        foreach (var file in NbFs.ListFilesRecursively(new DirectoryInfo(aerostat), AudioFiles).Select(f => f.FullName.Substring(2).Replace('\\', '/')))
        {
            var res = AeroNumberRegex.Match(file);
            if (!res.Success)
                throw new NbExceptionInfo(@"Can't get aerostat number out of {file}");
            string playlistFile = Path.Combine(playlists, $"aero_{res.Groups[1].Value}.m3u8");

            SavePlayList(playlistFile, NbExt.Yield(file).Concat(Enumerable.Range(0, 10).Select(_ => FetchRandom(songs))));
            cnt++;
        }
        return cnt > 0;
    }*/

    private string FetchRandom(List<string> list)
    {
        int ind = fRnd.Next(0, list.Count - 1);
        string res = list[ind];
        list.RemoveAt(ind);
        return res;
    }

    private List<string> LoadSongs() => new(
        NbFs.ListFilesRecursively(new DirectoryInfo(DiskSd), AudioFiles).Select(f => f.FullName.Replace(DiskSd, MicroSdSubDir).Replace('\\', '/')).Concat(
        NbFs.ListFilesRecursively(new DirectoryInfo(MainPath), AudioFiles).Select(f => f.FullName[2..].Replace('\\', '/'))));

    private static void SavePlayList(string fullName, IEnumerable<string> files) => File.WriteAllLines(fullName, files);

}
