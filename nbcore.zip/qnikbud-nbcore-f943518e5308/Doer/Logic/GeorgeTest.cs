﻿using NbCore.Crypto;
using WF = System.Windows.Forms;

namespace GeorgeTest
{
    public partial class GeorgeTest : Form
    {
        private readonly GeorgeConverter GeorConv;
        private readonly Random rnd = new();
        private readonly WF.Timer StatusTime = new();

        private char currentLetter = '\0';

        private static readonly List<Tuple<char, char>> mapRusSelected = new()
        {
Tuple.Create('й', 'ღ' ),
//{ 'ц', 'ჯ' },
//{ 'у', 'უ' },
//{ 'к', 'კ' },
Tuple.Create( 'е', 'ე' ),
Tuple.Create( 'н', 'ნ' ),
//{ 'г', 'გ' },
//{ 'ш', 'შ' },
//{ 'щ', 'წ' },
Tuple.Create( 'з', 'ზ' ),
//{ 'х', 'ხ' },
//{ 'ъ', 'ც' },

//{ 'ф', 'ფ' },
//{ 'ы', 'ძ' },
Tuple.Create( 'в', 'ვ' ),
//{ 'а', 'თ' },
Tuple.Create( 'п', 'ა' ),
//{ 'р', 'პ' },
//{ 'о', 'რ' },
//{ 'л', 'ო' },
Tuple.Create( 'д', 'ლ' ),
Tuple.Create( 'ж', 'დ' ),
//{ 'э', 'ჟ' },

//{ 'я', 'ჭ' },
//{ 'ч', 'ჩ' },
//{ 'с', 'ყ' },
Tuple.Create( 'м', 'ს' ),
Tuple.Create( 'и', 'მ' ),
Tuple.Create( 'т', 'ი' ),
//{ 'ь', 'ტ' },
//{ 'б', 'ქ' },
Tuple.Create( 'ю', 'ბ' ),

Tuple.Create( 'и', 'მ' ),
Tuple.Create( 'н', 'ნ' ),
Tuple.Create( 'е', 'ე' ),
Tuple.Create( 'и', 'მ' ),
Tuple.Create( 'н', 'ნ' ),
Tuple.Create( 'е', 'ე' ),


        };



        public GeorgeTest()
        {
            InitializeComponent();
            GeorConv = new GeorgeConverter();
            StatusTime.Tick += StatusTime_Tick;
            StatusTime.Interval = 3000;
        }

        private void StatusTime_Tick(object? sender, EventArgs e)
        {
            stMess.Text = String.Empty;
            StatusTime.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var ind = rnd.Next(0, mapRusSelected.Count);
            var pair = mapRusSelected.Skip(ind).First();
            if (currentLetter == pair.Item1)
                Form1_Load(sender, e); //Do not repeat letters - call random once more
            else
            {
                currentLetter = pair.Item1;
                label1.Text = pair.Item2.ToString();
            }
        }

        async private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 'A' && e.KeyChar <= 'z')
            {
                MessageBox.Show("Switch keyboard to Russian");
            }
            else if (e.KeyChar == currentLetter)
            {
                label1.Text += $"={currentLetter}";
                await Task.Delay(500);
                Form1_Load(sender, e);
            }
        }

        private void ConvertButton_Click(object sender, EventArgs e)
        {
            var text = Clipboard.GetData("UnicodeText") as string ?? throw new Exception("Clipboard doesn't contain text");
            var (res, count) = GeorConv.Convert(text);
            Clipboard.SetText(res);
            ShowStatus($"Converted {count} symbols");
        }



        private void ShowStatus(string mess)
        {
            stMess.Text = mess;
            StatusTime.Start();
        }



        /*private static Dictionary<char, char> mapRus = new Dictionary<char, char> {
{ 'й', 'ღ' },
{ 'ц', 'ჯ' },
{ 'у', 'უ' },
{ 'к', 'კ' },
{ 'е', 'ე' },
{ 'н', 'ნ' },
{ 'г', 'გ' },
{ 'ш', 'შ' },
{ 'щ', 'წ' },
{ 'з', 'ზ' },
{ 'х', 'ხ' },
{ 'ъ', 'ც' },

{ 'ф', 'ფ' },
{ 'ы', 'ძ' },
{ 'в', 'ვ' },
{ 'а', 'თ' },
{ 'п', 'ა' },
{ 'р', 'პ' },
{ 'о', 'რ' },
{ 'л', 'ო' },
{ 'д', 'ლ' },
{ 'ж', 'დ' },
{ 'э', 'ჟ' },

{ 'я', 'ჭ' },
{ 'ч', 'ჩ' },
{ 'с', 'ყ' },
{ 'м', 'ს' },
{ 'и', 'მ' },
{ 'т', 'ი' },
{ 'ь', 'ტ' },
{ 'б', 'ქ' },
{ 'ю', 'ბ' }};*/
    }
}
