﻿using Doer.Properties;
using DoerConfV1.Xml;
using NbCore.Crypto;
using NbWpfLib;

namespace Doer
{
    internal record ButtonAction(ToolbButton Btn, ToolbarsModel Mdl) : IDoerAction
    {
        public string Name => Btn.tooltip;
        public Task Run(IMainForm form) => Mdl.RunButton(Btn);
    }

    internal class ToolbarsModel
    {
        private readonly IMainForm MainForm;
        private readonly NbDictionary<string, string> RunParams = new(10, StringComparer.OrdinalIgnoreCase, "Variables to resolve URLs, such as %TXT%");

        private DoerConfV1.Xml.DoerConfV1? _conf;
        private DoerConfV1.Xml.DoerConfV1 Conf => _conf ?? throw new Exception("Configuration was not initialised");

        internal ToolbarsModel(IMainForm mainForm) => MainForm = mainForm;
        internal void Init(DoerConfV1.Xml.DoerConfV1 conf) => _conf = conf;

        internal void OnSearchTextUpdate(ListView.ListViewItemCollection items, string searchText)
        {
            var list = CreateActions(searchText).SelectNotNull(a => new ListViewItem(a.Name) { Tag = a }).ToArray();
            items.AddRange(list);
        }

        /// <summary>
        /// Create actions based on buttons
        /// </summary>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public IEnumerable<IDoerAction?> CreateActions(string searchText)
        {
            var list = Conf.toolbar_links.Safe().Concat(Conf.toolbar_search.Safe()).Concat(Conf.keyword_only.Safe()).ToList();
            var list2 = list.OfType<ToolbButton>().Concat(list.OfType<DropDownButton>().SelectMany(dd => dd.btn.Safe()));

            foreach (ToolbButton btn in list2)
            {
                string txt = btn.keywords ?? btn.tooltip;
                if ((txt.ContainsIC(searchText) || txt.ContainsIC(NbExt.RusEng(searchText))) && (btn.href is not null || btn.exec is not null)) //btn.search_href is not useful, because it needs user text
                    yield return new ButtonAction(btn, this);
            }
        }

        //Generic start process method used in buttons starting programs such as CloneSpy
        internal async Task GenericButton(object? sender, string userText)
        {
            switch (sender)
            {
                case ToolStripDropDownButton _: break;

                case ToolStripItem btn:
                    if (btn.Tag is string str) //Temporary code, support executable buttons in the config
                        btn.Tag = new ToolbButton() { exec = new BntExecInfo() { exec = str } };

                    ToolbButton btnDesc = btn.Tag as ToolbButton ?? throw new Exception($"Button {btn.Name} does not have the Tag set to ToolbButton");
                    await RunButton(btnDesc, userText);  //User text make no sense since it is substring for finding the Button Actions 
                    /*RunParams["%TXT%"] = System.Net.WebUtility.HtmlEncode(userText);

                    if(!String.IsNullOrWhiteSpace(btnDesc.pass))
                    {
                        var (yes, text) = NbDialogForm.Show("Title", "Password: "); //TODO: support password
                        var _ = text;
                        if (!yes)
                            return;
                    }

                    if (btnDesc.exec != null)
                    {
                        ExecExec(btnDesc.exec);
                        break;
                    }

                    if (btnDesc.search_href == null && btnDesc.href == null)
                        throw new Exception($"Neither search_href nor href are set in '{btn.Name}' button");

                    if (!String.IsNullOrEmpty(userText))
                        ExecHref(btnDesc.search_href ?? btnDesc.href);
                    else
                        ExecHref(btnDesc.href ?? btnDesc.search_href);

                    if (!String.IsNullOrWhiteSpace(btnDesc.clipboard_enc))
                    {
                        var dec = NbCrypto.DecryptBase64(btnDesc.clipboard_enc);
                        Clipboard.SetText(dec);
                    }*/

                    MainForm.CloseForm();
                    break;

                default:
                    if (sender == null)
                        throw new Exception($"Sender was not provided in GenericButton() method");
                    else
                        throw new Exception($"{sender?.GetType().Name} '{sender}' type is not supported, but called the Ts2Button_Click() method");
            }
        }

        internal Task RunButton(ToolbButton btnDesc, string? userText = null)
        {
            //Search text make no sense since it is substring for finding the Button Actions 
            if (userText != null)
                RunParams["%TXT%"] = System.Net.WebUtility.HtmlEncode(userText);

            if (!String.IsNullOrWhiteSpace(btnDesc.pass))
            {
                var (yes, text) = NbDialogForm.Show("Title", "Password: "); //TODO: support password
                var _ = text;
                if (!yes)
                    return Task.CompletedTask; ;
            }

            if (btnDesc.func != null)
            {
                return ExecFuncAsync(btnDesc.func, userText);
            }

            if (btnDesc.exec != null)
            {
                ExecExec(btnDesc.exec);
                return Task.CompletedTask;
            }

            if (btnDesc.search_href == null && btnDesc.href == null)
                throw new Exception($"Neither search_href nor href are set in '{btnDesc.tooltip}' button");

            if (!String.IsNullOrEmpty(userText))
                ExecHref(btnDesc.search_href ?? btnDesc.href);
            else
                ExecHref(btnDesc.href ?? btnDesc.search_href);

            if (!String.IsNullOrWhiteSpace(btnDesc.clipboard_enc))
            {
                var dec = NbCrypto.DecryptBase64(btnDesc.clipboard_enc);
                Clipboard.SetText(dec);
            }
            MainForm.CloseForm();
            return Task.CompletedTask;
        }

        private async Task ExecFuncAsync(BntFunctionInfo func, string? userText)
        {
            switch (func.func)
            {
                case nameof(ActionMoveMediaFiles): //TODO think about having all functions as actions
                    ActionMoveMediaFiles ammf = new();
                    await ammf.Run(MainForm);
                    return;
                
                default:
                    break;
            }

            if(func.func == "HumanPass")
            {
                var dec3 = NbCrypto.HumanReadablePass(29);
                Clipboard.SetText(dec3);
                MainForm.SetStatus("Generated password is saved into clipboard");
                return;
            }

            if (String.IsNullOrWhiteSpace(userText))  //TODO: Temporary solution
                throw new Exception($"The user input is empty");

            switch (func.func)
            {
                case "Encode":
                    var enc1 = NbCrypto.EncryptBase64(userText);
                    Clipboard.SetText(enc1);
                    MainForm.SetStatus("Encrypted message is in the clipboard");
                    break;

                case "Decode":
                    var dec1 = NbCrypto.DecryptBase64(userText);
                    Clipboard.SetText(dec1);
                    MainForm.SetStatus("Decrypted message is in the clipboard");
                    break;

                case "Deflate":
                    var enc2 = NbCrypto.ShrinkToSafe64(userText);
                    Clipboard.SetText(enc2);
                    MainForm.SetStatus("Deflated message is in the clipboard");
                    break;

                case "Inflate":
                    var dec2 = NbCrypto.ExpandFromSafe64(userText);
                    Clipboard.SetText(dec2);
                    MainForm.SetStatus("Inflated message is in the clipboard");
                    break;

                default:
                    throw new Exception($"Unsupported function {func.func} in button");
            }
        }

        private static void ExecExec(BntExecInfo exec)
        {
            DirectoryInfo? di = !String.IsNullOrEmpty(exec.work_dir) ? new DirectoryInfo(exec.work_dir) : null;
            List<string> pars = new(exec.param?.Length * 2 ?? 10);
            foreach (var p in exec.param.Safe())
            {
                if (!String.IsNullOrWhiteSpace(p.name))
                    pars.Add(p.name);
                if (!String.IsNullOrWhiteSpace(p.Value))
                    pars.Add(p.Value.Contains(' ') ? '"' + p.Value + '"' : p.Value);
            }

            NbProcess.FireAndForget(exec.exec, di, pars.ToArray());
        }

        private void ExecHref(BtnUrlInfo? urlInfo)
        {
            if (urlInfo == null)
                throw new Exception("UrlInfo was not provided");


            string hrefStr = urlInfo.GetString(RunParams); //Inject URL with parameters such as %TXT%

            if (!String.IsNullOrWhiteSpace(urlInfo.profile))
                NbProcess.FireAndForget(Conf.settings.firefox, null, "-P", urlInfo.profile, hrefStr);  //TODO: make async
            else
                NbProcess.FireAndForget(Conf.settings.firefox, null, hrefStr);
        }
    }
}
