﻿using System.Text;
using NbWin;

namespace DoerConfV1.Xml;

public partial class DoerConfV1
{
    private void Resolve()
    {
        DirectoryInfo iconDir = new(icons.default_dir);
        if (!iconDir.Exists)
            throw new Exception($"Default icon directory is not found: {iconDir.FullName}");

        //If icon is not described in XML - use default directory to load it on demand during resolving stage
        NbDictionary<string, Image> Images = new(20, StringComparer.OrdinalIgnoreCase, "Icons provided in xml", creator: n =>
        {
            FileInfo? icon = iconDir.GetFiles(n + ".*").OrderBy(f => f.Extension).FirstOrDefault();
            if (icon == null)
                throw new Exception($"Can't find icon '{n}' in default dir {iconDir.FullName}");
            return Image.FromFile(icon.FullName);
        });

        foreach (var icon in icons.Items.Safe())
            Images.Add(icon.name, icon.Load(icons.default_dir));

        Images.Add(String.Empty, new Bitmap(1, 1));

        toolbar_links.ForEachSafe(i => i.Resolve(Images));
        toolbar_search.ForEachSafe(i => i.Resolve(Images));
    }

    /*public string Setting(string name)
    {
        if (!parameters.TryGetValue(s => s.name.EqIC(name), out var sett))
            throw new Exception($"Setting '{name}' doens't exist");
        return sett.Value;
    }*/
}

public partial class BtnUrlInfo
{
    //http://rutracker.org/forum/tracker.php?max=1&nm=%TXT%

    public override string ToString() => GetString(null);

    public string GetString(IDictionary<string, string>? variables)
    {
        if (variables != null) //Replace the variables in URL as well as in the the separate parameters, because the variable could be a part of URL: https://www.google.com/maps/search/%TXT%
            foreach (var pair in variables)
                url = url.Replace(pair.Key, pair.Value);

        if (param == null || param.Length == 0)
            return url;

        StringBuilder bld = new(url);
        for (int i = 0; i < param.Length; i++)
        {
            var p = param[i];
            bld.Append(i == 0 ? '?' : '&');
            bld.Append(p.name).Append('=');

            if (variables?.TryGetValue(p.Value, out string? parValue) ?? false) //If variable is found in the dictionary - resolve
                bld.Append(parValue);
            else
                bld.Append(p.Value); //If not found - print the original value
        }
        return bld.ToString();
    }
}

public partial class ToolbarItem
{
    internal Image IconObj;
    internal void Resolve(NbDictionary<string, Image> images) => IconObj = images[icon];
}


public abstract partial class IconBase
{
    internal abstract Image Load(string defaultDir);
}

public partial class IconFile : IconBase
{
    private const int IconSize = 16;

    internal override Image Load(string defaultDir)
    {
        if (!Path.IsPathRooted(file))
            file = Path.Combine(defaultDir, file);

        if (hor == 0 && ver == 0)
            return Image.FromFile(file);

        Bitmap source = new(file);
        if (source.Width % IconSize != 0)
            throw new Exception($"File '{file}' width '{source.Width}' is not divisible by icon size {IconSize}");
        if (source.Height % IconSize != 0)
            throw new Exception($"File '{file}' height '{source.Height}' is not divisible by icon size {IconSize}");

        int horIcons = source.Width / IconSize;
        if (hor > horIcons)
            throw new Exception($"Image '{file}' contains {horIcons} columns of icons, but column #{hor} was requested (1-based) while loading image '{name}'");
        int verIcons = source.Height / IconSize;
        if (ver > verIcons)
            throw new Exception($"Image '{file}' contains {verIcons} rows of icons, but row #{ver} was requested (1-based) while loading image '{name}'");
        Rectangle rect = new((hor - 1) * IconSize, (ver - 1) * IconSize, IconSize, IconSize);

        Bitmap CroppedImage = source.Clone(rect, source.PixelFormat);
        return CroppedImage;
    }
}

public partial class IconBase64 : IconBase
{
    internal override Image Load(string _) => NbGraphics.ImageFromBase64(data);
}