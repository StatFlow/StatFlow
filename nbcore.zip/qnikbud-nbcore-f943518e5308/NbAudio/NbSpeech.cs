﻿using System.Speech.Synthesis;

namespace NbWpfLib;

//Needs windows SDK for network-dependent installation https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-6.0.406-windows-x64-installer
public sealed class NbSpeech : IDisposable
{
    private readonly SpeechSynthesizer Voice;

    public NbSpeech()
    {

        Voice = new SpeechSynthesizer();
        var a = Voice.GetInstalledVoices();

        var br = Voice.GetInstalledVoices().FirstOrDefault(v => v.VoiceInfo.Name.Contains("Bridget"));
        if (br != null)
            Voice.SelectVoice(br.VoiceInfo.Name);

        Voice.SetOutputToDefaultAudioDevice();
    }

    public Task Say(string text)
    {
        var taskCompSource = new TaskCompletionSource<bool>();
        Voice.SpeakAsync(text);

        EventHandler<SpeakCompletedEventArgs>? evt1 = null;
        evt1 = new EventHandler<SpeakCompletedEventArgs>((src, arg) =>
        {
            Voice.SpeakCompleted -= evt1;
            taskCompSource.SetResult(true);
        });

        Voice.SpeakCompleted += evt1;

        return taskCompSource.Task;
    }

    public Task SayToFile(string text, string fileName)
    {
        var taskCompSource = new TaskCompletionSource<bool>();
        Voice.SetOutputToWaveFile(fileName);
        Voice.SpeakAsync(text);

        EventHandler<SpeakCompletedEventArgs> evt1 = null;
        evt1 = new EventHandler<SpeakCompletedEventArgs>((src, arg) =>
        {
            Voice.SpeakCompleted -= evt1;
            Voice.SetOutputToDefaultAudioDevice();
            taskCompSource.SetResult(true);
        });

        Voice.SpeakCompleted += evt1;

        return taskCompSource.Task;
    }

      public void Dispose() => Voice?.Dispose();
}
