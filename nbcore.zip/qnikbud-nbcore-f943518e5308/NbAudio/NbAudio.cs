﻿using System.Speech.Synthesis;
using NAudio.Wave;

[assembly: System.Runtime.Versioning.SupportedOSPlatform("windows")]

//Needs windows SDK for network-dependent installation https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-6.0.406-windows-x64-installer
//Needs to be x86  (32bit) in order to pick up Bridget

namespace NbTools.Audio;

public sealed class NbAudio : IDisposable
{
    private readonly SpeechSynthesizer Voice;
    private readonly WaveOutEvent WaveDevice;

    public NbAudio()
    {
        WaveDevice = new WaveOutEvent();

        Voice = new System.Speech.Synthesis.SpeechSynthesizer();
        var a = Voice.GetInstalledVoices();

        var br = Voice.GetInstalledVoices().FirstOrDefault(v => v.VoiceInfo.Name.Contains("Bridget"));
        if (br != null)
            Voice.SelectVoice(br.VoiceInfo.Name);

        Voice.SetOutputToDefaultAudioDevice();
    }
    public Task PlayAudioFileSection(string fileName, TimeSpan from, TimeSpan length)
    {
        var ext = Path.GetExtension(fileName).ToLower();
        WaveStream a = ext switch
        {
            ".ogg" => new NAudio.Vorbis.VorbisWaveReader(fileName),
            _ => new AudioFileReader(fileName),
        };
        var taskCompSource = new TaskCompletionSource<bool>();
        EventHandler<StoppedEventArgs>? evt = null;
        evt = new EventHandler<StoppedEventArgs>((_, __) =>
        {
            WaveDevice.PlaybackStopped -= evt;
            a.Dispose();
            taskCompSource.SetResult(true);
        });

        WaveDevice.PlaybackStopped += evt;

        //Only PCM is supported
        a = new WaveOffsetStream(sourceStream: a, startTime: TimeSpan.Zero, sourceOffset: from, sourceLength: length);

        WaveDevice.Init(a);
        WaveDevice.Play();
        return taskCompSource.Task;
    }

    public Task PlayAudioFile(string fileName)
    {
        var ext = Path.GetExtension(fileName).ToLower();
        WaveStream a = ext switch
        {
            ".ogg" => new NAudio.Vorbis.VorbisWaveReader(fileName),
            _ => new AudioFileReader(fileName),
        };
        var taskCompSource = new TaskCompletionSource<bool>();
        EventHandler<StoppedEventArgs>? evt = null;
        evt = new EventHandler<StoppedEventArgs>((_, __) =>
        {
            WaveDevice.PlaybackStopped -= evt;
            a.Dispose();
            taskCompSource.SetResult(true);
        });

        WaveDevice.PlaybackStopped += evt;

        WaveDevice.Init(a);
        WaveDevice.Play();
        return taskCompSource.Task;
    }

    public Task Say(string text)
    {
        var taskCompSource = new TaskCompletionSource<bool>();
        Voice.SpeakAsync(text);

        EventHandler<SpeakCompletedEventArgs>? evt1 = null;
        evt1 = new EventHandler<SpeakCompletedEventArgs>((src, arg) =>
        {
            Voice.SpeakCompleted -= evt1;
            taskCompSource.SetResult(true);
        });

        Voice.SpeakCompleted += evt1;

        return taskCompSource.Task;
    }

    public Task SayToFile(string text, string fileName)
    {
        var taskCompSource = new TaskCompletionSource<bool>();
        Voice.SetOutputToWaveFile(fileName);
        Voice.SpeakAsync(text);

        EventHandler<SpeakCompletedEventArgs>? evt1 = null;
        evt1 = new EventHandler<SpeakCompletedEventArgs>((src, arg) =>
        {
            Voice.SpeakCompleted -= evt1;
            Voice.SetOutputToDefaultAudioDevice();
            taskCompSource.SetResult(true);
        });

        Voice.SpeakCompleted += evt1;

        return taskCompSource.Task;
    }

    public IEnumerable<string> Voices => Voice.GetInstalledVoices().Select(v => v.VoiceInfo.Name);

    public static void TrimMp3(string inputPath, string outputPath, TimeSpan? begin, TimeSpan? end)
    {
        if (begin.HasValue && end.HasValue && begin > end)
            throw new ArgumentOutOfRangeException(nameof(end), "end should be greater than begin");

        using var reader = new Mp3FileReader(inputPath);
        using var writer = File.Create(outputPath);
        Mp3Frame frame;
        while ((frame = reader.ReadNextFrame()) != null)
            if (reader.CurrentTime >= begin || !begin.HasValue)
            {
                if (reader.CurrentTime <= end || !end.HasValue)
                    writer.Write(frame.RawData, 0, frame.RawData.Length);
                else break;
            }
    }


    public void Dispose()
    {
        WaveDevice?.Dispose();
        Voice?.Dispose();
    }
}
