﻿using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using NbCollV1;
using NbCore;
using NbCore.NbNullable;

namespace NbTools.Collections
{
    public class DfColumnEnum<TEnum> : DfColumnBase<TEnum>
        where TEnum : struct, IComparable, IConvertible
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@int, @null = IsNullable };
        public override void AddDefault() => Vals.Add((TEnum)Enum.ToObject(typeof(TEnum), 0));

        public DfColumnEnum(string name, DfCollection coll, bool isNull) : base(name, coll, isNull) { }

        public override int CreateText(INbReader val, int index) { throw new NotImplementedException(); }

        public override bool IsEqual(TEnum x, TEnum y) => x.Equals(y);
        public override int ValCompare(TEnum x, TEnum y) => x.CompareTo(y);

        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => throw new NotImplementedException();

        public override bool TryGetValueFromString(string str, out TEnum val, [NotNullWhen(false)] out string? errorMessage)
        {
            if (Enum.TryParse(str, out TEnum res))
            {
                errorMessage = null;
                val = res;
                return true;
            }
            else
            {
                errorMessage = $"One of those enum values are expected: {String.Join(", ", Enum.GetNames(typeof(TEnum)))}";
                val = default;
                return false;
            }
        }
    }

    public class DfColumnDateTime : DfColumnBase<DateTime>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.DateTime, @null = IsNullable };
        public override void AddDefault() => Vals.Add(NbNull.DateTime_);

        public DfColumnDateTime(string name, DfCollection coll, bool isNull) : base(name, coll, isNull) { }

        public override int CreateText(INbReader rdr, int colIndex)
        {
            var dt = rdr.GetNullableDateTime(colIndex);
            if (dt.HasValue)
            {
                Vals.Add(dt.Value);
                fAllNull = false;
            }
            else
            {
                if (IsNullable)
                    Vals.Add(NbNull.DateTime_);
                else
                    throw new Exception($"Null value read in the non-nullable column {Name}");
            }
            return colIndex;
        }

        public override string Val2Str(DateTime dt) => (dt == NbNull.DateTime_) ? String.Empty : dt.ToString(dt.TimeOfDay == TimeSpan.Zero ? NbExt.ddMMMyyyy : NbExt.ddMMMyyyyHHmmss);
        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => frm.Format(this, index, fld_base, nbCss);

        public override bool IsEqual(DateTime x, DateTime y) => DateTime.Equals(x, y);
        public override int ValCompare(DateTime x, DateTime y) => DateTime.Compare(x, y);

        public override bool TryGetValueFromString(string str, out DateTime val, out string? errorMessage)
        {
            val = NbNull.DateTime_;
            errorMessage = null;
            if (String.IsNullOrWhiteSpace(str))
            {
                if (!IsNullable)
                    errorMessage = ErrNullString;
            }
            else if (!NbExt.TryParseDate(str, out val))
                errorMessage = $"Can't parse datetime out of '{str}'";

            return errorMessage == null;
        }
    }

    public class DfColumnDecimal : DfColumnBase<Decimal>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@decimal, @null = IsNullable };
        public override void AddDefault() => Vals.Add(NbNull.Decimal_);

        public DfColumnDecimal(string name, DfCollection coll, bool isNullable) : base(name, coll, isNullable) { }

        public override int CreateText(INbReader rdr, int colIndex)
        {
            if (rdr.IsDBNull(colIndex))
            {
                if (IsNullable)
                    return CreateValue(NbNull.Decimal_);
                else
                    throw new Exception($"Null value read in the non-nullable column {Name}");
            }
            else
            {
                fAllNull = false;
                return CreateValue(rdr.GetDecimal(colIndex));
            }
        }

        public override string Val2Str(Decimal val) => val == NbNull.Decimal_ ? String.Empty : val.ToString();
        public override string? Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => frm.Format(this, index, fld_base, nbCss);

        public override bool IsEqual(Decimal x, Decimal y) => x.Equals(y);
        public override int ValCompare(Decimal x, Decimal y) => x.CompareTo(y);

        public override bool TryGetValueFromString(string str, out decimal val, out string? errorMessage)
        {
            val = NbNull.Decimal_;
            errorMessage = null;
            if (String.IsNullOrWhiteSpace(str))
            {
                if (!IsNullable)
                    errorMessage = ErrNullString;
            }
            else if (!Decimal.TryParse(str, out val))
                errorMessage = $"Can't parse {nameof(Decimal)} out of '{str}'";

            return errorMessage == null;
        }
    }

    public class DfColumnInt16 : DfColumnBase<Int16>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@short, @null = IsNullable };
        public override void AddDefault() => Vals.Add(NbNull.Int16_);

        public DfColumnInt16(string name, DfCollection coll, bool isNullable) : base(name, coll, isNullable) { }

        public override int CreateText(INbReader rdr, int colIndex)
        {
            if (rdr.IsDBNull(colIndex))
            {
                if (IsNullable)
                    return CreateValue(NbNull.Int16_);
                else
                    throw new Exception($"Null value read in the non-nullable column {Name}");
            }
            else
            {
                fAllNull = false;
                return CreateValue(rdr.GetInt16(colIndex));
            }
        }

        public override string Val2Str(Int16 val) => val == NbNull.Int16_ ? String.Empty : val.ToString();
        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => frm.Format(this, index, fld_base, nbCss);

        public override bool IsEqual(Int16 x, Int16 y) => x.Equals(y);
        public override int ValCompare(Int16 x, Int16 y) => x.CompareTo(y);

        public override bool TryGetValueFromString(string str, out short val, out string? errorMessage)
        {
            val = NbNull.Int16_; //For null
            errorMessage = null;
            if (String.IsNullOrWhiteSpace(str))
            {
                if (!IsNullable)
                    errorMessage = ErrNullString;
            }
            else if (!Int16.TryParse(str, out val))
                errorMessage = $"Can't parse {nameof(Int16)} out of '{str}'";

            return errorMessage == null;
        }
    }

    public class DfColumnInt32 : DfColumnBase<Int32>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@int, @null = IsNullable };

        public override void AddDefault() => Vals.Add(NbNull.Int32_);

        public DfColumnInt32(string name, DfCollection coll, bool isNullable) : base(name, coll, isNullable) { }

        public override int CreateText(INbReader rdr, int colIndex)
        {
            if (rdr.IsDBNull(colIndex))
            {
                if (IsNullable)
                    return CreateValue(NbNull.Int32_);
                else
                    throw new Exception($"Null value read in the non-nullable column {Name}");
            }
            else
            {
                fAllNull = false;
                return CreateValue(rdr.GetInt32(colIndex));
            }
        }

        public override string Val2Str(int val) => val == NbNull.Int32_ ? String.Empty : val.ToString();
        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => frm.Format(this, index, fld_base, nbCss);

        public override bool IsEqual(int x, int y) => x.Equals(y);
        public override int ValCompare(int x, int y) => x.CompareTo(y);

        public override bool TryGetValueFromString(string str, out int val, out string? errorMessage)
        {
            val = NbNull.Int32_;
            errorMessage = null;
            if (String.IsNullOrWhiteSpace(str))
            {
                if (!IsNullable)
                    errorMessage = ErrNullString;
            }
            else if (!Int32.TryParse(str, out val))
                errorMessage = $"Can't parse {nameof(Int32)} out of '{str}'";

            return errorMessage == null;
        }
    }

    public class DfColumnInt64 : DfColumnBase<Int64>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@long, @null = IsNullable };
        public override void AddDefault() => Vals.Add(NbNull.Int64_);

        public DfColumnInt64(string name, DfCollection coll, bool isNullable) : base(name, coll, isNullable) { }

        public override int CreateText(INbReader rdr, int colIndex)
        {
            if (rdr.IsDBNull(colIndex))
            {
                if (IsNullable)
                    return CreateValue(NbNull.Int64_);
                else
                    throw new Exception($"Null value read in the non-nullable column {Name}");
            }
            else
            {
                fAllNull = false;
                return CreateValue(rdr.GetInt64(colIndex));
            }
        }

        public override string Val2Str(Int64 val) => val == NbNull.Int64_ ? String.Empty : val.ToString();
        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => frm.Format(this, index, fld_base, nbCss);

        public override bool IsEqual(Int64 x, Int64 y) => x.Equals(y);
        public override int ValCompare(Int64 x, Int64 y) => x.CompareTo(y);

        public override bool TryGetValueFromString(string str, out long val, out string? errorMessage)
        {
            val = NbNull.Int64_;
            errorMessage = null;
            if (String.IsNullOrWhiteSpace(str))
            {
                if (!IsNullable)
                    errorMessage = ErrNullString;
            }
            else if (!Int64.TryParse(str, out val))
                errorMessage = $"Can't parse {nameof(Int64)} out of '{str}'";

            return errorMessage == null;
        }
    }

    public class DfColumnStringIndex : DfColumnBase<string>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@string, @null = IsNullable };
        public override void AddDefault() => Vals.Add(null);

        private class Comp : IComparer<int>
        {
            private readonly IReadOnlyList<string> Vals;
            internal Comp(IReadOnlyList<string> vals) { Vals = vals; }
            public int Compare(int x, int y) => String.Compare(Vals[x], Vals[y], ignoreCase: true);
        }

        private readonly List<int> Index;

        private readonly IComparer<int> IndexComparer;
        private int MaxNumber = 1; //Used to nominate the index if the value is not provided

        public DfColumnStringIndex(string name, DfCollection coll, bool isNull) : base(name, coll, isNull)
        {
            Index = new List<int>();
            IndexComparer = new Comp(Vals);
        }

        public override void SetText(string res)
        {
            if (String.IsNullOrWhiteSpace(res))
                res = (MaxNumber + 1).ToString(); //If Id is not provided give the

            int index = fColl.GetLineForEditing();
            if (index == Vals.Count)
            {
                Vals.Add(res);
                int insLocation = Index.BinarySearch(index, IndexComparer); //Sort on insert
                if (insLocation < 0)
                {
                    insLocation = ~insLocation;
                    Index.Insert(insLocation, index);
                }
                else
                    throw new Exception("Such index already exists");
            }
            else
            {
                Vals[index] = res;
                Index.Sort(IndexComparer);
            }

            if (Int32.TryParse(res, out int num))
                MaxNumber = Math.Max(MaxNumber, num);

            Debug.Assert(Vals.Count == Index.Count);
        }

        public override int CreateText(INbReader val, int index) => throw new NotImplementedException();   /*=> CreateText("BLOB")*/
        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => frm.Format(this, index, fld_base, nbCss);

        /*public override int CreateText(string res)
        {
            Debug.Assert(Vals.Count == Index.Count);

            if (String.IsNullOrWhiteSpace(res))
                res = (MaxNumber + 1).ToString(); //If Id is not provided give the

            int index = Vals.Count;
            Vals.Add(res);

            int insLocation = Index.BinarySearch(index, IndexComparer);
            if (insLocation < 0)
            {
                insLocation = ~insLocation;
                Index.Insert(insLocation, index);
            }
            else
                throw new Exception("Such index already exists");

            if (Int32.TryParse(res, out int num))
                MaxNumber = Math.Max(MaxNumber, num);

            Debug.Assert(Vals.Count == Index.Count);
            return index;
        }*/

        public IReadOnlyCollection<int> InOrder => Index.AsReadOnly();

        //TODO: do binary search later
        public int GetIndById(string id) => Vals.FindIndex(s => String.Equals(s, id, StringComparison.OrdinalIgnoreCase));

        public override bool IsEqual(string x, string y) => String.Equals(x, y);
        public override int ValCompare(string x, string y) => String.Compare(x, y);

        public override bool TryGetValueFromString(string str, out string? val, out string? errorMessage)
        {
            if (!IsNullable && String.IsNullOrEmpty(str))
            {
                val = null;
                errorMessage = ErrNullString;
                return false;
            }
            else
            {
                val = str;
                errorMessage = null;
                return true;
            }
        }
    }

    public class DfColumnBlobString : DfColumnString
    {
        private readonly string RefTableName;
        private readonly string RefColumnName;
        private int RefColumnIndex = -1;
        //private readonly bool IsSameTable; //If blob is taken from the same table (RefTable = thisTable) the key value should be read from the primary key of this table
                                           //If blob is a reference to another table the value should be read from this field with will of a string or int type (not an actual blob)

        public DfColumnBlobString(string name, DfCollection coll, bool isNull, string ref_table_name, string ref_column_name, bool _) : base(name, coll, isNull)
        {
            RefTableName = ref_table_name;
            RefColumnName = ref_column_name;
            //IsSameTable = isSameTable;
        }

        public override int CreateText(INbReader rdr, int colIndex)
        {
            if (rdr.IsDBNull(colIndex))
            {
                if (IsNullable)
                    return CreateValue(null);
                else
                    throw new Exception($"Null value read in the non-nullable column {Name}");
            }
            else
            {
                fAllNull = false;
                return CreateValue(rdr.GetString(RefColumnIndex));
            }
        }

        public void Resolve(IEnumerable<IDfColumnBase> cols)
        {
            int counter = 0;
            foreach (var col in cols)
            {
                if (col.Name.EqIC(RefColumnName))
                {
                    RefColumnIndex = counter;
                    return;
                }
                counter++;
            }
            throw new Exception($"Can't resolve field {RefColumnName}");
        }
    }

    public class DfColumnBlobInt64 : DfColumnInt64
    {
        //private readonly string RefTableName;
        private readonly string RefColumnName;
        private int RefColumnIndex = -1;
        //private readonly bool IsSameTable; //If blob is taken from the same table (RefTable = thisTable) the key value should be read from the primary key of this table
                                           //If blob is a reference to another table the value should be read from this field with will of a string or int type (not an actual blob)

        public DfColumnBlobInt64(string name, DfCollection coll, bool isNull, string ref_table_name, string ref_column_name, bool isSameTable) : base(name, coll, isNull)
        {
            //RefTableName = ref_table_name;
            RefColumnName = ref_column_name;
            //IsSameTable = isSameTable;
        }

        public override int CreateText(INbReader rdr, int colIndex)
        {
            if (rdr.IsDBNull(colIndex))
            {
                if (IsNullable)
                    return CreateValue(NbNull.Int64_);
                else
                    throw new Exception($"Null value read in the non-nullable column {Name}");
            }
            else
            {
                fAllNull = false;
                return CreateValue(rdr.GetInt64(RefColumnIndex));
            }
        }

        public void Resolve(IEnumerable<IDfColumnBase> cols)
        {
            int counter = 0;
            foreach (var col in cols)
            {
                if (col.Name.EqIC(RefColumnName))
                {
                    RefColumnIndex = counter;
                    return;
                }
                counter++;
            }
            throw new Exception($"Can't resolve field {RefColumnName}");
        }
    }

    public class DfColumnString : DfColumnBase<string>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@string, @null = IsNullable };
        public override void AddDefault() => Vals.Add(null);

        public DfColumnString(string name, DfCollection coll, bool isNull) : base(name, coll, isNull) { }

        public override int CreateText(INbReader rdr, int colIndex) //TODO: set fAllNull in the base class for both SQl and CSV
        {
            if (rdr.IsDBNull(colIndex))
                return CreateValue(null);
            else
            {
                fAllNull = false;
                return CreateValue(rdr.GetString(colIndex));
            }
        }

        public override string? Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => frm.Format(this, index, fld_base, nbCss);

        public override bool IsEqual(string x, string y) => String.Equals(x, y);
        public override int ValCompare(string x, string y) => String.Compare(x, y);

        public override bool TryGetValueFromString(string str, out string? val, out string? errorMessage)
        {
            if (!IsNullable && String.IsNullOrEmpty(str))
            {
                val = null;
                errorMessage = ErrNullString;
                return false;
            }
            else
            {
                val = str;
                errorMessage = null;
                return true;
            }
        }
    }

    public class DfColumnSingleReference : DfColumnBase<int>, IDfReferenceColumn
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@string, @null = IsNullable };
        public override void AddDefault() => Vals.Add(-1);

        private readonly DfColumnStringIndex RefIndex; //Referenced index field (parents list)
        private DfColumnBackReference BackRef; //Backreferences from referenced object to this (children)

        public DfColumnSingleReference(string name, DfColumnStringIndex refIndex, DfCollection coll, bool isNull) : base(name, coll, isNull)
        {
            RefIndex = refIndex;
        }

        /// <summary>
        /// Used in Resolving after loading, creates another DfColumnBackReference column based on the contents of this field (can have multiple references). 
        /// </summary>
        /// <param name="backReferenceColumnName">The name of the new BackReference column</param>
        /// <param name="loaderColumn">The string column temporarily used to load data from csv. It will be deleleted</param>
        /// <returns>DfColumnBackReference column based on the contents of this field</returns>
        public DfColumnBackReference ResolveAndCreateBackeferenceColumn(string backReferenceColumnName, DfColumnString loaderColumn)
        {
            if (Vals.Count > 0) throw new Exception($"{nameof(DfColumnSingleReference)} field '{Name}' already has valued in {nameof(ResolveAndCreateBackeferenceColumn)} method");

            //TODO: this fColl should be the referenced table, not the current table
            int i = 0;
            try
            {
                BackRef = new DfColumnBackReference(backReferenceColumnName, RefIndex.fColl, this);
                for (; i < loaderColumn.Count; ++i) //For arch
                {
                    if (TryGetValueFromString(loaderColumn[i], out int refInd, out string? err))
                    {
                        Vals.Add(refInd); //Null values are also added
                        if (!refInd.IsNbNull())
                            BackRef.AddCreateBackReference(index: refInd, backRef: i); //The referenced element with ind=refInd, will store the back-reference to the current record: i
                    }
                    else
                        throw new Exception(err);
                }
            }
            catch (Exception ex)
            { throw new Exception($"Error resolving line line {i + 2}", ex); }

            Debug.Assert(Vals.Count == loaderColumn.Count);
            return BackRef;
        }

        public override string GetText(int index) => RefIndex.GetText(Vals[index]);

        public override int CreateText(INbReader rdr, int colIndex) => throw new Exception("DfColumnSingleReference should not load data itself, it should be initialized from another column");

        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => throw new NotImplementedException();
        public override bool IsEqual(int x, int y) => throw new NotImplementedException();
        public override int ValCompare(int x, int y) => throw new NotImplementedException();
        public void RemoveReference(int ind, int refInd, bool suppressNotification) => throw new NotImplementedException();

        public override bool TryGetValueFromString(string str, out int val, out string? errorMessage)
        {
            val = NbNull.Int32_;
            errorMessage = null;
            if (String.IsNullOrWhiteSpace(str))
            {
                if (!IsNullable)
                    errorMessage = ErrNullString;
            }

            val = RefIndex.GetIndById(str);
            if (val == -1)
                errorMessage = $"The referece '{str}' in the column '{Name}' can't be resolved";  //One for headers another for 0-baseness

            return errorMessage == null;
        }
    }


    public class DfColumnReference : DfColumnString, IDfReferenceColumn //Reusing List<string> for pre-Resolving time
    {
        private const string separator = "|";
        private List<List<int>?> ListOfLists; //Populated after resolving, Vals will be set to NULL - Think about re-using Val for it.

        private readonly DfColumnStringIndex RefIndex; //Referenced index field (parents)
        private DfColumnBackReference BackRef; //Backreferences from referenced object to this (children)

        public override int Count => (ListOfLists != null) ? ListOfLists.Count : Vals?.Count ?? 0; //Pre and post resolving cases covered

        public DfColumnReference(string name, DfColumnStringIndex refIndex, DfCollection coll, List<string>? vals = null) : base(name, coll, true) //is Null
        {
            RefIndex = refIndex;
            Vals = vals;
        }

        public override void AddDefault() => ListOfLists.Add(new List<int>(0));

        public override void SetText(string res)
        {
            if (Vals != null)
                base.SetText(res);
            else if (ListOfLists != null)
            {
                int index = fColl.GetLineForEditing();

                //TODO: support changing order
                List<int> newList = String.IsNullOrEmpty(res) ? new List<int>(0) : res.Split(separator[0]).Select(n =>
                {
                    int i = RefIndex.GetIndById(n);
                    if (i == -1)
                        throw new NbExceptionInfo($"Entity '{n}' doesn't exist in the referenced colum '{RefIndex.Name}'");
                    return i;
                }).ToList(); //TODO: Use enum later

                var numOfChanges = GetReferences(index).SynchronizeCollections(newList, refInd => AddReference(index, refInd, true), refInd => RemoveReference(index, refInd, true)); //Suppress notification
                if (numOfChanges > 0)
                    fColl.OnValueChanged(this, index); //One notification for all changes
            }
            else
                throw new NbExceptionInfo($"Neither {nameof(Vals)} nor {nameof(ListOfLists)} are set in {this}");
        }

        public override string GetText(int index)
        {
            if (ListOfLists == null)
                throw new NbExceptionInfo($"ListOfLists is not initialized in '{this}' Column");

            return String.Join(separator, ListOfLists[index].Safe().Select(i => RefIndex.GetText(i)));
        }

        public new IReadOnlyList<int> this[int ind] => GetReferences(ind);

        /// <summary>
        /// Returns the enumerable of the entities referenced by this field
        /// </summary>
        /// <param name="ind">The row in the column to return references for</param>
        /// <returns>the enumerable of the entities referenced by this field</returns>
        public IReadOnlyList<int> GetReferences(int ind) => ListOfLists.Count <= ind ? new List<int>(0) : ListOfLists[ind] ?? new List<int>(0);

        /// <summary>
        /// Used in Resolving after loading, creates another DfColumnBackReference column based on the contents of this field (can have multiple references). 
        /// </summary>
        /// <param name="backReferenceColumnName">The name of the new BackReference column</param>
        /// <returns>DfColumnBackReference column based on the contents of this field</returns>
        public DfColumnBackReference ResolveAndCreateBackeferenceColumn(string backReferenceColumnName, DfColumnString loaderColumn)
        {
            Debug.Assert(Vals != null && ListOfLists == null, "Values must exist before the resolving");

            BackRef = new DfColumnBackReference(backReferenceColumnName, RefIndex.fColl, this);
            ListOfLists = new List<List<int>>(Vals.Count);
            for (int i = 0; i < Vals.Count; ++i)
            {
                var str = Vals[i];
                if (String.IsNullOrWhiteSpace(str)) //No references - do not create sublist
                {
                    ListOfLists.Add(null);
                    continue;
                }

                var names = str.Split(separator[0]);
                var subList = new List<int>(names.Length);
                for (int j = 0; j < names.Length; ++j)
                {
                    int refInd = RefIndex.GetIndById(names[j]);
                    if (refInd == -1)
                        throw new Exception($"The referece '{names[j]}' in the column '{Name}' in the line {i + 2} can't be resolved");  //One for headers another for 0-baseness

                    BackRef.AddCreateBackReference(refInd, i); //The referenced element with ind=refInd, will store the back-reference to the current record: i
                    subList.Add(refInd);
                }
                ListOfLists.Add(subList);
            }

            Vals = null;
            Debug.Assert(Vals == null && ListOfLists != null, "Values should not exist after the resolving");
            return BackRef;
        }

        /// <summary>
        /// Adds another entry to the list of references in this field
        /// </summary>
        /// <param name="ind"></param>
        /// <param name="refInd"></param>
        public void AddReference(int ind, int refInd, bool suppressNotification = false)
        {
            Debug.Assert(ind >= 0 && refInd >= 0, "Index and reference index must be non-negative");

            if (ind == ListOfLists.Count) //Adding a new line
                ListOfLists.Add(null); //Adding a new cell to the array

            List<int>? lst = ListOfLists[ind];
            if (lst == null)
            {
                lst = new List<int>(1);
                ListOfLists[ind] = lst;
            }

            if (lst.Contains(refInd))
                throw new NbExceptionInfo($"Field {this}[{ind}] already contains the reference {refInd}");

            lst.Add(refInd);
            if (!suppressNotification)
                fColl.OnValueChanged(this, ind);

            BackRef.AddCreateBackReference(refInd, ind);
        }

        public void RemoveReference(int ind, int refInd, bool suppressNotification = false)
        {
            Debug.Assert(ind >= 0 && refInd >= 0, "Index and reference index must be non-negative");

            List<int>? lst = ListOfLists[ind];
            if (lst == null)
                throw new NbExceptionInfo($"Field {this}[{ind}] doens't contain any references");

            int indToDelete = lst.IndexOf(refInd);
            if (indToDelete == -1)
                throw new NbExceptionInfo($"Field {this}[{ind}] doens't contain reference {refInd}");

            lst.RemoveAt(indToDelete);
            if (!suppressNotification)
                fColl.OnValueChanged(this, ind);

            BackRef.RemoveBackReference(refInd, ind);
        }

        /// <summary>
        /// Used when the entity is deleted and all backreferences to it from the parent should be deleted as well
        /// </summary>
        /// <param name="ind">Index of the entry being deleted</param>
        public void DeleteAllBackReferences(int ind)
        {
            Debug.Assert(ind >= 0, "Index must be non-negative");

            foreach (int refInd in GetReferences(ind))
                BackRef.RemoveBackReference(refInd, ind);

            ListOfLists[ind] = null; //Delete the list of references to avoid saving the entries into the file and free memory
        }

        public IEnumerable<int> WhereInList(Predicate<IReadOnlyList<int>> pred, IEnumerable<int> inds) => inds.Where(i => pred(GetReferences(i)));
    }

    public class DfColumnBackReference : DfColumnBase<List<int>>
    {
        public override DfField DefaultLayout => new() { name = Name, type = DfType.@int, @null = IsNullable };
        public override void AddDefault() => Vals.Add(null);

        public readonly IDfReferenceColumn RefColumn;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="coll">The referenced collection which te Backreference fields belongs to, not the collection currently being resolved</param>
        /// <param name="size"></param>
        /// <param name="refColumn"></param>
        public DfColumnBackReference(string name, DfCollection coll, IDfReferenceColumn refColumn) : base(name, coll, true)  //isNull
        {
            Vals.AddRange(Enumerable.Repeat<List<int>>(null, coll.Count));
            RefColumn = refColumn;
        }

        private List<int> GetRowList(int index)
        {
            List<int> row;

            if (index < Vals.Count) //Row exists
            {
                row = Vals[index];
                if (row == null) //Lazy creation of sub-lists
                {
                    row = new List<int>();
                    Vals[index] = row;
                }
            }
            else if (index == Vals.Count) //Create new row
            {
                row = new List<int>();
                Vals.Add(row);
            }
            else
                throw new NbExceptionInfo($"DfColumn - attempt to save backreference at index '{index}' when only '{Vals.Count}' records exist");

            return row;
        }

        /// <summary>
        /// Adds an empty sell and returns the indext of the new row
        /// </summary>
        /// <returns>The index of the newly created row</returns>
        public int AddBackReferenceRow()
        {
            int res = Vals.Count;
            Vals.Add(null);
            return res;
        }

        public void AddCreateBackReference(int index, int backRef)
        {
            var row = GetRowList(index);

            if (row.Contains(backRef))
                throw new NbExceptionInfo($"Backreference {backRef} alredy exists in the row #{index}");

            row.Add(backRef);
            fColl.OnValueChanged(this, index);
        }

        public void RemoveBackReference(int index, int backRef)
        {
            if (index >= Vals.Count)
                throw new NbExceptionInfo($"row #{index} doesn't exist in the backreference field. There is total of {Vals.Count} rows");

            var row = Vals[index];
            int indToDelete = row?.FindIndex(i => i == backRef) ?? -1;
            if (indToDelete == -1)
                throw new NbExceptionInfo($"row #{index} doesn't contain backreference {backRef} field.");

            row.RemoveAt(indToDelete);
            if (row.Count == 0) //If is was the last reference - delete the whole list
                Vals[index] = null;

            fColl.OnValueChanged(this, index);
        }

        public void DeleteAllReferences(int index)
        {
            if (index >= Vals.Count)
                throw new NbExceptionInfo($"row #{index} doesn't exist in the backreference field. There is total of {Vals.Count} rows");

            var children = Vals[index];
            if (children != null)
            {
                foreach (var child in children.ToList()) //Copy, because the original list will be modified by backreference deletion
                {
                    RefColumn.RemoveReference(child, index, suppressNotification: false);
                }
            }
        }

        public IEnumerable<int> GetReferences(int index) => Vals[index] ?? Enumerable.Empty<int>();

        public override int CreateText(INbReader val, int index) { throw new NotImplementedException(); }
        public override bool IsEqual(List<int> x, List<int> Y) { throw new NotImplementedException(); }
        public override int ValCompare(List<int> x, List<int> y) { throw new NotImplementedException(); }
        public override string Format(int index, IDfCellFormatter frm, DfField fld_base, NbCss nbCss) => throw new NotImplementedException();

        public override bool TryGetValueFromString(string str, out List<int> val, out string? errorMessage) => throw new InvalidOperationException($"{nameof(TryGetValueFromString)} should never be called on {nameof(DfColumnBackReference)} class");
    }
}