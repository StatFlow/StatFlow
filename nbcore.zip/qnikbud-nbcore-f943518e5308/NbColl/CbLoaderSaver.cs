﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using NbCore;

namespace NbTools.Collections
{

    /// <summary>
    /// Takes a CbCollection in a constructor and provides csv loading a saving functionality
    /// </summary>
    public class CbLoaderSaverCsv
    {
        public readonly CbCollection Collection;
        private string? LastUsedFilename;

        public CbLoaderSaverCsv(CbCollection coll)
        {
            Collection = coll;
        }

        public void AppendString(string str, CsvParameters pars)
        {
            using (StringReader rdr = new StringReader(str))
                AppendStream(rdr, pars);

        }

        public void AppendFile(DirectoryInfo repoDir, CsvParameters pars) => AppendFile(Path.Combine(repoDir.FullName, Collection.Name + ".csv"), pars);

        public void AppendFile(string filename, CsvParameters pars)
        {
            LastUsedFilename = filename;
            using (StreamReader rdr = new StreamReader(filename))
                AppendStream(rdr, pars);
        }

        public void AppendStream(TextReader rdr, CsvParameters pars)
        {
            char sep = pars?.FieldDelimiterN ?? ',';
            bool quoted = pars?.QuoatedFields ?? false;

            bool trim = pars?.Trim ?? true;

            List<ICbCollectionColumn>? cols = null;
            StringBuilder bld = new();
            while (rdr.Peek() != -1) //Same as EOF
            {
                if (cols == null)
                {
                    cols = ProcessHeader(rdr.ReadLine(), Collection, sep);
                    continue;
                }


                Collection.Reset();
                int cnt = 0;
                IEnumerable<string> strs;
                if (quoted)
                    strs = NbExt.DeCsvLine2(rdr, bld, sep, trim);
                else
                {
                    var s = rdr.ReadLine();
                    strs = !String.IsNullOrWhiteSpace(s) ? s.Split(sep) : Enumerable.Empty<string>();
                }
                foreach (var str in strs)
                {
                    if (cnt == cols.Count)
                        break; //More columns in the file than in the cols collection
                    cols[cnt].SetTextToBuffer(str);
                    cnt++;
                }
                if (cnt > 0) //Do not append if the line was empty
                    Collection.Append();
            }
        }

        public void SaveToFile(string? filename = null, CsvParameters? pars = null)
        {
            LastUsedFilename = LastUsedFilename ?? filename;
            if (String.IsNullOrEmpty(LastUsedFilename))
                throw new Exception("Filename was not provided");

            string oldFile = LastUsedFilename + ".old";
            if (File.Exists(oldFile))
                File.Delete(oldFile);

            if (File.Exists(LastUsedFilename))
                File.Move(LastUsedFilename, oldFile);

            using (StreamWriter wrtr = new StreamWriter(LastUsedFilename))
            {
                SaveToWriter(wrtr, pars);
            }
        }

        public void SaveToWriter(TextWriter wrtr, CsvParameters? pars = null)
        {
            char sep = pars?.FieldDelimiterN ?? ',';

            bool first = true;
            foreach (var colName in Collection.Columns.Keys) //TODO: preferred column order
            {
                if (first)
                    first = false;
                else
                    wrtr.Write(sep);
                wrtr.Write(colName.ToCsvString());
            }
            wrtr.WriteLine();

            foreach (int i in Collection.All) //Doesn't include deleted
            {
                first = true;
                foreach (var col in Collection.Columns.Values) //TODO: preferred column order
                {
                    if (first)
                        first = false;
                    else
                        wrtr.Write(sep);
                    wrtr.Write(col.GetText(i).ToCsvString());
                }
                wrtr.WriteLine();
            }
            wrtr.Flush();
        }

        /*public void SaveToFile(string filename = null, CsvParameters pars = null)
         {
             char sep = pars?.FieldDelimiterN ?? ',';
             LastUsedFilename = LastUsedFilename ?? filename;
             if (String.IsNullOrEmpty(LastUsedFilename))
                 throw new Exception("Filename was not provided");

             string oldFile = LastUsedFilename + ".old";
             if (File.Exists(oldFile))
                 File.Delete(oldFile);

             if (File.Exists(LastUsedFilename))
                 File.Move(LastUsedFilename, oldFile);

             using (StreamWriter wtrt = new StreamWriter(LastUsedFilename))
             {
                 bool first = true;
                 foreach (var colName in Collection.Columns.Keys) //TODO: preferred column order
                 {
                     if (first)
                         first = false;
                     else
                         wtrt.Write(sep);
                     wtrt.Write(colName.ToCsvString());
                 }
                 wtrt.WriteLine();

                 foreach (int i in Collection.All) //Doesn't include deleted
                 {
                     first = true;
                     foreach (var col in Collection.Columns.Values) //TODO: preferred column order
                     {
                         if (first)
                             first = false;
                         else
                             wtrt.Write(sep);
                         wtrt.Write(col.GetText(i).ToCsvString());
                     }
                     wtrt.WriteLine();
                 }
             }
         }*/

        private static List<ICbCollectionColumn> ProcessHeader(string header, CbCollection coll, char sep)
        {
            return header.Split(sep).Select(s => coll.GetOrCreateColumn(s.Trim())).ToList();
        }
    }
}
