﻿using NbCore;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;

namespace NbTools
{
    public class NbObservableListSorter<TItem> : INbObservableList<TItem>
        where TItem : class, INotifyPropertyChanged
    {
        private readonly INbObservableList<TItem> fUnderLying;
        private List<TItem> fSortedListN = null;

        public NbObservableListSorter(INbObservableList<TItem> underLying)
        {
            fUnderLying = underLying;
            underLying.Changed += UnderLying_Changed;
        }

        private void UnderLying_Changed(TItem item, NotifyCollectionChangedAction action, int undIndex = -1, int newCount_oldInd = -1)
        {
            if (_sort == null) //if no sorter - propagate up
            {
                Changed?.Invoke(item, action, undIndex, newCount_oldInd);
                return;
            }

            switch (action)
            {
                case NotifyCollectionChangedAction.Add:
                    {
                        item.PropertyChanged += Item_PropertyChanged;
                        int ins = IndexToInsert(item);

                        fSortedListN.Insert(ins, item); //Insert the index in underlying in the 
                        Changed?.Invoke(item, action, ins, fSortedListN.Count);
                    }
                    break;

                case NotifyCollectionChangedAction.Remove:
                    {
                        item.PropertyChanged -= Item_PropertyChanged;
                        int ind = fSortedListN.IndexOf(item);
                        if (ind < 0) throw new NbExceptionInfo($"Entry with index {undIndex} is not found in the sorted list");

                        fSortedListN.RemoveAt(ind);
                        Changed?.Invoke(item, action, ind, fSortedListN.Count);
                    }
                    break;

                case NotifyCollectionChangedAction.Reset:
                    if (_sort != null)
                        SetSort(_sort, _fieldsUsedInSorting); //Replay the sorting logic
                    else
                        RemoveSort();
                    break;

                /*case NotifyCollectionChangedAction.Replace:
                    break;
                case NotifyCollectionChangedAction.Move:
                    break;*/
                default:
                    throw new NbExceptionInfo($"Unsupported Action: {action}");
            }

            if (fSortedListN.Count != fUnderLying.Count)
                throw new NbExceptionInfo($"Sorted list and underlying list counts do not match");
        }

        private int IndexToInsert(TItem item)
        {
            int ins = -1;
            for (int i = 0; i < fSortedListN.Count; ++i) //TODO: replace with binary search
            {
                if (ins == -1 && _sort(fSortedListN[i], item) >= 0) //Second is greater or equal to first
                    ins = i;
            }
            if (ins < 0) //If inserting entry i
                ins = fSortedListN.Count;
            return ins;
        }

        public void RemoveSort()
        {
            _sort = null;
            _fieldsUsedInSorting = null;
            fSortedListN = null;

            Changed?.Invoke(default, NotifyCollectionChangedAction.Reset);
        }

        public void SetSort(Func<TItem, TItem, int> sortFunc, string[] fieldsUsedInSorting)
        {
            _sort = sortFunc ?? throw new NbExceptionInfo("Sort function must be provided, use RemoveSort() to remove sorting");
            _fieldsUsedInSorting = fieldsUsedInSorting;

            if (fSortedListN == null)
                fSortedListN = new List<TItem>(fUnderLying.Count);
            else
            {
                foreach (var item in fSortedListN)
                    item.PropertyChanged -= Item_PropertyChanged;

                fSortedListN.Clear();
            }

            for (int i = 0; i < fUnderLying.Count; ++i) //Avoid re-allocation
            {
                var item = fUnderLying[i];
                item.PropertyChanged += Item_PropertyChanged;
                fSortedListN.Add(item);
            }

            fSortedListN.Sort((x, y) => _sort(x, y));
            Changed?.Invoke(default, NotifyCollectionChangedAction.Reset);
        }

        private Func<TItem, TItem, int> _sort = null; //If less than 0, x precedes y
        private string[] _fieldsUsedInSorting = null;

        private void Item_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (_fieldsUsedInSorting?.Contains(e.PropertyName, StringComparer.OrdinalIgnoreCase) ?? false)
            {
                if (sender is not TItem item)
                    throw new NbExceptionInfo($"Item send in PropertyChanged is not {typeof(TItem).Name}");

                //TODO: if the property affects the sorting
                int oldInd = fSortedListN.IndexOf(item);
                if (oldInd < 0) //If could be filtered out previously, so don't process Property Changed
                    return;

                fSortedListN.RemoveAt(oldInd);

                int newInd = IndexToInsert(item);
                fSortedListN.Insert(newInd, item);

                if (oldInd != newInd)
                    Changed?.Invoke(item, NotifyCollectionChangedAction.Move, newInd, oldInd);
            }
        }

        public TItem this[int index]
        {
            get
            {
                if (fSortedListN == null) //Sort order is not set
                    return fUnderLying[index];

                if (index < 0 || index >= fSortedListN.Count)
                    throw new NbExceptionInfo("Requested index is outside of range");
                return fSortedListN[index]; //Sorted list keeps indexes of underlying in proper order
            }
        }

        public int Count => fUnderLying.Count; //Sorting doesn't change the number of entries

        public event NbObservableListHandler<TItem> Changed;
    }
}
