﻿using NbCore;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace NbTools
{
    public delegate void NbObservableListHandler<TItem>(TItem item, NotifyCollectionChangedAction action, int index = -1, int newCount_oldInd = -1);

    public interface INbObservableList<TItem>
    {
        event NbObservableListHandler<TItem> Changed;

        TItem this[int index] { get; }
        int Count { get; }
    }

    public interface IObservableList<T> : IList<T>, INotifyCollectionChanged { }

    public class ObservableList<T> : List<T>, INotifyPropertyChanged, INbObservableList<T>
    {
        public ObservableList()
        {
            IsNotifying = true;

            // As a gimmick, I wanted to bind to the Count property, so I  use the OnPropertyChanged event from the INotifyPropertyChanged
            // interface to notify about Count changes.
            //CollectionChanged += new NotifyCollectionChangedEventHandler(delegate (object sender, NotifyCollectionChangedEventArgs e) { OnPropertyChanged(nameof(Count)); });
        }

        public bool IsNotifying { get; set; }

        #region Adding and removing items
        public new void Add(T item)
        {
            base.Add(item);
            /*NotifyCollectionChangedEventArgs e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, item, Count - 1);
            OnCollectionChanged(e);*/
            Changed?.Invoke(item, NotifyCollectionChangedAction.Add, Count - 1, Count);
        }

        public new void AddRange(IEnumerable<T> collection)
        {
            base.AddRange(collection);
            /*NotifyCollectionChangedEventArgs e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, new List<T>(collection));
            OnCollectionChanged(e);*/
        }

        public new void Clear()
        {
            base.Clear();
            /*NotifyCollectionChangedEventArgs e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset);
            OnCollectionChanged(e);*/
            Changed?.Invoke(default, NotifyCollectionChangedAction.Reset, -1, 0);
        }

        public new void Insert(int i, T item)
        {
            base.Insert(i, item);
            /*var e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, item, i);
            OnCollectionChanged(e);*/
            Changed?.Invoke(item, NotifyCollectionChangedAction.Add, i, Count);
        }

        public new void InsertRange(int i, IEnumerable<T> collection)
        {
            base.InsertRange(i, collection);
            /*var e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, collection);
            OnCollectionChanged(e);*/
        }

        public new void Remove(T item)
        {
            int ind = IndexOf(item);
            if (ind < 0)
                throw new NbExceptionInfo($"Can't find item {item} in the {nameof(ObservableList<T>)}");

            base.RemoveAt(ind);
            /*var e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, item, ind);
            OnCollectionChanged(e);*/
            Changed?.Invoke(item, NotifyCollectionChangedAction.Remove, ind, Count);
        }

        public new void RemoveAll(Predicate<T> match)
        {
            List<T> backup = FindAll(match);
            base.RemoveAll(match);
            /*var e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, backup);
            OnCollectionChanged(e);*/
        }

        public new void RemoveAt(int i)
        {
            T backup = this[i];
            base.RemoveAt(i);
            /*var e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, backup);
            OnCollectionChanged(e);*/
            Changed?.Invoke(backup, NotifyCollectionChangedAction.Remove, i, Count);
        }

        public new void RemoveRange(int index, int count)
        {
            base.RemoveRange(index, count);
            /*List<T> backup = GetRange(index, count);
            var e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, backup);
            OnCollectionChanged(e);*/
        }

        public new T this[int index]
        {
            get { return base[index]; }
            set
            {
                /*T oldValue = base[index];
                NotifyCollectionChangedEventArgs e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Replace, value, oldValue);
                OnCollectionChanged(e);*/
            }
        }
        #endregion

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion

        #region INbObservableList Members
        public event NbObservableListHandler<T>? Changed;
        #endregion
    }

    public class NbFrequency<K> where K : notnull
    {
        private readonly SortedDictionary<K, int> fDict;
        public NbFrequency(IEnumerable<K> vals)
        {
            fDict = new SortedDictionary<K, int>();
            vals.ForEachSafe(v => Add(v));
        }

        public NbFrequency()
        {
            fDict = new SortedDictionary<K, int>();
        }

        public int this[K vl] => fDict[vl];

        public void Add(K val)
        {
            if (fDict.ContainsKey(val))
                fDict[val] += 1;
            else
                fDict.Add(val, 1);
        }

        public double WeightedAverage(Func<K, double> getValue)
        {
            double accum = 0;
            int count = 0;
            foreach (var pair in fDict)
            {
                accum += getValue(pair.Key) * pair.Value; //Value * weight
                count += pair.Value;
            }
            return accum / count;
        }

        public ICollection<K> Keys => fDict.Keys;

        public K Top()
        {
            using var en = fDict.Keys.GetEnumerator();
            en.MoveNext();
            return en.Current;
        }

        public string ToCsvString()
        {
            StringBuilder bld = new();
            foreach (var pair in fDict)
            {
                bld.Append(pair.Key.ToString()).Append(',').AppendLine(pair.Value.ToString());
            }
            return bld.ToString();
        }
    }

    public class NbHistogram<K, V> where K : notnull
    {
        private readonly Dictionary<K, List<V>> fDict;
        public IReadOnlyDictionary<K, List<V>> Dict => fDict;

        public NbHistogram()
        {
            fDict = new Dictionary<K, List<V>>();
        }

        public bool Append(K key, V val)
        {
            if (fDict.TryGetValue(key, out List<V>? list))
            {
                list.Add(val);
                return true;
            }

            list = new List<V>(5) { val };
            fDict[key] = list;
            return false;
        }

        public int CountFor(K key) => fDict.TryGetValue(key, out List<V>? list) ? list.Count : 0;
        public override string ToString() => String.Join(", ", fDict.Select(p => $"{p.Key}: {p.Value.Count}"));

        public void ToCsv(string fileName, HistogramCsvParams csvParams, IComparer<K>? rowOrder)
        {
            csvParams ??= HistogramCsvParams.defHistParam; ;

            List<K> rowHeaders = fDict.Keys.ToList();
            if (rowOrder != null)
                rowHeaders.Sort(rowOrder);

            string cellDivider = csvParams?.CellDivider ?? "|";

            using StreamWriter wrtr = new(fileName);
            //Main line of headers
            wrtr.Write("Category,");
            if ((csvParams?.Total & HistogramCsvParams.Totals.Rows) != 0)
                wrtr.Write("Total,");
            wrtr.WriteLine("Values");

            foreach (var rowKey in rowHeaders)
            {
                //Row headers
                var rowList = fDict[rowKey];
                wrtr.Write(rowKey.ToString());
                if ((csvParams?.Total & HistogramCsvParams.Totals.Rows) != 0)
                {   //Sum of counts of all column cells
                    wrtr.Write(",");
                    wrtr.Write(rowList.Count);
                }

                wrtr.Write(",");
                WriteCell(wrtr, rowList, cellDivider);
                wrtr.WriteLine();
            }
        }

        internal static void WriteCell(TextWriter wrtr, IEnumerable<V> rowList, string cellDivider)
        {
            var cellStr = String.Join(cellDivider, rowList).Replace("\"", "\"\"");
            if (cellStr.Contains(',') || cellStr.Contains('"'))
            {
                wrtr.Write('"');
                wrtr.Write(cellStr);
                wrtr.Write('"');

            }
            else
                wrtr.Write(cellStr);
        }
    }

    public class HistogramCsvParams
    {
        public enum CellBehaviours { Concatenate, Count }
        public CellBehaviours CellBehaviour;

        [Flags]
        public enum Totals { None = 0, Rows = 1, Columns = 2, Both = Rows | Columns };
        public Totals Total;

        public string CellDivider;

        internal static HistogramCsvParams defHistParam = new()
        {
            CellBehaviour = HistogramCsvParams.CellBehaviours.Concatenate,
            CellDivider = "|",
            Total = HistogramCsvParams.Totals.None
        };
    }


    public class NbHistogram<K, K2, V>
        where K : notnull
        where K2 : notnull
    {
        private readonly Dictionary<K, NbHistogram<K2, V>> fDict;
        public IReadOnlyDictionary<K, NbHistogram<K2, V>> Dict => fDict;

        public NbHistogram()
        {
            fDict = new Dictionary<K, NbHistogram<K2, V>>();
        }

        public bool Append(K key, K2 key2, V val)
        {
            if (fDict.TryGetValue(key, out NbHistogram<K2, V>? hist))
            {
                hist.Append(key2, val);
                return true;
            }

            hist = new NbHistogram<K2, V>();
            hist.Append(key2, val);
            fDict[key] = hist;
            return false;
        }

        public override string ToString() => String.Join(", ", fDict.Select(p => $"{p.Key}: {p.Value}"));

        public void ToCsv(string fileName, HistogramCsvParams? csvPar = null,
            IComparer<K>? rowOrder = null, IComparer<K2>? columnOrder = null)
        {
            HistogramCsvParams csvParams = csvPar ?? HistogramCsvParams.defHistParam;

            List<K> rowHeaders = fDict.Keys.ToList();
            if (rowOrder != null)
                rowHeaders.Sort(rowOrder);

            List<K2> colHeaders = fDict.Values.SelectMany(h => h.Dict.Keys).Distinct().ToList();
            if (columnOrder != null)
                colHeaders.Sort(columnOrder);

            string cellDivider = csvParams.CellDivider ?? "|";

            using StreamWriter wrtr = new(fileName);
            //Main line of headers
            wrtr.Write("Pivot,");
            if ((csvParams.Total & HistogramCsvParams.Totals.Rows) != 0)
                wrtr.Write("Total,");
            wrtr.WriteLine(String.Join(",", colHeaders));

            //The line of totals just below headers
            if ((csvParams.Total & HistogramCsvParams.Totals.Columns) != 0)
            {
                wrtr.Write("Total");
                if ((csvParams.Total & HistogramCsvParams.Totals.Rows) != 0) //Total / Total cell - implement later
                    wrtr.Write(",");

                foreach (var colHeader in colHeaders)
                {
                    wrtr.Write(",");
                    int count = fDict.Values.Sum(d => d.CountFor(colHeader));
                    wrtr.Write(count > 0 ? count.ToString() : String.Empty);
                }
                wrtr.WriteLine();
            }

            foreach (var rowKey in rowHeaders)
            {
                //Row headers
                var rowDict = fDict[rowKey].Dict;
                wrtr.Write(rowKey.ToString());
                if ((csvParams.Total & HistogramCsvParams.Totals.Rows) != 0)
                {   //Sum of counts of all column cells
                    wrtr.Write(",");
                    wrtr.Write(rowDict.Sum(p => p.Value.Count));
                }

                foreach (var colKey in colHeaders)
                {
                    wrtr.Write(",");
                    if (rowDict.TryGetValue(colKey, out List<V>? cell))
                    {
                        wrtr.Write(",");
                        NbHistogram<K2, V>.WriteCell(wrtr, cell, cellDivider);
                    }
                }
                wrtr.WriteLine();
            }
        }
    }
}
