﻿using NbCore;
using NbCore.NbNullable;

namespace NbTools.Collections
{
    public interface ICbCollectionColumn
    {
        string Name { get; }
        string FullName { get; }

        int Count { get; }
        void ResetBuffer();
        bool SetTextToBuffer(string str); //False if text is incompatible with the column type
        string GetTextFromBuffer();
        string GetText(int index);

        void SelectBuffer(int ind);
        void AppendBuffer();
        void UpdateFromBufferAt(int ind);
        bool ValueChanged { get; }


        void ReplaceFromBuffer(int index);
        void Rename(string newName);
    }

    public interface ICbCollectionKeyColumn : ICbCollectionColumn
    {
        int IndexOf(string val);
    }

    public enum NullTreatments { AllowNull = 0, ExceptionOnNull, MalformedAsNull }

    public abstract class CbCollectionColumn<T> : ICbCollectionColumn, IComparer<int>
    {
        public override string ToString() => $"{Name}<{typeof(T).Name}>({fValues.Count})";

        public readonly CbCollection ParentCollection;
        public readonly NullTreatments NullTreatment;

        public string Name { get; private set; }
        public string FullName => ParentCollection.Name + "." + Name;
        public void Rename(string newName) => Name = newName;

        public List<T> fValues; //TODO: hide later
        public bool ValueChanged { get; protected set; }
        protected T fValue; //Think about making protected

        public T GetValue() => fValue;
        public int Count => fValues.Count;

        public string Text { get; set; }

        public CbCollectionColumn(CbCollection parentColl, string name, NullTreatments nullTreatment)
        {
            ParentCollection = parentColl;
            NullTreatment = nullTreatment;
            Name = name;

            fValues = parentColl.Capacity > 0 ? new List<T>(parentColl.Capacity) : new List<T>();
        }

        public CbCollectionKeyColumn<T> GenerateKeycolumn() => new(this);

        public bool SetTextToBuffer(string str)
        {
            bool res = TryFromText(str, out fValue);
            return res;
        }

        /// <summary>
        /// Converter from text throwing exception
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public T FromText(string str)
        {
            if (TryFromText(str, out var val))
                return val;
            else
                throw new NbException($"Can't parse '{typeof(T).Name}' out of '{str}'");
        }

        public string GetText(int index)
        {
            //if (ParentCollection.IsDeleted(index)) Doesn't allow to read values in the Deleted event notification
            //    throw new Exception($"Attempt to read from the deleted record #{index}");

            return ToText(fValues[index]);
        }

        /// <summary>
        /// Abstract method to convert a value from text, should be overriden for each type
        /// </summary>
        /// <param name="str"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        protected abstract bool TryFromText(string str, out T val);

        /// <summary>
        /// Virtual method to conver value to string, by default ToString() method of the object is used
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        protected virtual string ToText(T val) => val.ToString();

        /// <summary>
        /// Sets buffer to default value
        /// </summary>
        public void ResetBuffer() => fValue = default;

        public string GetTextFromBuffer() => ToText(fValue);

        /// <summary>
        /// Appends the value stored in buffer to the end of the collection.
        /// Useful when populating the collection from a file or from a database
        /// </summary>
        public void AppendBuffer() => fValues.Add(fValue);

        /// <summary>
        /// Updates the collection at a given index with the value stored in the buffer.
        /// Sets ValueChanged flag is the new value is different from the stored.
        /// Saves the old value into the buffer, so it can be used as an old value when raising events
        /// </summary>
        /// <param name="ind">index at which to make the update</param>
        public void UpdateFromBufferAt(int ind)
        {
            var oldVal = fValues[ind];
            if (oldVal == null)
            {
                if (fValue == null)
                {
                    ValueChanged = false;
                    return;
                }
            }
            else if (oldVal.Equals(fValue)) //TODO: check if proper Equals is called
            {
                ValueChanged = false;
                return;
            }

            (fValues[ind], fValue) = (fValue, fValues[ind]);
            ValueChanged = true;
            return;

        }

        /// <summary>
        /// Saves the value in the buffer into the collection column as specified index.
        /// No event is created
        /// </summary>
        /// <param name="index"></param>
        public void ReplaceFromBuffer(int index) => fValues[index] = fValue;

        /// <summary>
        /// Sets the internal buffer to the value at scepcified index
        /// </summary>
        /// <param name="index"></param>
        public void SelectBuffer(int index) => fValue = fValues[index];

        /// <summary>
        /// IComparer implementation. The method should compare two values at given Indexes
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public abstract int Compare(int x, int y);
    }

    public class CbString : CbCollectionColumn<string>
    {
        public CbString(CbCollection parentColl, string name, NullTreatments nullTr = NullTreatments.AllowNull)
            : base(parentColl, name, nullTr)
        { }
       
        protected override string ToText(string val) => val;
        protected override bool TryFromText(string str, out string val)
        {
            val = str;
            return true;
        }
        public override int Compare(int x, int y) => String.Compare(fValues[x], fValues[y], ignoreCase: true);
    }

    /// <summary>
    /// CbReference column, that keeps the reference to records in a table by the index of this record in the table.
    /// Based on Int32 type
    /// </summary>
    public class CbReferenceColumn<T> : CbCollectionColumn<Int32>
    {
        private readonly CbCollectionColumn<T> SourceColumn;
        private readonly CbCollectionKeyColumn<T> ReferredColumn;

        /// <summary>
        /// Creates new Column out of Source column, containing string identifiers and the desctination column using these keys as unique identifiers for its table
        /// </summary>
        /// <param name="parentColl">Collection for which this column will be created</param>
        /// <param name="srcColumn">Column with the references as text</param>
        /// <param name="dstColumn">Column in the references collection with keys as text</param>
        /// <param name="nullTr">Behaviour around null records</param>
        public CbReferenceColumn(CbCollection parentColl, CbCollectionColumn<T> srcColumn, CbCollectionKeyColumn<T> dstColumn, NullTreatments nullTr = NullTreatments.AllowNull)
            : base(parentColl, srcColumn.Name, nullTr)
        {
            SourceColumn = srcColumn;
            ReferredColumn = dstColumn;
            Resolve();
        }

        private void Resolve()
        {
            for (int i = 0; i < SourceColumn.fValues.Count; ++i)
            {
                var val = SourceColumn.fValues[i];
                var res = ResolveValue(val);
                fValues.Add(res);
            }
        }

        private int ResolveValue(T val)
        {
            if (NbNull.IsNbNull(val))
                return -1; //Null reference
            else
            {
                var ind = ReferredColumn.BinarySearch(val);
                if (ind == -1)
                    throw new NbException($"Can't find value '{val}' in the key column '{ReferredColumn.FullName}' referred from  '{SourceColumn.FullName}'");
                else
                    return ind;
            }
        }

        protected override bool TryFromText(string str, out int val)
        {
            T v = (T)Convert.ChangeType(str, typeof(T)); //TODO: think about improving this conversion
            val = ResolveValue(v);
            return true; //Null values are also counted as resolved
        }

        protected override string ToText(int val)
        {
            if (val < 0)
                if (NullTreatment == NullTreatments.ExceptionOnNull)
                    throw new NbException($"Null reference in the reference column '{this.FullName}': {val}");
                else //Null references are allowed
                    return String.Empty;
            else
                return ReferredColumn.GetText(val); //Dereferece and get the Text
        }

        /// <summary>
        /// Compares the values of references, maybe useful for sorting by references
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public override int Compare(int x, int y) => fValues[x].CompareTo(fValues[y]);
    }


    public class CbInt32 : CbCollectionColumn<Int32>
    {
        public CbInt32(CbCollection parentColl, string name, NullTreatments nullTr = NullTreatments.AllowNull)
            : base(parentColl, name, nullTr)
        { }

        protected override bool TryFromText(string str, out int val) => Int32.TryParse(str, out val);
        public override int Compare(int x, int y) => fValues[x].CompareTo(fValues[y]);
    }

    public class CbInt64 : CbCollectionColumn<Int64>
    {
        public CbInt64(CbCollection parentColl, string name, NullTreatments nullTr = NullTreatments.AllowNull)
            : base(parentColl, name, nullTr)
        { }

        protected override bool TryFromText(string str, out long val) => Int64.TryParse(str, out val);
        public override int Compare(int x, int y) => fValues[x].CompareTo(fValues[y]);
    }

    public class CbBoolean : CbCollectionColumn<bool>
    {
        public CbBoolean(CbCollection parentColl, string name, NullTreatments nullTr = NullTreatments.AllowNull)
            : base(parentColl, name, nullTr)
        { }

        protected override bool TryFromText(string str, out bool val)
        {
            //TODO: return Good, Null, Malformed instead of bool
            if (NullTreatment == NullTreatments.ExceptionOnNull && String.IsNullOrWhiteSpace(str))
                throw new NbException($"Nulls are not allowed in the '{FullName}' column");

            switch (str.ToUpperInvariant())
            {
                case "TRUE":
                case "1":
                case "Y":
                case "YES":
                    val = true;
                    return true;

                case "FALSE":
                case "0":
                case "N":
                case "NO":
                    val = false;
                    return true;

                default:
                    val = false;
                    return false;
            }
        }

        protected override string ToText(bool val) => val ? "1" : "0";
        public override int Compare(int x, int y) => fValues[x].CompareTo(fValues[y]);
    }
}