using AngleSharp.Dom;
using AngleSharp.Html.Dom;
using NbCore;
using NbCore.SelLocal;
using System.Text.RegularExpressions;

namespace NbSeleniumTest;

public partial class UnitTest1
{
    //Taskkill /IM geckodriver.exe /F

    //https://stackoverflow.com/questions/53039551/selenium-webdriver-modifying-navigator-webdriver-flag-to-prevent-selenium-detec
    [Fact]
    public void LebaraTestResutls()
    {
        string storeDir = @$"C:\AutoDelete\Lebara";
        NbFs.CreateDirRecursive(storeDir);
        DiskStoreFireFox sel = new(storeDir, "Bisc");

        const string lebarUrl = @"https://mobile.lebara.com/gb/en/login";
        (IHtmlDocument doc, string _) = sel.LoadAndStoreHtml(new Uri(lebarUrl), "html", DiskStoreFireFox.FolderStrategy.Url);
        if (doc == null)
            throw new Exception("Doc was not loaded");


        doc.ChildrenToFiles(storeDir, excludeScript: false);
    }


    [Fact]
    public void KillGecko()
    {
        var res = NbProcess.RunSync("TASKKILL", null, "/F", "/IM", "geckodriver.exe", "/T");
    }


        [Fact]
    public void Test1()
    {
        string modUrl = "http://192.168.1.1/webpages/login.html";
        using NbCore.SelLocal.NbSel sel = new("Bisc");
        sel.Ff.Navigate().GoToUrl(modUrl);

        File.WriteAllText(@"C:\AutoDelete\2.html", sel.Ff.PageSource);



        //Uri amaz = new(@"https://www.amazon.co.uk/s?k=kindle&ref=nb_sb_noss_2");
    }

    [Fact]
    public void UdemyTestResutls()
    {
        string storeDir = @$"C:\AutoDelete\Udemy";
        NbFs.CreateDirRecursive(storeDir);
        DiskStoreFireFox sel = new(storeDir, "default-release");

        const string udemyUrl = @"https://www.udemy.com/course/aws-certified-cloud-practitioner-practice-test/learn/quiz/4426386/result/862421204#overview";
        (IHtmlDocument doc, string _) = sel.LoadAndStoreHtml(new Uri(udemyUrl), "html", DiskStoreFireFox.FolderStrategy.Url);
        if (doc == null)
            throw new Exception("Doc was not loaded");


        doc.ChildrenToFiles(storeDir);
    }

    [Fact]
    public async Task Youtube_rss()
    {
        const string youtubeUrl4 = @"https://www.youtube.com/watch?v=0DHNmPmgfNk";
        var rss4 = await YoutubeRssLink_HttpClient(youtubeUrl4);
        // Assert.Equal("https://www.youtube.com/feeds/videos.xml?channel_id=UCgpSieplNxXxLXYAzJLLpng", rss3);


        const string youtubeUrl1 = @"https://www.youtube.com/watch?v=PeX4Wa-k1E8";
        const string youtubeUrl2 = @"https://www.youtube.com/watch?v=jZvxXyC8wCk";
        const string youtubeUrl3 = @"https://www.youtube.com/watch?v=7hBPI0xYezo";

        var rss3 = await YoutubeRssLink_HttpClient(youtubeUrl3);
        // Assert.Equal("https://www.youtube.com/feeds/videos.xml?channel_id=UCgpSieplNxXxLXYAzJLLpng", rss3);

        {
            var rss1 = YoutubeRssLink_FireFox(youtubeUrl1);
            Assert.Equal("https://www.youtube.com/feeds/videos.xml?channel_id=UCgpSieplNxXxLXYAzJLLpng", rss1);

            var rss2 = YoutubeRssLink_FireFox(youtubeUrl2);
            Assert.Equal("https://www.youtube.com/feeds/videos.xml?channel_id=UCKCVeAihEfJr-pGH7B73Wyg", rss2);
        }
    }


    [GeneratedRegex(@"""http:\\\/\\\/www.youtube.com\\\/channel\\\/(UC.+?)""")]   // ?  - for lazy
    public static partial Regex Channel1();
    [GeneratedRegex(@"""http:\/\/www.youtube.com\/channel\/(UC.+?)""")]   // ?  - for lazy
    public static partial Regex Channel2();
    [GeneratedRegex(@"""url"":""\/channel\/(.+?)""")]   // ?  - for lazy
    public static partial Regex Channel3();

    private static readonly Regex[] Chan = new Regex[] { Channel1(), Channel2(), Channel3() };

    public static async Task<string> YoutubeRssLink_HttpClient(string youtubeUrl)
    {
        string storeDir = @$"C:\AutoDelete\Youtube_rss";
        NbFs.CreateDirRecursive(storeDir);
        using HttpClient cln = new();
        string res = await cln.GetStringAsync(youtubeUrl) ?? throw new Exception($"No string was loaded from '{youtubeUrl}'");

        List<string> Links = new();
        foreach (var rg in Chan)
        {
            Match match = rg.Match(res);
            if (match.Success)
                Links.Add(match.Groups[1].Value);
        }

        if (Links.Count > 0)
            return @$"https://www.youtube.com/feeds/videos.xml?channel_id={Links[0]}";

        const string htmlFile = @"C:\AutoDelete\1.html";
        File.WriteAllText(htmlFile, res);
        throw new Exception($"Can't fild channel link. Check the file: '{htmlFile}'");
    }


    public static string YoutubeRssLink_FireFox(string youtubeUrl)
    {
        string storeDir = @$"C:\AutoDelete\Youtube_rss";
        NbFs.CreateDirRecursive(storeDir);
        DiskStoreFireFox sel = new(storeDir, "default");  //default-release

        (IHtmlDocument doc, string _) = sel.LoadAndStoreHtml(new Uri(youtubeUrl), "html", DiskStoreFireFox.FolderStrategy.Url, null, new WaitCond(DelayMs: 1000, null));
        if (doc == null)
            throw new Exception("Doc was not loaded");

        File.WriteAllText(@"C:\AutoDelete\1.html", doc.DocumentElement.InnerHtml);

        Match res = Channel1().Match(doc.DocumentElement.InnerHtml);
        if (!res.Success)
            throw new Exception("Can't fild channel link");

        var rssLink = @$"https://www.youtube.com/feeds/videos.xml?channel_id={res.Groups[1].Value}";
        return rssLink;
    }
    //var tk = await NbProcess.RunAsync("TASKKILL.exe", null, "/F", "/IM", "geckodriver.exe", "/T");
}

