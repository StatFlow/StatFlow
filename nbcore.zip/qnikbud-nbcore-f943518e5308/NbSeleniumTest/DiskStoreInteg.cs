﻿using NbCore;
using System.Security.Cryptography;

namespace NbSeleniumTest
{
    public class DiskStoreInteg
    {
        [Fact]
        public void Md5_Test()
        {
            string fileName = @"C:\App\DiskStore\Xh\thumb\c6\c6eb5383f8a6f742f834315fcc292";

            Lazy<MD5> Md5 = new(() => MD5.Create());
            using FileStream fs = new(fileName, FileMode.Open, FileAccess.Read);
            byte[] md5 = Md5.Value.ComputeHash(fs);
            string md5str = DiskStore.Bytes2HexStr(md5);
        }
    }
}
