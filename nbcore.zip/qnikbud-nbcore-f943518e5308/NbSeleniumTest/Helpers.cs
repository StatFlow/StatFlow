﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Xunit.Abstractions;

namespace NbSeleniumTest;

public sealed class NbSelRemoteFixture : IDisposable
{
    internal readonly WebApplicationFactory<Program> WebApp;
    internal readonly XunitLogger<NbSelRemoteFixture> Log;

    public NbSelRemoteFixture()
    {
        Log = new XunitLogger<NbSelRemoteFixture>();
        WebApp = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            /*builder.ConfigureServices(services => { services.AddSingleton<IHelloService, MockHelloService>(); });*/  //This is to mock the service 
            builder.ConfigureServices(ConfServ);
        });
    }

    void ConfServ(IServiceCollection srv)
    {
        var sd = new ServiceDescriptor(typeof(ILogger<NbSelRemoteFixture>), Log);
        srv.Add(sd);
    }

    public void Dispose() => WebApp?.Dispose();
}

public sealed class XunitLogger<T> : ILogger<T>, IDisposable
{
    internal ITestOutputHelper? OutputHelper { get; set; }

    public XunitLogger(ITestOutputHelper? output = null) => OutputHelper = output;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter) => OutputHelper?.WriteLine(state?.ToString());

    public bool IsEnabled(LogLevel logLevel) => true;
    public IDisposable? BeginScope<TState>(TState state) where TState : notnull => this;

    public void Dispose() { }
}