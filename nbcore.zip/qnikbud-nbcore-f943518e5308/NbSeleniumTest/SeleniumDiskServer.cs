﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Xunit;
using Xunit.Abstractions;

namespace NbSeleniumTest;

public class SeleniumDiskServer : IClassFixture<SelDiskFixture>
{
    readonly WebApplicationFactory<NbSel.DiskServer.Program> Serv;
    private readonly ITestOutputHelper Log; //https://xunit.net/docs/capturing-output

    public SeleniumDiskServer(SelDiskFixture webFixture, ITestOutputHelper log)
    {
        Serv = webFixture.WebApp;
        Log = log;
        //webFixture.Log.OutputHelper ??= log;
    }


    [Fact]
    public async Task TopicTest()
    {
        Log.WriteLine($"Started {nameof(TopicTest)}");

        var c = Serv.CreateClient();  //Think about having one client for the whole test class
        var d = await c.GetStringAsync("/");

    }
}


public sealed class SelDiskFixture : IDisposable
{
    internal readonly WebApplicationFactory<NbSel.DiskServer.Program> WebApp;
    //internal readonly XunitLogger<WebFixture> Log;

    public SelDiskFixture()
    {
        //Log = new XunitLogger<WebFixture>();
        WebApp = new WebApplicationFactory<NbSel.DiskServer.Program>().WithWebHostBuilder(builder =>
        {
            /*builder.ConfigureServices(services => { services.AddSingleton<IHelloService, MockHelloService>(); });*/  //This is to mock the service 
            builder.ConfigureServices(ConfServ);
        });
    }

    void ConfServ(IServiceCollection srv)
    {
        /*var sd = new ServiceDescriptor(typeof(ILogger<NbSel.DiskServer.Program>), Log);
        srv.Add(sd);*/
    }

    public void Dispose() => WebApp?.Dispose();
}

/*public sealed class XunitLogger<T> : ILogger<T>, IDisposable
{
    internal ITestOutputHelper? OutputHelper { get; set; }

    public XunitLogger(ITestOutputHelper? output = null) => OutputHelper = output;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter) => OutputHelper?.WriteLine(state?.ToString());

    public bool IsEnabled(LogLevel logLevel) => true;
    public IDisposable BeginScope<TState>(TState state) where TState : notnull => this;
    public void Dispose() { }
}*/