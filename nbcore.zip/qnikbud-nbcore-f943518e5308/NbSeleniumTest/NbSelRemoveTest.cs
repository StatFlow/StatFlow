﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace NbSeleniumTest;

public class NbSelRemoteTest : IClassFixture<NbSelRemoteFixture>
{
    readonly WebApplicationFactory<Program> WebApp;

    public NbSelRemoteTest(NbSelRemoteFixture fix)
    {
        WebApp = fix.WebApp;
    }


    [Fact]
    public async Task NbSelRemove_Test1()
    {
        var c = WebApp.CreateClient();  //Think about having one client for the whole test class
        var res = await c.GetStringAsync("/load?url=https://www.rbc.ru");
        //var res = await c.GetStringAsync("/");
    }
}
