//https://pmichaels.net/2021/11/28/dependency-injection-in-minimal-apis-in-net-6/
//https://learn.microsoft.com/en-us/aspnet/core/fundamentals/minimal-apis?view=aspnetcore-7.0

using NbSelRemotel;

var bld = WebApplication.CreateBuilder(args);
bld.Services.AddSingleton((sp) => new ServiceGecko("PCast"));


var app = bld.Build();

app.MapGet("/", () => "Hello World!");

app.MapGet("/gecko", (ServiceGecko gecko) => gecko.Name);

app.MapGet("/load", (string url, ServiceGecko gecko) => gecko.LoadPage(url));


app.Run();



public partial class Program { }