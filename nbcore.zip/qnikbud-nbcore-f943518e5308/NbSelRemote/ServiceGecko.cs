﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using System.Text;

namespace NbSelRemotel;

public record WaitCond(int? DelayMs, By? Element);

public sealed class ServiceGecko : IDisposable
{
    private const string ProfDir = @"%APPDATA%\Mozilla\Firefox\Profiles";
    public string Name => nameof(ServiceGecko);
    private readonly FirefoxDriver Ff;

    public ServiceGecko(string ffProfile)
    {
        var profileDir = GetProfDir(ffProfile);
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        FirefoxOptions opt = new() { Profile = new FirefoxProfile(profileDir.FullName) };
        opt.AddArgument("--disable-blink-features=AutomationControlled");   //Selenium detection suppression    https://stackoverflow.com/questions/53039551/selenium-webdriver-modifying-navigator-webdriver-flag-to-prevent-selenium-detec
        Ff = new(opt);

        static DirectoryInfo GetProfDir(string fireFoxProfile)
        {
            DirectoryInfo di = new(Environment.ExpandEnvironmentVariables(ProfDir));
            var res = di.GetDirectories().FirstOrDefault(d => d.Name.Split('.')[1] == fireFoxProfile) ?? throw new DirectoryNotFoundException($"Can't find '{fireFoxProfile}' Firefox profile in dir: {di.FullName}");
            return res;
        }
    }

    public (string pageSrc, string? newUrl) LoadPage(string url)  //WaitCond? waitCond
    {
        try
        {
            Ff.Navigate().GoToUrl(url);

            var waitCond = new WaitCond(1500, null);
            if (waitCond?.Element != null)
            {
                var wait = new WebDriverWait(Ff, TimeSpan.FromMilliseconds(waitCond.DelayMs ?? 3000));
                if (waitCond?.Element != null)
                {
                    wait.Until(drv => drv.FindElement(waitCond.Element));
                }
            }
            else if (waitCond?.DelayMs != null)
                Thread.Sleep(waitCond.DelayMs.Value);
            string pageSrc = Ff.PageSource;

            string? newUrl = (Ff.Url == url.ToString()) ? null : Ff.Url;
            return (Ff.PageSource, Ff.Url);
        }
        catch(Exception ex)
        {
            return (ex.Message, null);
        }
    }

    public void Dispose()
    {
        Ff.Dispose();
    }
}
