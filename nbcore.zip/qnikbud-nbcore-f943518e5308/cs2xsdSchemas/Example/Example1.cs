﻿namespace Example.Xml
{
    public partial class Example
    {
        private static void Resolve() { }
    }
}
