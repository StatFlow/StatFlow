﻿using System.Diagnostics.CodeAnalysis;
[assembly: SuppressMessage("Design", "CA1050:Declare types in namespaces", Justification = "Test classed do not have to be in namespace because they are not useds ouside by other code", Scope = "module")]
[assembly: SuppressMessage("Usage", "xUnit1004:Test methods should not be skipped", Justification = "Test used for schema generation", Scope = "module")]

public class NbXsdSchema
{
    [Fact(Skip = "Generates Schema")] 
    public void Schema() => Cs2Xsd.Generate(Root(), "NbXsdV1", @"..\..\..\..\cs2xsd\NbXsdV1.xsd", saveSchemaXml: true);

    static TypeAttrOnly XBaseTag => new(nameof(BaseTag) //Base for all tags (elem, attrib)
        , new Attr("Name", XsType.String)
        , new Attr("Doc", XsType.String)  //TODO: This should be inner value perhaps???
        );

    static TypeDerived XElem => new(nameof(Elem), XBaseTag
        , new Attr("type", XsType.String, Uses.Required)
        , new Attr("min", XsType.Int, Uses.Optional, "-2", "Unbounded=-1, None=-2")
        , new Attr("max", XsType.Int, Uses.Optional, "-2", "Unbounded=-1, None=-2")
        , new ListSingle("keys", "key", Key, allowEmpty: true) //Keys are not mandatory and should be used only in the root element
        );

    static TypeDerived XAttr => new(nameof(Attr), XBaseTag
        , new Attr("type", XsType.String, Uses.Required)
        , new Attr("use", XUses, Uses.Required)
        , new Attr("dflt", XsType.String, Uses.Optional)
        );

    static TypeDerived XVal => new(nameof(Val), XBaseTag
        , new Attr("type", XsType.String, Uses.Required)
        , new Attr("use", XUses, Uses.Required)
        , new Attr("dflt", XsType.String, Uses.Optional)
        );

    static TypeDerived XListSingle => new(nameof(ListSingle), XElem);

    static TypeEnum XUses => new(nameof(Uses), XsType.String,
        ("None", ""), ("Optional", ""), ("Required", ""), ("Prohibited", ""), ("Key", "Generates <xs:key> tag")
        );

    static TypeAttrOnly Key => new("XKey"
        , new Attr("name", XsType.NCName, Uses.Required, doc: "The name for unique key to be reffered by KeyRef")
        , new Attr("selector", XsType.String, Uses.Required, doc: "XPath from the rool element to the tag containing the key field, for instance:  icons/icon.")
        , new Attr("field", XsType.String, Uses.Required, doc: "The name of the field containing unique key, for instance @name for name attribute.")
        );

    static TypeChoice XXsType => new("XsType", min: 1, max: Elem.Unbounded //This should be some sort of a base type with miminum nodes
            , new Attr("name", XsType.String)
            , new Elem("attr", XAttr, 0, 1)
            , new Elem("val", XVal, 0, 1)
            , new Elem("elem", XElem, 0, 1)
            , new Elem("list_single", XListSingle, 0, 1)
        );

    static TypeDerived XTypeBuiltIn => new(nameof(TypeBuiltIn), XXsType);
    static TypeDerived XTypeName => new(nameof(TypeName), XXsType);
    static TypeDerived XTypeSequence => new(nameof(TypeSequence), XXsType);
    static TypeDerived XTypeChoice => new(nameof(TypeChoice), XXsType);
    static TypeDerived XTypeTagList => new(nameof(TypeTagList), XXsType);

    static TypeDerived XTypeAll => new(nameof(TypeAll), XXsType);
    static TypeDerived XTypeAttrOnly => new(nameof(TypeAttrOnly), XXsType);

    static TypeDerived XTypeDerived => new(nameof(TypeDerived), XXsType
        , new Elem("BaseType", XXsType, 1, 1)
        );
    static TypeDerived XTypeValuesList => new(nameof(TypeValuesList), XXsType
        , new Attr("MinLength", XsType.Int, Uses.Optional, "-1")
        , new Elem("ListOfType", XTypeBuiltIn, 1, 1)
        );

    static TypeDerived XTypeEnum => new(nameof(TypeEnum), XXsType
        , new Attr("type", XsType.String, Uses.Required)
        , new Elem("ListOfType", XTypeBuiltIn, 1, 1) //TODO: remove
        , new Elem("items", EnumItem, 1, Elem.Unbounded)
        );

    static TypeAttrOnly EnumItem => new("EnumItem" //Base for all tags (elem, attrib)
        , new Attr("key", XsType.String, Uses.Required)
        , new Attr("value", XsType.String, Uses.Required)  //TODO: This should be inner value perhaps???
        );

    static TypeAttrOnly TypeRef => new("type_ref", new Attr("type", XsType.String, Uses.Required)); //Base for all types

    internal static Elem Root()
    {
        var XTypes = new TypeChoice("types", min: 1, max: Elem.Unbounded
            , new Elem("XTypeBuiltIn", XTypeBuiltIn, 0, 1)
            , new Elem("XTypeName", XTypeName, 0, 1)

            , new Elem("XTypeSequence", XTypeSequence, 0, 1)
            , new Elem("XTypeChoice", XTypeChoice, 0, 1)
            , new Elem("XTypeTagList", XTypeTagList, 0, 1) //New List to replace Sequence and Choice (with attribute ordered)
            , new Elem("XTypeAll", XTypeAll, 0, 1)
            , new Elem("XTypeList", XTypeValuesList, 0, 1)
            , new Elem("XTypeEnum", XTypeEnum, 0, 1)
            , new Elem("XTypeAttrOnly", XTypeAttrOnly, 0, 1)
            , new Elem("XTypeDerived", XTypeDerived, 0, 1)
        //, new Attr("deleted", XsType.Bool, Uses.Optional, deflt: "false")
        );
        var Root = new TypeSequence("NbXsd"
            , new Elem("type", XTypes, 1)
            , new Elem("root", XElem, 1, 1)
            );

        return new Elem("nbxsd", Root);
    }
}
