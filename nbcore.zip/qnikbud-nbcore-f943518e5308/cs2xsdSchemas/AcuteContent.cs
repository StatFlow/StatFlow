﻿public class AcuteContent
{
    const string PathToRepo = @"..\..\..\..\..\";
    const string PathToXmlDir = PathToRepo + @"Cs\AcuteContent\AcuteContentBuilder\Xml\";

    [Fact]  // (Skip = "Generates Schema") DisplayName = "Acute Content Schema",
    public void Schema_Content() => Cs2Xsd.Generate(AcuteContentRoot(), xsdNameSpace: nameof(AcuteContent), PathToXmlDir + "AcuteContent.xsd", saveSchemaXml: true);

    [Fact]
    public void Schema_ContentBuilder() => Cs2Xsd.Generate(AcuteContentBuilderRoot(), xsdNameSpace: "AcuteContentBuilder", PathToXmlDir + "AcuteContentBuilder.xsd", saveSchemaXml: true);

    //private static XKey[] Keys() => new[] { new XKey() { name = "IconNames", selector = "icons/icon", field = "@name" } };

    static Elem AcuteContentBuilderRoot()
    {
        var Root = new TypeSequence("AcuteContentBuilderConfig"
            , new Elem("source_dir", XsType.String, 1, 1)
            , new Elem("tags_dir", XsType.String, 1, 1)
            , new Elem("music_mixin_dir", XsType.String, 0, 1)
            , new Elem("destination_dir", XsType.String, 1, 1)
            , new Elem("tag_helper_dir", XsType.String, 0, 1)
            , new Elem("ensure_thumbs", XsType.Bool, 1, 1, doc: "If true the builder will execute MediaPlayer for all files withouth corresponing screenshots")
            , new Elem("media_player", XsType.String, 1, 1)
            , new Elem("browser_url", XsType.String, 1, 1)
        );

        return new Elem("acute_content_builder", Root);
    }

    static Elem AcuteContentRoot()
    {
        TypeValuesList StringList = new(nameof(StringList), XsType.NCName);

        //List for hierarchy
        TypeAttrOnly NBox = new(nameof(NBox)
            , new Attr("tags", StringList, Uses.Optional));

        TypeDerived NText = new(nameof(NText), NBox
            , new Attr("text", XsType.String, Uses.Required));

        TypeDerived NPic = new(nameof(NPic), NBox
            , new Attr("src", XsType.String, Uses.Required)
            , new Attr("title", XsType.String, Uses.Required)
            );

        TypeDerived NPics = new(nameof(NPics), NBox //The list of pictures to be shown in the same spot with the arrows to switch
            , new Elem("pic", NPic, 1, 100));

        TypeDerived NVid = new(nameof(NVid), NBox
            , new Attr("src", XsType.String, Uses.Required)
            , new Attr("src_small", XsType.String, Uses.Optional)
            , new Elem("thumb", NPic, 1, 1)
            );

        TypeDerived NDir = new(nameof(NDir), NBox
            , new Attr("url", XsType.String, Uses.Required)
            , new Elem("thumb", NPic, 1, 1)
            );

        TypeChoice BoxList = new(nameof(BoxList), 0, Elem.Unbounded //This creates tags list in any order and with any number
            , new Elem("text", NText, Elem.Default, Elem.Unbounded)
            , new Elem("pic", NPic, Elem.Default, Elem.Unbounded)
            , new Elem("pics", NPics, Elem.Default, Elem.Unbounded)
            , new Elem("vid", NVid, Elem.Default, Elem.Unbounded)
            , new Elem("dir", NDir, Elem.Default, Elem.Unbounded)
        );

        var Root = new TypeSequence("AcuteContentXml"
            , new Attr("title", XsType.String, Uses.Optional)
            , new Elem("boxes", BoxList)
        );
        return new Elem("acute_content", Root);
    }
}