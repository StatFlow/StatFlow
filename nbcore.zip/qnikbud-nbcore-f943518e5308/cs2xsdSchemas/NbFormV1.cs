﻿public class NbFormV1
{
    const string PathToRepo = @"..\..\..\..\..\";

    [Fact(Skip = "Generates Schema")]
    public void Schema() => Cs2Xsd.Generate(Root(), xsdNameSpace: nameof(NbFormV1), PathToRepo + @"NbCore\NbWin\NbForm\NbFormV1.xsd");

    static Elem Root()
    {
        //Fields
        TypeAttrOnly FieldDescBase = new(nameof(FieldDescBase)
            , new Attr("name", XsType.String, Uses.Required)
            , new Attr("label", XsType.String, Uses.Required)
            );

        TypeDerived FieldText = new(nameof(FieldText), FieldDescBase
            , new Attr("old_val", XsType.String, Uses.Optional)
            , new Attr("new_val", XsType.String, Uses.Optional)
         );

        TypeDerived FieldNum = new(nameof(FieldNum), FieldDescBase
            , new Attr("old_val", XsType.Decimal, Uses.Optional)
            , new Attr("new_val", XsType.Decimal, Uses.Optional)
         );

        TypeDerived FieldDate = new(nameof(FieldDate), FieldDescBase
            , new Attr("old_val", XsType.Date, Uses.Optional)
            , new Attr("new_val", XsType.Date, Uses.Optional)
         );

        //This creates tags list in any order and with any number
        TypeChoice FiedDescs = new(nameof(FiedDescs), 0, Elem.Unbounded 
            //, new Attr("comment", XsType.String, Uses.Required)
            , new Elem("text", FieldText, 0, Elem.Unbounded)
            , new Elem("num", FieldNum, 0, Elem.Unbounded)
            , new Elem("date", FieldDate, 0, Elem.Unbounded)
        );


        //Button
        TypeEnum ButtonFunc = new(nameof(ButtonFunc), XsType.String, ("None", "None"), ("Enter", "Enter"), ("Esc", "Esc"));
        TypeEnum DlgResult = new(nameof(DlgResult), XsType.String, ("None", "None"), ("OK", "OK"), ("Cancel", "Cancel"),
            ("Abort", "Abort"), ("Retry", "Retry"), ("Ignore", "Ignore"), ("Yes", "Yes"), ("No", "No"), ("TryAgain", "TryAgain"), ("Continue", "Continue"));

        /*
        None = 0,
        OK = 1,
        Cancel = 2,
        Abort = 3,
        Retry = 4,
        Ignore = 5,
        Yes = 6,
        No = 7,
        TryAgain = 10,
        Continue = 11
        */

        TypeAttrOnly ButtonDesc = new(nameof(ButtonDesc)
            , new Attr("name", XsType.String, Uses.Required)
            , new Attr("label", XsType.String, Uses.Required)
            , new Attr("dialog_result", DlgResult, Uses.Optional, "None")
            , new Attr("func", ButtonFunc, Uses.Optional, "None")
            );

        //Root
        var Root = new TypeSequence("NbFormDesc"
             , new Attr("title", XsType.String, Uses.Optional)
             , new Elem("fields", FiedDescs)
             , new ListSingle("buttons", "button", ButtonDesc)
         );

        return new Elem("nbform", Root);
    }
}
