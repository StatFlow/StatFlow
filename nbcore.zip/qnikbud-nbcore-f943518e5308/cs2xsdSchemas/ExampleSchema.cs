﻿public class ExampleSchema
{
    [Fact(Skip = "Generates Schema")]
    public void Schema() => Cs2Xsd.Generate(Root(), xsdNameSpace: nameof(ExampleSchema), @"..\..\..\Example\Example.xsd", Keys(), saveSchemaXml: true);

    private static XKey[] Keys() => new[] { new XKey() { name = "IconNames", selector = "icons/icon", field = "@name" } };

    static Elem Root()
    {
        //Key references
        TypeAttrOnly Icon = new("Icon" //Base for all tags (elem, attrib)
            , new Attr("name", XsType.NCName, Uses.Key)
            , new Attr("data", XsType.String)
        );

        TypeAttrOnly Button = new("Button" //Base for all tags (elem, attrib)
            , new Attr("text", XsType.String)
            , new Attr("icon", XsType.NCName)
        );

        //List for hierarchy
        TypeAttrOnly Animal = new("Animal" //Base for all tags (elem, attrib)
            , new Attr("Name", XsType.String));

        TypeDerived Cat = new("Cat", Animal
            , new Attr("paws", XsType.String, Uses.Required));

        TypeDerived Bird = new("Bird", Animal
            , new Attr("wings", XsType.Int, Uses.Required));

        TypeChoice AnimalList = new(nameof(AnimalList), 0, Elem.Unbounded //This creates tags list in any order and with any number
            , new Elem("cat", Cat, Elem.Default, Elem.Unbounded)
            , new Elem("bird", Bird, Elem.Default, Elem.Unbounded)
        );

        TypeChoice AnimalListWithComment = new(nameof(AnimalListWithComment), 0, Elem.Unbounded //This creates tags list in any order and with any number
            , new Attr("comment", XsType.String, Uses.Required)
            , new Elem("cat", Cat, Elem.Default, Elem.Unbounded)
            , new Elem("bird", Bird, Elem.Default, Elem.Unbounded)
        );


        //List of unrelated eleements
        TypeChoice MixedButtonsList = new(nameof(MixedButtonsList), 0, Elem.Unbounded //This creates tags list in any order and with any number
            , new Elem("el1", UnrelatedType1(), Elem.Default, Elem.Unbounded)
            , new Elem("el2", UnrelatedType2(), Elem.Default, Elem.Unbounded)
        );

        static TypeAttrOnly UnrelatedType1() => new(nameof(UnrelatedType1)
            , new Attr("name1", XsType.NCName, Uses.Required)
        );

        static TypeAttrOnly UnrelatedType2() => new(nameof(UnrelatedType2)
            , new Attr("name2", XsType.NCName, Uses.Required)
        );

        //Simple stuff
        static TypeAttrOnly AttrOnlyTag() => new(nameof(AttrOnlyTag)
            , new Attr("name", XsType.NCName, Uses.Required)
            , new Attr("value", XsType.String, Uses.Optional, deflt: String.Empty)
        );

        static TypeSequence SequenceTag() => new(nameof(SequenceTag)
            , new Elem("string_elem1", XsType.String, 1, 1)
            , new Elem("string_elem2", XsType.String, 0, 1)
        );

        var Root = new TypeSequence(nameof(ExampleSchema)
            , new Attr("title", XsType.String, Uses.Optional, deflt: "Example")
            , new Elem("seq_tag", SequenceTag(), 0, 1)

            , new ListSingle("icons", "icon", Icon)
            , new ListSingle("buttons", "button", Button)
            , new Elem("mixed_list", MixedButtonsList, doc: "List of elements of two types with no common base class. This will generate object[] property.")
            , new Elem("animal_list", AnimalList, doc: "List of elements with common base class. The generated property should be the array of the base class")
            , new Elem("animal_list_comment", AnimalListWithComment, doc: "List of elements with common base class. The generated property should be the array of the base class")

            , new ListSingle("attronly_tag_list", "attronly_tag", AttrOnlyTag())
            , new ListSingle("string_list", "list_item", XsType.String)
            );
        return new Elem("example", Root);
    }

    //Thinking about possible list types
    // - List of single types (ListSingle = implemented)
    //  Ordered List of multiple types each is a single occurance
    //  Unordered List of multiple types each is a single occurance
    //  Ordered List of multiple types each with multiple / single occurance
    //  Unordered List of multiple types with  multiple / single single occurance
    // Each list should have its own attributes

}
