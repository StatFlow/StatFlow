﻿public class DoerConfV1
{
    const string PathToRepo = @"..\..\..\..\..\";

    [Fact]
    public void Schema() => Cs2Xsd.Generate(Root(), xsdNameSpace: nameof(DoerConfV1), PathToRepo + @"NbCore\Doer\Conf\DoerConf.xsd");

    static Elem Root()
    {
        TypeAttrOnly NameVal = new(nameof(NameVal)
            , new Attr("name", XsType.String, Uses.Optional) //Command line parameters might not have the name
            , new Val("val", XsType.String, Uses.Required)
        );

        //URL
        TypeAttrOnly UrlBase = new(nameof(UrlBase));

        TypeDerived BtnUrlInfo = new(nameof(BtnUrlInfo), UrlBase
            , new Attr("url", XsType.String, Uses.Required)
            , new Attr("profile", XsType.String, Uses.Optional, doc: "Browser profile that should be used for this link")
            , new Elem("param", NameVal, 0, Elem.Unbounded)
         );

        TypeDerived BntExecInfo = new(nameof(BntExecInfo), UrlBase
            , new Attr("exec", XsType.String, Uses.Required)
            , new Attr("work_dir", XsType.String, Uses.Optional)
            , new Elem("param", NameVal, 0, Elem.Unbounded)
         );

        TypeDerived BntFunctionInfo = new(nameof(BntFunctionInfo), UrlBase //Function for internal code, such as Encode or Decode logic
            , new Attr("func", XsType.String, Uses.Required)
         );

        //Toolbar items
        TypeAttrOnly ToolbarItem = new(nameof(ToolbarItem)
            , new Attr("icon", XsType.String, Uses.Optional, deflt: String.Empty)
            , new Attr("tooltip", XsType.String, Uses.Optional, deflt: String.Empty)
            , new Attr("pass", XsType.String, Uses.Optional)
            , new Attr("clipboard_enc", XsType.String, Uses.Optional)
            , new Attr("keywords", XsType.String, Uses.Optional)
        );

        TypeDerived ToolbButton = new(nameof(ToolbButton), ToolbarItem
            , new Attr("shortcut", XsType.String, Uses.Optional) //TODO: support regex for validation
            , new Elem("href", BtnUrlInfo)  //0, 1 is the default
            , new Elem("search_href", BtnUrlInfo)
            , new Elem("exec", BntExecInfo)
            , new Elem("func", BntFunctionInfo)
        );

        TypeDerived DropDownButton = new(nameof(DropDownButton), ToolbarItem
            , new Elem("btn", ToolbButton, Elem.Default, Elem.Unbounded)
        );

        TypeDerived ToolbDivider = new(nameof(ToolbDivider), ToolbarItem);

        TypeChoice MixedButtonsList = new(nameof(MixedButtonsList), 0, Elem.Unbounded //This creates tags list in any order and with any number
            , new Elem("btn", ToolbButton, Elem.Default, Elem.Unbounded)
            , new Elem("dropdown", DropDownButton, Elem.Default, Elem.Unbounded)
            , new Elem("div", ToolbDivider, Elem.Default, Elem.Unbounded)
        );

        //Icons
        TypeAttrOnly IconBase = new(nameof(IconBase)
            , new Attr("name", XsType.NCName, Uses.Required));

        TypeDerived IconBase64 = new(nameof(IconBase64), IconBase
            , new Attr("data", XsType.String, Uses.Required)
         );

        TypeDerived IconFile = new(nameof(IconFile), IconBase
            , new Attr("file", XsType.String, Uses.Required)
            //, new Attr("index", XsType.Int, Uses.Optional, "-1", "If the file contains multiple icons, the index of the icon if counted top-down, left-right")
            , new Attr("ver", XsType.Int, Uses.Optional, "0", "Base 1 top-bottom")
            , new Attr("hor", XsType.Int, Uses.Optional, "0", "Base 1 left-right")
         );

        TypeChoice MixedIconsList = new(nameof(MixedIconsList), 0, Elem.Unbounded //This creates tags list in any order and with any number
            , new Attr("default_dir", XsType.String, Uses.Optional, String.Empty, "The dir where to search icons if the path was not provided")
            , new Elem("base64", IconBase64, Elem.Default, Elem.Unbounded)
            , new Elem("file", IconFile, Elem.Default, Elem.Unbounded)
        );

        TypeTagList VeracryptSettings = new(nameof(VeracryptSettings)
            , new Attr("exec", XsType.String, Uses.Required)
            , new Elem("path", XsType.String, 0, Elem.Unbounded) //Many paths for the containers
        );

        TypeSequence SettingsList = new(nameof(SettingsList)
            , new Elem("veracrypt", VeracryptSettings)
            , new Elem("ffmpeg", XsType.String)
            , new Elem("firefox", XsType.String)
        );

        //Root
        var Root = new TypeSequence(nameof(DoerConfV1)
            , new Elem("toolbar_links", MixedButtonsList)
            , new Elem("toolbar_search", MixedButtonsList)
            , new Elem("keyword_only", MixedButtonsList)
            , new Elem("keyword_hidden", MixedButtonsList)
            , new Elem("settings", SettingsList)

            //, new ListSingle("parameters", "param", NameVal)
            , new Elem("icons", MixedIconsList)
        );

        return new Elem("doer_conf", Root);
    }
}
