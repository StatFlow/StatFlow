using Doer;

namespace DoerTest;

public class DoerLogicTest
{
    [Fact]
    public void Test1()
    {
        var list = ActionMoveMediaFiles.ClearJd().ToList();
    }
}