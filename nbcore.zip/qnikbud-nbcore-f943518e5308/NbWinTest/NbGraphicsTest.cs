﻿using NbWin;
namespace NbWinTest;

public class NbGraphicsTest
{
    [Fact]
    public void GetExifDate_Test()
    {
        var a = NbGraphics.GetExifDate(@"WP_000660.jpg");
        Assert.Equal(new DateTime(2014, 05, 24, 9, 58, 08), a);
    }
}
