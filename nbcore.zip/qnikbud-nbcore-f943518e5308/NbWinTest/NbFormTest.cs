using NbWpfLib;
using NbFormV1.Xml;
using System.Windows.Forms;

namespace NbWinTest;

public class NbFormTest
{
    [Fact]
    public void NbFormDesc_Simple()
    {
        var _ = NbDialogForm.Show("text", "caption");

    }

    [Fact]
    public void NbFormDesc_Desc()
    {
        var flds = new FieldDescBase[] { new FieldText() { label = "Text field" } };
        var btns = new ButtonDesc[] {
            new ButtonDesc() { label = "Go", name = "GoAhead", func = ButtonFunc.Enter, dialog_result = DlgResult.OK } ,
            new ButtonDesc() { label = "Stop and Think!", name = "Stop", func = ButtonFunc.Esc, dialog_result = DlgResult.Cancel } ,
        };

        NbFormDesc formDesc = new($"Test dialog {DateTime.Now:HH-mm-ss}", flds, btns);

        DialogResult res = NbDialogForm.Show(formDesc);
        Assert.Equal(DialogResult.OK, res);
    }
}