﻿namespace NbOrm.Xml;

public enum OracleTypes { Int16, Int32, Int64, Decimal, Double, Single, NVarchar2, Varchar2, Char, TimeStamp, Date, Blob };

public class SqlScriptOracle : SqlScript
{
    //private const string IndentStr = "  ";

    public override IEnumerable<string> DropScript(model aModel) => DropTables(aModel);

    private static IEnumerable<string> DropTables(model aModel)
    {
        return aModel.tables.SelectMany(ts => ts.Items.Safe()).OfType<table>().Where(t => t.owner == TableOwnership.xml)
            .Reverse().Select(t => String.Format("DROP TABLE {0} CASCADE CONSTRAINTS;", t.SqlName));
    }

    protected override IEnumerable<string> CreateScriptContents(IEnumerable<table> ownedTables, model aModel)
    {
        var sequences = ownedTables.Where(t => t.Items.OfType<field>().Any(f => f.key == field_baseKey.identity))
            .Select(t => String.Format("CREATE SEQUENCE {0};", t.SequenceName));

        var tables = ownedTables.SelectMany(t => BracketedStatement("CREATE TABLE  " + t.SqlName, TableFields(t, aModel).JoinCommas()));

        //Triggers only for the tables holding identity fields
        var triggers = ownedTables.Where(t => t.Items.OfType<field>().Any(f => f.key == field_baseKey.identity))
            .Where(t => t.owner == TableOwnership.xml).SelectMany(t => t.SqlOraTriggers());

        return sequences.EmptyLines(2, tables).EmptyLines(2, triggers);
    }


    private static IEnumerable<string> TableFields(table tab, model model)
    {
        int maxNameLength = tab.Items.Max(f => f.name.Length) + 1;
        string mask = "{0,-" + maxNameLength.ToString() + "}";
        // ID NUMBER(8)  NOT NULL, 
        foreach (var f in tab.Items)
        {
            string fldDef = String.Format(mask, f.name) + f.SqlOraTableFieldEnding(model.tables.SelectMany(ts => ts.Items.Safe()).ToList());
            string? constr = f.SqlOraContraint(tab.SqlName);
            yield return String.IsNullOrEmpty(constr) ? fldDef
                : fldDef + Environment.NewLine + new String(' ', maxNameLength) + constr; //two lines in case of contraints 
        }
    }


    internal const string Number = "NUMBER";
    internal const string Date = "DATE";

    internal static string CType2OraType(CType cType)
    {
        return cType switch
        {
            CType.@bool => "CHAR",
            //case CType. byte: 
            //break; 
            //case CType. sbyte: 
            //break; 
            //case CType.char: 
            //break;
            CType.@decimal or CType.@double or CType.@float or CType.@int or CType.@uint or CType.@long or CType.@ulong or CType.@short or CType.@ushort => Number,
            CType.@string => "NVARCHAR2",
            CType.DateTime => Date,
            _ => throw new NbExceptionEnum<CType>(cType),
        };
    }

    public enum Db2XmlConversionMode { CsDriven, DbDriven }

    public static CType OraType2CType(string oraType, int? length, int? decimal_points, Db2XmlConversionMode mode)
    {
        switch (oraType)
        {
            //Oracle section
            case "NUMBER":
            case "numeric":
                if ((decimal_points ?? 0) != 0)
                    return CType.@decimal;

                switch (mode)
                {
                    case Db2XmlConversionMode.CsDriven:
                        if (length <= 10)
                            return CType.@int;
                        else if (length <= 20)
                            return CType.@long;
                        else
                            return CType.@decimal;

                    case Db2XmlConversionMode.DbDriven:
                        if (length <= 9)
                            return CType.@int;
                        else if (length <= 18)
                            return CType.@long;
                        else
                            return CType.@decimal;

                    default:
                        throw new NbExceptionEnum<Db2XmlConversionMode>(mode.ToString());
                }

            case "CHAR":
            case "NCHAR":
            case "VARCHAR2":
            case "NVARCHAR2":
                return CType.@string;
            case "CLOB":
            case "BLOB":
            case "RAW":
            case "LONG":
                return CType.blob;
            case "DATE":
            case "TIMESTAMP(6)":
            case "TIMESTAMP(4)":
            case "TIMESTAMP(3)":
                return CType.DateTime;
            case "UNDEFINED":
                return CType.@string;

            //Ms Sql section
            case "bit": return CType.@bool;
            case "byte": return CType.@byte;
            case "tinyint": return CType.@byte;
            case "int": return CType.@int;
            case "bigint": return CType.@long;
            case "long": return CType.@long;
            case "float": return CType.@float;
            case "real": return CType.@double;

            case "smallint":
                return CType.@char;

            case "decimal":
            case "money":
                return CType.@decimal;

            case "datetime":
            case "datetime2":
            case "date":
            case "smalldatetime":
            case "timestamp":
            case "datetimeoffset": //TODO: use TimeSpan here
                return CType.DateTime;

            case "nchar":
            case "char":
            case "varchar":
            case "nvarchar":
            case "sysname":
            case "uniqueidentifier":
                return CType.@string;

            case "varbinary":
            case "ntext":
            case "text":
            case "xml":
            case "image":
                return CType.blob;

            default:
                throw new NbException($"Unsupported oraType: {oraType} for CType conversion");
        }
    }

    //TODO: keep dictionary of the identifiers and add numbers to the end if names conflict 
    /// <summary> 
    /// Tries to use 38 characters of Oracle indentifier to create meaningful name 1/! </summary> 
    /// <param name="parts"></param> 
    /// <returns></returns> 
    internal static string OraName(params string[] parts)
    {
        if (parts == null || parts.Length == 0)
            throw new ArgumentException("OraName takes non-empty array");
        const int oraNameMaxLength = 30;
        int simpleLength = parts.Sum(p => p.Length + 1) - 1;
        if (simpleLength <= oraNameMaxLength)
            return String.Join("_", parts);

        string res = String.Empty;

        for (int i = parts.Length - 1; i >= 0; --i)
        {
            // remaining length # between fields / #fields 
            int shareLengh = (oraNameMaxLength - res.Length - i) / (i + 1);
            string currpart = parts[i];
            res = (i > 0 ? "_" : String.Empty) + (currpart.Length > shareLengh ? currpart.Substring(currpart.Length - shareLengh, shareLengh) : currpart) + res;
        }
        return res.Trim('_'); //Can’t start with  _
    }
}

public class SqlCsOracle : SqlCs
{
    public const string OraOutParam = ":pOut_id";

    protected override IEnumerable<string> SqlInsertStringDef(recordset recset, field identityN)
    {
        string insertStatement = String.Format("INSERT INTO {0} ({1})\r\nVALUES ({2}){3}", recset.SqlName,
            String.Join(recordset.sqlFieldSeparator, recset.Fields.Where(f => f != identityN).Select(f => f.name)),
            String.Join(recordset.sqlFieldSeparator, recset.Fields.Where(f => f != identityN).Select(f => ParamName(f))),
            identityN != null ? String.Format("\r\nRETURNING {0} INTO {1}", identityN.name, OraOutParam) : String.Empty);

        yield return String.Format("string sql = @\"{0}\";", insertStatement);
    }

    protected override IEnumerable<string> SqlUpdateStringDef(recordset recset, field_base primary_key)
    {
        const string separator = ",";//+ Environment.NewLine	//"INSERT INTO {0} ({1})\r\nVALUES ({2}){3}"
        string insertStatement = String.Format("UPDATE {0} SET\r\n{1}\r\nWHERE {2}", recset.SqlName,
            String.Join(separator, recset.Fields.Where(f => f != primary_key).Select(f => UpdateLine(f))),
            UpdateLine(primary_key));

        yield return String.Format("string sql = @\"{0}\";", insertStatement);
    }

    protected override string ParamName(field_base fld) => ":p_" + fld.name;
    protected override string UpdateLine(field_base fld) => $"{fld.name} = {ParamName(fld)}";
}
