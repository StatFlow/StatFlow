﻿using NbOrm.Xml;
using NbCore;

namespace NbOrm.Nbq
{
    /// <summary>
    /// Parsed Nbq language using the list of lexems 'lex' and  the dictionary of XML recordset decritions 'tables'
    /// </summary>
    public class NbqRecordset
    {
        public static NbqRecordset Try(IEnumerator<NbqLexem> lex, NbDictionary<string, recordset> tables)
        {
            if (lex.Current.type != NbqLexem.Type.Identifier)
                throw new NbqException("Recordset identifier is expected", lex.Current);

            var identifier = lex.Current.ValN;
            if (lex.MoveNext() && lex.Current.IsPunct('.'))
            { //Read combined modifiere
                if (!lex.MoveNext())
                    throw new NbqException("Undetifier must continue after the dot", lex.Current);
                if (lex.Current.type != NbqLexem.Type.Identifier)
                    throw new NbqException("Second part of identifier is expected", lex.Current);
                identifier = identifier + "." + lex.Current.ValN;

                lex.MoveNext(); //Advance for the next call
            }

            if (!tables.TryGetValue(identifier, out recordset? tbl))
                throw new NbqException($"Can't find recordset '{identifier}' in the model", lex.Current);

            return new NbqRecordset(tbl, lex);
        }

        public readonly recordset Recordset;
        public readonly List<NbqWhereSingleExpr>? Wheres;

        private NbqRecordset(recordset tbl, IEnumerator<NbqLexem> lex)
        {
            Recordset = tbl;
            if (lex.Current?.type == NbqLexem.Type.Punctuation) //If next exists and it is a bracket
            {
                if (lex.Current.CharN == NbqParser.Bracket(BracketType.Fields, true)) // '('
                    throw new NbqException("Fields closure is not yet supported", lex.Current);
                else if (lex.Current.CharN == NbqParser.Bracket(BracketType.Params, true)) // '['
                    Wheres = ParseWhereListN(tbl, lex);
                else
                    throw new NbqException($"Unexpected symbol, {NbqParser.Bracket(BracketType.Fields, true)} or {NbqParser.Bracket(BracketType.Params, true)} are expected", lex.Current);
            }
            else
                Wheres = new List<NbqWhereSingleExpr>(0);
        }

        private static List<NbqWhereSingleExpr>? ParseWhereListN(recordset tbl, IEnumerator<NbqLexem> lex)
        {
            var prevLex = lex.Current;

            var list = new Lazy<List<NbqWhereSingleExpr>>(() => new List<NbqWhereSingleExpr>(), false);
            do
            {
                if (!lex.MoveNext())
                    throw new NbqException("Unexpected end of line after", prevLex);

                NbqWhereSingleExpr? where = ParseWhereN(tbl, lex);
                if (where != null)
                    list.Value.Add(where);
                prevLex = lex.Current;
            }
            while (prevLex.type == NbqLexem.Type.Punctuation && prevLex.CharN == NbqParser.ParamSeparator);

            if (prevLex.type == NbqLexem.Type.Punctuation && prevLex.CharN == NbqParser.Bracket(BracketType.Params, false))
                lex.MoveNext();

            return list.IsValueCreated ? list.Value : null;
        }

        private static SearchTypes MapLexToSearchType(NbqLexem.Type lexType) => lexType switch
        {
            NbqLexem.Type.String => SearchTypes.@string,
            NbqLexem.Type.Number => SearchTypes.@int,
            NbqLexem.Type.DateTime => SearchTypes.date,
            _ => SearchTypes.none,
        };

        private static NbqWhereSingleExpr? ParseWhereN(recordset tbl, IEnumerator<NbqLexem> lex)
        {
            NbqWhereSingleExpr res = new();
            switch (lex.Current.type)
            {
                //There is no field, use default search fields or keys
                case NbqLexem.Type.String:
                case NbqLexem.Type.Number:
                case NbqLexem.Type.DateTime:
                    var dst = MapLexToSearchType(lex.Current.type);
                    res.Field = tbl.GetFieldForSearchTypeN(dst);
                    if (res.Field == null && (tbl as view)?.fCustSql == null) //views with custom sql are allowed to have unresolved fields
                        throw new Exception($"Default search field or parameter for type {dst} is not found in the recordset {tbl.name}, please specify the field / parameter name");
                    res.ValueLexem = lex.Current;
                    break;

                case NbqLexem.Type.Identifier:
                    if (tbl is view)    //First search for view parameters, because they allow filtering in the query, not of result.
                    {
                        res.Field = (tbl as view)?.Parameters.FirstOrDefault(f => f.name.EqIC(lex.Current.ValN));
                    }

                    if (res.Field == null) //Then search on the rest of the fields
                    {
                        res.Field = tbl.Fields.FirstOrDefault(f => f.name.EqIC(lex.Current.ValN));
                        if (res.Field == null)
                            throw new Exception($"Field {lex.Current.ValN} is not found in the table {tbl.name}");
                    }

                    lex.MoveNext();
                    if (lex.Current.type != NbqLexem.Type.Punctuation || lex.Current.CharN != '=')
                        throw new Exception($"Symbol = is expected after identifier {res.Field.name}");

                    lex.MoveNext();
                    switch (res.Field.GetCType())
                    {
                        case CType.@string:
                            if (lex.Current.type != NbqLexem.Type.String)
                                throw new Exception($"String is expected as a value for the '{res.Field.name}' field");

                            res.ValueLexem = lex.Current;
                            break;

                        case CType.@int:
                        case CType.@long:
                        case CType.@decimal:
                            if (lex.Current.type != NbqLexem.Type.Number)
                                throw new Exception($"Number is expected as a value for the '{res.Field.name}' field");

                            res.ValueLexem = lex.Current;
                            break;

                        case CType.DateTime:
                            if (lex.Current.type != NbqLexem.Type.DateTime)
                                throw new Exception($"DateTime is expected as a value for the '{res.Field.name}' field");
                            res.ValueLexem = lex.Current;
                            break;

                        default:
                            throw new Exception($"Unspported field CType '{res.Field.GetCType()}' in NbqWhere parsing");
                    }
                    break;

                default:
                    throw new NbqException("Identifier, String, number or date are expected", lex.Current);
            }

            lex.MoveNext(); //Advance to the next
            return res;
        }
    }


    public class NbqWhereSingleExpr
    {
        public field_base? Field;
        public NbqLexem? ValueLexem;

        public override string ToString() => $"{Field?.name} = {ValueLexem}";
    }

}
