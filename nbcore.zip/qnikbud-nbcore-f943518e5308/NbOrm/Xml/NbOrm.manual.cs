﻿using System.Xml.Serialization;
using System.Xml.Linq;

//#pragma warning disable IDE1006

namespace NbOrm.Xml;

public partial class model
{
    public static SearchTypes CtypeToSearchType(CType cType) => cType switch
    {
        CType.@char or CType.@string => SearchTypes.@string,
        CType.@decimal or CType.@double or CType.@float or CType.@int or CType.@uint or CType.@long or CType.@ulong or CType.@short or CType.@ushort => SearchTypes.@int,
        CType.DateTime => SearchTypes.date,
        _ => SearchTypes.none,
    };

    public static bool IsNumeric(CType cType) => cType switch
    {
        CType.@byte or CType.@sbyte or CType.@char or CType.@decimal or CType.@double or CType.@float or CType.@int or CType.@uint or CType.@long or CType.@ulong or CType.@short or CType.@ushort => true,
        _ => false,
    };

    public recordset GetRecordset(string name) => tables.SelectMany(ts => ts.Items.Safe()).Single(t => t.name.Equals(name, StringComparison.OrdinalIgnoreCase));

    private static readonly XmlSerializer modelXmlSerializer = new(typeof(model));

    public static object NbDir { get; private set; }

    internal void ResolveAndValidate(IDictionary<string, XElement?> viewMixedContents)
    {
        int tablesEndingWithS = tables.SelectMany(ts => ts.Items.Safe()).OfType<table>().Count(t => t.XmlName.EndsWith("S") || t.XmlName.EndsWith("s"));

        modelConfig cnf = new() { pluralise = (tablesEndingWithS < tables.Length / 2) ? TriBool.@true : TriBool.@false };
        config = cnf.PushSettingsTo(config);

        if (tables == null || tables.Length == 0)
            throw new NbException("Data model doesn't contain any tables");

        var tableDict = tables.SelectMany(ts => ts.Items.Safe()).ToNbDictionary(t => t.name, t => t, description: "Full set of recordsets from XML");

        foreach (var tableSet in tables)
        {
            foreach (var recordset in tableSet.Items.Safe())
            {
                try
                {
                    viewMixedContents.TryGetValue(recordset.name, out XElement? mixedContent);
                    recordset.TableSet = tableSet;
                    recordset.ResolveAndValidate(config, tableDict, types, mixedContent);
                }
                catch (Exception ex)
                {
                    throw new Exception($"Error while resolving {recordset.GetType().Name} '{recordset.name}'", ex);
                }
            }
        }
    }

    public static model LoadXml(string xmlFileName)
    {
        var viewMixedContexts = new NbDictionary<string, XElement?>(20, description: "NbOrm mixed contents");
        try
        {
            model res;
            using (FileStream str = new(xmlFileName, FileMode.Open))
            using (StreamReader rdr = new(str))
            {
                res = (model)(modelXmlSerializer.Deserialize(rdr) ?? throw new Exception("Deserilizer has failed"));

                str.Seek(0, SeekOrigin.Begin);
                var doc = XDocument.Load(str);
                var tbls = doc.Element(nameof(model))?.Element("tables");
                var views = tbls?.Elements(nameof(view)).ToList();
                foreach (var v in views.Safe())
                {
                    AddTo(v.Element("sql"), viewMixedContexts, Attrib(v, "name").Value);
                }
            }
            res.ResolveAndValidate(viewMixedContexts);
            return res;
        }
        catch (Exception ex)
        {
            throw new Exception($"Error deserializing '{xmlFileName}'", ex);
        }
    }

    private static void AddTo<K, T>(T obj, NbDictionary<K, T> dict, K key) where K : notnull => dict.Add(key, obj); //NbDictionari uses new and the call on the interface uses the base component's method

    public static XAttribute Attrib(XElement node, string name)
    {
        var ns = node.GetDefaultNamespace().NamespaceName;
        var at = node.Attribute(XName.Get(name, ns));
        if (at == null)
            throw new NbException($"Element '{node.Name}' doesn't contain attibute '{name}'");
        return at;
    }

    public static IEnumerable<FileInfo> ListFiles(string aSearchWithPath) => new DirectoryInfo(Path.GetDirectoryName(aSearchWithPath)).GetFiles(Path.GetFileName(aSearchWithPath)).OrderBy(fi => fi.Name);

    //Reads multiple xmls with the same schema
    public static model MergeXmls(string xmlFileSearchPatternWithPath)
    {
        List<string> csvFiles = new();
        var viewMixedContexts = new NbDictionary<string, XElement?>(20, description: "NbOrm mixed contents");
        model mod = null;
        var xmlsToLoad = ListFiles(xmlFileSearchPatternWithPath).ToList();
        foreach (var fi in xmlsToLoad)
        {
            try
            {
                using (FileStream str = new(fi.FullName, FileMode.Open))
                using (StreamReader rdr = new(str))
                {
                    var res = (model)(modelXmlSerializer.Deserialize(rdr) ?? throw new Exception("Model deserialization returned null"));
                    if (mod == null)
                        mod = res;
                    else
                        res.MergeTo(mod);

                    str.Seek(0, SeekOrigin.Begin);
                    var doc = XDocument.Load(str);
                    var tbls = doc.Element(nameof(model))?.Elements("tables");
                    var lst = tbls?.Elements(nameof(view)).ToList();
                    foreach (var v in lst.Safe())
                    {
                        AddTo(v.Element("sql"), viewMixedContexts, Attrib(v, "name").Value);
                    }
                }

                string csvFileName = Path.Combine(fi.DirSafe().FullName, Path.GetFileNameWithoutExtension(fi.FullName) + ".csv");
                if (File.Exists(csvFileName))
                    csvFiles.Add(csvFileName);
            }
            catch (Exception ex)
            { throw new Exception($"Error deserializing '{fi.FullName}'", ex); }
        }
        if (mod == null)
            throw new Exception($"No xml files with the pattern '{xmlFileSearchPatternWithPath}' were loaded");

        mod.ResolveAndValidate(viewMixedContexts);

        foreach (string csvFile in csvFiles)
            mod.ResolveCsv(csvFile);

        return mod;
    }

    private void ResolveCsv(string csvFile)
    {
        var enum_types = types.OfType<enum_static>().ToNbDictionary(t => t.name, t => t, StringComparer.OrdinalIgnoreCase, types.Length, "Xml model's enum_static types");
        var par = new CsvParameters { FieldDelimiterN = '\t' };

        foreach (var line in NbExt.FromCsv<EnumTypeLine>(csvFile, par))
        {
            enum_types[line.TypeName].AddValue(line.Key, line.Value); //[] throws prober exception
        }
    }

    public class EnumTypeLine
    {
#pragma warning disable CS0649
        public string TypeName;
        public string Key;
        public string Value;
#pragma warning restore CS0649
    }

    private void MergeTo(model mod)
    {
        //public modelConfig config; //Not yet supported for merging
        mod.tables = tables.Merge(mod.tables);
        mod.types = types.Merge(mod.types);
        name = MergeStr(name, mod.name);
    }

    public void WriteXml(string xmlFileName)
    {
        try
        {
            using StreamWriter wrtr = new(xmlFileName);
            modelXmlSerializer.Serialize(wrtr, this);
        }
        catch (Exception ex)
        {
            throw new Exception($"Error serializing into '{xmlFileName}'", ex);
        }
    }

    public static string MergeStr(string oldVal, string newVal) => String.IsNullOrWhiteSpace(newVal) ? oldVal : newVal;
    public static T Merge<T>(T oldVal, T newVal) where T : class => newVal ?? oldVal;
}

public partial class modelConfig
{
    internal modelConfig PushSettingsTo(modelConfig parCnf)
    {
        if (parCnf == null)
            return this;

        if (parCnf.pluralise == TriBool.not_specified)
            parCnf.pluralise = this.pluralise;

        return parCnf;
    }
}
//#pragma warning restore IDE1006