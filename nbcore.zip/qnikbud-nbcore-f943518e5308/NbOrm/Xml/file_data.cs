﻿using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml.XPath;
using NbTools.Collections;
using NbCollV1;
using NbOrm.Nbq;

#pragma warning disable IDE1006
namespace NbOrm.Xml;

public partial class file_data
{
    [XmlIgnore]
    public CustomCollectionProvider fCustColl; //Custom function to load the collection by url, model and enviroment

    public override IEnumerable<field_base> Fields => fields.SafeOfType<field_base>();
    public override IEnumerable<recordset> TableReferences => Enumerable.Empty<table>();
    public DfDynamicCollection? LoadDynamicCollection(Uri uri, model mdl, object env) => null;

    public override void ResolveAndValidate(modelConfig config, NbDictionary<string, recordset> tablesDict, type_base[] types, XElement? mixedContentN) 
    {
        Cfg = config;

        foreach (var ffield in Fields)
            ffield.ResolveReference(config, this, this, tablesDict, types);
    }

    private static IEnumerable<FileInfo> ListFiles(string aSearchWithPath) => new DirectoryInfo(Path.GetDirectoryName(aSearchWithPath)).GetFiles(Path.GetFileName(aSearchWithPath)).OrderBy(fi => fi.Name);

    public override DfDynamicCollection DfDynamicCollectionByUriN(NbqQueryType qType, string query, model mdl, DfTable layoutN, object env)
    {
        if (fCustColl != null)
            return fCustColl(qType, query, mdl, env);

        DfDynamicCollection coll = new DfDynamicCollection(name);
        switch (Item)
        {
            case file_dataCsv csvDesc:
                //var csvPar = new CsvParameters { FieldDelimiterN = '\t'/*, LoggerN = (a) => { } */}; //TODO: additional CSV parameters from xml
                foreach (var fi in ListFiles(csvDesc.path_pattern))
                    coll.LoadFromCsv(fi.FullName, layoutN); //TODO: think about loadig many files - no layout yet
                break;

            case file_dataHtml_flat hFlat:
                //TODO: enable in the parent component
                //var xdoc = SgmlReader.NbLoadFile(hFlat.path_pattern);
                //coll.LoadFromXml(WebLib.NbFindRecursive(xdoc.Element("html"), hFlat.node_name, hFlat.attribute_name, hFlat.attribute_value)); //"toc-item"
                break;

            case file_dataXml_flat xFlat:
                if (String.IsNullOrWhiteSpace(xFlat.path_pattern))
                    throw new Exception("file_date xml file is not specified");
                if (!File.Exists(xFlat.path_pattern))
                    throw new Exception($"file_date xml file is not found: '{xFlat.path_pattern}'");

                using (var fRdr = new StreamReader(xFlat.path_pattern))
                using (XmlReader xRdr = XmlReader.Create(fRdr))
                {
                    XElement root = XDocument.Load(xRdr).Root;
                    XElement colEl = root.XPathSelectElement(xFlat.node_xpath);
                    coll.LoadFromXml(colEl.Elements(), recSet: null); //TODO: use recSet here
                }
                break;
            default: throw new NbExceptionPatternMatching(Item, "file_data subtype");
        }

        return coll;
    }

    public override string SqlSelectStatement() => throw new NbExceptionInfo($"{nameof(file_data)} doesn't provide Sql Statements");
    public override string SqlSelectStatementByUri(NbqQueryType qType, string query, model mdl, object env) => SqlSelectStatement();
    internal override IEnumerable<string> CsClass(SqlCs csGenerator) { yield break; } //file source - no need to generate sql
}
#pragma warning restore IDE1006