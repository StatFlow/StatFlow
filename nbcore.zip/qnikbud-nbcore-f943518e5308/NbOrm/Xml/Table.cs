﻿using System.Xml.Linq;
using NbOrm.Nbq;

namespace NbOrm.Xml;

public partial class table : recordset
{
    public override IEnumerable<field_base> Fields => Items;
    public override IEnumerable<recordset> TableReferences => Enumerable.Empty<table>();

    public override string SqlName => Cfg.table_prefix + table_name;

    internal override IEnumerable<string> CsClass(SqlCs csGenerator)
    {
        return CsCode.BracedStatement("public partial class " + CsName,
            Items.Select(f => f.CsProperty())
            .EmptyLines(1, CsSelect())
            .EmptyLines(1, csGenerator.CsInsert(this))
            .EmptyLines(1, csGenerator.CsUpdate(this))
            .EmptyLines(1, csGenerator.CsDelete(this))
            .EmptyLines(1, csGenerator.CsDeleteAll(this))
            );
    }

    public override string SqlSelectStatementByUri(NbqQueryType qType, string query, model mdl, object par)
    {
        NbqRecordset parsedUri = NbqParser.Parse(query, mdl);

        if (qType == NbqQueryType.nbblob)
            return SqlGenerator.GenerateBlobSql(parsedUri, this);
        else
            return SqlGenerator.GenerateTableSql(parsedUri, this);
    }

    public override string SqlSelectStatement() => $"SELECT {String.Join(recordset.sqlFieldSeparator, Items.Select(f => f.SelectLine))}\r\nFROM {SqlName} ";

    public IEnumerable<string> SqlOraTriggers() => Items.OfType<field>().Where(f => f.key == field_baseKey.identity).Select(f => f.SqlOraIdentityTrigger(this));

    public string SequenceName => SqlScriptOracle.OraName(SqlName, "SEQ");

    public override void ResolveAndValidate(modelConfig config, NbDictionary<string, recordset> tablesDict, type_base[] types, XElement? mixedContentN)
    {
        Cfg = config;
        if (String.IsNullOrWhiteSpace(XmlName))
            throw new NbException("Table with empty name found");
        if (Items == null || Items.Length == 0)
            throw new NbException($"Table '{XmlName}' int model doesn't contain any fields");

        if (String.IsNullOrWhiteSpace(table_name)) //table_name is optional, by default is it the same as class name
            table_name = name;

        foreach (var ffield in Items.Safe())
            ffield.ResolveReference(config, this, this, tablesDict, types);

        //Validating order_desc and order_asc fields for default order
        field_base prev = null;
        foreach (var fld in Items.Safe().Where(b => b.OrderNum >= 0).OrderBy(a => a.OrderNum))
        {
            if (fld.order_asc >= 0 && fld.order_desc >= 0)
                throw new Exception($"{name}.{fld.name} field has both order_asc and order_desc tags defined");

            if (prev != null && prev.OrderNum == fld.OrderNum)
                throw new Exception($"Fields '{prev.name}' and '{fld.name}' of the table '{name}' have the same order number {prev.OrderNum}");

            prev = fld;
        }
    }

    public override recordset MergeTo(recordset toTable)
    {
        if (GetType() != toTable.GetType())
            throw new NbExceptionInfo($"Attempt to merget {GetType().Name} {name} and {toTable.GetType().Name} {toTable.name} ");

        table other = toTable as table;

        Items = Items.Merge(other.Items);
        color = model.MergeStr(color, other.color);
        return this;
    }

    /*public string GetKeyValueSql(IList list)
    {
        field_base keyFld = Fields.SingleVerbose(f => f.key == field_baseKey.kvKey, () => $"Key field is not specified in the Key-Value table {name}", i => $"{i} field specified as the Key fields in the Key-Value table {name}");
        field_base nameFld = Fields.SingleVerbose(f => f.key == field_baseKey.kvName, () => $"Name field is not specified in the Key-Value table {name}", i => $"{i} field specified as the Name fields in the Key-Value table {name}");
        field_base valueFld = Fields.SingleVerbose(f => f.key == field_baseKey.kvValue, () => $"Value field is not specified in the Key-Value table {name}", i => $"{i} field specified as the Value fields in the Key-Value table {name}");

        string listStr;
        if (list is List<decimal?>)
            listStr = String.Join(", ", list.Cast<decimal?>());
        else if (list is List<string>)
            listStr = "'" + String.Join("', '", list.Cast<string>()) + "'";
        else
            throw new Exception($"Unsupported list type in GetKeyValueSql: {list.GetType().Name}");

        return $"select {keyFld.SelectLine}, {nameFld.SelectLine}, {valueFld.SelectLine} from {SqlName} where {keyFld.SelectLine} in ({listStr})"; //TODO: support numeric IDs
    }*/
}
