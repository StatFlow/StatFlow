﻿using System.Text;
using NbOrm.Nbq;

namespace NbOrm.Xml;

public class SqlGenerator
{
    internal static string GenerateViewSql(NbqRecordset parsedUri, SQL xmlSql, string recName)
    {
        var uriUnused = parsedUri.Wheres.ToNbDictionary(w => w.Field.name, w => w, StringComparer.OrdinalIgnoreCase, parsedUri.Wheres.Count, "Uri-based parameters");

        var bld = new StringBuilder();
        foreach (var obj in xmlSql.Items.Safe())
        {
            if (obj is String st)
                bld.Append(st).AppendLine(); 
            else if (obj is SQLWhere_and wa) 
                bld.Append(wa.GetStatement2(parsedUri, recName, uriUnused)).AppendLine();
            else
                throw new Exception($"Unsupported object of type '{obj.GetType().Name}' within SQL mixed context");
        }
        //TODO: Apply additional post -select filtering using fields remaining in uriUnused
        return bld.ToString().Trim().TrimEnd(';');
    }

    internal static string GenerateTableSql(NbqRecordset parsedUri, table table)
    {
        var statements = GenerateTableWheres(parsedUri, table).ToList();
        var where = (statements.Count == 0) ? String.Empty : " WHERE " + String.Join("\r\n AND ", statements);
        var orderby = String.Join(", ", table.Fields.Where(f => f.order_asc >= 0 || f.order_desc >= 0) //Where order number is set
            .OrderBy(f => f.order_asc >= 0 ? f.order_asc : f.order_desc) //Order by the order number
            .Select(f => f.SelectLine + (f.order_asc >= 0 ? " asc" : " desc")));
        if (!String.IsNullOrEmpty(orderby))
            orderby = "\r\nORDER BY " + orderby;

        return $@"SELECT top 100 {String.Join(recordset.sqlFieldSeparator, table.Fields.Select(f => f.SelectLine))}
FROM {table.SqlName}
{where}{orderby}";
    }

    internal static IEnumerable<string> GenerateTableWheres(NbqRecordset parsedUri, table table)
    {
        return parsedUri.Wheres.Select(wrh =>
        {
            var filterField = table.Fields.SingleVerbose(f => wrh.Field.name.EqIC(f.name),
                () => $"field '{wrh.Field.name}' is not found in the table '{table.name}'",
                i => $"{i} fields with the name '{wrh.Field.name}' are found in the table '{table.name}'");

            return filterField.SqlName + " = " + wrh.ValueLexem.SqlValue();
        });
    }

    internal static string GenerateBlobSql(NbqRecordset parsedUri, table table)
    {
        var statements = GenerateTableWheres(parsedUri, table).ToList();
        var where = (statements.Count == 0) ? String.Empty : " WHERE " + String.Join("\r\n AND ", statements);
        var blobFld = table.Fields.SingleVerbose(f => f.GetCType() == CType.blob, () => $"There are no blob fields in the '{table.name}' table", i => $"There are {i} blob fields in the {table.name} table");

        return $"SELECT {blobFld.SelectLine} FROM {table.SqlName} " + where;
    }
}

public partial class SQL
{
    public IEnumerable<field_base> Parameters => Items.SafeOfType<SQLWhere_and>().SelectMany(w => w.param);
}

/// <summary>
/// Represents one instance of where inclusion into the sql text, contains a list of parameter and can has its own where statement
/// </summary>
public partial class SQLWhere_and
{
    /// <summary>
    /// Produce where statements for the parameters in the SQLWhere_and tag and remove used parameters from uriParUnused.
    /// In the end the uriParUnused will have the list of restrictions not satisfied by the parameters of the view
    /// </summary>
    public string GetStatement2(NbqRecordset parsedUri, string recName, IDictionary<string, NbqWhereSingleExpr> uriParUnused)
    {
        var statements = GetStatements(parsedUri, recName, uriParUnused).ToList();
        if (statements.Count == 0)
            return String.Empty;
        else
            return (create_where ? " WHERE " : String.Empty) + String.Join("\r\n AND ", statements);
    }

    public IEnumerable<string> GetStatements(NbqRecordset parsedUri, string recName, IDictionary<string, NbqWhereSingleExpr> uriParUnused)
    {
        //Pair params with uri params, first by full name, then by search type, then check the required params
        foreach (var par in param) //for each parameter in a where statemet
        {
            //Find corresponding uri parameter
            var uriParN = parsedUri.Wheres.SingleOrDefaultVerbose(w => par.name.EqIC(w.Field.name), i => $"There are {i} paremeters with the name {par.name} in the Uri");
            if (uriParN != null) //uri parameter found
            {
                uriParUnused.Remove(par.name); //Remove from the 'unused list' will not throw exception

                yield return par.GetStatement(uriParN);
            }
            else if (!par.@null) //If parameter has to be filled for the view to run (mandatory ->  null="false")
                throw new Exception($"Can't find view's mandatory parameter '{par.name}' in the Uri");
            //else don't produce any statements for this param
        }
    }
}

public partial class ViewParam
{
    protected override string ref_field_tag => ref_field;

    public string GetStatement(NbqWhereSingleExpr nbq) => (sql_name ?? name) + " = " + nbq.ValueLexem.SqlValue();
}
