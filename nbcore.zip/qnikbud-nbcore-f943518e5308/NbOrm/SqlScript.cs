﻿using NbOrm.Xml;

namespace NbOrm;

public abstract class SqlScript
{
    public abstract IEnumerable<string> DropScript(model aModel);

    public IEnumerable<string> CreateScript(model aModel)
    {
        //Validation 
        if (aModel.tables == null || aModel.tables.Length == 0)
            throw new NbException("There are no tables defined in the model xml");
        foreach (var tbl in aModel.tables.SelectMany(ts => ts.Items.Safe()).OfType<table>())
        {
            if (tbl.Items == null || tbl.Items.Length == 0)
                throw new NbException($"There are no fields in the table {tbl.SqlName} in the model xml");
        }
        var ownedTables = aModel.tables.SelectMany(ts => ts.Items.Safe()).OfType<table>().Where(t => t.owner == TableOwnership.xml).ToList(); //There will be multiple traversion
        return CreateScriptContents(ownedTables, aModel);
    }

    protected abstract IEnumerable<string> CreateScriptContents(IEnumerable<table> tables, model aModel);

    private const string IndentStr = "  ";
    protected static IEnumerable<string> BracketedStatement(string header, IEnumerable<string> lines)
    {
        IEnumerator<string> en = lines.GetEnumerator();
        bool hasNext = en.MoveNext();
        if (!hasNext)
            yield break;
        yield return header + " (";
        while (hasNext)
        {
            string curr = en.Current;
            hasNext = en.MoveNext();
            if (hasNext)
                yield return IndentStr + curr;
            else
            {
                yield return IndentStr + curr + ");";
                yield return String.Empty;
            }
        }
    }
}

public abstract class SqlCs
{
    protected abstract string ParamName(field_base fld);
    protected abstract string UpdateLine(field_base fld);

    public void XmlDesc2CsFile(model mdl, string csFile)
    {
        try
        {
            string csFileName = !String.IsNullOrWhiteSpace(mdl.name) ? mdl.name : "Default";
            File.WriteAllLines(csFile, CsFile(mdl));
        }
        catch (Exception ex)
        {
            Console.WriteLine(NbException.Exception2String(ex));
            Console.ReadKey();
        }
    }

    private IEnumerable<string> CsFile(model mdl)
    {
        string[] uses = new string[] { "System", "System.Collections.Generic", "NbTools" }; //"System.Data.Common", "System.Data.SqlClient"
        return CsCode.CsHeader
            .EmptyLines(1, uses.Select(u => String.Format("using {0};", u)))
            .EmptyLines(1, CsCode.BracedStatement("namespace " + mdl.name,
            mdl.tables.SelectMany(ts => ts.Items.Safe()).SelectMany(t => t.CsClass(this))));
    }

    internal IEnumerable<string> CsInsert(recordset recset)
    {
        field identityN = recset.Fields.OfType<field>().SingleOrDefault(f => f.key == field_baseKey.identity);
        return CsCode.BracedStatement("internal void Insert(INbConn connection)",
            SqlInsertStringDef(recset, identityN)  //was Style.Choose(SqlOraInsertStringDef(identityN), SqlMsInsertStringDef(identityN))
            .EmptyLines(1, CsInsertCommand(recset, identityN)));
    }

    protected abstract IEnumerable<string> SqlInsertStringDef(recordset recset, field identityN);

    private IEnumerable<string> CsInsertCommand(recordset recset, field identityN)
    {
        string outParam;
        if (identityN == null)
            outParam = @"cmd.Run();";
        else
        {
            if (CsCode.CType2CsType(identityN.BaseType.Ctype) != "Int32")
                throw new NbException("Only Int32 Return parameters are supported");
            else
                outParam = String.Format(@"this.{0} = cmd.RunGetInt32();", identityN.name);
        }

        return CsCode.BracedStatement("using (var cmd = connection.CreateCommand(sql))",
           recset.Fields.Where(f => f != identityN).Select(f => CommandParamLine(f))
           .EmptyLines(1, outParam));
    }


    internal IEnumerable<string> CsUpdate(recordset recset)
    {
        var primKey = recset.PrimaryKeyN;
        if (primKey == null)
            return CsCode.Nothing;
        //throw new Exception("Can't generae Update for a table without primary key");

        return CsCode.BracedStatement("internal void Update(INbConn connection)",
             SqlUpdateStringDef(recset, primKey)  //style.Choose(SqlOraUpdateStringDef(primKey), SqlMsUpdateStringDef(primKey))
            .EmptyLines(1, CsUpdateCommand(recset, primKey)));
    }

    protected abstract IEnumerable<string> SqlUpdateStringDef(recordset recset, field_base primary_key);

    private IEnumerable<string> CsUpdateCommand(recordset recset, field_base prim_key)
    {
        return CsCode.BracedStatement("using (var cmd = connection.CreateCommand(sql))",
            recset.Fields.Where(f => f != prim_key).Select(f => CommandParamLine(f)) //All withouth the primary key
           .EmptyLines(1, CsCode.YieldNotNull(prim_key).Select(f => CommandParamLine(f))) //Last param is primary
           .EmptyLines(1, @"cmd.Run();"));
    }

    internal IEnumerable<string> CsDelete(recordset recset)
    {
        var primKeys = recset.Fields.OfType<field>().Where(f => f.key == field_baseKey.primary || f.key == field_baseKey.identity).ToList();
        switch (primKeys.Count)
        {
            case 0:
                return CsCode.Nothing; //throw new Exception("Can't generate Delete for a tablewithout primary key");
            case 1:
                return CsCode.BracedStatement("internal void Delete(INbConn connection)",
                     SqlDeleteStringDef(recset, primKeys[0])
                    .EmptyLines(1, CsDeleteCommand(primKeys[0])));

            default:
                return NbExt.Yield($"//Composite primary keys are not yet supported: ({String.Join(", ", primKeys.Select(k => k.name))})");
        }
    }

    private IEnumerable<string> SqlDeleteStringDef(recordset recset, field primary_key)
    {
        string insertStatement = String.Format("DELETE FROM {0} WHERE {1}", recset.SqlName,
            UpdateLine(primary_key)); //style.Choose(primary_key.OraUpdateLine, primary_key.MsUpdateLine));
        yield return String.Format("string sql = \"{0}\";", insertStatement);
    }

    private IEnumerable<string> CsDeleteCommand(field prim_key)
    {
        return CsCode.BracedStatement("using (var cmd = connection.CreateCommand(sql))",
            CsCode.YieldNotNull(prim_key).Select(f => CommandParamLine(f))
            .EmptyLines(1, @"cmd.Run();"));
    }

    internal IEnumerable<string> CsDeleteAll(recordset recset)
    {
        return CsCode.BracedStatement("internal static void DeleteAll(INbConn connection, string suffix = null)",
            SqlDeleteAllStringDef(recset)
            .EmptyLines(1, CsDeleteAllCommand()));
    }


    private IEnumerable<string> SqlDeleteAllStringDef(recordset recset)
    {
        yield return $"string sql = \"DELETE FROM {recset.SqlName} \" + suffix;";
    }

    private IEnumerable<string> CsDeleteAllCommand()
    {
        return CsCode.BracedStatement("using (var cmd = connection.CreateCommand(sql))",
             NbExt.Yield(@"cmd.Run();"));
    }

    private string CommandParamLine(field_base fld) => $"cmd.AddParam(\"{fld.name}\", {fld.name});";
}
