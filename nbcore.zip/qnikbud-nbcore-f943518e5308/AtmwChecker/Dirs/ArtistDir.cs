﻿using System.Text.RegularExpressions;

internal class ArtistDir
{
    internal enum AlbumFolderTypes { Albums, Collections, CoversTributes, Bootlegs };
    internal readonly string Name;
    internal string TheName => Name.EndsWith(", The") ? "The " + Name[..^5] : Name;

    internal readonly DirectoryInfo Dir;
    internal readonly Context Context;

    public ArtistDir(DirectoryInfo dir, Context context)
    {
        Dir = dir;
        Context = context;
        Name = dir.Name;
    }

    internal void Process()
    {
        var subDirs = Dir.GetDirectories();
        if (!subDirs.Any(d => Path.GetFileNameWithoutExtension(d.Name) == nameof(AlbumFolderTypes.Albums)))
        {
            ProcessAlbumsDir(Dir, AlbumFolderTypes.Albums); //If Albums is not available treat current dir as albums
            return;
        }

        //Else process various sumfolders in the root dir
        foreach (var subDir in subDirs)
        {
            string fldName = Path.GetFileNameWithoutExtension(subDir.Name);

            if (!Enum.TryParse<AlbumFolderTypes>(fldName, out var folderType))
            {
                Context.Log($"Artist subfolder doesn't conform to standard: {subDir.FullName}");
                continue;
            }

            ProcessAlbumsDir(subDir, folderType);
        }
    }

    private static readonly string[] AlbumNameExclusions =
    {
        "Play This Intimately (As If Among Friends)", "90125",
    };


    private static readonly Regex DirNameRegex = new(@"^(\d{4})([a-z]?|\.\d{2}\.\d{2})\s-?\s?(.+)$");  // Allow full date in 1984.01.25 format as well as 1982a

    private static readonly Regex AllowedChars = new(@"^[a-zA-Z\d'! \.\-,&]+$");
    private const string AlbNameRegex = @"^[A-Z]"; //Album should start with Capital letter (or digit 90125 by Yes)

    private void ProcessAlbumsDir(DirectoryInfo albDir, AlbumFolderTypes folderType)
    {
        foreach (DirectoryInfo di in albDir.GetDirectories())
        {
            var reg1 = DirNameRegex.Match(di.Name);
            if (reg1.Success && folderType == AlbumFolderTypes.Albums)
            {
                string albName = reg1.Groups[3].Value;
                int year = Int32.Parse(reg1.Groups[1].Value);

                var reg2 = AllowedChars.Match(albName);
                if (!reg2.Success && !AlbumNameExclusions.Contains(albName))
                    Context.Log($"Album name has forbidden symbols: {di.FullName}");

                if (!AlbNameRegex.IsMatch(albName) && !AlbumNameExclusions.Contains(albName))
                    Context.Log($"Album must start with capital lettter: {albName}, {di.FullName}");

                AlbumDir alm = new(this, albName, Context);
                alm.Process(di);
            }
            else if (folderType != AlbumFolderTypes.Albums) //Only albums collection have to confrom to album names standards
            {
                ProcessGenericDir(di);
            }
            else
                Context.Log($"Album directory name does't conform to standard: {di.FullName}");
        }
    }

    internal void ProcessGenericDir(DirectoryInfo dir)
    {
        foreach (var di in dir.GetDirectories())
            ProcessGenericDir(di);

        Context.Check(dir.GetFiles());
    }
}
