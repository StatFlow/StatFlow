﻿using System.Text.RegularExpressions;

internal class AlbumDir
{
    internal readonly Context Context;
    internal readonly ArtistDir Artist;
    internal readonly string AlbumName;

    internal AlbumDir(ArtistDir art, string albumName, Context context)
    {
        Context = context;
        Artist = art;
        AlbumName = albumName;
    }

    internal void Process(DirectoryInfo Dir)
    {
        var (dirs, files) = GetDirsAndFiles(Dir); //Cоздать список директорий / файлов и обработчики должны обрабатывать и удалять файлы из списка - оставшиеся файлы / директории будут ворнингами.

        if (dirs.Any(d => d.Name == "CD1")) //If CD1 is found assume multi-disk
        {
            ProcessCDFolders(dirs);
            ProcessGraphics(dirs, files, Dir, requireGraphics: false); //Do not force graphics in the root of multi-CD albums

            if (dirs.Any())
                Context.Log(dirs.Select(d => d.Name).ListStrings($"Multi-disc album directory '{Dir.FullName}' constains unrecognized dirs:"));
            if (files.Any())
                Context.Log(files.Select(f => f.Name).ListStrings($"Multi-disc album directory '{Dir.FullName}' constains unrecognized files:"));
        }
        else
        {
            ProcessDiscDir(Dir);
        }
    }

    private void ProcessCDFolders(List<DirectoryInfo> dirs)
    {
        dirs.ScanBackAndRemove(dir =>
        {
            if (dir.Name == "CD1" || dir.Name == "CD2" || dir.Name == "CD3")
            {
                ProcessDiscDir(dir);
                return true;
            }
            else
                return false;
        });
    }

    internal void ProcessDiscDir(DirectoryInfo rootDir)
    {
        var (dirs, files) = GetDirsAndFiles(rootDir); //Cоздать список директорий / файлов и обработчики должны обрабатывать и удалять файлы из списка - оставшиеся файлы / директории будут ворнингами.
        ProcessGraphics(dirs, files, rootDir, requireGraphics: true);
        ProcessUrlFiles(files);
        if (dirs.Any()) //Only graphics directories are allowed inside disc directory
            Context.Log(dirs.Select(d => d.Name).ListStrings($"Disc directory '{rootDir.FullName}' constains unrecognized dirs:"));


        //Process files
        if (files.Count == 0)
            Context.Log($"Album directory '{rootDir.FullName}' doesn't contain any files");

        if (!ProcessCueAlbum(files, rootDir)) //If not cue than list-style
            ProcessFileListAlbum(files, rootDir);
    }

    private bool ProcessCueAlbum(List<FileInfo> files, DirectoryInfo rootDir)
    {
        var cues = files.Where(f => Path.GetExtension(f.Name).EqIC(".cue")).ToList();
        if (cues.Count == 0)
            return false;
        else if (cues.Count > 1)
            Context.Log($"Album directory '{rootDir.FullName}' contains more than one cue file");
        else if (cues.Count == 1) //Process cue style folder
        {
        }
        return true;
    }


    public static readonly string[] AllowedLyricsExtensions = { ".lrc", ".txt" };
    public static readonly string[] AllowedAudioExtensions = { ".mp3", ".m4a", ".wav", ".ogg", ".flac" };

    private const string NumberedFilesRegex = @"^(\d+)";

    private void ProcessFileListAlbum(List<FileInfo> files, DirectoryInfo rootDir)
    {
        List<(FileInfo fi, int num)> audio = new(files.Count);
        List<(FileInfo fi, int num)> lyrics = new(files.Count);

        files.ScanBackAndRemove(f =>
        {
            if (AllowedAudioExtensions.Contains(f.Extension, StringComparer.OrdinalIgnoreCase))
            {
                if (NumberedFilesRegex.IsMatch(f.Name, out int num))
                    audio.Add((f, num));
            }
            else if (AllowedLyricsExtensions.Contains(f.Extension, StringComparer.OrdinalIgnoreCase))
            {
                if (NumberedFilesRegex.IsMatch(f.Name, out int num))
                    lyrics.Add((f, num));
            }
            else
                return false;
            return true;
        });

        if (files.Any()) //Only audio and lyrics files are allowed in List-based Disc directory
            Context.Log(files.Select(d => d.Name).ListStrings($"List-based Disc directory '{rootDir.FullName}' files with unrecognized extensions:"));

        if (!audio.Select(p => p.num).IsContinuous())
            Context.Log(audio.Select(d => d.num.ToString()).ListStrings($"List-based Disc directory '{rootDir.FullName}' audio files do not have continuous numbering:", maxEntries: 30));

        if (lyrics.Any()) //Check lyrics if it exists
        {
            if (!lyrics.Select(p => p.num).IsContinuous())
                Context.Log(lyrics.Select(d => d.num.ToString()).ListStrings($"List-based Disc directory '{rootDir.FullName}' lyrics files do not have continuous numbering:", maxEntries: 30));
        }
    }

    //private static readonly string[] RequiredGraphFilesWithMusic = new[] { "Cover.jpg" };
    private static readonly string[] AllowedGraphFilesWithMusic = new[] { "Cover.jpg", "Cover200.jpg", "Front.jpg", "Back.jpg", "Disc.jpg" };
    private static readonly string[] AllowedGraphicsFolders = new[] { "Scans", "Covers", "Artwork" };

    private void ProcessGraphics(List<DirectoryInfo> dirs, List<FileInfo> files, DirectoryInfo di, bool requireGraphics)
    {
        for (int i = dirs.Count - 1; i >= 0; i--)
        {
            var dir = dirs[i];
            if (AllowedGraphicsFolders.Any(f => f.EqIC(dir.Name)))
            {
                ProcessGenericDir(dir);
                dirs.RemoveAt(i);
            }
        }

        if (requireGraphics) //Graphics is not needed in the root of multi-CD albums
        {
            if (!files.Any(fi => fi.Name.EqIC("Cover.jpg") || fi.Name.EqIC("Front.jpg")))
            {
                Context.Log($"Can't find 'Cover.jpg' graphics is album '{di.FullName}'");
                if (SearchGraphicsMax-- > 0)
                    SearchForGraphics(Artist.TheName, AlbumName, Path.Combine(di.FullName, "Cover.jpg"));
            }
        }

        for (int i = files.Count - 1; i >= 0; i--)
        {
            FileInfo file = files[i];
            if (AllowedGraphFilesWithMusic.Any(fn => file.Name.EqIC(fn)))
                files.RemoveAt(i);
        }
    }


    private static int SearchGraphicsMax = 10;
    public void SearchForGraphics(string artist, string album, string pathToStoreGraphics) => NbProcess.FireAndForget(@"C:\Program Files\AlbumArtDownloader\AlbumArt.exe", null,
        "/artist", artist, "/album", album, "/path", pathToStoreGraphics, "/autoclose", "/minSize", "1000");

    private void ProcessUrlFiles(List<FileInfo> files)
    {
        files.ScanBackAndRemove(f => f.Extension.EqIC(".url")); //TODO; user URLs later
    }

    internal void ProcessGenericDir(DirectoryInfo dir)
    {
        foreach (var di in dir.GetDirectories())
            ProcessGenericDir(di);

        Context.Check(dir.GetFiles());
    }

    //Reverse order to facilitate the scanning from back to head with simultaneous removal
    private static (List<DirectoryInfo> dirs, List<FileInfo> files) GetDirsAndFiles(DirectoryInfo parent) =>
    (
        parent.GetDirectories().Where(d => !d.NameWithoutExtension().EqIC("info")).OrderByDescending(d => d.Name).ToList(),
        parent.GetFiles().Where(f => !f.NameWithoutExtension().EqIC("info")).OrderByDescending(f => f.Name).ToList()
    );


    /*private static readonly Regex AlbumDirRegex = new(@"^(\d{4})([a-z]?|\.\d{2}\.\d{2})\s-?\s?(.+)$");  // Allow full date in 1984.01.25 format as well as 1982a

    internal static bool TryProcess(DirectoryInfo di)
    {
        var reg1 = AlbumDirRegex.Match(di.Name);
        if (reg1.Success && folderType == AlbumFolderTypes.Albums)
        {
            string name = reg1.Groups[3].Value;
            int year = Int32.Parse(reg1.Groups[1].Value);

            var reg2 = AllowedChars.Match(name);
            if (!reg2.Success)
                Log($"Album name has forbidden symbols: {di.FullName}");

            AlbumDir alm = new(this, name, year, di, DupChecker, Log);
            await alm.Process();
        }
        return true;
    }*/

}
