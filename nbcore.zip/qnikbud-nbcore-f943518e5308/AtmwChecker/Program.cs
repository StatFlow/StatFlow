﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics;

const string DirBase = @"C:\!Music22\";
const string DirCore = DirBase + "Core";



try
{

    using StreamWriter log = new(NbExt.FileTimeStamp + "_Results.txt");
    ProcessAllDirs(str => { log.WriteLine(str); Console.WriteLine(str); Debug.WriteLine(str); });

    Console.WriteLine("Processing successful!");
}
catch (Exception ex)
{
    Console.WriteLine("Fatal exception: " + ex.ToString());
}

static void ProcessAllDirs(Action<string> Log)
{
    NbDictionary<string, ArtistDir> Artists = new();
    //NbDictionary<long, FileInfo> UniqueFiles = new();
    Context context = new(Log);

    var dirCore = new DirectoryInfo(DirCore);
    Log("############################## Processing " + DirCore + "############################## ");

    foreach (var dir in dirCore.GetDirectories())
    {
        var art = new ArtistDir(dir, context);
        art.Process();
    }
    foreach (var file in dirCore.GetFiles())
    {
        if (file.Name == "desktop.ini")
            continue;

        Log($"File '{file.Name}' is not expected in the root of Music directory: {dirCore.FullName}");
    }

}

/*class AtmwLogger
{
    internal void Info(string mess, FileSystemInfo fsi)
    {

    }

    internal void Warning(string mess, FileSystemInfo fsi)
    {

    }

    internal void Error(string mess, FileSystemInfo fsi)
    {

    }
}*/
