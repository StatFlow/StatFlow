﻿internal class Context
{
    private readonly NbDictionary<long, FileInfo> uniqueFiles = new();
    internal readonly Action<string> Log;

    internal Context(Action<string> log) => Log = log;

    internal void Check(IEnumerable<FileInfo> fi) => fi.ForEachSafe(f => IsDupe(f));

    internal bool IsDupe(FileInfo fi)
    {
        if (uniqueFiles.TryGetValue(fi.Length, out var oldFi))
        {
            if (NbMedia.GetFileMediaType(fi.Extension) == NbMedia.FileMediaTypes.Photo) //Relax dupe checking for photos
            {
                if (fi.Directory?.Parent?.FullName == fi.Directory?.Parent?.FullName ||
                    fi.Directory?.Parent?.Parent?.FullName == fi.Directory?.Parent?.Parent?.FullName)
                    return false;
            }

            string oldMd5 = NbCore.Crypto.NbCrypto.Md5Hex(oldFi.FullName);
            string newMd5 = NbCore.Crypto.NbCrypto.Md5Hex(fi.FullName);
            if (oldMd5 != newMd5)
                return true; //different MD5s

            Log($"Files with the same size: {oldFi.FullName} and {fi.FullName}");
            return true;
        }
        else
        {
            uniqueFiles.Add(fi.Length, fi);
            return false;
        }
    }
}
