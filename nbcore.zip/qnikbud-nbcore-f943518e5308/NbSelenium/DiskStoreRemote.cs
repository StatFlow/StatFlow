﻿using System;
using System.IO;
using System.Threading.Tasks;

using AngleSharp.Html.Dom;
using AngleSharp.Html.Parser;
using OpenQA.Selenium;
using Serilog.Core;

namespace NbCore.SelRemote
{
    public record WaitCond(int? DelayMs, By? Element);

    public sealed class DiskStoreFireFox : DiskStore
    {
        public enum FolderStrategy { Url, Key, Md5 }

        private const string ProfDir = @"%APPDATA%\Mozilla\Firefox\Profiles";

        public DiskStoreFireFox(string rootDir, string fireFoxProfile, Logger? log = null)
        : base(rootDir)
        {
        }

        //using var stream = File.OpenRead(@"N:\__WORK__\ToDo\2021.08.21\240x135.t.mp4");
        //await stream.CopyToAsync(ms);

        /// <summary>
        /// Loads the file in memory, calculates the md5 and saves the file into the storage using the StoreRoot, Url.Host and type provided
        /// </summary>
        /// <param name="uri">Url of the resource</param>
        /// <param name="type">Type of the resource to create subdirectory in the storage</param>
        /// <returns>MD5 in the for of byte array and string</returns>
        public Task<(byte[], string)> LoadBinary_StoreByMd5(Uri uri, string type)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// Loads the file with Selenium and stores it into the folder driven by url.
        /// </summary>
        /// <param name="url">Url of the file to load</param>
        /// <param name="type">The type of the page, like list of goods or individual page for an purchase</param>
        /// <returns>Html parsed into DOM</returns>
        public (IHtmlDocument doc, string? newUrl) LoadAndStoreHtml(Uri url, string type, FolderStrategy strat, string? id = null, WaitCond? waitCond = null)
        {
            HtmlParser prs = new();
            var pair = GetStreamForStoredByUrl(url, type, strat, id, waitCond);
            using Stream stream = pair.stream;
            return (prs.ParseDocument(stream), pair.newUrl);
        }

        private (Stream stream, string? newUrl) GetStreamForStoredByUrl(Uri url, string type, FolderStrategy strat, string? id, WaitCond? waitCond)
        {
            throw new NotImplementedException();
        }
    }
}
