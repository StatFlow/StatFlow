﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbCore.SelLocal
{
    public sealed class NbSel : IDisposable
    {
        private const string ProfDir = @"%APPDATA%\Mozilla\Firefox\Profiles";
        public readonly FirefoxDriver Ff;


        public NbSel(string fireFoxProfile)
        {
            DirectoryInfo di = new(Environment.ExpandEnvironmentVariables(ProfDir));
            var profileDir = di.GetDirectories().FirstOrDefault(d => d.Name.Split('.')[1] == fireFoxProfile) ?? throw new DirectoryNotFoundException($"Can't find '{fireFoxProfile}' Firefox profile in dir: {di.FullName}");

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            FirefoxOptions opt = new() { Profile = new FirefoxProfile(profileDir.FullName) };
            Ff = new(opt);
        }

        /*public async Task Init(string fireFoxProfile)
        {

        }*/


        public void Dispose()
        {
            Ff?.Dispose();
        }



        public static void Do()
        {
            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

            string amaz = @"https://www.amazon.co.uk/s?k=kindle&ref=nb_sb_noss_2";

            FirefoxProfile prof = new(@"C:\Users\budan\AppData\Roaming\Mozilla\Firefox\Profiles\d0qpmnkx.Bisc");
            FirefoxOptions opt = new() { Profile = prof };
            using FirefoxDriver driver = new(opt);
            driver.Navigate().GoToUrl(amaz);

            File.WriteAllText(@"C:\AutoDelete\2.html", driver.PageSource);


            //Looks like the ZipStorer code needs encoding 437. .NET core removes built -in support for many less common encodings, including 437.To make the encoding available in .NET core, you need to reference the System.Text.Encoding System.Text.Encoding.CodePages Nuget package and somewhere before Encoding.GetEncoding(437) gets called, make sure to call Encoding.RegisterProvider(CodePagesEncodingProvider.Instance).


            //As a workaround users can do the above steps in their own code.

            /*var link = driver.FindElement(By.PartialLinkText("Ashok kumar Ganesan"));
            var jsToBeExecuted = $"window.scroll(0, {link.Location.Y});";
            ((IJavaScriptExecutor)driver).ExecuteScript(jsToBeExecuted);
            var wait = new WebDriverWait(driver, TimeSpan.FromMinutes(1));
            var clickableElement = wait.Until(ExpectedConditions.ElementToBeClickable(By.PartialLinkText("Ashok kumar Ganesan")));
            //Wait.Until(c => c.FindElement(By.Id("content-section")));  - another option*/

            //clickableElement.Click();

        }
    }
}
