﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using AngleSharp.Html.Parser;
using AngleSharp.Dom;
using AngleSharp.Html.Dom;

namespace NbCore.SelLocal
{
    public static class NbHtmlParser
    {
        public static void ChildrenToFiles(this IHtmlDocument doc, string dir, bool excludeScript = true) => doc.Body?.ChildrenToFiles(dir, excludeScript);

        public static void ChildrenToFiles(this IHtmlElement elem, string dir, bool excludeScript = true)
        {
            NbFs.CreateDirRecursive(dir);
            int cnt = 1;
            foreach (IElement child in elem.Children)
            {
                if (excludeScript && child.NodeName == "SCRIPT")
                    continue;

                File.WriteAllText(Path.Combine(dir, $"{cnt++:d2}. {child.NodeName} ({NbExt.UserFriendlyFileSize(child.OuterHtml.Length, 2)}).html"), child.OuterHtml);
            }
        }

        public static void ToFile(this IElement elem, string file)
        {
            FileInfo fi = new(file);
            NbFs.CreateDirRecursive(fi);
            File.WriteAllText(fi.FullName, elem.OuterHtml);
        }

        public static void Parse(string fileName)
        {
            var parser = new HtmlParser();
            //var document = parser.ParseDocument(@"<span><a href=""google.com"" title=""Google""><span class=""icon icon_none""></span></a></span><span><a href = ""bing.com"" title = ""Bing""><span class=""icon icon_none""></span></a></span><span><a href = ""yahoo.com"" title=""Yahoo""><span class=""icon icon_none""></span></a></span>");

            var document = parser.ParseDocument(File.ReadAllText(fileName));
            var htmlNode = document.Children.Single();
            var bodyNode = htmlNode.LastChild;

            var _ = bodyNode?.GetWithBiggestHtml()?.GetElementsByTagName("main")?.Single();

            /*var bg1 = main.GetWithBiggestHtml();
            var ch1 = bg1.GetChildrenWithSizes();

            var bg2 = bg1.GetWithBiggestHtml();
            var ch2 = bg2.GetChildrenWithSizes();

            var bg3 = bg2.GetWithBiggestHtml();
            var ch3 = bg3.GetChildrenWithSizes();

            var bg4 = bg3.GetWithBiggestHtml();
            var ch4 = bg4.GetChildrenWithSizes();


            var bg5 = bg4.GetWithBiggestHtml();
            var ch5 = bg5.GetChildrenWithSizes();*/


            //var list = bodyNode.ChildNodes.OfType<IElement>().Select(n => (n, n.InnerHtml.Length)).ToList();


            //LINQ example
            //var blueListItemsLinq = document.All.Where(m => m.LocalName == "a" ).ToList();  //&& m.GetAttribute("title") == "Bing"

            //LINQ equivalent CSS selector example
            var blueListItemsCSS = document.QuerySelectorAll("a[title='Bing']");

            //print href attributes value to console
            foreach (var item in blueListItemsCSS)
            {
                Console.WriteLine(item.GetAttribute("href"));
            }
        }

        public static List<(string name, int size, IElement el)> GetChildrenWithSizes(this INode nd) => nd.ChildNodes.OfType<IElement>().Select(e => (e.NodeName, e.InnerHtml.Length, e)).ToList();


        public static IElement GetWithBiggestHtml(this INode nd)
        {
            int maxVal = 0, maxInd = -1, cntr = -1;
            foreach (var child in nd.ChildNodes)
            {
                cntr++; //Always update counter
                if (child is IElement el)
                {
                    int vl = el.InnerHtml.Length;
                    if (maxVal < vl)
                    {
                        maxInd = cntr;
                        maxVal = vl;
                    }
                }
            }

            if (maxInd >= 0)
                return nd.ChildNodes[maxInd] as IElement ?? throw new Exception($"Node is not an element at {maxInd}: {nd.ChildNodes[maxInd]}");
            else
                throw new Exception("Can't find the longest element");
        }
    }
}
