﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using OpenQA.Selenium.Firefox;

using AngleSharp.Html.Dom;
using AngleSharp.Html.Parser;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Net;
using Serilog.Core;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium;
using System.Threading;
using OpenQA.Selenium.Internal;

[assembly: InternalsVisibleTo("NbSeleniumTest")]

namespace NbCore.SelLocal
{
    public record WaitCond(int? DelayMs, By? Element);

    public sealed class DiskStoreFireFox : DiskStore, IDisposable
    {
        public enum FolderStrategy { Url, Key, Md5 }

        private const string ProfDir = @"%APPDATA%\Mozilla\Firefox\Profiles";

        private readonly Lazy<FirefoxDriver> Ff;
        private readonly WebClient WebClient = new();
        internal readonly Lazy<MD5> Md5;  //use NbCrypto Md5

        public DiskStoreFireFox(string rootDir, string fireFoxProfile, Logger? log = null)
            : base(rootDir)
        {
            if (!Directory.Exists(rootDir))
                throw new Exception($"DiskStore root directory '{rootDir}' doesn't exist");
            var profileDir = GetProfDir(fireFoxProfile);

            Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
            FirefoxOptions opt = new() { Profile = new FirefoxProfile(profileDir.FullName) };
            opt.AddArgument("--disable-blink-features=AutomationControlled");   //Selenium detection suppression    https://stackoverflow.com/questions/53039551/selenium-webdriver-modifying-navigator-webdriver-flag-to-prevent-selenium-detec
            Ff = new(() => new(opt));
            Md5 = new(() => MD5.Create());
        }

        private static DirectoryInfo GetProfDir(string fireFoxProfile)
        {
            DirectoryInfo di = new(Environment.ExpandEnvironmentVariables(ProfDir));
            var res = di.GetDirectories().FirstOrDefault(d => d.Name.Split('.')[1] == fireFoxProfile) ?? throw new DirectoryNotFoundException($"Can't find '{fireFoxProfile}' Firefox profile in dir: {di.FullName}");
            return res;
        }

        //using var stream = File.OpenRead(@"N:\__WORK__\ToDo\2021.08.21\240x135.t.mp4");
        //await stream.CopyToAsync(ms);

        /// <summary>
        /// Loads the file in memory, calculates the md5 and saves the file into the storage using the StoreRoot, Url.Host and type provided
        /// </summary>
        /// <param name="uri">Url of the resource</param>
        /// <param name="type">Type of the resource to create subdirectory in the storage</param>
        /// <returns>MD5 in the for of byte array and string</returns>
        public async Task<(byte[], string)> LoadBinary_StoreByMd5(Uri uri, string type)
        {
            //Load file into memory
            using MemoryStream ms = new();
            using (Stream webStrem = await WebClient.OpenReadTaskAsync(uri))
            {
                await webStrem.CopyToAsync(ms);
                ms.Position = 0;
            }

            byte[] md5 = Md5.Value.ComputeHash(ms);
            string md5str = Bytes2HexStr(md5);

            var fi = new FileInfo(Path.Combine(DirByKey(md5str, type), md5str));
            if (!fi.Exists)
            {
                NbFs.CreateDirRecursive(fi);
                using FileStream file = new(fi.FullName, FileMode.CreateNew, FileAccess.Write);
                ms.Position = 0;
                await ms.CopyToAsync(file);
            }

            return (md5, md5str);
        }


        /// <summary>
        /// Loads the file with Selenium and stores it into the folder driven by url.
        /// </summary>
        /// <param name="url">Url of the file to load</param>
        /// <param name="type">The type of the page, like list of goods or individual page for an purchase</param>
        /// <returns>Html parsed into DOM</returns>
        public (IHtmlDocument doc, string? newUrl) LoadAndStoreHtml(Uri url, string type, FolderStrategy strat, string? id = null, WaitCond? waitCond = null)
        {
            HtmlParser prs = new();
            var pair = GetStreamForStoredByUrl(url, type, strat, id, waitCond);
            using Stream stream = pair.stream;
            return (prs.ParseDocument(stream), pair.newUrl);
        }

        private (Stream stream, string? newUrl) GetStreamForStoredByUrl(Uri url, string type, FolderStrategy strat, string? id, WaitCond? waitCond)
        {
            string pagePath = HtmlPathByUrl(url, type, strat, id);
            string? newUrl = null;
            if (!File.Exists(pagePath))
            {
                newUrl = Selenium2Disk(url, pagePath, waitCond);
            }
            return (new FileStream(pagePath, FileMode.Open, FileAccess.Read), newUrl);
        }

        private static readonly char[] BannedChars = new char[] { '<', '>', ':', '"', '|', '?', '*' };  //'/', '\\', - will be used for split

        private string HtmlPathByUrl(Uri url, string type, FolderStrategy strat, string? key)
        {
            switch (strat)
            {
                case FolderStrategy.Url:
                    var convUrl = url.PathAndQuery.Replace('?', '¿');

                    if (BannedChars.Any(c => convUrl.Contains(c)))
                        throw new Exception($"Url '{url}' contains one of characters banned for files: {String.Join(", ", BannedChars)}");

                    List<string> parts = new() { StoreRoot, url.Host, type };
                    foreach (string part in convUrl.Split('/').Where(s => !String.IsNullOrWhiteSpace(s)))
                        parts.Add(part);

                    var path = Path.Combine(parts.ToArray());
                    if (!path.EndsWith(".html", StringComparison.OrdinalIgnoreCase))
                        path += ".html";
                    return path;

                case FolderStrategy.Key:
                    return Path.Combine(DirByKey(key ?? throw new ArgumentNullException(nameof(key), $"Id must be provided if FolderStrategy.Id is chosen"), type), key);

                //case FolderStrategy.Md5:
                //    break;
                default:
                    throw new NbExceptionEnum<FolderStrategy>(strat);
            }
        }

        private string Selenium2Disk(Uri url, string pagePath, WaitCond? waitCond)
        {
            Ff.Value.Navigate().GoToUrl(url);

            if (waitCond?.Element != null)
            {
                var wait = new WebDriverWait(Ff.Value, TimeSpan.FromMilliseconds(waitCond.DelayMs ?? 3000));
                wait.Until(drv => drv.FindElement(waitCond.Element));
            }
            else if (waitCond?.DelayMs != null)
                Thread.Sleep(waitCond.DelayMs.Value);
            string newUrl = Ff.Value.Url;

            FileInfo fi = new(pagePath);
            NbFs.CreateDirRecursive(fi);
            File.WriteAllText(pagePath, Ff.Value.PageSource);
            return newUrl; //This could be a new URL due to redirection
        }

        public void Dispose()
        {
            if (Ff.IsValueCreated)
                Ff.Value.Dispose();
            if (Md5.IsValueCreated)
                Md5.Value.Dispose();
        }
    }
}


