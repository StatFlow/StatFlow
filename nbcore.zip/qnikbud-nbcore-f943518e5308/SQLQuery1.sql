﻿declare @empl table(name nvarchar(max) null, boss nvarchar(max) null);

insert into @empl values ('Paul',null);
insert into @empl values ('Luke','Paul');
insert into @empl values ('Kate','Paul');
insert into @empl values ('Marge','Kate');
insert into @empl values ('Edith','Kate');
insert into @empl values ('Pam','Kate');
insert into @empl values ('Carol','Luke');
insert into @empl values ('John','Luke');
insert into @empl values ('Jack','Carol');
insert into @empl values ('Alex','Carol');

with t(level,path,boss,name) as (
        select 0,name,boss,name from @empl where boss is null
    union all
        select
            level + 1,
            path + ' > ' + e.name,
            e.boss, e.name 
        from 
            @empl e
			inner join t on e.boss = t.name                
) select * from t order by path;


with t(level,Path,Id,ParentDirId,Name) as (
        select 0,Name,Id,ParentDirId,Name from Dirs where ParentDirId is null
    union all
        select
            level + 1,
            Path + '/' + e.name,
			e.Id,
            e.ParentDirId,
			e.Name 
        from 
            Dirs e
			inner join t on e.ParentDirId = t.Id                
) 

select f.Id, t.Path, f.Name, f.Extension, f.Size, f.Hash from t 
	inner join Files f on f.ParentDirId = t.Id 
	where f.hash is not null
	order by f.hash



