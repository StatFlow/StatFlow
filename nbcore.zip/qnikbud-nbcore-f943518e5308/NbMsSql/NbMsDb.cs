﻿using System.Data;
using Microsoft.Data.SqlClient;


using NbCore;

namespace NbOrm.Ms
{
    public sealed class NbMsConn : INbConn, IDisposable
    {
        //private readonly SqlConnection fConn;
        private readonly string ConnString;
        public ConnectionType ConnType => ConnectionType.MsSql;

        public NbMsConn(string connString)
        {
            ConnString = connString;
        }

        public INbCommand CreateCommand(string sql) => new NbMsCommand(ConnString, sql);
        public INbTrans BeginTransaction() => throw new NotImplementedException();
        public INbReader CreateReader(string sql) => new NbMReader(ConnString, sql);

        public void Dispose() { } //fConn.Dispose();

        public DataTable ReadDataTableAsync(string query, TimeSpan timeout = default)
        {
            using var conn = new SqlConnection(ConnString);
            conn.Open();

            using var da = new SqlDataAdapter();
            using (da.SelectCommand = conn.CreateCommand())
            {
                da.SelectCommand.CommandText = query;
                if (timeout != default)
                    da.SelectCommand.CommandTimeout = (int)timeout.TotalSeconds;

                //da.SelectCommand.Connection.ConnectionString = _connectionString;
                DataSet ds = new(); //conn is opened by data adapter
                da.Fill(ds);
                return ds.Tables[0];
            }
        }

        /// <summary>
        /// Creates a throw-away connection in order to initialize the pool
        /// </summary>
        /// <returns></returns>
        public Task Initialize()
        {
            using var conn = new SqlConnection(ConnString);
            return conn.OpenAsync();
        }

        public async Task<T?> ReadSingleAsync<T>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? rdr.GetValue<T>(0) : default;
        }

        public async Task<(T?, U?)> ReadSingleAsync<T, U>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? (rdr.GetValue<T>(0), rdr.GetValue<U>(1)) : default;
        }

        public async Task<(T?, U?, V?)> ReadSingleAsync<T, U, V>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? (rdr.GetValue<T>(0), rdr.GetValue<U>(1), rdr.GetValue<V>(1)) : default;
        }

        public async Task<List<T?>> ReadListAsync<T>(string sql)
        {
            var list = new List<T?>();
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                list.Add(rdr.GetValue<T>(0));
            return list;
        }

        public async Task<List<(T?, U?)>> ReadListAsync<T, U>(string sql)
        {
            var list = new List<(T?, U?)>();
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                list.Add((rdr.GetValue<T>(0), rdr.GetValue<U>(1)));
            return list;
        }

        public async Task<List<(T?, U?, V?)>> ReadListAsync<T, U, V>(string sql)
        {
            var list = new List<(T?, U?, V?)>();
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                list.Add((rdr.GetValue<T>(0), rdr.GetValue<U>(1), rdr.GetValue<V>(2)));
            return list;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="K"></typeparam>
        /// <typeparam name="V"></typeparam>
        /// <param name="sql"></param>
        /// <param name="ignoreDupes">If set to true, ignores duplicates (first encounter stays in the dictionary) and null keys (not inserted)</param>
        /// <param name="dictDecr"></param>
        /// <returns></returns>
        public async Task<NbDictionary<K, V?>> ReadDictionaryAsync<K, V>(string sql, bool ignoreDupes = false, string? dictDecr = null) where K : notnull
        {
            var dict = new NbDictionary<K, V?>(description: dictDecr);
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
            {
                var key = rdr.GetValue<K>(0);
                if (ignoreDupes && (key is null || dict.ContainsKey(key)))
                    continue;

                dict.Add(key ?? throw new Exception($"key is null in {nameof(ReadDictionaryAsync)}"),
                    rdr.GetValue<V?>(1));
            }
            return dict;
        }
    }

    public sealed class NbMsCommand : INbCommand
    {
        private readonly SqlConnection fConn;
        private readonly SqlCommand fCmd;

        public NbMsCommand(string connStr, string sql)
        {
            fConn = new SqlConnection(connStr);
            fCmd = fConn.CreateCommand();
            fCmd.CommandText = sql;
            fCmd.CommandType = System.Data.CommandType.Text;
        }

        public void AddParam(string name, object value) => fCmd.Parameters.AddWithValue("@" + name, value ?? DBNull.Value);
        public void AddParam(string name, bool value) => fCmd.Parameters.AddWithValue("@" + name, value);
        public void AddParam(string name, bool? value) => fCmd.Parameters.AddWithValue("@" + name, (object?)value ?? DBNull.Value);
        public void AddBlob(string name, byte[] value) => throw new NotImplementedException();

        public async Task RunAsync()
        {
            await fConn.OpenAsync();
            await fCmd.ExecuteNonQueryAsync();
        }
        public async Task<int> RunGetInt32Async()
        {
            await fConn.OpenAsync();
            object res = await fCmd.ExecuteScalarAsync() ?? throw new Exception($"{nameof(SqlCommand.ExecuteScalarAsync)} didn't retrun any results)");
            if (res is int intRes)
                return intRes;
            throw new Exception($"{nameof(SqlCommand.ExecuteScalarAsync)} returned '{res.GetType().Name}' instead Int32");
        }

        public void Dispose()
        {
            fCmd?.Dispose();
            fConn?.Dispose();
        }

        public T ReadSingle<T>() => throw new NotImplementedException();
        public Tuple<T, U> ReadSingle<T, U>() => throw new NotImplementedException();
        public Tuple<T, U, V> ReadSingle<T, U, V>() => throw new NotImplementedException();
    }

    public sealed class NbMReader : INbReader, IDisposable
    {
        private readonly SqlConnection fConn;
        private readonly SqlCommand fCmd;
        private SqlDataReader? fRdr;

        public Type GetFieldType(int ordinal) => Rdr.GetFieldType(ordinal);
        public bool IsDBNull(int ordinal) => Rdr.IsDBNull(ordinal);
        public int FieldCount() => Rdr.FieldCount;

        public NbMReader(string connStr, string sql)
        {
            fConn = new SqlConnection(connStr);
            fCmd = fConn.CreateCommand();
            fCmd.CommandText = sql;
            fCmd.CommandType = System.Data.CommandType.Text;
        }

        private SqlDataReader Rdr => fRdr ?? throw new Exception("Reader was not initialized");

        private async Task<SqlDataReader> RdrAsync()
        {
            if (fRdr == null)
            {
                await fConn.OpenAsync();
                fRdr = await fCmd.ExecuteReaderAsync();
            }
            return fRdr;
        }

        public async Task<bool> ReadAsync()
        {
            var rdr = await RdrAsync();
            return await rdr.ReadAsync();
        }

        public void Dispose()
        {
            Rdr?.Dispose();
            fCmd?.Dispose();
            fConn?.Dispose();
        }


        public T? GetValue<T>(int index) => Rdr.IsDBNull(index) ? default : (T)Convert.ChangeType(Rdr.GetValue(index), typeof(T));

        public T GetNullableNumber<T>(int index) where T : struct => Rdr.IsDBNull(index) ? default : GetNumber<T>(index);

        public T GetNumber<T>(int index) where T : struct
        {
            return typeof(T).Name switch
            {
                nameof(Byte) => (T)(object)Rdr.GetByte(index),
                nameof(Int16) => (T)(object)Rdr.GetInt16(index),
                nameof(Int32) => (T)(object)Rdr.GetInt32(index),
                _ => throw new Exception($"Unsupported type in GetNumber<{typeof(T).Name}>"),
            };
        }

        public string GetString(int index) => Rdr.GetString(index);
        public string? GetNullableString(int index) => Rdr.IsDBNull(index) ? null : Rdr.GetString(index);


        public Int16? GetNullableInt16(int index) => Rdr.IsDBNull(index) ? (Int16?)null : GetInt16(index);

        public Int16 GetInt16(int index)
        {
            var a = Rdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Boolean) => Rdr.GetBoolean(index) ? (short)1 : (short)0,
                nameof(Byte) => Rdr.GetByte(index),
                nameof(Int16) => Rdr.GetInt16(index),
                _ => throw new Exception($"Unsupported type in GetNullableInt16: {a}"),
            };
        }

        public int? GetNullableInt32(int index) => Rdr.IsDBNull(index) ? (int?)null : GetInt32(index);

        public int GetInt32(int index)
        {
            var a = Rdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Byte) => Rdr.GetByte(index),
                nameof(Int16) => Rdr.GetInt16(index),
                nameof(Int32) => Rdr.GetInt32(index),
                nameof(Boolean) => Rdr.GetBoolean(index) ? 1 : 0,
                _ => throw new Exception($"Unsupported type in {nameof(GetInt32)}: {a}"),
            };
        }

        public long? GetNullableInt64(int index) => Rdr.IsDBNull(index) ? (long?)null : Rdr.GetInt64(index);
        public long GetInt64(int index)
        {
            var a = Rdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Byte) => Rdr.GetByte(index),
                nameof(Int16) => Rdr.GetInt16(index),
                nameof(Int32) => Rdr.GetInt32(index),
                nameof(Int64) => Rdr.GetInt64(index),
                nameof(Boolean) => Rdr.GetBoolean(index) ? 1 : 0,
                _ => throw new Exception($"Unsupported type in {nameof(GetInt64)}: {a}"),
            };
        }

        public decimal GetDecimal(int index) => Rdr.GetDecimal(index);
        public decimal? GetNullableDecimal(int index) => Rdr.IsDBNull(index) ? (decimal?)null : Rdr.GetDecimal(index);
        public double GetDouble(int index) => Rdr.GetDouble(index);
        public double? GetNullableDouble(int index) => Rdr.IsDBNull(index) ? (double?)null : Rdr.GetDouble(index);
        public DateTime GetDateTime(int index) => Rdr.GetDateTime(index);
        public DateTime? GetNullableDateTime(int index) => Rdr.IsDBNull(index) ? (DateTime?)null : Rdr.GetDateTime(index);
        public bool GetBoolean(int index) => Rdr.GetBoolean(index);
        public bool? GetNullableBoolean(int index) => Rdr.IsDBNull(index) ? (bool?)null : Rdr.GetBoolean(index);
        public char GetChar(int index) => Rdr.GetString(index)[0];
        public char? GetNullableChar(int index) => Rdr.IsDBNull(index) ? (char?)null : Rdr.GetString(index)[0];
        public string GetName(int index) => Rdr.GetName(index);

        public string GetBlob(int v) => throw new NotImplementedException();
        public byte[] GetBytes(int index) => throw new NotImplementedException();
        public DataTable FillDataTable() => throw new NotImplementedException();
    }

    /*public class NbMsTrans : INbTrans, IDisposable
    {
        private readonly SqlTransaction fTrans;

        public NbMsTrans(SqlConnection conn) => fTrans = conn.BeginTransaction(); //TODO: Isolation level
        public void Commit() => fTrans.Commit();
        public void Dispose() => fTrans.Dispose();
    }*/
}
