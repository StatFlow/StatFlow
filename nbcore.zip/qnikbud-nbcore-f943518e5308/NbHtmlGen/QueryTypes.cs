﻿using NbTools.Collections;
using NbOrm.Nbq;
using NbOrm.Xml;
using NbCollV1;
using NbCore;

namespace NbHtmlGen
{
    public abstract class QueryTypeBase
    {
        public abstract string Name { get; }
        public abstract NbqQueryType NbqType { get; } // { nbquery, nbsql, nbblob, nbdgml, nbcsv };
        public override string ToString() => Name;

        public abstract Task<QueryResult?> GetQueryResult(NbqQueryType qType, string query, INbConnGetter connGetter, string envName, model mod, layout_info layoutTables);

        private static readonly QueryTypeSqlData sqlData = new();
        private static readonly QueryTypeSqlText sqlText = new();
        private static readonly QueryTypeSqlBlob sqlBlob = new();
        private static readonly QueryTypeSqlDgml sqlDgml = new();
        private static readonly QueryTypeCsv csv = new();

        public static QueryTypeBase[] All = new QueryTypeBase[] { sqlData, sqlText, sqlBlob, sqlDgml, csv };

        public static QueryTypeBase ByName(string name)
        {
            if (String.IsNullOrEmpty(name))
                throw new NbExceptionInfo($"Query type is not specified");

            var qt = All.FirstOrDefault(i => i.Name.EqIC(name));
            if (qt == null)
                throw new NbExceptionInfo($"Unsupported QueryTypeBase: '{name}'");
            return qt;
        }

        [Obsolete("Use ByQType instead")]
        public static QueryTypeBase ByUri(Uri uri)
        {
            if (uri == null)
                throw new Exception("Empty Uri provided");

            if (!Enum.TryParse(uri.Scheme, out NbqQueryType enumType))
                throw new Exception($"Unsupported query type in uri: {uri.ToString()}. Supported types are: {String.Join(", ", Enum.GetValues(typeof(NbqQueryType)).Cast<NbqQueryType>().Select(t => t.ToString())) }");

            var qt = All.FirstOrDefault(i => i.NbqType == enumType);
            if (qt == null)
                throw new NbExceptionInfo($"Unsupported QueryTypeBase: '{enumType}'");
            return qt;
        }

        public static QueryTypeBase ByQType(NbqQueryType enumType)
        {
            var qt = All.FirstOrDefault(i => i.NbqType == enumType);
            if (qt == null)
                throw new NbExceptionInfo($"Unsupported QueryTypeBase: '{enumType}'");
            return qt;
        }
    }




    public class QueryTypeSqlData : QueryTypeBase
    {
        public override string Name => "Sql Data";
        public override NbqQueryType NbqType => NbqQueryType.nbquery;

        public override async Task<QueryResult?> GetQueryResult(NbqQueryType qType, string query, INbConnGetter connGetter, string envName, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;
            DfTable layoutTable = GetOrCreate(layoutTables, recSet.name, recSet);


            DfDynamicCollection? collN = recSet.DfDynamicCollectionByUriN(qType, query, mod, layoutTable, envName);
            string? sqlByUriN = null;
            if (collN == null)
            {
                sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, envName);

                collN = new DfDynamicCollection(recSet.name);
                var conn = connGetter.GetConnection(envName, recSet.GetConnectionName());
                await collN.LoadFromDbAsync(conn, sqlByUriN, layoutTable, 100);
            }

            if (collN != null)
                return new QueryResultRecordset(query, this, collN, recSet, layoutTable);
            else
                return new QueryResultFile(query, this, sqlByUriN);
        }


        public static DfTable GetOrCreate(layout_info li, string name, recordset recSet)
        {
            if (li.TryGetValue(recSet.name, out DfTable layoutTableN))
                return layoutTableN;

            layoutTableN = new DfTable { name = name };
            //layoutTableN.PopulateByRecordset(recSet.Fields); //TODO: something wrong here
            if (li.table == null)
                li.table = new DfTable[0];

            li.table = li.table.Concat(NbExt.Yield(layoutTableN)).ToArray(); //Adding to the collection
            return layoutTableN;
        }
    }

    public class QueryTypeSqlText : QueryTypeBase
    {
        public override string Name => "Sql Text";
        public override NbqQueryType NbqType => NbqQueryType.nbsql;


        public override Task<QueryResult> GetQueryResult(NbqQueryType qType, string query, INbConnGetter connGetter, string envName, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;
            string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, envName);

            return Task.FromResult<QueryResult>(new QueryResultFile(query, this, sqlByUriN));
        }
    }

    public class QueryTypeSqlBlob : QueryTypeBase
    {
        public override string Name => "Sql Blob";
        public override NbqQueryType NbqType => NbqQueryType.nbblob;

        public override async Task<QueryResult> GetQueryResult(NbqQueryType qType, string query, INbConnGetter connGetter, string envName, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;

            string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, envName);
            var conn = connGetter.GetConnection(envName, recSet.GetConnectionName());

            return new QueryResultFile(query, this, await BlobHtmlFormatter.Load(conn, sqlByUriN));
        }
    }

    public class QueryTypeSqlDgml : QueryTypeBase
    {
        public override string Name => "Dgml";
        public override NbqQueryType NbqType => NbqQueryType.nbdgml;

        public override async Task<QueryResult?> GetQueryResult(NbqQueryType qType, string query, INbConnGetter connGetter, string envName, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;
            layoutTables.TryGetValue(recSet.name, out DfTable layoutTableN);
            string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, envName);

            /*var dlg = new SaveFileDialog
            {
                Filter = "Dgml file (*.dgml)|*.dgml",
                FileName = query.Substring(0, 1).ToUpperInvariant() + query.Substring(1) + ".dgml"
            };*/

            var targetFileName = "Dummy.txt"; // (dlg.ShowDialog() ?? false) ? dlg.FileName : null;
            if (targetFileName != null)
            {
                DfDynamicCollection coll2 = new DfDynamicCollection("Bla");

                var conn = connGetter.GetConnection(envName, recSet.GetConnectionName());
                await coll2.LoadFromDbAsync(conn, sqlByUriN, layoutTableN, 100);
                var dgmlWriter = new DgmlExporter(coll2);
                dgmlWriter.Write(targetFileName, title: query);
            }

            return null;
        }
    }

    public class QueryTypeCsv : QueryTypeBase
    {
        public override string Name => "Csv";
        public override NbqQueryType NbqType => NbqQueryType.nbcsv;

        public override async Task<QueryResult?> GetQueryResult(NbqQueryType qType, string query, INbConnGetter connGetter, string envName, model mod, layout_info layoutTables)
        {
            //TODO: think about saving to csv withouth repeating the request
            /*var dlg = new SaveFileDialog
            {
                Filter = "Csv file (*.csv)|*.csv",
                FileName = query.Substring(0, 1).ToUpperInvariant() + query.Substring(1) + ".csv"
            };*/

            var targetFileName = "dummy.csv"; //(dlg.ShowDialog() ?? false) ? dlg.FileName : null;
            if (targetFileName != null)
            {
                NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
                recordset recSet = parsed.Recordset;
                layoutTables.TryGetValue(recSet.name, out DfTable layoutTableN);
                var connName = recSet.GetConnectionName();

                DfDynamicCollection collN = recSet.DfDynamicCollectionByUriN(qType, query, mod, layoutTableN, envName);
                if (collN == null)
                {
                    string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, envName);
                    collN = new DfDynamicCollection(recSet.name);
                    var conn = connGetter.GetConnection(envName, recSet.GetConnectionName());
                    await collN.LoadFromDbAsync(conn, sqlByUriN, layoutTableN, 100);
                }

                if (collN != null)
                    collN.Save("Pass dir here, name should be in colletion name", new CsvParameters { FieldDelimiterN = ',' });
            }

            return null; //Don't save csv export into history
        }
    }
}