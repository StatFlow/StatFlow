﻿namespace NbHtmlGen
{
    /*public class TilesFormatter
    {
        public static NbTag Generate<T>(NbTag root, NbCss css, IEnumerable<INbTagGenerator> items)
            where T : INbTagGenerator //TODO: support colour for columns??
        {
            foreach (var item in items)
            {
                item.Generate(root);
            }
            return root;
        }
    }*/
}
