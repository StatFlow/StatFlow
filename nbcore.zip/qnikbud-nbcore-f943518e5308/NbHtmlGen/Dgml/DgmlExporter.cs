﻿using System.Xml.Serialization;
using NbCore;
using NbTools.Collections;
using NbTools.Dgml;

namespace NbOrm.Xml
{
    public class DgmlExporter
    {
        private readonly DfDynamicCollection fColl;
        private readonly IDfColumnBase fPrimColumn;
        private readonly IDfColumnBase fParentColumn;
        private readonly List<IDfColumnBase> fInfoColumns;

        private static Lazy<XmlSerializer> modelXmlSerializer = new Lazy<XmlSerializer>(() => new XmlSerializer(typeof(DirectedGraph)), false);

        public DgmlExporter(DfDynamicCollection coll)
        {
            fColl = coll;
            fPrimColumn = fColl.PrimaryKeyColumn;
            if (fPrimColumn == null)
                throw new NbExceptionInfo($"Collection {coll} doesn't have primary key field defined and can't be used for dgml export");


            fParentColumn = fColl.ParentKeyColumnN;
            //if (fParentColumn == null)
                //throw new NbExceptionInfo($"Collection {coll} doesn't have {nameof(field_baseKey.parent_id)} key field defined and can't be used for dgml export");
                //nameof(field_baseKey.parent_id)

            fInfoColumns = fColl.GetColumns().Where(c => c != fPrimColumn && c != fParentColumn).ToList();
        }

        //    <Link Label="EntityId" Source="CashflowProfiles" Target="tdb_Entities" />
        public void Write(string targetFileName, string title)
        {
            try
            {
                var primCol = fColl.PrimaryKeyColumn;
                var parentCol = fColl.ParentKeyColumnN;

                var cols = fColl.GetColumns().ToDictionary(c => c.Name);
                var nodes = new List<DirectedGraphNode>(fColl.Count);
                var links = new List<DirectedGraphLink>(fColl.Count);
                for (int r = 0; r < fColl.Count; ++r)
                {
                    var thisId = primCol.GetText(r);
                    var label = String.Join(", ", fInfoColumns.Select(c => c.GetText(r))); //Concatenate all non-key columns

                    nodes.Add(new DirectedGraphNode { Id = thisId, Label = label });
                    var parentId = fParentColumn.GetText(r);
                    if (String.IsNullOrEmpty(parentId))
                        continue;

                    links.Add(new DirectedGraphLink { Source = parentId, Target = thisId });
                }

                DirectedGraph dg = new DirectedGraph
                {
                    Title = title,
                    Nodes = nodes.ToArray(),
                    Links = links.ToArray()
                };

                using (StreamWriter wrtr = new StreamWriter(targetFileName))
                {
                    modelXmlSerializer.Value.Serialize(wrtr, dg);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error serializing dgml into '{targetFileName}'", ex);
            }
        }
    }
}
