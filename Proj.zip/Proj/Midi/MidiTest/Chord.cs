﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Nb.Library.Clr;

namespace NbMusic
{
    public class Chord
    {
        public enum ChordTypes { Major, Minor, Sept };
        public enum Gammas { Major, Minor, MajorHarmonic, MinorHarmonic }

        public static readonly Dictionary<Gammas, int[]> ChordSteps = new Dictionary<Gammas, int[]>
        {
            {Gammas.Major, new int[] {0, 2, 4, 5, 7, 9, 11 }},
            {Gammas.Minor, new int[] {0, 2, 3, 5, 7, 8, 10 } },
            {Gammas.MajorHarmonic,  new int[] {0, 2, 4, 5, 7, 8, 11 } },
            {Gammas.MinorHarmonic, new int[] {0, 2, 3, 5, 7, 9, 10 } },
        };


        public List<Note> Notes = new List<Note>(5);

        public readonly Gammas Gamma;
        public readonly ChordTypes ChordType;
        public readonly Note Tonic;
        public readonly string StepsText;

        public Chord(Note tonic, ChordTypes type)
        {
            Tonic = tonic;
            ChordType = type;
            Notes.Add(tonic);

            switch (type)
            {
                case ChordTypes.Major:
                    Notes.Add(tonic.Transpose(4));
                    Notes.Add(tonic.Transpose(7));
                    Gamma = Gammas.Major;
                    break;

                case ChordTypes.Minor:
                    Notes.Add(tonic.Transpose(3));
                    Notes.Add(tonic.Transpose(7));
                    Gamma = Gammas.Minor;
                    break;

                case ChordTypes.Sept:
                    Notes.Add(tonic.Transpose(4));
                    Notes.Add(tonic.Transpose(7));
                    Notes.Add(tonic.Transpose(10));
                    Gamma = Gammas.Major;
                    break;

                default:
                    throw new NbsException($"Unsupported ChordType: '{type.ToString()}'");
            }

            StepsText = String.Join(", ", ChordSteps[Gamma].Select(sh => tonic.Transpose(sh).Letter));
        }

        public static ChordTypes ParseChordType(string str)
        {
            switch (str)
            {
                case "": return ChordTypes.Major;
                case "m": return ChordTypes.Minor;
                case "7": return ChordTypes.Sept;
                default:
                    throw new NbsException("Unsupported chord type '{0}'", str);
            }
        }

        private static Regex CommonChordRegex = new Regex(@"([\[\]]*)([A-G][b#]?)([m7]?)");
        // 1 [] - inversion, 2 - base note, 3 -  chord type

        public static Chord FromCommonText(measure mes)
        {
            Match match = CommonChordRegex.Match(mes.chord);
            if (!match.Success)
                throw new NbsException($"Common chord text '{mes.chord}' doesn't match a the Regex");

            Note tonic = Note.FromCommonText(match.Groups[2].Value).Transpose(-12);
            tonic.MidiLength = Note.TickPerQuarter * mes.quarters;

            ChordTypes cType = ParseChordType(match.Groups[3].Value);
            Chord chord = new Chord(tonic, cType);

            foreach (char bracket in match.Groups[1].Value)
            {
                if (bracket == '[')
                    chord.InverseDown();
                else if (bracket == ']')
                    chord.InverseUp();
                else
                    throw new NbsException($"Common note text '{mes.chord}' contains unsupported inversion modifier '{bracket}'");
            }

            return chord;
        }

        public override string ToString() => $"{Tonic} {ChordType}";

        private int ToStep(Note n)
        {
            var gm = ChordSteps[Gamma];
            for (int i = 0; i < gm.Length; ++i)
            {
                var newNote = Tonic.Transpose(gm[i]);
                if ((n.MidiTone - newNote.MidiTone) % 12 == 0)
                    return i + 1; //1-base number of a step
            }
            throw new Exception($"Can't find a step for {n} in the chord {this}");
        }


        internal string ToSteps(List<Note> notes) => String.Join(" ", notes.Select(n => this.ToStep(n)));

        private void InverseUp()
        {
            Note temp = Notes[0].Transpose(12);
            Notes.RemoveAt(0);
            Notes.Insert(Notes.Count - 1, temp);
        }

        private void InverseDown()
        {
            Note temp = Notes[Notes.Count - 1].Transpose(-12);
            Notes.RemoveAt(Notes.Count - 1);
            Notes.Insert(0, temp);
        }
    }
}
