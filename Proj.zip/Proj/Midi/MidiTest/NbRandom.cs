﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;

namespace MidiTest
{
    public class WeightedRandom 
    {
        private readonly Random Rnd = new Random();
        private readonly SortedList<int, int> Dict = new SortedList<int, int>(100);
        private int fCummulativeWeight = 0;


        public void AddValue(int aValue, int aWeight)
        {
            fCummulativeWeight += aWeight;
            Dict.Add(fCummulativeWeight, aValue);
        }

        public int GetValue()
        {
            int rnd = Rnd.Next(0, fCummulativeWeight + 1);
            foreach (var pair in Dict)
            {
                if (rnd <= pair.Key)
                    return pair.Value;
            }
            throw new Exception("Shouldn't be here");
        }
    }
}
