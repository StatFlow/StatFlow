﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;

namespace NbMusic
{
    public partial class music
    {
        private static XmlSerializer ser = new XmlSerializer(typeof(music));

        public static music LoadFile(string aFileName)
        {
            music mus;
            try
            {
                using (StreamReader rdr = new StreamReader(aFileName))
                {
                    mus = (music)ser.Deserialize(rdr);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(String.Format("Error parsing '{0}' music file", aFileName), ex);
            }
            return mus;
        }

        public void Save(string aFileName)
        {
            using (StreamWriter wrtr = new StreamWriter(aFileName))
            {
                ser.Serialize(wrtr, this);
            }
        }
    }
}
