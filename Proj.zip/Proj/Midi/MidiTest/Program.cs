﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using NAudio.Midi;
using System.Xml.Serialization;
using NbMusic;
using System.IO;
using Nb.Library.Clr;

namespace MidiTest
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                //ReadMidiFile();
                ParseXml();
            }
            catch (Exception ex)
            {
                Console.WriteLine(NbsException.Exception2String(ex));
                Console.Write("Press any key...");
                Console.ReadKey();
            }
        }

        public static void ReadMidiFile()
        {
            string midiFile = "Bolero.mid";

            Note noteOn = new Note(); //custom class Note
            MidiFile midiSrc = new MidiFile(midiFile);


            var midiDst = new MidiEventCollection(1, midiSrc.DeltaTicksPerQuarterNote);

            int trkCount = 0;
            foreach (IList<MidiEvent> trackEvents in midiSrc.Events)
            {
                midiDst.AddTrack(trackEvents);
                trkCount++;
                if (trkCount > 16)
                {
                    int a = 1;
                }
            }

            midiDst.PrepareForExport();
            MidiFile.Export("NewMid.mid", midiDst);


            /*List<TempoEvent> tempo = new List<TempoEvent>();

            using (StreamWriter wrtr = new StreamWriter("midiText.csv"))
            {
                foreach (var midiEvent in midiSrc.Events)
                {
                    midiDst.AddTrack( .AddEvents(midiEvent, midiEvent.Channel);
                    foreach (var midiSubEvent in midiEvent)
                    {
                        wrtr.WriteLine(midiSubEvent.ToString().Replace(' ', ','));
                    }
                }
            }*/


            /*foreach (MidiEvent note in midi.Events[i])
            {
                TempoEvent tempoE;

                try { tempoE = (TempoEvent)note; tempo.Add(tempoE); }
                catch { }

                if (note.CommandCode == MidiCommandCode.NoteOn)
                {
                    var t_note = (NoteOnEvent)note;

                    var noteOffEvent = t_note.OffEvent;

                    noteOn.NoteName.Add(t_note.NoteName);
                    noteOn.NoteNumber.Add(t_note.NoteNumber);
                    noteOn.NoteVelocity.Add(t_note.Velocity);
                    noteOn.NoteLenght.Add(t_note.NoteLength);

                    double d = (t_note.AbsoluteTime / midi.DeltaTicksPerQuarterNote) * tempo[tempo.Count() - 1].Tempo;

                    noteOn.StartTime.Add(TimeSpan.FromSeconds(d));
                }

            }*/
        }


        private static void ParseXml()
        {
            music mus = music.LoadFile(@"MusicStruct.xml");
            int currTime = Note.TickPerQuarter * 2; //Skip half-measure

            using (NbMidiFile file = new NbMidiFile(@"test.mid", mus.BeatsPerMinute))
            {
                foreach (measure mes in mus.measure)
                {
                    if (mes.common != null)
                    {
                        var notes = ParseCommon(mes.common);
                        foreach (Note note in notes)
                        {
                            file.AddNote(note, currTime, 1);
                        }
                        Chord chord = Chord.FromCommonText(mes);
                        chord.Notes.ForEach(n => file.AddNote(n, currTime, 2));

                        mes.steps = chord.ToSteps(notes);
                    }
                    currTime += Note.TickPerQuarter * mes.quarters; //Next measure start
                }
            }

            mus.Save(@"MusicStruct_out.xml");
        }

        private static List<Note> ParseCommon(string aCommonNotesText)
        {
            List<Note> notes = new List<Note>(100);
            int measureBeginSlot = -1;
            int counter = 0;
            foreach (string noteText in aCommonNotesText.Split(new char[] { ' ' }))
            {
                if (String.IsNullOrWhiteSpace(noteText))
                    continue;

                if (noteText.StartsWith("|"))
                {
                    if (measureBeginSlot != -1)
                        throw new NbsException("Measure starting symbol is repeated twice in the common notes string: {0}", aCommonNotesText);

                    measureBeginSlot = counter;
                    noteText.Replace("|", String.Empty);
                }
                else if (noteText.EndsWith("|"))
                {
                    if (measureBeginSlot != -1)
                        throw new NbsException("Measure starting symbol is repeated twice in the common notes string: {0}", aCommonNotesText);

                    measureBeginSlot = counter + 1;
                    noteText.Replace("|", String.Empty);
                }

                notes.Add(Note.FromCommonText(noteText));
                counter++; 
            }

            int currTime = 0;
            for (int i = measureBeginSlot - 1; i >= 0; --i)
            {
                Note note = notes[i];
                currTime -= note.MidiLength;
                note.MidiStart = currTime;
            }

            currTime = 0;
            for (int i = Math.Max(measureBeginSlot, 0); i < notes.Count; ++i)
            {
                Note note = notes[i];
                note.MidiStart = currTime;
                currTime += note.MidiLength;
            }

            return notes;
        }


        private static void GenerateRandomMid()
        {
            WeightedRandom tones = new WeightedRandom();
            tones.AddValue(1, 3);
            tones.AddValue(2, 2);
            tones.AddValue(3, 3);
            tones.AddValue(4, 2);
            tones.AddValue(5, 3);
            tones.AddValue(6, 3);
            tones.AddValue(7, 2);
            tones.AddValue(8, 2);


            WeightedRandom durations = new WeightedRandom();
            durations.AddValue(1, 1);
            durations.AddValue(2, 2);
            durations.AddValue(4, 5);
            durations.AddValue(8, 4);
            durations.AddValue(16, 3);


            using (NbMidiFile file = new NbMidiFile(@"test.mid", 70))
            {
                for (int i = 1; i < 100; ++i)
                    file.AddNote(tones.GetValue(), durations.GetValue());
                /*file.AddNote(1, 2);
                file.AddNote(3, 4);
                file.AddNote(5, 4);


                file.AddNote(7+1, 8);
                file.AddNote(7 + 3, 8);
                file.AddNote(7 + 5, 8);
                file.AddNote(7 + 8, 8);


                file.AddNote(-7 + 1, 8);
                file.AddNote(-7 + 3, 8);
                file.AddNote(-7 + 5, 8);
                file.AddNote(-7 + 8, 8);*/

            }

            //Application.Run(new Form1());

            //delta ticks per quarter note is your choice. people usually go with numbers that are multiples of 2 and 3, allowing for subdivisions into triplets etc. 
            //Common values are 96, 240, 480. So if you have 120 BPM and 240 ticks per beat there are 28800 ticks per minute, or 480 ticks per second
            //(so you have an effective time resolution of 2ms.


            /*MidiEventCollection collection = new MidiEventCollection(0, 120);

            collection.AddEvent(new NoteEvent(1, 1, MidiCommandCode.NoteOn, 60, 100), 0);
            collection.AddEvent(new NoteEvent(240, 1, MidiCommandCode.NoteOff, 60, 0), 0);

            collection.AddEvent(new NoteEvent(240, 1, MidiCommandCode.NoteOn, 65, 100), 0);
            collection.AddEvent(new NoteEvent(480, 1, MidiCommandCode.NoteOff, 65, 0), 0);

            collection.PrepareForExport();

            collection.PrepareForExport();
            MidiFile.Export(@"c:\Temp\test.mid", collection);*/
        }
    }

}
