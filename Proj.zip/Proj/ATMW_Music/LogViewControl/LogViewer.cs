using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace Nb.Library.LogView
{

    internal class CopyCommand : ILogCommand
    {
        private string StrToCopy;

        internal CopyCommand(string aStrToCopy)
        {
            StrToCopy = aStrToCopy;
        }

        public string Name
        {
            get { return "Copy"; }
        }

        public void Execute()
        {
            Clipboard.SetText(StrToCopy);
        }
    }

    public enum Severity { Error = 2, Warning = 0, Message = 1 }; // ������ ��������������� ������� ������� � �����-�����
    public interface ILogEntry
    {
        Severity Severity { get; }
        string Description { get; }
        string GetColumnText(int aIndex);
        IEnumerable<ILogCommand> Commands { get;}
    }

    public interface ILogCommand
    {
        string Name { get; }
        void Execute(); //Returns true if the Error line should be closed
    }


    internal class LogJob
    {
        internal readonly ILogCommand Command;
        internal readonly ListViewItem ListItem;

        internal LogJob(ILogCommand aCmd, ListViewItem aLogLine)
        {
            Command = aCmd;
            ListItem = aLogLine;
        }
    }

    /// <summary>
    /// Provides lazy initialization for LogViewTabs
    /// </summary>
    public class LogViewSession : IDisposable
    {
        private readonly LogViewContainer fCnt;
        private readonly string fName;
        
        private bool firstLine = true;
        private LogViewControl fLvc;

        internal LogViewSession(LogViewContainer aCnt, string aName)
        {
            fCnt = aCnt;
            fName = aName;
        }

        public void Add(ILogEntry aEntry)
        {
            if (firstLine)
            {
                fLvc = fCnt.CreateLogTab(fName);
                fLvc.Clear();
                fLvc.BeginUpdate();
                firstLine = false;
            }

            fLvc.Add(aEntry);
        }



        #region IDisposable Members

        public void Dispose()
        {
            fLvc.EndUpdate();
            fCnt.tabControl1.SelectTab(fName);
        }

        #endregion
    }

}