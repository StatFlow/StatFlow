using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Nb.Library.LogView
{
    public partial class LogViewControl : UserControl
    {
        private readonly TabPage fTabPage;
        private readonly string fName;

        public LogViewControl()
        {
            InitializeComponent();
            fTabPage = null;
            fName = null;
        }

        public LogViewControl(TabPage aTabPage, string aName)
        {
            InitializeComponent();
            contextMenuStrip1.Opening += new CancelEventHandler(contextMenuStrip1_Opening);
            contextMenuStrip1.ItemClicked += new ToolStripItemClickedEventHandler(contextMenuStrip1_ItemClicked);
            fTabPage = aTabPage;
            fName = aName;
        }

        void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            Dictionary<string, List<LogJob>> jobs = new Dictionary<string, List<LogJob>>(20);
            jobs.Add("&Copy", new List<LogJob>(10));

            foreach (ListViewItem item in ListView1.SelectedItems) //Build unique list of commands
            {
                jobs["&Copy"].Add(new LogJob(new CopyCommand(item.Text), item));

                ILogEntry entry = item.Tag as ILogEntry;
                if (entry == null)
                    continue;

                foreach (ILogCommand cmd in entry.Commands)
                {
                    List<LogJob> logJobList;
                    if (!jobs.TryGetValue(cmd.Name, out logJobList))
                    {
                        logJobList = new List<LogJob>(50);
                        jobs.Add(cmd.Name, logJobList);
                    }
                    logJobList.Add(new LogJob(cmd, item));
                }
            }

            contextMenuStrip1.Items.Clear();

            foreach (KeyValuePair<string, List<LogJob>> pair in jobs) //Populate the list of commands into the menu
            {
                ToolStripMenuItem item = new ToolStripMenuItem(pair.Key);
                item.Tag = pair.Value;
                contextMenuStrip1.Items.Add(item);
            }
            if (contextMenuStrip1.Items.Count == 0)
                e.Cancel = true;
        }

        void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            DateTime start = DateTime.Now;
            List<LogJob> cmdList = e.ClickedItem.Tag as List<LogJob>;
            if (cmdList == null)
                throw new Exception("Empty command list for Menu item: " + e.ClickedItem.Name);

            foreach (LogJob logJob in cmdList) //TODO: show progress here
            {
                logJob.Command.Execute();
                ListView1.Items.Remove(logJob.ListItem);
            }

            TimeSpan span = DateTime.Now - start;
            if (span.TotalSeconds > 5)
                MessageBox.Show(String.Format("Operation is completed on {0} items", cmdList.Count));
        }


        private IEnumerable<ILogEntry> SelectedEntries
        {
            get
            {
                foreach (ListViewItem item in ListView1.SelectedItems)
                {
                    ILogEntry entry = item.Tag as ILogEntry;
                    if (entry != null)
                        yield return entry;
                }
            }
        }



        //Events
        public delegate void LogEntryEvent(ILogEntry aEntry);
        public event LogEntryEvent ItemSelected;


        public void Clear()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => Clear()));
                return;
            }

            ListView1.Items.Clear();
            fTabPage.Select();
        }

        public void Add(ILogEntry aEntry)
        {
            ListViewItem item = new ListViewItem(aEntry.Description, (int)aEntry.Severity);
            item.Tag = aEntry;

            string column = aEntry.GetColumnText(0);
            if (!String.IsNullOrEmpty(column))
            {
                item.SubItems.Add(column);
            }
            
            if (InvokeRequired)
                Invoke(new Action(() => ListView1.Items.Add(item)));
            else
                ListView1.Items.Add(item);
        }

        public int Count
        {
            get { return ListView1.Items.Count; }
        }

        public string SelectedText
        {
            get
            {
                string str = "";
                foreach (ListViewItem item in ListView1.SelectedItems)
                {
                    str += (item.Tag as ILogEntry).Description + "\r\n";
                }
                return str;
            }
        }


        private void ListView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.C && e.Control)
            {
                Clipboard.SetDataObject(SelectedText, true);
            }
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ListView1.SelectedItems.Count > 0)
            {
                LogEntryEvent temp = ItemSelected; //Safe invocation
                if (temp != null)
                {
                    temp((ListView1.SelectedItems[0].Tag) as ILogEntry);
                }
            }
        }

        private void ListView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (ListView1.Sorting == SortOrder.Ascending)
                ListView1.Sorting = SortOrder.Descending;
            else
                ListView1.Sorting = SortOrder.Ascending;

            this.ListView1.Sort(); // Perform the sort with these new sort options.
        }

        internal void BeginUpdate()
        {
            ListView1.BeginUpdate();
        }

        internal void EndUpdate()
        {
            ListView1.EndUpdate();
            fTabPage.Text = String.Format("{0} ({1})", fName, ListView1.Items.Count);
        }
    }
}