using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace Nb.Library.LogView
{
    public partial class LogViewContainer : UserControl
    {
        private Dictionary<string, LogViewControl> fTabs = new Dictionary<string, LogViewControl>(10);

        public LogViewContainer()
        {
            InitializeComponent();
        }

        public LogViewControl CreateLogTab(string aName)
        {
            LogViewControl cnt;
            if (!fTabs.TryGetValue(aName, out cnt))
            {
                TabPage tp = new TabPage(aName);
                tp.Name = aName;
                tabControl1.TabPages.Add(tp);
                cnt = new LogViewControl(tp, aName);
                tp.Controls.Add(cnt);
                cnt.Dock = DockStyle.Fill;
                fTabs.Add(aName, cnt);
            }

            tabControl1.SelectTab(aName);
            return cnt;
        }

        public void RemoveLogTab(string aName)
        {
            tabControl1.TabPages.RemoveByKey(aName);
        }

        public LogViewControl this[string aName]
        {
            get { return CreateLogTab(aName); }
        }

        public LogViewSession GetLogSession(string aName)
        {
            return new LogViewSession(this, aName);
        }
    }
}
