using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.ComponentModel;

namespace Atmw.Xml
{
    [XmlType("file")]
    public class AxFile : AxElement
    {
        [XmlAttribute("duration"),
        DefaultValue(0.0)]
        public double duration;

        //[Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxFile()
        { }

        protected AxFile(FileInfo aFi)
            : base(aFi.Name, aFi.LastWriteTime)
        { }

        public static string DurationString(double tot)
        {
            StringBuilder bld = new StringBuilder();

            int days = (int)tot / (24 * 60 * 60);
            if (days > 0)
            {
                bld.Append(String.Format("{0} days ", days));
                tot -= days * (24 * 60 * 60);
            }

            int hours = (int)tot / (60 * 60);
            if (hours > 0)
            {
                bld.Append(String.Format("{0:d2}:", hours));
                tot -= hours * 24 * 60 * 60;
            }

            int minutes = (int)tot / 60;
            bld.Append(String.Format("{0:d2}:", minutes));
            tot -= minutes * 60;

            int seconds = Convert.ToInt32(tot);
            bld.Append(String.Format("{0:d2}", seconds));

            return bld.ToString();
        }

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }

        public static AxFile RecognizerN(FileInfo fInfo)
        {
            if (fInfo.Name.Equals("Thumbs.db", StringComparison.OrdinalIgnoreCase))
                return null; //Ignore Thumbs.db

            AxFileAudio audio = AxFileAudio.RecognizerN(fInfo);
            if (audio != null)
                return audio;

            AxFilePicture pict = AxFilePicture.RecognizerN(fInfo);
            if (pict != null)
                return pict;

            /*if (AxFileText.IsTextFileExtension(fInfo))  //Don't create nodes for text files yet
                return null;*/

            AxFileText txt = AxFileText.RecognizerN(fInfo);
            if (txt != null)
                return txt;

            return new AxFile(fInfo);
        }

        public override void Update(List<ElementChange> aChanges)
        {
            FileInfo fi = new FileInfo(PathName);
            DateTime newDateTime = AxElement.DropSecondFractionsUtc(fi.LastWriteTime);
            if (Changed < newDateTime) //Changed after Id3Tag Were read
            {
                Changed = newDateTime;
                aChanges.Add(new ElementChange(ElementChange.Types.Updated, this));
                UpdateFileChanged(null);
            }
        }

        public virtual void UpdateFileChanged(IErrorLogger aLogger)
        { }

        public override void CheckIntegrity(IErrorLogger aLogger)
        {
            aLogger.Log(this, "Unrecognized file found");
        }
    }


}
