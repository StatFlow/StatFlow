using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections;

namespace Atmw.Xml
{
    public delegate bool VisitorAction(AxElement aElement);

    public interface IElementVisitor
    {
        VisitorAction VisitN(AxDirectory aDir);
        VisitorAction VisitN(AxDisk aDisk);
        VisitorAction VisitN(AxAlbum aAlbum);

        VisitorAction VisitN(AxFile aFile);
        VisitorAction VisitN(AxFileAudio aFileAudio);
        VisitorAction VisitN(AxFileAudioMp3 aFileAudioMp3);

        VisitorAction VisitN(AxArtist aFile);
    }

    public interface IErrorLogger
    {
        void Log(AxElement aElement, string mesage);
        void Log(AxElement aElement, string aDescriptionFormat, params object[] args);
        void Log(string aMenuName, VisitorAction aAction, AxElement aElement, string aDescriptionFormat, params object[] args);
        void Log(string aMenuName, Action aAction, AxElement aElement, string aDescriptionFormat, params object[] args);
        void Log(AxElement aElement, string aMessage, params Tuple<string, Action>[] aCommands);
    }


    public class XmlManager
    {
        private XmlSerializer fSerializer = new XmlSerializer(typeof(AxDirectory));

        public AxRoot LoadXml(string tracksDir, string lyricsDir, string graphicsDir)
        {
            using (StreamReader file = new StreamReader(tracksDir + ".xml"))
            {
                AxRoot root = (AxRoot)fSerializer.Deserialize(file);
                root.SetDirs(tracksDir, lyricsDir, graphicsDir);
                return root;
            }
        }

        public void SaveXml(AxDirectory aXml, string aFileName)
        {
            using (TextWriter writer = new StreamWriter(aFileName))
            {
                //fGridXml.Timestamp = DateTime.Now.ToString(); TODO: timestamp
                fSerializer.Serialize(writer, aXml);
            }

        }


    }

    public class ElementChange
    {
        public enum Types { Added, Removed, Updated };

        public readonly Types Type;
        public readonly AxElement Element;

        public ElementChange(Types aType, AxElement aElement)
        {
            Type = aType;
            Element = aElement;
        }
    }

    public class AxArtist : AxElement
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxArtist()
        { }

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }


        public override void Update(List<ElementChange> aChanges)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public override void CheckIntegrity(IErrorLogger aLogger)
        {
            throw new Exception("The method or operation is not implemented.");
        }
    }

    public class AxPerformerGroup : AxArtist
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxPerformerGroup()
        { }

    }

    public class AxPerformerPerson : AxArtist
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxPerformerPerson()
        { }
    }

    public class AxTreeStatistics
    {
        public AxTreeStatistics()
        { }

        public int Directories
        {
            get { return fDirectories; }
            internal set { fDirectories = value; }
        } private int fDirectories;


        public int Files
        {
            get { return fFiles; }
            internal set { fFiles = value; }
        } private int fFiles;


        public override string ToString()
        {
            StringBuilder str = new StringBuilder();
            str.AppendFormat("Directories: {0}\r\n", fDirectories);
            str.AppendFormat("Files: {0}\r\n", fFiles);
            return str.ToString();
        }
    }

}
