using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Linq;
using System.Diagnostics;

using Nb.Library;
using NbTools;

namespace Atmw.Xml
{
    [XmlType("root")]
    public class AxRoot : AxDirectory
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxRoot()
        { }

        public enum PathType { Tracks, Lyrics, Graphics }
        private string fTrackPath, fLyricsPathN, fGraphicsPathN;

        internal void SetDirs(string trackPath, string lyricsPathN, string graphicsPathN)
        {
            fTrackPath = trackPath.TrimEnd('\\');
            fLyricsPathN = (lyricsPathN != null) ? lyricsPathN.TrimEnd('\\') : null;
            fGraphicsPathN = (graphicsPathN != null) ? graphicsPathN.TrimEnd('\\') : null;
        }

        private AxRoot(DirectoryInfo trackPath, DirectoryInfo lyricsPathN, DirectoryInfo graphicsPathN) //TODO: check why it is public, take the method into this class
            : base(trackPath.FullName.TrimEnd('\\'), trackPath.LastWriteTime)
        {
            SetDirs(trackPath.FullName, lyricsPathN.FullName, graphicsPathN.FullName);
        }

        public static AxRoot CreateRoot(DirectoryInfo trackPath, DirectoryInfo lyricsPathN, DirectoryInfo graphicsPathN)
        {
            AxRoot root = new AxRoot(trackPath, lyricsPathN, graphicsPathN); //It has to be the full path for the root node
            root.PopulateDir(trackPath);
            return root;
        }

        public override string PathFor(AxRoot.PathType aType)
        {
            switch (aType)
            {
                case PathType.Tracks: return fTrackPath;
                case PathType.Lyrics:
                    if (!String.IsNullOrEmpty(fLyricsPathN))
                        return fLyricsPathN;
                    else
                        throw new NbException("Lyrics path was not provided");
                case PathType.Graphics:
                    if (!String.IsNullOrEmpty(fGraphicsPathN))
                        return fGraphicsPathN;
                    else
                        throw new NbException("Graphics path was not provided");
                default:
                    throw new NbException("Unsupported AxRoot.PathType: ", aType.ToString());
            }
        }
    }


    [XmlType("dir")]
    public class AxDirectory : AxElement
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxDirectory()
        { }

        public AxDirectory(DirectoryInfo aDirInfo)
            : base(aDirInfo.Name, aDirInfo.LastWriteTime)
        { }

        protected AxDirectory(string aName, DateTime aChangeDate) //TODO: check why it is public, take the method into this class
            : base(aName, aChangeDate)
        { }

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }

        [XmlArrayItem(Type = typeof(AxRoot)),
        XmlArrayItem(Type = typeof(AxDirectory)),
        XmlArrayItem(Type = typeof(AxAlbum)),
        XmlArrayItem(Type = typeof(AxDisk))]
        public List<AxDirectory> dirs = new List<AxDirectory>();

        [XmlArrayItem(Type = typeof(AxFile)),
        XmlArrayItem(Type = typeof(AxFileAudio)),
        XmlArrayItem(Type = typeof(AxFileAudioMp3)),
        XmlArrayItem(Type = typeof(AxFilePicture)),
        XmlArrayItem(Type = typeof(AxFileText))
        ]
        public List<AxFile> files = new List<AxFile>();

        public AxElement FindElement(string aPath)
        {
            if (!aPath.StartsWith(Filename))
                return null;

            string subPath = aPath.Substring(Filename.Length);
            if (subPath.Length == 0)
                return this;
            else if (!subPath.StartsWith("\\"))
                throw new NbException("Malformed subpath '{0}' in {1}", subPath, aPath);
            else
                subPath = subPath.Substring(1); //Removing the \

            foreach (AxDirectory dir in dirs)
            {
                AxElement el = dir.FindElement(subPath);
                if (el != null)
                    return el;
            }

            foreach (AxFile file in files)
            {
                if (file.Filename == subPath)
                    return file;
            }
            return null;
        }


        private AxDirectory FindDir(string aDirName)
        {
            return dirs.Find(delegate(AxDirectory dir) { return dir.Filename.Equals(aDirName); });
        }

        private AxFile FindFile(string aFileName)
        {
            return files.Find(delegate(AxFile dir) { return dir.Filename.Equals(aFileName); });
        }

        public void Resolve()
        {
            foreach (AxDirectory dir in dirs)
            {
                dir.Parent = this;
                dir.Resolve();
            }
            foreach (AxFile file in files)
            {
                file.Parent = this;
            }
        }

        //Generic directory - call integrity check recursively
        public override void CheckIntegrity(IErrorLogger aLogger)
        {
            foreach (AxDirectory dir in dirs)
            {
                dir.CheckIntegrity(aLogger);
            }

            bool audioFilesFound = false;
            foreach (AxFile fl in files)
            {
                if (fl is AxFileAudio)
                    audioFilesFound = true;
                fl.CheckIntegrity(aLogger);
            }

            if (audioFilesFound)
                aLogger.Log(this, "Audio files found, but directory is not recognized as Album");
        }

        public override void CheckLyrics(IErrorLogger aLogger)
        {
            if (LyricsDir.Exists)
            {
                var lyrDirs = LyricsDir.GetDirectories().Select(di => di.Name);
                foreach (string orphanLyrics in lyrDirs.Except(dirs.Select(di => di.Filename)))
                    aLogger.Log(this, "Orphan Lyrics directory found: '{0}'", LyricsDir.FullName + "\\" + orphanLyrics);

                foreach (AxDirectory dir in dirs)  //Generic directory - call integrity check recursively
                    dir.CheckLyrics(aLogger);
            }
            else
                aLogger.Log(this, "Lyrics directory doesn't exist: '{0}'", LyricsDir.FullName);
        }

        private DirectoryInfo LyricsDir
        {
            get
            {
                if (fLyricsDir == null)
                    fLyricsDir = new DirectoryInfo(PathFor(AxRoot.PathType.Lyrics));
                return fLyricsDir;

            }
        } private DirectoryInfo fLyricsDir;

        public override string ToString()
        {
            return Filename;
        }

        public static AxDirectory Recognizer(DirectoryInfo dInfo)
        {
            AxAlbum alb = AxAlbum.RecognizerN(dInfo);
            if (alb != null)
                return alb;

            AxDirectory newDir = new AxDirectory(dInfo);
            newDir.PopulateDir(dInfo);
            return newDir;
        }

        protected void PopulateDir(DirectoryInfo dInfo)
        {
            foreach (DirectoryInfo di in dInfo.GetDirectories())
            {
                AxDirectory dr = AxDirectory.Recognizer(di);
                if (dr != null)
                {
                    dr.Parent = this;
                    dirs.Add(dr);
                }
            }

            foreach (FileInfo fInfo in dInfo.GetFiles())
            {
                AxFile fl = AxFile.RecognizerN(fInfo);
                if (fl != null)
                {
                    fl.Parent = this;
                    files.Add(fl);
                }
            }
        }

        public override void Update(List<ElementChange> aChanges)
        {
            UpdateDirs(aChanges);
            UpdateFiles(aChanges);
        }

        private void UpdateDirs(List<ElementChange> aChanges)
        {
            List<AxDirectory> removedDirs = new List<AxDirectory>(dirs.Count);
            removedDirs.AddRange(dirs);

            DirectoryInfo rootDirInfo = new DirectoryInfo(PathName);

            //This cycle checks for new directories
            foreach (DirectoryInfo dInfo in rootDirInfo.GetDirectories())
            {
                AxDirectory dr = FindDir(dInfo.Name);
                if (dr == null) //If existing dir can't be found
                {
                    dr = AxDirectory.Recognizer(dInfo); //Create a new one (recurve)
                    if (dr != null)
                    {
                        dr.Parent = this;
                        dirs.Add(dr);
                        aChanges.Add(new ElementChange(ElementChange.Types.Added, dr));
                    }
                }
                else //Existing directory is found
                {
                    removedDirs.Remove(dr);
                    dr.Update(aChanges);    //Do the Update recursively
                }
            }
            foreach (AxDirectory dr in removedDirs)
            {
                aChanges.Add(new ElementChange(ElementChange.Types.Removed, dr));
                dirs.Remove(dr);
            }
        }

        private void UpdateFiles(List<ElementChange> aChanges)
        {
            List<AxFile> removedFiles = new List<AxFile>(files.Count);
            removedFiles.AddRange(files);

            DirectoryInfo rootDirInfo = new DirectoryInfo(PathName);

            foreach (FileInfo fInfo in rootDirInfo.GetFiles())
            {
                AxFile fl = FindFile(fInfo.Name);
                if (fl == null) //If existing file can't be found
                {
                    fl = AxFile.RecognizerN(fInfo); //Create new file
                    if (fl != null)
                    {
                        fl.Parent = this;
                        files.Add(fl);
                        aChanges.Add(new ElementChange(ElementChange.Types.Added, fl));
                    }
                }
                else //Existing file is found
                {
                    removedFiles.Remove(fl);
                    fl.Update(aChanges);    //Do the Update on files as well
                }
            }

            foreach (AxFile fl in removedFiles)
            {
                aChanges.Add(new ElementChange(ElementChange.Types.Removed, fl));
                files.Remove(fl);
            }
        }

        public void FillStatictics(AxTreeStatistics aStat)
        {
            foreach (AxDirectory dir in dirs)
            {
                aStat.Directories++;
                dir.FillStatictics(aStat);
            }
            aStat.Files += files.Count;
        }

        public void BuildListOfElements<T>(IList<T> aList)
            where T : class
        {
            foreach (AxDirectory aSubNode in dirs)
            {
                aSubNode.BuildListOfElements(aList);
                if (aSubNode is T)
                    aList.Add(aSubNode as T);
            }

            foreach (AxFile file in files)
            {
                if (file is T)
                    aList.Add(file as T);
            }
        }
    }
}
