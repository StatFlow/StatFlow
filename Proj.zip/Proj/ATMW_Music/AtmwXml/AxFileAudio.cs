using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.ComponentModel;

namespace Atmw.Xml
{
    [XmlType("aud")]
    public class AxFileAudio : AxFile
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxFileAudio()
        { }

        protected AxFileAudio(FileInfo aFi)
            :base(aFi)
        { }

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }

        public override string Name
        {
            get
            {
                if (String.IsNullOrEmpty(fName))
                {
                    Match mtch = fFilenameRegex.Match(this.Filename);
                    if (mtch.Success)
                        fName = mtch.Groups[4].Value;
                    else
                        fName = Filename.Substring(0, Filename.LastIndexOf('.'));
                }
                return fName;
            }
        } private string fName;


        [CategoryAttribute("Main")]
        public int TrackNo
        {
            get
            {
                string trackStr = null;
                Match mtch = fJustDigitsRegex.Match(this.Filename);
                if (mtch.Success)
                    trackStr = mtch.Groups[1].Value;

                int val = -1;
                Int32.TryParse(trackStr, out val);
                return val;
            }
        }

        [CategoryAttribute("Main")]
        public bool BonusTrack
        {
            get
            {
                Match mtch = fFilenameRegex.Match(this.Filename);
                if (!mtch.Success)
                    return false;

                string postFix = mtch.Groups[2].Value;
                return !String.IsNullOrEmpty(postFix);
            }
        }

        public override string IconName
        {
            get
            {
                return BonusTrack ? "AxFileAudio_bonus" : null;
            }
        }

        public virtual string CheckFilename(IErrorLogger aLogger)
        {
            Match mtch = fFilenameRegex.Match(this.Filename);
            if (!mtch.Success)
            {
                string error = String.Format("File '{0}' has wrong name format", Filename);
                aLogger.Log(this, "File '{0}' has wrong name format", Filename);
            }
            return null;
        }

        public override void CheckIntegrity(IErrorLogger aLogger)
        {
        }

        public static new AxFileAudio RecognizerN(FileInfo fInfo)
        {
            AxFileAudioMp3 audioMp3 = AxFileAudioMp3.RecognizerN(fInfo);
            if (audioMp3 != null)
                return audioMp3;
            else if (!IsAudioFileExtension(fInfo))
                return null;

            return new AxFileAudio(fInfo);
        }




#region Static part
        
        static AxFileAudio()
        {
            StringBuilder regex = new StringBuilder(@"^(\d+)(_*)(\s-|.) (.+)\.(?:"); //(\d+|\w\d) for a2 numbering

            /*
             * ^(\d+) - ����� � ������
             * (_*) - ���� ����� � ������ 10a
             * (\s-|.)    - ��� 10. Name  ��� 10 - Name
             * 
             * (.+) - ���� ��� �����
             * \.\S+$ - ���������� � ������ � ����������� ������������� ��������� � ����� �����
             */

            bool firstLine = true;
            foreach (string ext in AudioFileExtensions)
            {
                if (!firstLine)
                    regex.Append('|');

                regex.Append(ext.Substring(1)); //without dot
                firstLine = false;
            }

            regex.Append(")$");
            fFilenameRegex = new Regex(regex.ToString(), RegexOptions.IgnoreCase);
            fJustDigitsRegex = new Regex(@"^(\d+)", RegexOptions.IgnoreCase);
        }
        protected static Regex fFilenameRegex;
        private static Regex fJustDigitsRegex;

        public static string[] AudioFileExtensions = new string[] { ".mp3", ".wav", ".ogg", ".flac", ".ape", ".m4a", ".wma" };
        private static bool IsAudioFileExtension(FileInfo aFi)
        {
            string ext = aFi.Extension.ToLower();
            return Array.Exists<string>(AudioFileExtensions, delegate(string aStr) { return aStr.Equals(ext, StringComparison.OrdinalIgnoreCase); });
        }
#endregion
    }
}
