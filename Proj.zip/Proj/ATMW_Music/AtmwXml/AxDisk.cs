using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Atmw.Xml
{
    [XmlType("dsk")]
    public class AxDisk : AxDirectory //TODO: Derive AxAlbum from Disk?
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxDisk()
        {}

        private AxDisk(DirectoryInfo aDirInfo)
            :base(aDirInfo)
        {}

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }

        public override string Name
        {
            get { return Filename; }
        }

        public static AxDisk RecognizerN(DirectoryInfo dInfo)
        {
            if (!dInfo.Name.StartsWith("CD")) //Disk directory should start wiht CD
                return null;
            if (dInfo.GetDirectories().Length > 0)
                return null; //Disk can't have sub-directories

            AxDisk dsk = new AxDisk(dInfo);
            foreach (FileInfo fInfo in dInfo.GetFiles()) //TODO: restrict disk not to have files other than Audio
            {
                AxFile fl = AxFile.RecognizerN(fInfo);
                if (fl != null)
                {
                    fl.Parent = dsk;
                    dsk.files.Add(fl);
                }
            }
            return dsk;
        }

        public override void CheckIntegrity(IErrorLogger aLogger)
        {
            if (files == null || files.Count == 0)
                aLogger.Log(this, "Disk contains no files");
            if (dirs != null && dirs.Count > 0)
                aLogger.Log(this, "Disk other directories");

            //TODO: check for song numbers (combine with Album)
        }
    }

}
