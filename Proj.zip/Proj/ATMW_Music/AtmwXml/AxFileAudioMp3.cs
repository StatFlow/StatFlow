using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.ComponentModel;
using HundredMilesSoftware.UltraID3Lib;
using Nb.Library;
using System.Text.RegularExpressions;

using Nb.Library.Clr;
using AtmwSettings; //for extensions
using NbTools;

namespace Atmw.Xml
{
    [XmlType("mp3")]
    public class AxFileAudioMp3 : AxFileAudio
    {
        #region Properties Section
        [XmlAttribute("id3tag_date"),
        Category("ID3"),
        ReadOnly(true)]
        public DateTime Id3TagDate  //The last time Id3 Tag was read
        {
            get { return fId3TagDate; }
            set { fId3TagDate = DropSecondFractionsUtc(value); }
        } private DateTime fId3TagDate;


        [XmlAttribute("id3_album"),
        DefaultValue(""),
        Category("ID3"),
        ReadOnly(true)]
        public string iAlbum
        {
            get { return fAlbum; }
            set { fAlbum = value; }
        } private string fAlbum;

        [XmlAttribute("iArtist"),
        DefaultValue(""),
        Category("ID3"),
        ReadOnly(true)]
        public string iArtist
        {
            get { return fArtist; }
            set { fArtist = value; }
        } private string fArtist;

        [XmlAttribute("iTitle"),
        DefaultValue(""),
        Category("ID3"),
        ReadOnly(true)]
        public string iTitle
        {
            get { return fTitle; }
            set { fTitle = value; }
        } private string fTitle;

        [XmlAttribute("iComments"),
        DefaultValue(""),
        Category("ID3"),
        ReadOnly(true)]
        public string iComments
        {
            get { return fComments; }
            set { fComments = value; }
        } private string fComments;

        [XmlAttribute("iYear"),
        DefaultValue(0),
        Category("ID3"),
        ReadOnly(true)]
        public int iYear
        {
            get { return fYear; }
            set { fYear = value; }
        } private int fYear;

        [XmlAttribute("iTrackNum"),
        DefaultValue(0),
        Category("ID3"),
        ReadOnly(true)]
        public int iTrackNum
        {
            get { return fTrackNum; }
            set { fTrackNum = value; }
        } private int fTrackNum;


        [XmlAttribute("iTrackCount"),
        DefaultValue(0),
        Category("ID3"),
        ReadOnly(true)]
        public int iTrackCount
        {
            get { return fTrackCount; }
            set { fTrackCount = value; }
        } private int fTrackCount;

        #endregion

        private static char[] fId3TrimChars;

        static AxFileAudioMp3() //Static constructor
        {
            fId3TrimChars = new char[] { ' ', '\x0' };
        }


        //[Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxFileAudioMp3()
        { }

        private AxFileAudioMp3(FileInfo aFi)
            : base(aFi)
        {
            fId3TagDate = DateTime.MinValue;
        }

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }

        public override void Update(List<ElementChange> aChanges)
        {
            base.Update(aChanges);

            if (Id3TagDate == DateTime.MinValue) //The ID3 was never read
                UpdateFileChanged(null);
        }


        public override void UpdateFileChanged(IErrorLogger aLogger)
        {
            //DO check if ID3 Tag must be re-read
            try
            {
                UltraID3 id3 = new UltraID3();
                id3.Read(this.PathName);

                ID3v2Tag v2 = id3.ID3v2Tag;
                if (v2.ExistsInFile)
                {
                    iAlbum = v2.Album;
                    iArtist = v2.Artist;
                    iTitle = v2.Title;
                    iComments = v2.Comments;

                    iYear = v2.Year ?? 0;
                    iTrackNum = v2.TrackNum ?? 0;
                    iTrackCount = v2.TrackCount ?? 0;
                }
                else
                {
                    if (aLogger != null)
                        aLogger.Log(this, "File '{0}' doesn't have ID3v2 tag", Filename);

                    //Strings
                    iAlbum = StrFromId3(id3.Album);
                    iArtist = StrFromId3(id3.Artist);
                    iTitle = StrFromId3(id3.Title);
                    iComments = StrFromId3(id3.Comments);
                    //Numbers
                    iYear = id3.Year.HasValue ? (int)id3.Year.Value : 0;
                    iTrackNum = id3.TrackNum.HasValue ? (int)id3.TrackNum.Value : 0;
                    iTrackCount = id3.TrackCount.HasValue ? (int)id3.TrackCount.Value : 0;

                    Id3TagDate = DropSecondFractionsUtc(DateTime.Now);
                }
            }
            catch (Exception ex)
            {
                NbException nbex = new NbException(ex, "Error reading Id3 tag for the file {0}", this.PathName);
                if (!NbMessageBox.YesNo(nbex, "Do you want to continue?"))
                    throw new NbExceptionUserCancelled();
            }
        }

        public override string CheckFilename(IErrorLogger aLogger)
        {
            Match mtch = fFilenameRegex.Match(this.Filename);
            if (!mtch.Success)
            {
                string error = String.Format("File '{0}' has wrong name format", Filename);
                aLogger.Log("Rename by ID3 tag", elem => { (elem as AxFileAudioMp3).RenameFileByID3(aLogger); return false; },
                    this, "File '{0}' has wrong name format", Filename);
            }
            return null;
        }


        public bool RenameFileByID3(IErrorLogger aLogger)
        {
            UltraID3 id3 = new UltraID3();
            id3.Read(this.PathName);

            ID3v2Tag v2 = id3.ID3v2Tag;
            if (v2.ExistsInFile && v2.TrackNum.HasValue)
            {
                string filename = String.Format("{0:D2} - {1}.mp3", v2.TrackNum.Value, v2.Title).LegalizeForFilename();
                FileInfo fl = new FileInfo(this.Filename);
                string newPathName = new FileInfo(this.PathName).DirectoryName + "\\" + filename;
                File.Move(this.PathName, newPathName);
                this.Filename = filename;
                return true;
            }

            return false; //Close remove the log line
        }

        public bool CreateId3ByFile(IErrorLogger aLogger)
        {
            Match mtch = fFilenameRegex.Match(this.Filename);
            if (!mtch.Success)
                return false; //Can't update by filename, because it is a wrong format

            AxAlbum alb;
            if (!ParentOfType(out alb))
                return false; //Can't find album parent for the track

            UltraID3 id3 = new UltraID3();
            id3.Read(this.PathName);

            ID3v2Tag v2 = id3.ID3v2Tag;
            v2.TrackNum = Int16.Parse(mtch.Groups[1].Value);
            v2.Title = mtch.Groups[4].Value.ToString();
            v2.Album = alb.Name;
            v2.Year = alb.Year;

            id3.Write();
            return true; //Close remove the log line
        }

        private bool UpdateId3TrackNo(AxElement aElement)
        {
            iTrackNum = TrackNo;
            WriteId3();
            return true;
        }

        public void WriteId3()
        {
            //DO check if ID3 Tag must be re-read
            try
            {
                UltraID3 id3 = new UltraID3();
                id3.Read(this.PathName);
                ID3v2Tag tag = id3.ID3v2Tag;

                tag.Album = Legalize(iAlbum, 30);
                tag.Artist = Legalize(iArtist, 30);
                tag.Title = Legalize(iTitle, 30);
                tag.Comments = (iComments == null) ? "" : Legalize(iComments, 28);
                tag.Year = iYear == 0 ? null : (short?)iYear;
                tag.TrackNum = iTrackNum == 0 ? null : (short?)iTrackNum;
                //id3.TrackCount is readonly
                id3.Write();
                Id3TagDate = DropSecondFractionsUtc(DateTime.Now);
            }
            catch (Exception ex)
            {
                throw new NbException(ex, "UltraID3 exception during UpdateFileChanged: {0}", this.PathName);
            }
        }


        private static string StrFromId3(string aStr)
        {
            return aStr.Trim(fId3TrimChars);
        }


        public override void CheckIntegrity(IErrorLogger aLogger)
        {
            var sett = config.Instance.checker.id3_tags;
            if (sett.perform)
                CheckId3Tags(aLogger, sett);

            sett = config.Instance.checker.lyrics;
            string dir = config.Instance.directories.lyrics;
            if (sett.perform && !String.IsNullOrEmpty(dir))
                CheckLyrics(aLogger, sett, dir);
        }

        private void CheckLyrics(IErrorLogger aLogger, CheckWithExceptions sett, string aLyricsDir)
        {

        }


        private void CheckId3Tags(IErrorLogger aLogger, CheckWithExceptions sett)
        {
            if (Id3TagDate == DateTime.MinValue)
            {
                UpdateFileChanged(aLogger); //Re-read ID3 Tag
                //aLogger.Log(this, "Id3 tag was not read");
                //return;
            }

            //bool CreateId3ByFilename = false;

            if (iTrackNum == 0)
                aLogger.Log("Update ID3 TrackNo", UpdateId3TrackNo, this, "Id3 track No is not set");
            else if (iTrackNum != TrackNo)
                aLogger.Log("Update ID3 TrackNo", UpdateId3TrackNo, this, "Id3 '{0}' and filename '{1}' track numbers are not in sync", iTrackNum, TrackNo);

            if (String.IsNullOrEmpty(iTitle))
                aLogger.Log(this, "Id3 Song name is not set");
            else
            {
                if (iTitle.Length == 0)
                    aLogger.Log(this, "Id3 song title is empty");
                else if (iTitle[0] == ' ')
                    aLogger.Log(this, "Id3 song starts with space: '{0}'", iTitle);


                if (!iTitle.LegalizeForFilename().Equals(Name))
                    aLogger.Log("Rename by ID3 tag", elem => { (elem as AxFileAudioMp3).RenameFileByID3(aLogger); return false; },
                        this, "Id3 title '{0}' and filename title '{1}' do not match", iTitle.LegalizeForFilename(), Name);
                //CreateId3ByFilename = true;
            }

            AxAlbum alb;
            if (!ParentOfType(out alb))
                aLogger.Log(this, "Song is not within an album");
            else
            {
                if (String.IsNullOrEmpty(iAlbum))
                    aLogger.Log(this, "Id3 Album name is not set");
                else
                {
                    if (iAlbum[0] == ' ') aLogger.Log(this, "Id3 Album name starts with space: '{0}'", iAlbum);

                    if (iAlbum != alb.Name) aLogger.Log(this, "Id3 Album '{0}' and parent folder '{1}' do not match", iAlbum, alb.Name);
                    //CreateId3ByFilename = true;
                }
            }

            /*AxArtist art;
            if (!ParentOfType(out art))
                aLogger.Log(this, "Song is not within a performer folder");
            else
            {
                if (String.IsNullOrEmpty(iArtist))
                    aLogger.Log(this, "Id3 Artist name is not set");
                else if (iArtist != art.Name)
             * {
                    aLogger.Log(this, "Id3 Artist '{0}' and folder artist '{1}' do not match", iArtist, art.Name);
             * CreateId3ByFilename = true;
             */


            //if (CreateId3ByFilename)
            //    aLogger.Log("Create ID3 by filename", elem => { (elem as AxFileAudioMp3).CreateId3ByFile(aLogger); return false; },
            //        this, "Id3 title '{0}' and filename title '{1}' do not match", iTitle.LegalizeForFilename(), Name);
        }


        private string Legalize(string aStr, int length)
        {
            if (aStr.Length > length)
            {
                if (length < 3)
                    throw new NbException("Can't legalize to a string with length of {0}", length);

                aStr = String.Format("{0}...", aStr.Substring(0, length - 3));
            }

            return aStr;
        }


        public new static AxFileAudioMp3 RecognizerN(FileInfo aFi)
        {
            if (aFi.Extension.ToLower() == ".mp3")
                return new AxFileAudioMp3(aFi);
            else
                return null;
        }

    }
}
