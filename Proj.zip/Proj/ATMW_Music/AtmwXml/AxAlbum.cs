using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Serialization;
using System.IO;
using System.Drawing;
using System.Linq;

using Nb.Library.Clr;
using System.Diagnostics;
using AtmwSettings;

namespace Atmw.Xml
{
    [XmlType("alb")]
    public class AxAlbum : AxDirectory
    {
        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxAlbum()
        { }

        private AxAlbum(DirectoryInfo aDirInfo)
            : base(aDirInfo)
        { }

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }

        //1. Album starts with the year + an optional letter like 1988 1990a 1990b
        //2. Optional dash is allowed:  1980a - Hot Space
        //3. Album should start with letter or digit
        static Regex NameFormat = new Regex(@"^(\d{4})[a-z]?[\d\.]{0,6} (- )?(.+)$");

        public override string Name
        {
            get
            {
                if (String.IsNullOrEmpty(fName))
                {
                    Match nameCheck = AxAlbum.NameFormat.Match(Filename);
                    if (nameCheck.Success)
                        fName = nameCheck.Groups[3].Value;
                    else
                        fName = Filename;
                }
                return fName;
            }
        } private string fName;

        public short Year
        {
            get
            {
                if (fYear == 0)
                {
                    Match nameCheck = AxAlbum.NameFormat.Match(Filename);
                    if (nameCheck.Success)
                        fYear = Int16.Parse(nameCheck.Groups[1].Value);
                }
                return fYear;
            }
        } private short fYear = 0;

        public string Artist
        {
            get
            {
                AxDirectory artist = null;
                this.ParentOfType<AxDirectory>(out artist);
                return artist.Name;
            }
        }

        public override string ToString()
        {
            return Filename;
        }

        public static AxAlbum RecognizerN(DirectoryInfo dInfo)
        {
            AxAlbum alb = new AxAlbum(dInfo);
            foreach (DirectoryInfo di in dInfo.GetDirectories())
            {
                AxDisk dsk = AxDisk.RecognizerN(di);
                if (dsk != null)
                {
                    dsk.Parent = alb;
                    alb.dirs.Add(dsk); //Album can contain disks
                }
                else
                    return null; //Album can't contain non-disk directories
            }

            foreach (FileInfo fInfo in dInfo.GetFiles())
            {
                AxFile fl = AxFile.RecognizerN(fInfo);
                if (fl != null)
                {
                    fl.Parent = alb;
                    alb.files.Add(fl);
                }
            }
            return alb;
        }


        public override void CheckIntegrity(IErrorLogger aLogger)
        {
            if (dirs != null && dirs.Count > 0)
            {   //Some directories found
                if (files != null && files.Exists(file => file is AxFileAudio))
                    aLogger.Log(this, "Album contains songs and directories, one one type is allowed");

                foreach (AxDirectory dir in dirs)
                {
                    if (!(dir is AxDisk))
                    {
                        aLogger.Log(this, "An album should only contain disks of files, but '{0}' '{1}' was found", dir.GetType().Name, dir.Name);
                    }
                    dir.CheckIntegrity(aLogger);
                }
            }
            else
            {   //No directories found
                if (files == null || files.Count == 0)
                    aLogger.Log(this, "Album contains no files and no disks");
                else
                {
                    SongsCheck(files, aLogger);
                    GraphicsCheck(files, aLogger, this);
                }
            }

            Match nameCheck = AxAlbum.NameFormat.Match(Filename);
            if (!nameCheck.Success)
            {
                aLogger.Log(this, "Malformed name of an album: '{0}'", Filename);
            }

            if (files != null && files.Count > 0)
            {
                foreach (AxFile fl in files)
                {
                    fl.CheckIntegrity(aLogger);
                }
            }
        }

        internal static void GraphicsCheck(List<AxFile> aFiles, IErrorLogger aLogger, AxAlbum aAlbum)
        {
            var sett = config.Instance.checker;
            if (!sett.album_art.perform)
                return;

            string artistName = aAlbum.Artist;
            if (sett.album_art.IsIncluded(artistName, aAlbum.Name))
            {
                var albGraphDir = aAlbum.PathFor(AxRoot.PathType.Graphics);
                var coverFiles = Directory.EnumerateFiles(albGraphDir, "cover.*", SearchOption.TopDirectoryOnly);
                List<string> covers = coverFiles.Where(f =>
                {
                    string extension = f.Substring(f.LastIndexOf('.')).ToLowerInvariant();
                    return AxFilePicture.PictureFileExtensions.Contains(extension);
                }).ToList();

                if (covers.Count > 1)
                {
                    aLogger.Log(aAlbum,
                        String.Format("Album '{0}' has several cover files: {1}", aAlbum.Name, String.Join(", ", covers)),
                        Tuple.Create<string, Action>("Explore to graphics", () => Process.Start("explorer.exe", "/select,\"" + covers[0] + "\"")));
                }
                else if (covers.Count == 1)
                {
                    if (sett.album_art_1000px.IsIncluded(artistName, aAlbum.Name))
                    {
                        using (var img = Image.FromFile(covers[0]))
                        {
                            if (img.Height < 1000 || img.Width < 1000)
                                aLogger.Log(aAlbum,
                                    String.Format("Image '{0}' is less than 1000px is height", covers[0]),
                                    Tuple.Create<string, Action>("Explore to graphics", () => Process.Start("explorer.exe", "/select,\"" + covers[0] + "\"")),
                                    Tuple.Create<string, Action>("Search for graphics", () => aAlbum.SearchForGraphics(albGraphDir)),
                                    Tuple.Create<string, Action>("Forget", () => sett.album_art_1000px.AddExclusion(artistName, aAlbum.Name)));
                        }
                    }
                }
                else
                {
                    var frontFiles = Directory.EnumerateFiles(albGraphDir, "front.*", SearchOption.TopDirectoryOnly);
                    List<string> fronts = frontFiles.Where(f =>
                    {
                        string extension = f.Substring(f.LastIndexOf('.')).ToLowerInvariant();
                        return AxFilePicture.PictureFileExtensions.Contains(extension);
                    }).ToList();
                    if (fronts.Count > 0)
                    {
                        aLogger.Log(aAlbum,
                            String.Format("Album '{0}' doesn't contain Cover.jpg file, but has a front.jpg", aAlbum.Name),
                            Tuple.Create<string, Action>("Rename Front->Cover", () => { new FileInfo(fronts[0]).MoveTo(Path.Combine(albGraphDir, "Cover.jpg")); }));
                    }
                    else
                    {
                        aLogger.Log(aAlbum,
                            String.Format("Album '{0}' doesn't contain Cover.jpg file", aAlbum.Name),
                            Tuple.Create<string, Action>("Explore to graphics", () => Process.Start("explorer.exe", "\"" + albGraphDir + "\"")),
                            Tuple.Create<string, Action>("Search for graphics", () => aAlbum.SearchForGraphics(albGraphDir)),
                            Tuple.Create<string, Action>("Forget", () => sett.album_art.AddExclusion(artistName, aAlbum.Name)));
                    }
                }
            }
        }

        public void SearchForGraphics(string pathToStoreGraphics)
        {
            string pars = String.Format(@"/artist ""{0}"" /album ""{1}"" /path ""{2}"" /autoclose /minSize 1000", this.Parent.Name, this.Name, pathToStoreGraphics + "\\Cover.jpg");
            Process.Start(@"C:\Program Files\AlbumArtDownloader\AlbumArt.exe", pars);
        }

        internal static void SongsCheck(List<AxFile> aFiles, IErrorLogger aLogger)
        {
            var sett = config.Instance.checker.track_num;
            if (sett.perform)
            {
                SortedList<int, AxFile> orderedList = new SortedList<int, AxFile>(aFiles.Count);

                foreach (AxFile fl in aFiles)
                {
                    AxFileAudio audFile = fl as AxFileAudio;
                    if (audFile != null)
                    {
                        int trackNo = audFile.TrackNo;
                        if (trackNo == -1)
                            aLogger.Log(audFile, "Can't read track no from the file name: '{0}'", audFile.Filename);

                        if (orderedList.ContainsKey(trackNo))
                        {
                            aLogger.Log(audFile, "Track '{0}' has the same number as '{1}'.", audFile.Filename, orderedList[trackNo].Filename);
                            continue;
                        }
                        orderedList.Add(trackNo, audFile);
                    }
                }

                for (int i = 0; i < orderedList.Count; i++)
                {
                    if (orderedList.Keys[i] != i + 1)
                    {
                        aLogger.Log(orderedList.Values[i], "Track '{0}' is at the position '{1}', but has number '{2}'", orderedList.Values[i].Filename, i + 1, orderedList.Keys[i]);
                        continue;
                    }
                }
            }
        }

        public override void CheckLyrics(IErrorLogger aLogger)
        {
            var sett = config.Instance.checker.lyrics;
            if (sett.perform)
            {
            }
        }
    }
}
