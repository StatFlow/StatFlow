﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AtmwSettings
{
    using System.Xml.Serialization;
    using System.IO;
    using Nb.Library;
    using System.ComponentModel;
    using Nb.Library.Clr;
    using NbTools;

    public partial class config
    {
        [XmlAttribute(Namespace = "http://www.w3.org/2001/XMLSchema-instance", AttributeName = "schemaLocation")]
        public string Schema = @"AtmwSettings C:\Svn.h\Projects\ATMW_Music\AtmwXml\AtmwSettings.xsd";

        private string fFileName;
        private static XmlSerializer Serializer = new XmlSerializer(typeof(config));

        public static config Instance
        {
            get
            {
                if (fCfg == null)
                {
                    LoadFile(String.Format("{0}{1}", AppDomain.CurrentDomain.BaseDirectory, "AtmwSettings.xml"));
                }
                return fCfg;
            }
        } private static config fCfg;

        public static void Reload()
        {
            LoadFile(config.Instance.fFileName);
        }


        public static config LoadFile(string fileName)
        {
            if (!File.Exists(fileName))
                throw new Exception(String.Format("Can't find '{0}' configuration file", fileName));

            try
            {
                using (StreamReader rdr = new StreamReader(fileName))
                {
                    fCfg = (config)Serializer.Deserialize(rdr);
                    fCfg.Initialize(fileName);
                }
            }
            catch (Exception ex)
            {
                throw new NbException(ex, "Error parsing '{0}' configuration file", fileName);
            }
            return fCfg;
        }



        private void Initialize(string fileName)
        {
            fCfg.fFileName = fileName;
            /*fMediaPlayer = Environment.ExpandEnvironmentVariables(this.media_player_path);
            if (!File.Exists(fMediaPlayer))
                throw new NbException("Can't find media player: '{0}'", fMediaPlayer);

            string mediaRoot = Environment.ExpandEnvironmentVariables(this.media_path);
            if (!Directory.Exists(mediaRoot))
                throw new NbException("Can't find media directory: '{0}'", mediaRoot);
            else
            {
                fMediaFiles = new List<FileInfo>(100);
                AddMediaFilesRecursively(new DirectoryInfo(mediaRoot));
            } */
        }

        public void Save()
        {
            using (StreamWriter wrtr = new StreamWriter(fFileName))
            {
                //Array.Sort(this.tasks, (a, b) => b.weight.CompareTo(a.weight)); //Sort task by wheight before saving, descending order: biggest weight on top
                Serializer.Serialize(wrtr, this);
            }
        }


    }


    public partial class Checker
    {
        [Category("Album Art"),
        Description("Set if you want to check wether the album art exist in every album"),
        DefaultValue(true),
        XmlIgnore]
        public bool AlbumArt
        {
            get { return album_art.perform; }
            set { album_art.perform = value; }
        }

        [Category("Album Art"),
        Description("Set if you want to check wether the album art is bigger than 1000 pixel"),
        DefaultValue(true),
        XmlIgnore]
        public bool AlbumArt1000
        {
            get { return album_art_1000px.perform; }
            set { album_art_1000px.perform = value; }
        }

        [Category("Tracks"),
        Description("Set if you want to check id3 tags"),
        DefaultValue(true),
        XmlIgnore]
        public bool Id3Tags
        {
            get { return id3_tags.perform; }
            set { id3_tags.perform = value; }
        }

        [Category("Tracks"),
        Description("Set if you want to check consistency in track numbers"),
        DefaultValue(true),
        XmlIgnore]
        public bool Numbers
        {
            get { return track_num.perform; }
            set { track_num.perform = value; }
        }

        [Category("Lyrics"),
        Description("Set if you want to check consistency in track numbers"),
        DefaultValue(true),
        XmlIgnore]
        public bool Lyrics
        {
            get { return lyrics.perform; }
            set { lyrics.perform = value; }
        }
    }


    public partial class CheckWithExceptions
    {
        public bool IsIncluded(string aArtist, string aAlbum)
        {
            if (!perform)
                return false;

            if (ex_art == null)
                return true; //No exceptions perform check

            var artEx = ex_art.Where(ex => ex.name.Equals(aArtist, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            if (artEx == null)
                return true; //There's no Exception for this artist - perform check.
            else if (artEx.ex_alb == null)
                return false; //Artist is mentioned, but there are no albums - exclude all albums for the artist

            var albEx = artEx.ex_alb.Where(ex => aAlbum.Equals(ex.name, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            if (albEx == null)
                return true; //The album is not in the list of restricted albums - perform check.
            else
                return false; //The album is in the list of restricted albums - do not perform check.
        }

        public void AddExclusion(string aArtist, string aAlbum)
        {
            ExArt artist = Extensions.ArrayFindOrAppend(ref ex_art, 
                art => aArtist.Equals(art.name, StringComparison.OrdinalIgnoreCase), 
                () => new ExArt { name = aArtist });

            Extensions.ArrayFindOrAppend(ref artist.ex_alb, 
                alb => aArtist.Equals(alb.name, StringComparison.OrdinalIgnoreCase),
                () => new ExAlb { name = aAlbum });
        }
    }
}
