using System;
using System.Text;
using System.Collections.Generic;
using System.Xml.Serialization;
using System.Diagnostics;
using System.ComponentModel;
using Nb.Library;
//TODO: check all the library dependencies


namespace Atmw.Xml
{
    //Commands can't be created on the level of AxElement, because they need full access to the environment,
    //while AtmwXml library should not depend on anything else except for XML framework


    abstract public class AxElement
    {
        #region Properties Section
        [XmlAttribute("name"),
        Category("Main"),
        ReadOnly(true)]
        public string Filename //Directory or file name
        {
            get { return fFilename; }
            set { fFilename = value; } //Can be private, but public for serializing
        } private string fFilename;

        [XmlAttribute("changed"),
        Category("Main"),
        ReadOnly(true)]
        public DateTime Changed //The time stamp of the last change
        {
            get { return fLastChangeDateTime; }
            set { fLastChangeDateTime = DropSecondFractionsUtc(value); } //Can be private, but public for serializing
        } private DateTime fLastChangeDateTime;

        [CategoryAttribute("Main")]
        public virtual string Name //What is displayed on the screen
        { get { return Filename; } }

        public virtual string IconName
        { get { return null; } } //null means use default icon the node class type

        public virtual string PathName
        {
            get
            {
                if (Parent != null)
                    return Parent.PathName + "\\" + Filename;
                else
                    return Filename;
            }
        }


        public virtual string ReversePath
        {
            get
            {
                if (Parent != null)
                    return Filename + "\\" + Parent.ReversePath;
                else
                    return Filename;
            }
        }

        public virtual string PathFor(AxRoot.PathType aType)
        {
            if (Parent != null)
                return Parent.PathFor(aType) + "\\" + Filename;
            else
                return Filename;
        }

        public override string ToString()
        {
            return String.Format("{0}: {1}", GetType().Name, Name);
        }

        [XmlIgnore]
        public AxElement Parent
        {
            get { return fParent; }
            set { fParent = value; }

        } private AxElement fParent;

        public bool ParentOfType<T>(out T aParent)
            where T : AxElement
        {
            AxElement par = Parent;
            if (par == null)
            {
                aParent = null;
                return false;
            }
            else if (Parent.GetType() == typeof(T))
            {
                aParent = (T)par;
                return true;
            }
            else
                return par.ParentOfType(out aParent);
        }

        [XmlIgnore]
        public object Tag;
        #endregion


        [Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxElement()
        { }

        protected AxElement(string aFilename, DateTime aChangedDate)
        {
            Filename = aFilename;
            Changed = aChangedDate;
        }


        public static DateTime DropSecondFractionsUtc(DateTime aDateTime)
        {
            long ticks = aDateTime.ToUniversalTime().Ticks;
            return new DateTime(ticks - ticks % 10000000, DateTimeKind.Utc); //Get rid of seconds fractions
        }

        public abstract void Update(List<ElementChange> aChanges);
        public abstract void CheckIntegrity(IErrorLogger aLogger);
        public virtual void CheckLyrics(IErrorLogger aLogger) { } //Do nothing by default

        public abstract VisitorAction AcceptVisitor(IElementVisitor aVisitor);
    }
}
