using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using System.Text;
using System.Text.RegularExpressions;

namespace Atmw.Xml
{
    [XmlType("pic")]
    public class AxFilePicture : AxFile
    {
        //[Obsolete("Don't use parameterless constructors of xml classes. They are declared public only for XmlSerializer.")]
        public AxFilePicture()
        { }

        protected AxFilePicture(FileInfo aFi)
            : base(aFi)
        { }

        public override VisitorAction AcceptVisitor(IElementVisitor aVisitor)
        {
            return aVisitor.VisitN(this);
        }

        public override string Name
        {
            get
            {
                if (String.IsNullOrEmpty(fName))
                {
                    Match mtch = fFilenameRegex.Match(this.Filename);
                    if (mtch.Success)
                        fName = mtch.Groups[1].Value;
                    else
                        fName = Filename.Substring(0, Filename.LastIndexOf('.'));
                }
                return fName;
            }
        } private string fName;

        internal static new AxFilePicture RecognizerN(FileInfo fInfo)
        {
            if (!IsPictureFileExtension(fInfo))
                return null;

            return new AxFilePicture(fInfo);
        }

        public override string IconName
        {
            get { return "AxFilePicture"; }
        }


        public override void CheckIntegrity(IErrorLogger aLogger)
        {
        }

        #region Static part

        static AxFilePicture()
        {
            StringBuilder regex = new StringBuilder(@"^(.+)\.(?:");
            bool firstLine = true;
            foreach (string ext in PictureFileExtensions)
            {
                if (!firstLine)
                    regex.Append('|');

                regex.Append(ext.Substring(1)); //without dot
                firstLine = false;
            }

            regex.Append(")$");
            fFilenameRegex = new Regex(regex.ToString(), RegexOptions.IgnoreCase);
            fJustDigitsRegex = new Regex(@"^(\d+)", RegexOptions.IgnoreCase);
        }
        private static Regex fFilenameRegex;
        private static Regex fJustDigitsRegex;

        public static string[] PictureFileExtensions = new string[] { ".png", ".jpg" };
        private static bool IsPictureFileExtension(FileInfo aFi)
        {
            string ext = aFi.Extension.ToLower();
            return Array.Exists<string>(PictureFileExtensions, delegate(string aStr) { return aStr == ext; });
        }
        #endregion


    }
}
