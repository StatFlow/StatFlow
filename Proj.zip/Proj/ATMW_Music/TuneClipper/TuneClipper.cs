// Copyright (c) Microsoft Corporation. All rights reserved.

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

// Reference the primary interop assembly.
//using Microsoft.MediaPlayer.Interop;
using AxWMPLib;
using WMPLib; 

// Fix progress bar's start and end times.
namespace TuneClipper
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class frmTuneClipper : System.Windows.Forms.Form
    {
        private System.Windows.Forms.ListBox bxClipList;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnPlay;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TrackBar barCompress;
        private System.Windows.Forms.TrackBar barVolume;
        private System.Windows.Forms.Label lblRate;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.Label lblCurrentSong;
        private System.ComponentModel.IContainer components;
        private System.Windows.Forms.Timer progBarTimer;
        private System.Windows.Forms.Label lblRateNumber;
        private System.Windows.Forms.Button btnClearListbox;
        private System.Windows.Forms.Button btnClearMarkers;
        private System.Windows.Forms.CheckBox bxRepeat;
        private System.Windows.Forms.CheckBox bxSequential;
        private System.Windows.Forms.Label lblCurrentItems;
        private System.Windows.Forms.Label lblNowPlaying;
        private System.Windows.Forms.Button btnAddFile;
        private System.Windows.Forms.TrackBar songTrackBar;
        private System.Windows.Forms.Label lblSeek;
        private System.Windows.Forms.ProgressBar songProgBar;
        private AxWindowsMediaPlayer Player;

        // The following definitions are used to make the code more readable.
        const bool START = true;
        const bool END = false;
        const int  UP = -1;
        const int  DOWN = 1;
        
        // Class containing info on each mediaclip in the array.
        public class Clip
        {
            public string mediaName;
            public string mediaURL;
            public string startString;
            public int    startSeconds;
            public string endString;
            public int    endSeconds;
        }

        // Create dynamic array to contain Clip objects.
        ArrayList clipArray = new ArrayList();

        // Create a new Playlist object and initialize it to null.
        WMPLib.IWMPPlaylist Playlist = null; 

        // The currentClip variable is used as an indexing variable for clipArray.
        // The currentClip variable is initialized to 0.
        int currentClip = 0;

        // The following variables hold play modes and program states.
        bool repeat = false;
        bool sequential = false;
        bool ended = false;

        
        public frmTuneClipper()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            // Create a new playlist named "media" and assign it to the
            // IWMPPlaylist object you created.
            Playlist = Player.newPlaylist("media", "");
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if (components != null) 
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTuneClipper));
            this.bxClipList = new System.Windows.Forms.ListBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnEnd = new System.Windows.Forms.Button();
            this.btnPlay = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClearListbox = new System.Windows.Forms.Button();
            this.barVolume = new System.Windows.Forms.TrackBar();
            this.barCompress = new System.Windows.Forms.TrackBar();
            this.lblRate = new System.Windows.Forms.Label();
            this.lblVolume = new System.Windows.Forms.Label();
            this.btnClearMarkers = new System.Windows.Forms.Button();
            this.lblCurrentSong = new System.Windows.Forms.Label();
            this.progBarTimer = new System.Windows.Forms.Timer(this.components);
            this.lblRateNumber = new System.Windows.Forms.Label();
            this.bxRepeat = new System.Windows.Forms.CheckBox();
            this.bxSequential = new System.Windows.Forms.CheckBox();
            this.btnAddFile = new System.Windows.Forms.Button();
            this.lblCurrentItems = new System.Windows.Forms.Label();
            this.lblNowPlaying = new System.Windows.Forms.Label();
            this.songTrackBar = new System.Windows.Forms.TrackBar();
            this.lblSeek = new System.Windows.Forms.Label();
            this.Player = new AxWindowsMediaPlayer();
            this.songProgBar = new System.Windows.Forms.ProgressBar();
            ((System.ComponentModel.ISupportInitialize)(this.barVolume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barCompress)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.songTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).BeginInit();
            this.SuspendLayout();
            // 
            // bxClipList
            // 
            this.bxClipList.ColumnWidth = 45;
            this.bxClipList.Location = new System.Drawing.Point(32, 224);
            this.bxClipList.Name = "bxClipList";
            this.bxClipList.Size = new System.Drawing.Size(320, 199);
            this.bxClipList.TabIndex = 8;
            this.bxClipList.DoubleClick += new System.EventHandler(this.bxClipList_DoubleClick);
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(32, 456);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(80, 32);
            this.btnStart.TabIndex = 14;
            this.btnStart.Text = "Mark Start";
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnEnd
            // 
            this.btnEnd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.btnEnd.Location = new System.Drawing.Point(144, 456);
            this.btnEnd.Name = "btnEnd";
            this.btnEnd.Size = new System.Drawing.Size(88, 32);
            this.btnEnd.TabIndex = 15;
            this.btnEnd.Text = "Mark End";
            this.btnEnd.Click += new System.EventHandler(this.btnEnd_Click);
            // 
            // btnPlay
            // 
            this.btnPlay.Location = new System.Drawing.Point(32, 72);
            this.btnPlay.Name = "btnPlay";
            this.btnPlay.Size = new System.Drawing.Size(56, 23);
            this.btnPlay.TabIndex = 1;
            this.btnPlay.Text = "Play";
            this.btnPlay.Click += new System.EventHandler(this.btnPlay_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(112, 72);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(56, 23);
            this.btnStop.TabIndex = 2;
            this.btnStop.Text = "Stop";
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "All Windows Media files | *.wma;*.asf;*.wmv;";
            this.openFileDialog1.InitialDirectory = "c:\\";
            this.openFileDialog1.Multiselect = true;
            // 
            // btnUp
            // 
            this.btnUp.Location = new System.Drawing.Point(376, 280);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(56, 23);
            this.btnUp.TabIndex = 10;
            this.btnUp.Text = "Up";
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(376, 320);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(56, 23);
            this.btnDown.TabIndex = 11;
            this.btnDown.Text = "Down";
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(376, 360);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(56, 23);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Text = "Delete";
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnClearListbox
            // 
            this.btnClearListbox.Location = new System.Drawing.Point(376, 400);
            this.btnClearListbox.Name = "btnClearListbox";
            this.btnClearListbox.Size = new System.Drawing.Size(56, 23);
            this.btnClearListbox.TabIndex = 13;
            this.btnClearListbox.Text = "Clear";
            this.btnClearListbox.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // barVolume
            // 
            this.barVolume.Location = new System.Drawing.Point(312, 136);
            this.barVolume.Maximum = 100;
            this.barVolume.Name = "barVolume";
            this.barVolume.Size = new System.Drawing.Size(120, 42);
            this.barVolume.TabIndex = 7;
            this.barVolume.TickStyle = System.Windows.Forms.TickStyle.None;
            this.barVolume.Value = 25;
            this.barVolume.Scroll += new System.EventHandler(this.barVolume_Scroll);
            // 
            // barCompress
            // 
            this.barCompress.Location = new System.Drawing.Point(56, 136);
            this.barCompress.Maximum = 20;
            this.barCompress.Minimum = 5;
            this.barCompress.Name = "barCompress";
            this.barCompress.Size = new System.Drawing.Size(168, 42);
            this.barCompress.TabIndex = 6;
            this.barCompress.Value = 10;
            this.barCompress.Scroll += new System.EventHandler(this.barCompress_Scroll);
            // 
            // lblRate
            // 
            this.lblRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.lblRate.Location = new System.Drawing.Point(16, 136);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(40, 23);
            this.lblRate.TabIndex = 15;
            this.lblRate.Text = "Rate";
            // 
            // lblVolume
            // 
            this.lblVolume.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.lblVolume.Location = new System.Drawing.Point(256, 136);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(56, 23);
            this.lblVolume.TabIndex = 16;
            this.lblVolume.Text = "Volume";
            // 
            // btnClearMarkers
            // 
            this.btnClearMarkers.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.btnClearMarkers.Location = new System.Drawing.Point(256, 456);
            this.btnClearMarkers.Name = "btnClearMarkers";
            this.btnClearMarkers.Size = new System.Drawing.Size(96, 32);
            this.btnClearMarkers.TabIndex = 16;
            this.btnClearMarkers.Text = "Clear Marks";
            this.btnClearMarkers.Click += new System.EventHandler(this.btnClearMarkers_Click);
            // 
            // lblCurrentSong
            // 
            this.lblCurrentSong.BackColor = System.Drawing.Color.Transparent;
            this.lblCurrentSong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.lblCurrentSong.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblCurrentSong.Location = new System.Drawing.Point(32, 40);
            this.lblCurrentSong.Name = "lblCurrentSong";
            this.lblCurrentSong.Size = new System.Drawing.Size(320, 24);
            this.lblCurrentSong.TabIndex = 23;
            // 
            // progBarTimer
            // 
            this.progBarTimer.Interval = 1;
            this.progBarTimer.Tick += new System.EventHandler(this.progBarTimer_Tick);
            // 
            // lblRateNumber
            // 
            this.lblRateNumber.BackColor = System.Drawing.SystemColors.Control;
            this.lblRateNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.lblRateNumber.Location = new System.Drawing.Point(56, 168);
            this.lblRateNumber.Name = "lblRateNumber";
            this.lblRateNumber.Size = new System.Drawing.Size(168, 23);
            this.lblRateNumber.TabIndex = 24;
            this.lblRateNumber.Text = " 0.5             1.0            1.5             2.0";
            // 
            // bxRepeat
            // 
            this.bxRepeat.Location = new System.Drawing.Point(352, 72);
            this.bxRepeat.Name = "bxRepeat";
            this.bxRepeat.TabIndex = 4;
            this.bxRepeat.Text = "Repeat";
            this.bxRepeat.CheckedChanged += new System.EventHandler(this.bxRepeat_CheckedChanged);
            // 
            // bxSequential
            // 
            this.bxSequential.Location = new System.Drawing.Point(352, 96);
            this.bxSequential.Name = "bxSequential";
            this.bxSequential.TabIndex = 5;
            this.bxSequential.Text = "Sequential";
            this.bxSequential.CheckedChanged += new System.EventHandler(this.bxSequential_CheckedChanged);
            // 
            // btnAddFile
            // 
            this.btnAddFile.Location = new System.Drawing.Point(376, 240);
            this.btnAddFile.Name = "btnAddFile";
            this.btnAddFile.Size = new System.Drawing.Size(56, 23);
            this.btnAddFile.TabIndex = 9;
            this.btnAddFile.Text = "Add...";
            this.btnAddFile.Click += new System.EventHandler(this.btnAddFile_Click);
            // 
            // lblCurrentItems
            // 
            this.lblCurrentItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.lblCurrentItems.Location = new System.Drawing.Point(32, 200);
            this.lblCurrentItems.Name = "lblCurrentItems";
            this.lblCurrentItems.Size = new System.Drawing.Size(128, 23);
            this.lblCurrentItems.TabIndex = 29;
            this.lblCurrentItems.Text = "Current Playlist Items:";
            // 
            // lblNowPlaying
            // 
            this.lblNowPlaying.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.lblNowPlaying.Location = new System.Drawing.Point(32, 16);
            this.lblNowPlaying.Name = "lblNowPlaying";
            this.lblNowPlaying.Size = new System.Drawing.Size(80, 24);
            this.lblNowPlaying.TabIndex = 30;
            this.lblNowPlaying.Text = "Now Playing:";
            // 
            // songTrackBar
            // 
            this.songTrackBar.Location = new System.Drawing.Point(216, 72);
            this.songTrackBar.Name = "songTrackBar";
            this.songTrackBar.Size = new System.Drawing.Size(136, 42);
            this.songTrackBar.TabIndex = 3;
            this.songTrackBar.TickFrequency = 5;
            this.songTrackBar.TickStyle = System.Windows.Forms.TickStyle.None;
            this.songTrackBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.songTrackBar_MouseUp);
            this.songTrackBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.songTrackBar_MouseDown);
            this.songTrackBar.Scroll += new System.EventHandler(this.songTrackBar_Scroll);
            // 
            // lblSeek
            // 
            this.lblSeek.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
            this.lblSeek.Location = new System.Drawing.Point(168, 72);
            this.lblSeek.Name = "lblSeek";
            this.lblSeek.Size = new System.Drawing.Size(48, 24);
            this.lblSeek.TabIndex = 32;
            this.lblSeek.Text = "Seek";
            this.lblSeek.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Player
            // 
            this.Player.Enabled = true;
            this.Player.Location = new System.Drawing.Point(384, 24);
            this.Player.Name = "Player";
            this.Player.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("Player.OcxState")));
            this.Player.Size = new System.Drawing.Size(0, 0);
            this.Player.TabIndex = 33;
            this.Player.PlayStateChange += new AxWMPLib._WMPOCXEvents_PlayStateChangeEventHandler(this.Player_PlayStateChange);
            // 
            // songProgBar
            // 
            this.songProgBar.Location = new System.Drawing.Point(32, 424);
            this.songProgBar.Name = "songProgBar";
            this.songProgBar.Size = new System.Drawing.Size(320, 23);
            this.songProgBar.TabIndex = 34;
            // 
            // frmTuneClipper
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(472, 521);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.songProgBar,
                                                                          this.Player,
                                                                          this.lblSeek,
                                                                          this.songTrackBar,
                                                                          this.lblNowPlaying,
                                                                          this.lblCurrentItems,
                                                                          this.btnAddFile,
                                                                          this.bxSequential,
                                                                          this.bxRepeat,
                                                                          this.lblRateNumber,
                                                                          this.lblCurrentSong,
                                                                          this.btnClearMarkers,
                                                                          this.lblVolume,
                                                                          this.lblRate,
                                                                          this.barCompress,
                                                                          this.barVolume,
                                                                          this.btnClearListbox,
                                                                          this.btnDelete,
                                                                          this.btnDown,
                                                                          this.btnUp,
                                                                          this.btnStop,
                                                                          this.btnPlay,
                                                                          this.btnEnd,
                                                                          this.btnStart,
                                                                          this.bxClipList});
            this.Name = "frmTuneClipper";
            this.Text = "Tune Clipper";
            ((System.ComponentModel.ISupportInitialize)(this.barVolume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barCompress)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.songTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() 
        {
            Application.Run(new frmTuneClipper());
        }

        // The following code executes everytime the click event is fired.
        // This provides play/pause functionality when the user clicks 
        // the "Play" button.
        private void btnPlay_Click(object sender, System.EventArgs e)
        {

            if (Player.playState == WMPPlayState.wmppsPlaying)
            {
                pause();
            }
            else
            {
                playClip();
            }
        }

        // When the Click event is fired on the Stop button, the following code
        // checks if the Player is playing, and if so, it stops the player,
        // sets the value for the progress bar to the start of the current clip
        // and updates the UI.
        private void btnStop_Click(object sender, System.EventArgs e)
        {   
            if (Player.playState == WMPPlayState.wmppsPlaying)
            {
                stop();
                songTrackBar.Value = ((Clip)clipArray[currentClip]).startSeconds;
                updateCurrentPositionText();
            }
        }

        // When the Click event is fired on the "Add..." button, the
        // open file dialog box opens and any media items that the user 
        // selects are added into a playlist and clipArray for use by 
        // the application.
        private void btnAddFile_Click(object sender, System.EventArgs e)
        {
            // Open a File dialog window.
            openFileDialog1.ShowDialog(this);
            
            for (int i = 0; i < openFileDialog1.FileNames.Length; i++)
            {
                // Store songs selected through the file dialog window
                // into the "media" playlist.
                Playlist.appendItem(Player.newMedia(
                    openFileDialog1.FileNames.GetValue(i).ToString()));

                // Add a new clip object to clipArray for every new clip created.
                clipArray.Add(new Clip());

                // Create a temporary Clip object to make the code more readable.
                Clip tempClip = (Clip)clipArray[Playlist.count - 1];

                // Assign all the member variables for the current clip object.
                tempClip.mediaName = Playlist.get_Item(Playlist.count - 1).name;
                tempClip.mediaURL = Playlist.get_Item(Playlist.count - 1).sourceURL;
                tempClip.startSeconds = 0;
                tempClip.startString = "00:00";
                tempClip.endString = Playlist.get_Item(Playlist.count - 1).durationString;
                tempClip.endSeconds = (int)(Math.Ceiling(Playlist.get_Item(Playlist.count - 1).duration));

                // Update the listbox.
                updateClip(Playlist.count - 1);
            }
        }

        private void btnStart_Click(object sender, System.EventArgs e)
        {
            markCurrentClip(START);
        }

        private void btnEnd_Click(object sender, System.EventArgs e)
        {
            markCurrentClip(END);
        }

        private void btnUp_Click(object sender, System.EventArgs e)
        {
            moveSelectedClip(UP);
        }

        private void btnDown_Click(object sender, System.EventArgs e)
        {
            moveSelectedClip(DOWN);
        }

        private void btnDelete_Click(object sender, System.EventArgs e)
        {
            deleteSelectedClip();
        }

        private void btnClear_Click(object sender, System.EventArgs e)
        {
            clearClipList();
        }

        // In the following code, the current media stops playing and the selected clip 
        // begins playing when the DoubleClick event is fired.
        private void bxClipList_DoubleClick(object sender, System.EventArgs e)
        {
            stop();
            playClip();
        }

        // When the Click event is fired on the "Clear Markers" button, the following code
        // resets the current clip back to it's default state, and updates the UI.
        private void btnClearMarkers_Click(object sender, System.EventArgs e)
        {
            stop();
            SetDefaultState(((Clip)clipArray[bxClipList.SelectedIndex]));
            updateClip(bxClipList.SelectedIndex);
            updateCurrentPositionText();
            bxClipList.SetSelected(currentClip, true);
        }

        // The following code toggles the sequential functionality on and 
        // off whenever the CheckChanged event is fired in the "Sequential" checkbox.
        private void bxSequential_CheckedChanged(object sender, System.EventArgs e)
        {
            if (bxSequential.Checked)
            {
                sequential = true;
            }
            else
            {
                sequential = false;
            }
        }

        // The following code toggles the repeat functionality on and off 
        // whenever the CheckedChanged event is fired in the "Repeat" checkbox.
        private void bxRepeat_CheckedChanged(object sender, System.EventArgs e)
        {
        
            if (bxRepeat.Checked)
            {
                repeat = true;
            }
            else 
            {
                repeat = false;
            }
        }

        // The Tick event is fired repeatedly during playback. Every time it is 
        // fired, the progress bar is updated, and a check is made whether to play 
        // the next clip, repeat playback, or stop depending on user settings.
        private void progBarTimer_Tick(object sender, System.EventArgs e)
        {
            if (Player.playState == WMPPlayState.wmppsPlaying)
            {
                if (Player.Ctlcontrols.currentPosition <= ((Clip)clipArray[currentClip]).endSeconds)
                {
                    songProgBar.Value = (int)Math.Ceiling(Player.Ctlcontrols.currentPosition);
                    updateCurrentPositionText();
                }
                else
                {
                    songProgBar.Value = songProgBar.Maximum;
                }
            }

            if ((Player.playState == WMPPlayState.wmppsUndefined) || (ended == true) || (Player.Ctlcontrols.currentPosition > ((Clip)clipArray[currentClip]).endSeconds)) 
            {
                if (sequential)
                {
                    startNextClip();
                }
                else if (repeat)
                {
                    startCurrentClip();
                }
                else 
                { 
                    stop();
                }
            }
        }

        private void barCompress_Scroll(object sender, System.EventArgs e)
        {
            Player.settings.rate = (double)this.barCompress.Value/10;
        }

        private void barVolume_Scroll(object sender, System.EventArgs e)
        {
            Player.settings.volume = this.barVolume.Value;
        }

        // When the Scroll event is fired on songTrackBar, the current position 
        // of the current media is set to the value of the track bar. The progress 
        // bar is also synced up the current position of the track bar.
        private void songTrackBar_Scroll(object sender, System.EventArgs e)
        {
            Player.Ctlcontrols.play();
            Player.Ctlcontrols.currentPosition = (double)songTrackBar.Value;
            songProgBar.Value = (int)Math.Ceiling((decimal)songTrackBar.Value);
        }

        // The following code changes the button text to "Play" or "Pause" depending on whether
        // the current media is playing or not and it handles the progress bar where the playState value 
        // is wmpppsStopped.
        private void Player_PlayStateChange(object sender, _WMPOCXEvents_PlayStateChangeEvent e)
        {
            if (Player.playState == WMPPlayState.wmppsMediaEnded)
            {
                ended = true;
            }
            else if (Player.playState == WMPPlayState.wmppsPlaying)
            {
                btnPlay.Text = "Pause";
                songTrackBar.Enabled = true;
            }
        }

        // The play method starts the Player, enables the timer and sets the bounds
        // for the progress bar and songTrackBar.
        private void play()
        {
            ended = false;

            // Create a temporary Clip object to make the code more readable.
            Clip tempClip = (Clip)clipArray[currentClip];

            // Set the Min property to 0 and the Max property to the 
            // maximum value for the control. This is needed so that you can switch 
            // between clips with different start and end times.
            songProgBar.Minimum = 0;
            songProgBar.Maximum = 2147483647;

            // Now set the Min and Max properties to the start and end times for 
            // the current clip.
            songProgBar.Minimum = tempClip.startSeconds;
            songProgBar.Maximum= tempClip.endSeconds;
            songProgBar.Value = tempClip.startSeconds;

            songTrackBar.Minimum = tempClip.startSeconds;
            songTrackBar.Maximum = tempClip.endSeconds;
            songTrackBar.Value = tempClip.startSeconds;

            Player.settings.rate = (double)this.barCompress.Value/10;

            Player.Ctlcontrols.currentPosition = tempClip.startSeconds;
            Player.Ctlcontrols.play();
            progBarTimer.Enabled = true;
        }

        // The pause method pauses the Player.
        private void pause()
        {
            Player.Ctlcontrols.pause();
            btnPlay.Text = "Play";
            progBarTimer.Enabled = false;
        }

        // The stop method stops the Player and disables the timer.
        private void stop()
        {
            progBarTimer.Enabled = false;
            Player.Ctlcontrols.stop();
            btnPlay.Text = "Play";
            songTrackBar.Value = songTrackBar.Minimum;
            songProgBar.Value = songProgBar.Minimum;  
        }

        // The playClip method plays the current media item.
        private void playClip() 
        { 

            if (bxClipList.SelectedIndex != currentClip) 
            {
                currentClip = bxClipList.SelectedIndex;
            }
            
            if (currentClip < 0)
            {
                MessageBox.Show("No media item has been selected.");
            }
            else
            {
                startCurrentClip();
            }
        }

        // The startCurrentClip method sets the URL property for the Player object
        // as well as checking whether the clip is paused before playing the current clip.
        private void startCurrentClip() 
        { 
            // Check whether the player is paused before starting the current clip.
            if (Player.playState == WMPPlayState.wmppsPaused)
            {
                Player.Ctlcontrols.play();
                progBarTimer.Enabled = true;
            }
            else
            {
                Player.URL = ((Clip)clipArray[currentClip]).mediaURL;
                play();
            }
        }

        // The startNextClip method plays the next clip in the list. If the end 
        // of the list has been reached and repeat is set, the first clip in the 
        // list is played.
        private void startNextClip() 
        {
            if (++currentClip == bxClipList.Items.Count) 
            {
                if(!repeat)
                {
                    stop();
                    return;
                }
                currentClip = 0;
            } 
            bxClipList.SetSelected(currentClip, true);
            startCurrentClip(); 
        }

        // The updateCurrentPositionText method updates the display 
        // text with the current position and media name.
        private void updateCurrentPositionText() 
        {
            lblCurrentSong.Text = timeString((int)Math.Ceiling(Player.Ctlcontrols.currentPosition)) + " - " + Player.currentMedia.name;
        }

        // The markCurrentClip method sets the clip start or end position 
        // according to the specified value, with true indicating the start position
        // and false indicating the end position. START and END have been set to 
        // these values to make calling code easier to read.
        private void markCurrentClip(bool startend) 
        {

            // Create a temporary Clip object to make the code more readable.
            Clip tempClip = (Clip)clipArray[currentClip];

            if (startend) 
            {  
                
                // Marking the clip start time.
                tempClip.startString = Player.Ctlcontrols.currentPositionString;
                tempClip.startSeconds = (int)Math.Ceiling(Player.Ctlcontrols.currentPosition);

                // If the start time is empty or later than the current end time, 
                // set the end time to the media duration.
                if ((tempClip.endString == "") || (tempClip.startSeconds > tempClip.endSeconds) ) 
                {
                    tempClip.endString = Player.currentMedia.durationString;
                    tempClip.endSeconds = (int)Player.currentMedia.duration;
                }      

            } 
            else 
            {  
                // Marking the clip end time.
                tempClip.endString = Player.Ctlcontrols.currentPositionString;
                tempClip.endSeconds = (int)Math.Ceiling(Player.Ctlcontrols.currentPosition);

                // If the end time is empty or prior to the current start time, 
                // set the start time to the beginning.
                if ((tempClip.startString == "") || (tempClip.endSeconds < tempClip.startSeconds)) 
                {
                    tempClip.startString = "00:00";
                    tempClip.startSeconds = 0;
                }

            }

            // Update the list box with current clip information.
            updateClip(currentClip);
            bxClipList.SetSelected(currentClip, true);

        }

        // The clearClipList method deletes all entries in bxClipList, 
        // clipArray, Playlist, and resets values to their default state.
        private void clearClipList() 
        {
            stop();
            bxClipList.Items.Clear();
            clipArray.Clear();
            currentClip = 0;
            songProgBar.Minimum = 0;
            songProgBar.Maximum = 2147483647;
            songProgBar.Value = 0;
            Player.settings.rate = 1.0;
            lblCurrentSong.Text = "";

            // Remove all of the items in the playlist.
            for (int i = Playlist.count - 1; i > -1; i--)
            {
                Playlist.removeItem(Playlist.get_Item(i));
            }
        }

        // The deleteSelectedClip method deletes the currently selected clip
        // from the clip list, the clip array, and the playlist.
        private void deleteSelectedClip() 
        {
            if (bxClipList.SelectedIndex > -1) 
            {
                if (bxClipList.Items.Count == 1) 
                {
                    clearClipList();
                } 
                else 
                {
                    int selectedClip = bxClipList.SelectedIndex;
                    string selectedClipName = Playlist.get_Item(selectedClip).name;
                    stop();

                    // Remove the selected item from the list box,
                    // the clip array, and the playlist.
                    bxClipList.Items.RemoveAt(selectedClip);
                    clipArray.RemoveAt(selectedClip);
                    Playlist.removeItem(Playlist.get_Item(selectedClip));

                    bxClipList.SelectedItem = selectedClip;

                    if (selectedClipName == Player.currentMedia.name)
                    {
                        lblCurrentSong.Text = "";
                    }
                }
            }
            
        }

        // The moveSelectedClip method moves the currently selected clip by the specified number 
        // of positions. Negative values move the clip up, while positive values move it down.  
        // For convenience, UP has been defined as -1 and DOWN has been defined as 1.
        private void moveSelectedClip(int updown) 
        {

            if (bxClipList.SelectedIndex > -1) 
            {

                int selectedClip = bxClipList.SelectedIndex;

                if ( (selectedClip + updown > -1) && (selectedClip + updown < bxClipList.Items.Count) ) 
                {
                    
                    // Update the array.
                    object clipTemp = clipArray[selectedClip + updown];
                    clipArray[selectedClip + updown] = clipArray[selectedClip];
                    clipArray[selectedClip] = clipTemp;

                    // Update the listbox.
                    object listTemp = bxClipList.Items[selectedClip + updown];
                    bxClipList.Items[selectedClip + updown] = bxClipList.Items[selectedClip];
                    bxClipList.Items[selectedClip] = listTemp; 

                    // Update the playlist.
                    Playlist.moveItem(selectedClip, selectedClip + updown);

                    // Set the selected item in the listbox index to the selected clip.
                    bxClipList.SetSelected(selectedClip + updown, true);
                }
            }
        }

        // The updateClip method updates the specified entry in the clip list
        // with the current clip information from the clipArray.
        private void updateClip(int clipNumber) 
        {
            // Create a temporary Clip object to make the code more readable.
            Clip tempClip = (Clip)clipArray[clipNumber];

            string duration = timeString((tempClip.endSeconds - tempClip.startSeconds));
            string startTime = tempClip.startString;
            string endTime = timeString(tempClip.endSeconds);
            string clipName = tempClip.mediaName;

            string updateText = "  " + duration + "  (" + startTime + " - " + endTime + ")    " + clipName;

            if (bxClipList.Items.Count > clipNumber) 
            {
                bxClipList.Items.RemoveAt(clipNumber);
                bxClipList.Items.Insert(clipNumber, updateText);
            } 
            else 
            {
                bxClipList.Items.Add(updateText);
            }
        }

        // The timeString method formats the specified seconds value into MM:SS format
        // where MM indicates the minutes and SS indicates the seconds.  
        // Windows Media Player provides strings in this format for media duration and 
        // position values, so this function is only needed for clip duration values.
        private string timeString(int time) 
        {

            int    minutes = (int)Math.Floor((decimal)time / 60);
            int    seconds = (int)(time % 60);
            string minutesString = "";
            string secondsString = "";
            
            if (minutes > 60) 
            {
                minutesString = ">1 hr";
            } 
            else if (minutes < 10) 
            {
                minutesString = "0" + minutes.ToString();
            }
            else
            {
                minutesString = minutes.ToString();
            }

            
            if (seconds < 10) 
            {
                secondsString = "0" + seconds.ToString();
            }
            else
            {
                secondsString = seconds.ToString();
            }
            return minutesString + ":" + secondsString;
        }
        
        // This method resets the selected media item to it's default values.
        private void SetDefaultState (Clip mediaClip)
        {
            mediaClip.startString = "00:00";
            mediaClip.endString = Playlist.get_Item(bxClipList.SelectedIndex).durationString;
            mediaClip.startSeconds = 0;
            mediaClip.endSeconds = (int)Playlist.get_Item(bxClipList.SelectedIndex).duration;
        }

        private void songTrackBar_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Player.Ctlcontrols.currentPosition = (double)songTrackBar.Value;
            songProgBar.Value = (int)Math.Ceiling((decimal)songTrackBar.Value);
            Player.Ctlcontrols.pause();
            btnPlay.Text = "Play";
        }

        private void songTrackBar_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Player.Ctlcontrols.play();
        }
    }
}
