<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1285358964328" ID="ID_1248517120" MODIFIED="1285358995078" TEXT="ATMW">
<node CREATED="1285358995812" ID="ID_870988194" MODIFIED="1285359004343" POSITION="right" TEXT="&#x423;&#x441;&#x43e;&#x432;&#x435;&#x440;&#x448;&#x435;&#x43d;&#x441;&#x442;&#x432;&#x43e;&#x432;&#x430;&#x43d;&#x438;&#x44f;">
<node CREATED="1285359005156" ID="ID_1208406604" MODIFIED="1285359019000" TEXT="&#x41f;&#x43e;&#x434;&#x434;&#x435;&#x440;&#x436;&#x43a;&#x430; &#x433;&#x440;&#x430;&#x444;&#x438;&#x447;&#x435;&#x441;&#x43a;&#x438;&#x445; &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; - &#x445;&#x43e;&#x442;&#x44f; &#x431;&#x44b; &#x43d;&#x435; &#x440;&#x443;&#x433;&#x430;&#x442;&#x44c;&#x441;&#x44f; &#x43d;&#x430; &#x43d;&#x438;&#x445;"/>
<node CREATED="1285359019953" ID="ID_40815586" MODIFIED="1285359034687" TEXT="&#x415;&#x441;&#x43b;&#x438; &#x437;&#x430;&#x43f;&#x43e;&#x43b;&#x43d;&#x44f;&#x435;&#x442;&#x441;&#x44f; &#x432;&#x43a;&#x43b;&#x430;&#x434;&#x43a;&#x430; check - &#x430;&#x43a;&#x442;&#x438;&#x432;&#x438;&#x437;&#x438;&#x440;&#x43e;&#x432;&#x430;&#x442;&#x44c; &#x435;&#x451;"/>
</node>
<node CREATED="1286287961283" ID="ID_1017407990" MODIFIED="1286287972408" POSITION="left" TEXT="&#x421;&#x435;&#x440;&#x44c;&#x451;&#x437;&#x43d;&#x44b;&#x435; &#x444;&#x438;&#x447;&#x438;">
<node CREATED="1286287972862" ID="ID_1945894023" MODIFIED="1286288008112" TEXT="&#x41f;&#x43e;&#x434;&#x434;&#x435;&#x440;&#x436;&#x43a;&#x430; CUE &#x444;&#x430;&#x439;&#x43b;&#x43e;&#x432; &#x434;&#x43b;&#x44f; "/>
</node>
</node>
</map>
