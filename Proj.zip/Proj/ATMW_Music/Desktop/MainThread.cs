using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Nb.Library;
using NbTools;

namespace Desktop
{
    static class MainThread
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                Application.Run(new MainForm(args));
            }
            catch (Exception ex)
            {
                NbMessageBox.OK(NbException.Exception2String(ex));
            }
        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = e.ExceptionObject as Exception;
            if (ex == null)
                NbMessageBox.OK("Unhadled domain exception with unknown type: '{0}'", e.ExceptionObject.GetType().Name);
            else
                NbMessageBox.OK("Domain Exception: \r\n" + NbException.Exception2String(ex));
        }

        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            if (e.Exception is NbExceptionUserCancelled)
                return; //Do not show "User cancelled exception"
            else
                NbMessageBox.OK("Thread Exception: \r\n" + NbException.Exception2String(e.Exception));
        }
    }
}