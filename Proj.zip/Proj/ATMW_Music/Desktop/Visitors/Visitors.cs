﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atmw.Xml;
using System.Diagnostics;
using Nb.Library.LogView;
using Nb.Library;

namespace Desktop.Visitors
{
    namespace Desktop.Visitors
    {

        //Должен возвращать название команды действие над элементом
        class VisitorOpenFolder : VisitorAbstract
        {
            internal override string Name
            {
                get { return "Explore to"; }
            }

            public override VisitorAction VisitN(AxDirectory aDir)
            {
                return delegate(AxElement aElement)
                {
                    Process.Start("explorer.exe", "\"" + aElement.PathName + "\"");
                    return false; //Don't remove the log line
                };
            }

            public override VisitorAction VisitN(AxFile aFile)
            {
                return delegate(AxElement aElement)
                {
                    Process.Start("explorer.exe", "/select,\"" + aElement.PathName + "\"");
                    return false; //Don't remove the log line
                };
            }
        }

        class VisitorOpenInMp3Tag : VisitorAbstract
        {
            internal override string Name
            {
                get { return "Open in Mp3Tag"; }
            }

            public override VisitorAction VisitN(AxDirectory aDir)
            {
                return delegate(AxElement aElement)
                {
                    Process.Start(@"C:\Program Files (x86)\Mp3tag\Mp3tag.exe", "\"" + aElement.PathName + "\"");
                    return false; //Don't remove the log line
                };
            }

            public override VisitorAction VisitN(AxFile aFile)
            {
                return delegate(AxElement aElement)
                {
                    Process.Start(@"C:\Program Files (x86)\Mp3tag\Mp3tag.exe", "\"" + aElement.PathName + "\"");
                    return false; //Don't remove the log line
                };
            }
        }



        class VisitorStatistics : VisitorAbstract
        {
            internal override string Name
            {
                get { return "Statictics"; }
            }

            public override VisitorAction VisitN(AxDirectory aDir)
            {
                return delegate(AxElement aElement)
                {
                    AxTreeStatistics stat = new AxTreeStatistics();
                    (aElement as AxDirectory).FillStatictics(stat); //Recursive
                    NbMessageBox.OK(stat.ToString()); //TODO: think about posting everythig to Logview
                    return false;
                };
            }
        }

        class VisitorCheckIntegrity : VisitorAbstract
        {
            private readonly IErrorLogger fLogger;
            private readonly LogViewControl fLogView;

            internal VisitorCheckIntegrity(LogViewControl aLogview, IErrorLogger aLogger)
            {
                fLogger = aLogger;
                fLogView = aLogview;
            }

            internal override string Name
            { get { return "Check Integrity"; } }

            public override VisitorAction VisitN(AxDirectory aDir)
            {
                return delegate(AxElement aElement)
                {
                    fLogView.Clear();
                    fLogView.Add(new LogViewEntry(Severity.Message, "Starting integrity check"));
                    (aElement as AxDirectory).CheckIntegrity(fLogger);
                    fLogView.Add(new LogViewEntry(Severity.Message, "Finished integrity check"));
                    return false;
                };
            }
        }


        class VisitorCheckLyrics : VisitorAbstract
        {
            private readonly IErrorLogger fLogger;
            private readonly LogViewControl fLogView;

            internal VisitorCheckLyrics(LogViewControl aLogview, IErrorLogger aLogger)
            {
                fLogger = aLogger;
                fLogView = aLogview;
            }

            internal override string Name
            { get { return "Check Lyrics"; } }

            public override VisitorAction VisitN(AxDirectory aDir)
            {
                return delegate(AxElement aElement)
                {
                    fLogView.Clear();
                    fLogView.Add(new LogViewEntry(Severity.Message, "Starting lyrics check"));
                    (aElement as AxDirectory).CheckLyrics(fLogger);
                    fLogView.Add(new LogViewEntry(Severity.Message, "Finished lyrics check"));
                    return false;
                };
            }
        }

        class VisitorPlay : VisitorAbstract
        {
            private readonly PlayController fPlayController;

            internal VisitorPlay(PlayController aPlayController)
            {
                fPlayController = aPlayController;
            }

            public override bool SupportsInvocation(VisitorAbstract.Invocation aInvocation)
            { return true; }  //Show for all modes 

            internal override string Name
            {
                get { return "&Play"; }
            }

            public override VisitorAction VisitN(AxElement aFile)
            {
                return delegate(AxElement aElement)
                {
                    fPlayController.PlayElement(aElement);
                    return false; //Do not close the log view entry
                };
            }
        }


        class VisitorEnqueue : VisitorAbstract
        {
            private readonly PlayController fPlayController;

            internal VisitorEnqueue(PlayController aPlayController)
            {
                fPlayController = aPlayController;
            }

            public override bool SupportsInvocation(VisitorAbstract.Invocation aInvocation)
            { return true; }  //Show for all modes 

            internal override string Name
            {
                get { return "&Enqueue"; }
            }

            public override VisitorAction VisitN(AxFileAudio aFile)
            {
                return delegate(AxElement aElement)
                {
                    fPlayController.EnqueueElement(aElement); //TODO: simplify the call chain
                    return false; //Do not close the log view entry
                };
            }
        }
    }



    //Clipboard.SetDataObject(Element.Parent.PathName, true); //TODO: copy path
}
