﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atmw.Xml;
using System.Diagnostics;
using Nb.Library.LogView;
using Nb.Library;

namespace Desktop.Visitors
{
    class VisitorCheckSongNames : VisitorAbstract
    {
        private readonly IErrorLogger fLogger;
        private readonly LogViewControl fLogView;

        internal VisitorCheckSongNames(LogViewControl aLogview, IErrorLogger aLogger)
        {
            fLogger = aLogger;
            fLogView = aLogview;
        }

        internal override string Name
        { get { return "Check Song Names"; } }

        public override VisitorAction VisitN(AxDirectory aDir)
        {
            return delegate(AxElement selElement)
            {
                fLogView.Clear();
                fLogView.Add(new LogViewEntry(Severity.Message, "Starting Song Name analisys"));

                if (selElement is AxDirectory)
                {   //Node contains subnodes
                    List<AxFile> files = new List<AxFile>(1000);
                    BuildFileList(selElement as AxDirectory, files);

                    foreach (AxFile file in files)
                    {
                        AxFileAudio fa = file as AxFileAudio;
                        if (fa == null)
                            continue;

                        fa.CheckFilename(fLogger);
                    }

                }
                else if (selElement is AxFileAudio)
                {   //Single node run
                    fLogView.Clear();
                    (selElement as AxFileAudio).CheckFilename(fLogger);
                }

                fLogView.Add(new LogViewEntry(Severity.Message, "Finished song name analisys"));
                return false;
            };
        }

        public void BuildFileList(AxDirectory aNode, List<AxFile> aFileList)
        {
            foreach (AxDirectory aSubNode in aNode.dirs)
            {
                BuildFileList(aSubNode, aFileList);
            }

            foreach (AxFile file in aNode.files)
            {
                aFileList.Add(file);
            }
        }
    }
}
