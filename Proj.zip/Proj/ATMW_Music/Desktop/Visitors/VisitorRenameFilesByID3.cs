﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Atmw.Xml;
using Nb.Library.LogView;

namespace Desktop.Visitors
{

    class VisitorRenameFilesByID3 : VisitorAbstract
    {
        private readonly IErrorLogger fLogger;
        private readonly LogViewControl fLogView;

        internal VisitorRenameFilesByID3(LogViewControl aLogview, IErrorLogger aLogger)
        {
            fLogger = aLogger;
            fLogView = aLogview;
        }

        internal override string Name
        { get { return "Check Song Names"; } }

        public override VisitorAction VisitN(AxFileAudioMp3 aMp3File)
        {
            return delegate(AxElement selElement)
            {

                if (selElement is AxFileAudioMp3)
                {   //Single node run
                    AxFileAudioMp3 mp3 = selElement as AxFileAudioMp3;
                    mp3.RenameFileByID3(fLogger);
                }
                return false;
            };
        }
    }
}
