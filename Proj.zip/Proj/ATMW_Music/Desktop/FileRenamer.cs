using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Atmw.Xml;
using System.Text.RegularExpressions;
using System.IO;
using System.Diagnostics;
using Nb.Library;

namespace Desktop
{
    public partial class FileRenamer : Form
    {
        private readonly List<AxFile> fFilelist;

        public FileRenamer(List<AxFile> aFilelist)
        {
            fFilelist = aFilelist;
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            listBefore.Items.Clear();
            listAfter.Items.Clear();
            try
            {
                Regex regex = new Regex(textBoxRegex.Text, RegexOptions.IgnoreCase);


                foreach (AxFile file in fFilelist)
                {
                    AxFileAudio fa = file as AxFileAudio;
                    if (fa == null)
                        continue;

                    if (!String.IsNullOrEmpty(fa.CheckFilename(null))) //TODO; provide empty logger?
                    {
                        listBefore.Items.Add(fa.Filename);
                        Match mt = regex.Match(fa.Filename);

                        RenameTask task;
                        if (mt.Success)
                        {
                            switch (mt.Groups.Count)
                            {
                                case 1: task = new RenameTask("Please use () in the regexp"); break;
                                case 2: task = new RenameTask("Please use indicate song number and song name"); break;
                                case 3: task = new RenameTask(fa, 
                                    String.Format("{0} - {1}.mp3", mt.Groups[1].Value,mt.Groups[2].Value)); 
                                    break;
                                case 4: task = new RenameTask(fa,
                                    String.Format("{0} - {1} - {2}.mp3", mt.Groups[1].Value, mt.Groups[2].Value, mt.Groups[3].Value));
                                    break;
                                default: task = new RenameTask("Regexp Error"); break;
                            }
                        }
                        else
                        {
                            task = new RenameTask("------");
                        }

                        ListViewItem li = new ListViewItem(task.NewFilename, 0);
                        li.Tag = task;
                        listAfter.Items.Add(li);
                    }
                }
            }
            catch (Exception ex)
            {
                NbMessageBox.OK(ex.Message);
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            DialogResult res = NbMessageBox.Show("Are you sure you want to rename the files?", "File renamer", 
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                foreach(ListViewItem li in listAfter.Items)
                {
                    if (li.Tag is RenameTask)
                    {
                        (li.Tag as RenameTask).Execute();
                    }
                }

            }
        }

        private void listAfter_AfterLabelEdit(object sender, LabelEditEventArgs e)
        {
            RenameTask task = listAfter.Items[e.Item].Tag as RenameTask;
            task.NewFilename = e.Label;
        }

        private void listAfter_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F2)
            {
                if (listAfter.SelectedItems.Count == 1)
                    listAfter.SelectedItems[0].BeginEdit();
            }
        }
    }

    class RenameTask
    {
        private readonly AxFile fFile;
        
        public string NewFilename
        {
            get { return fNewFilename; }
            set { fNewFilename = value; }
        } private string fNewFilename; //Also may hold the error description

        public RenameTask(AxFile aFile, string aNewName)
        {
            fFile = aFile;
            fNewFilename = aNewName;

            //Apply "Pascal Casing"
            string[] words = fNewFilename.Split(new char[] { ' ','_' });
            fNewFilename = "";
            foreach (string word in words)
            {
                if (!String.IsNullOrEmpty(word) && Char.IsLetter(word[0]) && Char.IsLower(word[0]))
                    fNewFilename += word[0].ToString().ToUpper() + word.Substring(1) + " ";
                else
                    fNewFilename += word + " ";
            }

            fNewFilename = fNewFilename.Substring(0, fNewFilename.Length - 1);
        }

        public RenameTask(string aErrorDesc)
        {
            fNewFilename = aErrorDesc;
            fFile = null;
        }

        public override string ToString()
        {
            if (fFile != null)
                return fNewFilename;
            else
                return "Error: " + fNewFilename;
        }

        public void Execute()
        {
            if (fFile != null)
            {
                File.Move(fFile.PathName, fFile.Parent.PathName + "\\" + fNewFilename);
                //Debug.WriteLine("Rename " + fFile.Name + " to " + fNewFilename);
            }
        }
    }
}