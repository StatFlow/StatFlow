using System.Collections.Generic;
using System.Linq;
using Atmw.Xml;
using Nb.Library.LogView;
using NbTools;

namespace Desktop
{
    public class NbLoggerFullException : NbException
    {
        public NbLoggerFullException()
            : base("The number of messages has exceeded 1000. The process is stopped")
        { }
    }

    public static class Extensions
    {
        public static IEnumerable<T> Safe<T>(this IEnumerable<T> aColl)
        {
            if (aColl != null)
                return aColl;
            else
                return Enumerable.Empty<T>();
        }

        public static IEnumerable<T> ToEnumerable<T>(this T aObj)
        {
            yield return aObj;
        }
    }


    internal class LogViewEntry : ILogEntry
    {
        private readonly AxElement Element;
        private readonly IEnumerable<MenuCommand> fMenuCommandsN;
        private readonly MenuCommmandController fMenuControllerN;
        
        public Severity Severity
        {
            get { return fSeverity; }
        } private readonly Severity fSeverity;

        public string Description
        {
            get { return fDescription; }
        } private readonly string fDescription;

        
        public LogViewEntry(Severity aSeverity, string aDesc)
            : this(aSeverity, aDesc, null, null, null)
        { }

        public LogViewEntry(Severity aSeverity, string aDesc, AxElement aElement, MenuCommmandController aLogger)
            : this(aSeverity, aDesc, aElement, aLogger, null)
        { }

        public LogViewEntry(Severity aSeverity, string aDesc, AxElement aElement, MenuCommmandController aLogger, IEnumerable<MenuCommand> aCommandsN)
        {
            fSeverity = aSeverity;
            fDescription = aDesc;
            Element = aElement;
            fMenuCommandsN = aCommandsN;
            fMenuControllerN = aLogger;
        }

        public string GetColumnText(int aIndex)
        {
            if (aIndex == 0)
                return (Element == null) ? " " : Element.ReversePath;
            else
                return null;
        }

        public IEnumerable<ILogCommand> Commands
        {
            get
            {
                foreach (var cmd in fMenuCommandsN.Safe())
                    yield return cmd; 
                //if (fMenuCommandN != null) //Show specific commands first
                    //yield return fMenuCommandN;

                if (fMenuControllerN != null && Element != null)
                {
                    //TODO: yield separator command or introduce command groups
                    foreach (MenuCommand mCmd in fMenuControllerN.GetElementMenuCommands(Element, VisitorAbstract.Invocation.RightClick))
                        yield return mCmd;
                }
            }
        }
    }
}
