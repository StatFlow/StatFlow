using System;
using System.Collections.Generic;
using System.Text;

using Atmw.Xml;
using System.Diagnostics;
using Nb.Library;
using Nb.Library.LogView;

namespace Desktop
{
    //Abstract visitor - keep empty implementations of all Visit methods
    abstract class VisitorAbstract : IElementVisitor
    {
        public enum Invocation { RightClick, DoubleClick };

        //TODO: return the menu icon here as well
        abstract internal string Name { get; }

        virtual public bool SupportsInvocation(Invocation aInvocation)
        {
            return (aInvocation == Invocation.RightClick); //By default item if the the right button
        }

        //Empty default implementations, should be overriden in solid Visitors
        #region IElementVisitor Members

        virtual public VisitorAction VisitN(AxElement aElement)
        { return null; }

        virtual public VisitorAction VisitN(AxDirectory aDir)
        { return VisitN(aDir as AxElement); }

        virtual public VisitorAction VisitN(AxDisk aDisk)
        { return VisitN(aDisk as AxDirectory); }

        virtual public VisitorAction VisitN(AxAlbum aAlbum)
        { return VisitN(aAlbum as AxDirectory); }


        virtual public VisitorAction VisitN(AxFile aFile)
        { return VisitN(aFile as AxElement); }

        virtual public VisitorAction VisitN(AxFileAudio aFileAudio)
        { return VisitN(aFileAudio as AxFile); }

        virtual public VisitorAction VisitN(AxFileAudioMp3 aFileAudioMp3)
        { return VisitN(aFileAudioMp3 as AxFileAudio); }

        virtual public VisitorAction VisitN(AxArtist aPerf)
        { return VisitN(aPerf as AxElement); }

        virtual public VisitorAction VisitN(AxFilePicture aFileAudio)
        { return VisitN(aFileAudio as AxFilePicture); }

        virtual public VisitorAction VisitN(AxFileText aFileAudio)
        { return VisitN(aFileAudio as AxFileText); }

        #endregion
    }
}





