namespace Desktop
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.mtlbFile = new System.Windows.Forms.ToolStripDropDownButton();
            this.mtlbFileLoadFromDisk = new System.Windows.Forms.ToolStripMenuItem();
            this.mtlbFileSave = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.mtlbFileExit = new System.Windows.Forms.ToolStripMenuItem();
            this.MainToolbarUpdateButton = new System.Windows.Forms.ToolStripButton();
            this.MainToolbarPlayButton = new System.Windows.Forms.ToolStripButton();
            this.MainToolbarShuffleButton = new System.Windows.Forms.ToolStripButton();
            this.MainToolbarFileRenamerButton = new System.Windows.Forms.ToolStripButton();
            this.MainToolbarPlayerSelectsButton = new System.Windows.Forms.ToolStripButton();
            this.MainToolbarPlayModeButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.justTheNodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sequenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.loopTrackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loopAlbumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.shuffleTracksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shuffleAlbumsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btCheckerOptions = new System.Windows.Forms.ToolStripButton();
            this.btTools = new System.Windows.Forms.ToolStripDropDownButton();
            this.statsByExtensionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.fStatusPlayer = new System.Windows.Forms.ToolStripStatusLabel();
            this.fProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.fProgressLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.SelectorTabs = new System.Windows.Forms.TabControl();
            this.SelectorTabTree = new System.Windows.Forms.TabPage();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.treeViewContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.testToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MainImageList = new System.Windows.Forms.ImageList(this.components);
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.SelectorTabList = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lvAlphabeticList = new System.Windows.Forms.ListView();
            this.listViewContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.quickSearchTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.logViewContainer1 = new Nb.Library.LogView.LogViewContainer();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SelectorTabs.SuspendLayout();
            this.SelectorTabTree.SuspendLayout();
            this.treeViewContextMenu.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mtlbFile,
            this.MainToolbarUpdateButton,
            this.MainToolbarPlayButton,
            this.MainToolbarShuffleButton,
            this.MainToolbarFileRenamerButton,
            this.MainToolbarPlayerSelectsButton,
            this.MainToolbarPlayModeButton,
            this.btCheckerOptions,
            this.btTools});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(921, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // mtlbFile
            // 
            this.mtlbFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.mtlbFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mtlbFileLoadFromDisk,
            this.mtlbFileSave,
            this.toolStripMenuItem3,
            this.mtlbFileExit});
            this.mtlbFile.Image = ((System.Drawing.Image)(resources.GetObject("mtlbFile.Image")));
            this.mtlbFile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.mtlbFile.Name = "mtlbFile";
            this.mtlbFile.Size = new System.Drawing.Size(38, 22);
            this.mtlbFile.Text = "&File";
            // 
            // mtlbFileLoadFromDisk
            // 
            this.mtlbFileLoadFromDisk.Name = "mtlbFileLoadFromDisk";
            this.mtlbFileLoadFromDisk.Size = new System.Drawing.Size(154, 22);
            this.mtlbFileLoadFromDisk.Text = "Load from Disk";
            this.mtlbFileLoadFromDisk.Click += new System.EventHandler(this.MainToolBarLoadButton_Click);
            // 
            // mtlbFileSave
            // 
            this.mtlbFileSave.Name = "mtlbFileSave";
            this.mtlbFileSave.Size = new System.Drawing.Size(154, 22);
            this.mtlbFileSave.Text = "Save";
            this.mtlbFileSave.Click += new System.EventHandler(this.mtlbFileSave_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(151, 6);
            // 
            // mtlbFileExit
            // 
            this.mtlbFileExit.Name = "mtlbFileExit";
            this.mtlbFileExit.Size = new System.Drawing.Size(154, 22);
            this.mtlbFileExit.Text = "Exit";
            this.mtlbFileExit.Click += new System.EventHandler(this.mtlbFileExit_Click);
            // 
            // MainToolbarUpdateButton
            // 
            this.MainToolbarUpdateButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MainToolbarUpdateButton.Image = ((System.Drawing.Image)(resources.GetObject("MainToolbarUpdateButton.Image")));
            this.MainToolbarUpdateButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainToolbarUpdateButton.Name = "MainToolbarUpdateButton";
            this.MainToolbarUpdateButton.Size = new System.Drawing.Size(75, 22);
            this.MainToolbarUpdateButton.Text = "Update Tree";
            this.MainToolbarUpdateButton.Click += new System.EventHandler(this.MainToolbarUpdateButton_Click);
            // 
            // MainToolbarPlayButton
            // 
            this.MainToolbarPlayButton.Image = ((System.Drawing.Image)(resources.GetObject("MainToolbarPlayButton.Image")));
            this.MainToolbarPlayButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainToolbarPlayButton.Name = "MainToolbarPlayButton";
            this.MainToolbarPlayButton.Size = new System.Drawing.Size(49, 22);
            this.MainToolbarPlayButton.Text = "Play";
            this.MainToolbarPlayButton.Click += new System.EventHandler(this.MainToolbarPlayButton_Click);
            // 
            // MainToolbarShuffleButton
            // 
            this.MainToolbarShuffleButton.Image = ((System.Drawing.Image)(resources.GetObject("MainToolbarShuffleButton.Image")));
            this.MainToolbarShuffleButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainToolbarShuffleButton.Name = "MainToolbarShuffleButton";
            this.MainToolbarShuffleButton.Size = new System.Drawing.Size(64, 22);
            this.MainToolbarShuffleButton.Text = "Shuffle";
            this.MainToolbarShuffleButton.Click += new System.EventHandler(this.MainToolbarShuffleButton_Click);
            // 
            // MainToolbarFileRenamerButton
            // 
            this.MainToolbarFileRenamerButton.Image = ((System.Drawing.Image)(resources.GetObject("MainToolbarFileRenamerButton.Image")));
            this.MainToolbarFileRenamerButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainToolbarFileRenamerButton.Name = "MainToolbarFileRenamerButton";
            this.MainToolbarFileRenamerButton.Size = new System.Drawing.Size(74, 22);
            this.MainToolbarFileRenamerButton.Text = "Renamer";
            // 
            // MainToolbarPlayerSelectsButton
            // 
            this.MainToolbarPlayerSelectsButton.CheckOnClick = true;
            this.MainToolbarPlayerSelectsButton.Image = ((System.Drawing.Image)(resources.GetObject("MainToolbarPlayerSelectsButton.Image")));
            this.MainToolbarPlayerSelectsButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainToolbarPlayerSelectsButton.Name = "MainToolbarPlayerSelectsButton";
            this.MainToolbarPlayerSelectsButton.Size = new System.Drawing.Size(98, 22);
            this.MainToolbarPlayerSelectsButton.Text = "Player Selects";
            this.MainToolbarPlayerSelectsButton.ToolTipText = "Player selects current track in the tree";
            // 
            // MainToolbarPlayModeButton
            // 
            this.MainToolbarPlayModeButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.justTheNodeToolStripMenuItem,
            this.sequenceToolStripMenuItem,
            this.toolStripMenuItem1,
            this.loopTrackToolStripMenuItem,
            this.loopAlbumToolStripMenuItem,
            this.toolStripMenuItem2,
            this.shuffleTracksToolStripMenuItem,
            this.shuffleAlbumsToolStripMenuItem});
            this.MainToolbarPlayModeButton.Image = ((System.Drawing.Image)(resources.GetObject("MainToolbarPlayModeButton.Image")));
            this.MainToolbarPlayModeButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.MainToolbarPlayModeButton.Name = "MainToolbarPlayModeButton";
            this.MainToolbarPlayModeButton.Size = new System.Drawing.Size(92, 22);
            this.MainToolbarPlayModeButton.Text = "Play Mode";
            // 
            // justTheNodeToolStripMenuItem
            // 
            this.justTheNodeToolStripMenuItem.Name = "justTheNodeToolStripMenuItem";
            this.justTheNodeToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.justTheNodeToolStripMenuItem.Text = "Just the Node";
            this.justTheNodeToolStripMenuItem.Click += new System.EventHandler(this.justTheNodeToolStripMenuItem_Click);
            // 
            // sequenceToolStripMenuItem
            // 
            this.sequenceToolStripMenuItem.Name = "sequenceToolStripMenuItem";
            this.sequenceToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.sequenceToolStripMenuItem.Text = "Sequence";
            this.sequenceToolStripMenuItem.Click += new System.EventHandler(this.sequenceToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(150, 6);
            // 
            // loopTrackToolStripMenuItem
            // 
            this.loopTrackToolStripMenuItem.Name = "loopTrackToolStripMenuItem";
            this.loopTrackToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.loopTrackToolStripMenuItem.Text = "Loop track";
            this.loopTrackToolStripMenuItem.Click += new System.EventHandler(this.loopTrackToolStripMenuItem_Click);
            // 
            // loopAlbumToolStripMenuItem
            // 
            this.loopAlbumToolStripMenuItem.Name = "loopAlbumToolStripMenuItem";
            this.loopAlbumToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.loopAlbumToolStripMenuItem.Text = "Loop album";
            this.loopAlbumToolStripMenuItem.Click += new System.EventHandler(this.loopAlbumToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(150, 6);
            // 
            // shuffleTracksToolStripMenuItem
            // 
            this.shuffleTracksToolStripMenuItem.Name = "shuffleTracksToolStripMenuItem";
            this.shuffleTracksToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.shuffleTracksToolStripMenuItem.Text = "Shuffle tracks";
            this.shuffleTracksToolStripMenuItem.Click += new System.EventHandler(this.shuffleTracksToolStripMenuItem_Click);
            // 
            // shuffleAlbumsToolStripMenuItem
            // 
            this.shuffleAlbumsToolStripMenuItem.Name = "shuffleAlbumsToolStripMenuItem";
            this.shuffleAlbumsToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.shuffleAlbumsToolStripMenuItem.Text = "Shuffle albums";
            this.shuffleAlbumsToolStripMenuItem.Click += new System.EventHandler(this.shuffleAlbumsToolStripMenuItem_Click);
            // 
            // btCheckerOptions
            // 
            this.btCheckerOptions.Image = ((System.Drawing.Image)(resources.GetObject("btCheckerOptions.Image")));
            this.btCheckerOptions.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btCheckerOptions.Name = "btCheckerOptions";
            this.btCheckerOptions.Size = new System.Drawing.Size(69, 22);
            this.btCheckerOptions.Text = "Settings";
            this.btCheckerOptions.ToolTipText = "Checker Options";
            this.btCheckerOptions.Click += new System.EventHandler(this.btCheckerOptions_Click);
            // 
            // btTools
            // 
            this.btTools.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btTools.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statsByExtensionToolStripMenuItem});
            this.btTools.Image = ((System.Drawing.Image)(resources.GetObject("btTools.Image")));
            this.btTools.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btTools.Name = "btTools";
            this.btTools.Size = new System.Drawing.Size(49, 22);
            this.btTools.Text = "Tools";
            // 
            // statsByExtensionToolStripMenuItem
            // 
            this.statsByExtensionToolStripMenuItem.Name = "statsByExtensionToolStripMenuItem";
            this.statsByExtensionToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.statsByExtensionToolStripMenuItem.Text = "Stats by extension";
            this.statsByExtensionToolStripMenuItem.Click += new System.EventHandler(this.statsByExtensionToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fStatusPlayer,
            this.fProgressBar,
            this.fProgressLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 642);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(921, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // fStatusPlayer
            // 
            this.fStatusPlayer.AutoSize = false;
            this.fStatusPlayer.Name = "fStatusPlayer";
            this.fStatusPlayer.Size = new System.Drawing.Size(100, 17);
            this.fStatusPlayer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // fProgressBar
            // 
            this.fProgressBar.ForeColor = System.Drawing.Color.DarkGreen;
            this.fProgressBar.Name = "fProgressBar";
            this.fProgressBar.Size = new System.Drawing.Size(300, 16);
            this.fProgressBar.Step = 1;
            this.fProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.fProgressBar.MouseDown += new System.Windows.Forms.MouseEventHandler(this.fProgressBar_MouseDown);
            // 
            // fProgressLabel
            // 
            this.fProgressLabel.AutoSize = false;
            this.fProgressLabel.Name = "fProgressLabel";
            this.fProgressLabel.Size = new System.Drawing.Size(36, 17);
            this.fProgressLabel.Text = "00:00";
            // 
            // splitContainer1
            // 
            this.splitContainer1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer1.Size = new System.Drawing.Size(921, 617);
            this.splitContainer1.SplitterDistance = 306;
            this.splitContainer1.TabIndex = 2;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.SelectorTabs);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer2.Size = new System.Drawing.Size(306, 617);
            this.splitContainer2.SplitterDistance = 347;
            this.splitContainer2.TabIndex = 0;
            // 
            // SelectorTabs
            // 
            this.SelectorTabs.Controls.Add(this.SelectorTabTree);
            this.SelectorTabs.Controls.Add(this.SelectorTabList);
            this.SelectorTabs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SelectorTabs.Location = new System.Drawing.Point(0, 0);
            this.SelectorTabs.Name = "SelectorTabs";
            this.SelectorTabs.SelectedIndex = 0;
            this.SelectorTabs.Size = new System.Drawing.Size(306, 347);
            this.SelectorTabs.TabIndex = 0;
            // 
            // SelectorTabTree
            // 
            this.SelectorTabTree.Controls.Add(this.treeView1);
            this.SelectorTabTree.Controls.Add(this.toolStrip2);
            this.SelectorTabTree.Location = new System.Drawing.Point(4, 22);
            this.SelectorTabTree.Name = "SelectorTabTree";
            this.SelectorTabTree.Padding = new System.Windows.Forms.Padding(3);
            this.SelectorTabTree.Size = new System.Drawing.Size(298, 321);
            this.SelectorTabTree.TabIndex = 0;
            this.SelectorTabTree.Text = "Tree";
            this.SelectorTabTree.UseVisualStyleBackColor = true;
            // 
            // treeView1
            // 
            this.treeView1.ContextMenuStrip = this.treeViewContextMenu;
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.HideSelection = false;
            this.treeView1.ImageIndex = 0;
            this.treeView1.ImageList = this.MainImageList;
            this.treeView1.Indent = 19;
            this.treeView1.Location = new System.Drawing.Point(3, 28);
            this.treeView1.Name = "treeView1";
            this.treeView1.SelectedImageIndex = 0;
            this.treeView1.Size = new System.Drawing.Size(292, 290);
            this.treeView1.TabIndex = 1;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            this.treeView1.NodeMouseDoubleClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeView1_NodeMouseDoubleClick);
            this.treeView1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.treeView1_KeyUp);
            this.treeView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.treeView1_MouseDown);
            // 
            // treeViewContextMenu
            // 
            this.treeViewContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testToolStripMenuItem});
            this.treeViewContextMenu.Name = "treeViewContextMenu";
            this.treeViewContextMenu.Size = new System.Drawing.Size(97, 26);
            this.treeViewContextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.treeViewContextMenu_Opening);
            // 
            // testToolStripMenuItem
            // 
            this.testToolStripMenuItem.Name = "testToolStripMenuItem";
            this.testToolStripMenuItem.Size = new System.Drawing.Size(96, 22);
            this.testToolStripMenuItem.Text = "Test";
            // 
            // MainImageList
            // 
            this.MainImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("MainImageList.ImageStream")));
            this.MainImageList.TransparentColor = System.Drawing.Color.Magenta;
            this.MainImageList.Images.SetKeyName(0, "comp.bmp");
            this.MainImageList.Images.SetKeyName(1, "AxDir");
            this.MainImageList.Images.SetKeyName(2, "AxFileAudioMp3");
            this.MainImageList.Images.SetKeyName(3, "AxAlbum");
            this.MainImageList.Images.SetKeyName(4, "AxAlbum1");
            this.MainImageList.Images.SetKeyName(5, "AxFile");
            this.MainImageList.Images.SetKeyName(6, "AxFileAudio_bonus");
            this.MainImageList.Images.SetKeyName(7, "AxFileAudio");
            this.MainImageList.Images.SetKeyName(8, "AxFileTextHtml");
            this.MainImageList.Images.SetKeyName(9, "AxPictureFile");
            // 
            // toolStrip2
            // 
            this.toolStrip2.Location = new System.Drawing.Point(3, 3);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(292, 25);
            this.toolStrip2.TabIndex = 0;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // SelectorTabList
            // 
            this.SelectorTabList.Location = new System.Drawing.Point(4, 22);
            this.SelectorTabList.Name = "SelectorTabList";
            this.SelectorTabList.Padding = new System.Windows.Forms.Padding(3);
            this.SelectorTabList.Size = new System.Drawing.Size(298, 321);
            this.SelectorTabList.TabIndex = 1;
            this.SelectorTabList.Text = "List";
            this.SelectorTabList.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(306, 266);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lvAlphabeticList);
            this.tabPage1.Controls.Add(this.toolStrip3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(298, 240);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "List";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lvAlphabeticList
            // 
            this.lvAlphabeticList.ContextMenuStrip = this.listViewContextMenu;
            this.lvAlphabeticList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lvAlphabeticList.Location = new System.Drawing.Point(3, 28);
            this.lvAlphabeticList.Name = "lvAlphabeticList";
            this.lvAlphabeticList.Size = new System.Drawing.Size(292, 209);
            this.lvAlphabeticList.SmallImageList = this.MainImageList;
            this.lvAlphabeticList.TabIndex = 1;
            this.lvAlphabeticList.UseCompatibleStateImageBehavior = false;
            this.lvAlphabeticList.View = System.Windows.Forms.View.List;
            this.lvAlphabeticList.VirtualMode = true;
            this.lvAlphabeticList.RetrieveVirtualItem += new System.Windows.Forms.RetrieveVirtualItemEventHandler(this.lvAlphabeticList_RetrieveVirtualItem);
            this.lvAlphabeticList.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.lvAlphabeticList_MouseDoubleClick);
            // 
            // listViewContextMenu
            // 
            this.listViewContextMenu.Name = "listViewContextMenu";
            this.listViewContextMenu.Size = new System.Drawing.Size(61, 4);
            this.listViewContextMenu.Opening += new System.ComponentModel.CancelEventHandler(this.listViewContextMenu_Opening);
            // 
            // toolStrip3
            // 
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quickSearchTextBox});
            this.toolStrip3.Location = new System.Drawing.Point(3, 3);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(292, 25);
            this.toolStrip3.TabIndex = 0;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // quickSearchTextBox
            // 
            this.quickSearchTextBox.Name = "quickSearchTextBox";
            this.quickSearchTextBox.Size = new System.Drawing.Size(100, 25);
            this.quickSearchTextBox.TextChanged += new System.EventHandler(this.quickSearchTextBox_TextChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.propertyGrid1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(298, 240);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Properties";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // propertyGrid1
            // 
            this.propertyGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.propertyGrid1.Location = new System.Drawing.Point(3, 3);
            this.propertyGrid1.Name = "propertyGrid1";
            this.propertyGrid1.Size = new System.Drawing.Size(292, 234);
            this.propertyGrid1.TabIndex = 0;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.logViewContainer1);
            this.splitContainer3.Size = new System.Drawing.Size(611, 617);
            this.splitContainer3.SplitterDistance = 459;
            this.splitContainer3.TabIndex = 0;
            // 
            // logViewContainer1
            // 
            this.logViewContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logViewContainer1.Location = new System.Drawing.Point(0, 0);
            this.logViewContainer1.Name = "logViewContainer1";
            this.logViewContainer1.Size = new System.Drawing.Size(611, 154);
            this.logViewContainer1.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 664);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "ATMW";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.SelectorTabs.ResumeLayout(false);
            this.SelectorTabTree.ResumeLayout(false);
            this.SelectorTabTree.PerformLayout();
            this.treeViewContextMenu.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.PropertyGrid propertyGrid1;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TabControl SelectorTabs;
        private System.Windows.Forms.TabPage SelectorTabTree;
        private System.Windows.Forms.TabPage SelectorTabList;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ListView lvAlphabeticList;
        private System.Windows.Forms.ImageList MainImageList;
        private System.Windows.Forms.ToolStripButton MainToolbarPlayButton;
        private System.Windows.Forms.ToolStripButton MainToolbarShuffleButton;
        private System.Windows.Forms.ToolStripButton MainToolbarFileRenamerButton;
        private System.Windows.Forms.ToolStripStatusLabel fStatusPlayer;
        private System.Windows.Forms.ToolStripProgressBar fProgressBar;
        private System.Windows.Forms.ToolStripStatusLabel fProgressLabel;
        private System.Windows.Forms.ToolStripButton MainToolbarPlayerSelectsButton;
        private System.Windows.Forms.ToolStripDropDownButton MainToolbarPlayModeButton;
        private System.Windows.Forms.ToolStripMenuItem justTheNodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sequenceToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem shuffleTracksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shuffleAlbumsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loopTrackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loopAlbumToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ContextMenuStrip treeViewContextMenu;
        private System.Windows.Forms.ToolStripMenuItem testToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton MainToolbarUpdateButton;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStripTextBox quickSearchTextBox;
        private System.Windows.Forms.ToolStripDropDownButton mtlbFile;
        private System.Windows.Forms.ToolStripMenuItem mtlbFileLoadFromDisk;
        private System.Windows.Forms.ToolStripMenuItem mtlbFileSave;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem mtlbFileExit;
        private System.Windows.Forms.ContextMenuStrip listViewContextMenu;
        private Nb.Library.LogView.LogViewContainer logViewContainer1;
        private System.Windows.Forms.ToolStripButton btCheckerOptions;
        private System.Windows.Forms.ToolStripDropDownButton btTools;
        private System.Windows.Forms.ToolStripMenuItem statsByExtensionToolStripMenuItem;
    }
}

