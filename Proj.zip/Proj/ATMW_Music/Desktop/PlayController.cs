using System;
using System.Collections.Generic;
using System.Text;
using Atmw.Xml;
using System.IO;
using System.Windows.Forms;
using Nb.Library;
using System.Diagnostics;
using Atmw.Player;
using NbTools;

namespace Desktop
{
    internal enum PlaySequenceModeEnum { JustTheNode, Sequence, LoopTrack, LoopAlbum, ShuffleTracks, ShuffleAlbums };

    class PlayController
    {
        //private AxElement fElementToPlay;
        private static string fWinampPath;
        private static string fCachePath;

        public PlayController(string cachePathN)
        {
            fCachePath = cachePathN;
            fWinampPath = Environment.GetEnvironmentVariable("SYSTEMDRIVE") + @"\Program Files\Winamp\Winamp.exe"; //TODO: use settings for this kind of stuff
        }

        internal PlaySequenceModeEnum PlaySequenceMode
        {
            get { return fPlaySequenceMode; }
            set { fPlaySequenceMode = value; }
        } private PlaySequenceModeEnum fPlaySequenceMode = PlaySequenceModeEnum.JustTheNode; //Default setting //TODO: Save in settings file


        //Uses media player
        public void PlayElement(AxElement selElement)
        {
            if (selElement == null)
                return;

            if (selElement is AxFileAudio)
            {
                AtmwPlayer.ExecuteAsync(new ApCommandPlay(selElement as AxFileAudio, ApCommandPlay.Type.Start), fCachePath);
            }
            else if (selElement is AxDirectory)
            {   //Shuffle
                List<AxFileAudio> files = BuildListOfFiles(selElement as AxDirectory, PlaySequenceMode);
                //(selElement as AxDirectory).BuildListOfElements(files);


                ApCommandPlay cmd = new ApCommandPlay(ApCommandPlay.Type.Start);
                foreach (AxFileAudio file in files)
                {
                    cmd.AddFile(file);
                }

                AtmwPlayer.ExecuteAsync(cmd, fCachePath);
            }
            else if (selElement is AxFilePicture)
            {
                Process.Start((selElement as AxFilePicture).PathName); //Open default windows viewer
            }
            else
                throw new NbException("Can't play element of type '{0}'", selElement.GetType().Name);
        }


        private static List<AxFileAudio> BuildListOfFiles(AxDirectory dir,  PlaySequenceModeEnum sequenceMode)
        {
            const int MaxSize = 1000;
            List<AxFileAudio> files = new List<AxFileAudio>(MaxSize);
            switch (sequenceMode)
            {
                case PlaySequenceModeEnum.JustTheNode:
                    dir.BuildListOfElements(files);
                    break;
                case PlaySequenceModeEnum.Sequence:
                    dir.BuildListOfElements(files);
                    break;
                case PlaySequenceModeEnum.LoopTrack:
                    dir.BuildListOfElements(files);
                    break;
                case PlaySequenceModeEnum.LoopAlbum:
                    dir.BuildListOfElements(files);
                    break;
                case PlaySequenceModeEnum.ShuffleTracks:
                    {
                        List<AxFileAudio> allFiles = new List<AxFileAudio>(1000);
                        dir.BuildListOfElements(allFiles);


                    }
                    break;
                case PlaySequenceModeEnum.ShuffleAlbums:
                    break;
                default:
                    break;
            }
            return files;
        }






        public void EnqueueElement(AxElement selElement)
        {
            if (selElement == null)
                return;

            if (selElement is AxFileAudio)
                AtmwPlayer.ExecuteAsync(new ApCommandPlay(selElement as AxFileAudio, ApCommandPlay.Type.Enqueue), fCachePath);
        }


        /*         /// <summary>
        /// Calculates next file in relation to current for player
        /// </summary>
        /// <param name="aCurrentFile"></param>
        /// <returns></returns>
        internal AxFile NextFile(AxFile aCurrentFile)
        {
            AxDirectory dr = (aCurrentFile.Parent as AxDirectory);
            if (dr == null)
                return null;

            switch (fPlaySequenceMode)
            {
                case PlaySequenceModeEnum.LoopTrack:
                    return aCurrentFile;
                case PlaySequenceModeEnum.LoopAlbum:
                    {
                        int ind = dr.files.IndexOf(aCurrentFile);
                        if (ind < dr.files.Count - 1)
                            return dr.files[ind + 1];
                        else
                            return dr.files[0];
                    }
                case PlaySequenceModeEnum.JustTheNode:
                    return null;
                default:
                    throw new Exception("Unsupported play sequence '" + fPlaySequenceMode.ToString() + "'");
            }
        }

         
        internal void Play(AxElement selElement, bool aShuffled)
        {
            fElementToPlay = selElement;
            if (selElement is AxDirectory)
            {   //Node contains subnodes
                List<AxFileAudio> files = new List<AxFileAudio>(1000);
                (selElement as AxDirectory).BuildListOfElements(files);
                CreateAndRunPlayList(files, aShuffled);
            }
            else if (selElement is AxFile)
            {   //Single node run
                RunWinamp((selElement as AxFile).PathName);
            }
        }

        [Obsolete("Implement in AxHierarchy")]
        public void BuildAudioFileList(AxDirectory aNode, List<AxFileAudio> aFileList)
        {
            foreach (AxDirectory aSubNode in aNode.dirs)
            {
                BuildAudioFileList(aSubNode, aFileList);
            }

            foreach (AxFile file in aNode.files)
            {
                if (file is AxFileAudio)
                    aFileList.Add(file as AxFileAudio);
            }
        }

        private void CreateAndRunPlayList(List<AxFileAudio> files, bool aShuffle)
        {
            string playListFileName = Application.StartupPath + "\\NbMedia.m3u"; //TODO: use temp dir
            using (StreamWriter playList = new StreamWriter(playListFileName, false, Encoding.Default))
            {
                int counter = 100; //Do not create lists longer than 1000 items.
                if (!aShuffle)
                {
                    foreach (AxFile file in files)
                    {
                        playList.WriteLine(file.PathName);
                        if (--counter <= 0)
                            break;
                    }
                }
                else
                {
                    Random rnd = new Random();
                    for (int i = files.Count; i > 0; i--)
                    {
                        int sample = rnd.Next(i);
                        playList.WriteLine(files[sample].PathName);
                        files.RemoveAt(sample);

                        if (--counter <= 0)
                            break;
                    }
                }
            }
            RunWinamp(playListFileName);
        }

        private void RunWinamp(string fileName)
        {
            if (String.IsNullOrEmpty(fileName))
                return;
            else if (!File.Exists(fWinampPath))
            {
                NbMessageBox.OK("Can't find '{0}'", fWinampPath);
            }


            Process MyProc = new Process();
            MyProc.StartInfo.FileName = fWinampPath;
            MyProc.StartInfo.Arguments = "\"" + fileName + "\"";

            MyProc.Start();
        }*/
    }
}
