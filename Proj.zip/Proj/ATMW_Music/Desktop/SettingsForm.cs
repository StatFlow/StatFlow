﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AtmwSettings;

namespace Desktop
{
    public partial class SettingsForm : Form
    {
        public SettingsForm(object aSettingsObj)
        {
            InitializeComponent();
            propertyGrid1.SelectedObject = aSettingsObj;
        }
    }
}
