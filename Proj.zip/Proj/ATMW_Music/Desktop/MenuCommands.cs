using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using Atmw.Xml; //AxElement and VisitorAction enviromnent
using Nb.Library.LogView;
using Desktop.Visitors;
using Desktop.Visitors.Desktop.Visitors;
using System.Threading.Tasks;
using Nb.Library; //LogViewControl environment 

namespace Desktop
{
    /// <summary>
    /// This class represents one action to be done on one AxElements. If effectively joins two environments:
    /// AxElement and VisitorAction enviromnent with LogViewControl environment (ILogCommand interface)
    /// </summary>
    public class MenuCommand : ILogCommand
    {
        private readonly string fName;
        private readonly VisitorAction fVisitorAction;
        private readonly AxElement Element;

        private readonly Action fAction;

        public MenuCommand(string aName, VisitorAction aAction, AxElement aElement)
        {
            fName = aName;
            fVisitorAction = aAction;
            Element = aElement;

            if (fVisitorAction == null)
                throw new ArgumentException("Action can't be set to null", "aAction");
            if (Element == null)
                throw new ArgumentException("Element can't be set to null", "aElement");
        }

        public MenuCommand(string aName, Action aAction)
        {
            fName = aName;
            fAction = aAction;

            if (fAction == null)
                throw new ArgumentException("Action can't be set to null", "aAction");
        }

        public string Name
        {
            get { return fName; }
        }

        public void Execute()
        {
            Task tsk = new Task(() =>  
                {
                    if (fVisitorAction != null)
                        fVisitorAction(Element);
                    else if (fAction != null)
                        fAction();
                }, TaskCreationOptions.LongRunning);
            
           //tsk.ContinueWith(t => NbMessageBox.Show("ATMW", "Processing finished", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk));
           tsk.Start();
        }

        public void HandleClick(object sender, EventArgs e)
        {
            Execute();
        }
    }

    /// <summary>
    /// Keeps the list of all types of operations on the Elements (visitors) and generates lists of MenuCommand for any given AxElement
    /// </summary>
    public class MenuCommmandController : IErrorLogger
    {
        

        private readonly VisitorAbstract[] fVisitors;
        private readonly LogViewControl fLogView;

        internal MenuCommmandController(LogViewControl aLogNiew, PlayController aPlayController)
        {
            fLogView = aLogNiew;
            fVisitors = new VisitorAbstract[] {
                new VisitorPlay(aPlayController),
                new VisitorEnqueue(aPlayController),
                new VisitorOpenFolder(),
                new VisitorOpenInMp3Tag(),
                new VisitorStatistics(),
                new VisitorCheckIntegrity(aLogNiew, this), //TODO: Allocate specific tabs for the logger
                new VisitorCheckSongNames(aLogNiew, this),
                new VisitorRenameFilesByID3(aLogNiew, this),
                new VisitorCheckLyrics(aLogNiew, this)
            };
        }


        internal IEnumerable<MenuCommand> GetElementMenuCommands(AxElement aElement, VisitorAbstract.Invocation aInvocation)
        {
            foreach (VisitorAbstract visitor in fVisitors)
            {
                if (!visitor.SupportsInvocation(aInvocation))
                    continue;

                VisitorAction action = aElement.AcceptVisitor(visitor);
                if (action != null)
                {
                    yield return new MenuCommand(visitor.Name, action, aElement);
                }
            }
        }


        #region IErrorLogger Members
        public void Log(AxElement aElement, string aDescriptionFormat, params object[] args)
        {
            CheckLogCount(fLogView);
            fLogView.Add(new LogViewEntry(Severity.Error, String.Format(aDescriptionFormat, args), aElement, this));
        }

        public void Log(AxElement aElement, string mesage)
        {
            CheckLogCount(fLogView);
            fLogView.Add(new LogViewEntry(Severity.Error, mesage, aElement, this));
        }

        public void Log(string aMenuName, VisitorAction aAction, AxElement aElement, string aDescriptionFormat, params object[] args)
        {
            CheckLogCount(fLogView);
            MenuCommand cmd = new MenuCommand(aMenuName, aAction, aElement);
            fLogView.Add(new LogViewEntry(Severity.Error, String.Format(aDescriptionFormat, args), aElement, this, cmd.ToEnumerable()));
        }

        public void Log(string aMenuName, Action aAction, AxElement aElement, string aDescriptionFormat, params object[] args)
        {
            CheckLogCount(fLogView);
            MenuCommand cmd = new MenuCommand(aMenuName, aAction);
            fLogView.Add(new LogViewEntry(Severity.Error, String.Format(aDescriptionFormat, args), aElement, this, cmd.ToEnumerable()));
        }

        public void Log(AxElement aElement, string aMessage, params Tuple<string, Action>[] aCommands)
        {
            CheckLogCount(fLogView);
            var cmds = aCommands.Safe().Select(cm => new MenuCommand(cm.Item1, cm.Item2));
            fLogView.Add(new LogViewEntry(Severity.Error, aMessage, aElement, this, cmds));
        }

        private static void CheckLogCount(LogViewControl cnt)
        {
            if (cnt.Count >= 1000)
            {
                cnt.Add(new LogViewEntry(Severity.Message, "The number of messages exceeded 1000. The process is stopped"));
                throw new NbLoggerFullException();
            }
        }
        #endregion
    }
}
