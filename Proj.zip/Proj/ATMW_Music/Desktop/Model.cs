using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

using Atmw.Xml;
using Nb.Library.LogView;
using Nb.Library;
using NbTools;

namespace Desktop
{
    public class Model
    {
        private XmlManager fXmlManager;
        private LogViewContainer fLogViewContainer;

        public Model(LogViewContainer aLogViewContainer)
        {
            fXmlManager = new XmlManager();
            fLogViewContainer = aLogViewContainer;
        }

        public void LoadDataFromDisk(string aTrackDir, string aLyricsDir, string aGraphicDir)
        {
            BuildTreeOfElementsFromDisk(aTrackDir, aLyricsDir, aGraphicDir);
            fXmlManager.SaveXml(Root, aTrackDir + ".xml");
        }

        public bool LoadDataFromXml(string aTracksDir, string aLyricsDir, string aGraphicsPath)
        {
            string fileName = aTracksDir + ".xml";
            if (File.Exists(fileName))
            {
                fRoot = fXmlManager.LoadXml(aTracksDir, aLyricsDir, aGraphicsPath);
                fRoot.Resolve();
                return true;
            }
            else
                return false;
        }

        public void SaveXmlFile()
        {
            string filePath = Root.PathName + ".xml";

            FileInfo fi = new FileInfo(filePath);
            string timestamped = NbDir.TimeStampTheFile(fi);
            fi.MoveTo(timestamped);

            fXmlManager.SaveXml(Root, filePath);
        }

        /*public void UpdateDataInXml(string aRootDir)
        {
            fRoot = fXmlManager.LoadXml(aRootDir + ".xml");
            fRoot.Resolve();

            List<ElementChange> changes = new List<ElementChange>(1000);
            fRoot.Update(changes);

            if (changes.Count == 0)
                NbMessageBox.OK("No changes");
            else
            {
                StringBuilder bld = new StringBuilder();
                foreach (ElementChange ec in changes)
                {
                    bld.Append(ec.Type.ToString());
                    bld.Append(" ");
                    bld.AppendLine(ec.Element.PathName);
                }
                NbMessageBox.OK(bld.ToString());
            }

            fXmlManager.SaveXml(Root, aRootDir + ".xml");
        }*/

        public void UpdateDataInXml(AxElement aElement)
        {
            List<ElementChange> changes = new List<ElementChange>(1000);
            aElement.Update(changes);

            if (changes.Count == 0)
                NbMessageBox.OK("No changes");
            else using (LogViewSession logSess = fLogViewContainer.GetLogSession("Update"))
                {
                    foreach (ElementChange ec in changes)
                    {
                        string mess = String.Format("{0} {1}", ec.Type.ToString(), ec.Element.PathName);
                        logSess.Add(new LogViewEntry(Severity.Message, mess));
                    }
                }
        }

        public AxRoot Root
        {
            get { return fRoot; }
        } AxRoot fRoot;

        private void BuildTreeOfElementsFromDisk(string aTrackRoot, string aLyricsRoot, string aGraphicsRoot)
        {
            fRoot = AxRoot.CreateRoot(new DirectoryInfo(aTrackRoot), new DirectoryInfo(aLyricsRoot), new DirectoryInfo(aGraphicsRoot));
        }
    }
}
