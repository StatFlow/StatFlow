using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Atmw.Xml;
using System.Diagnostics;
using Atmw.Player;
using System.Globalization;
using Nb.Library;
using Nb.Library.LogView;
using System.Collections;
using AtmwSettings;
using System.Threading.Tasks;
using System.IO;
using System.Linq;
using NbTools;

namespace Desktop
{
    public partial class MainForm : Form
    {
        private readonly Model fModel;
        private readonly MenuCommmandController fMenuCommmandController;
        private readonly PlayController fPlayController;

        private readonly MouseEventHandler fProgressBarMouseMoveHandler;
        private readonly ApEvents fApEvents;

        private Timer fListUpdateTimer;

        SortedList<string, AxElement> repeatedItems;


        public MainForm(string[] aArgs)
        {
            InitializeComponent();
            if (aArgs.Length > 0)
                config.LoadFile(aArgs[0]); //First parameter is the settings file, optional

            fProgressBarMouseMoveHandler = new MouseEventHandler(fProgressBar_MouseMove);
            fApEvents = AtmwPlayer.Events(this);
            fApEvents.PlayStateChanged += new ApEvents.PlayStateDelegate(fPlayer_OnStateChanged);

            fListUpdateTimer = new Timer();
            fListUpdateTimer.Interval = 300;
            fListUpdateTimer.Tick += new EventHandler(fListUpdateTimer_Tick);

            fModel = new Model(logViewContainer1);
            fPlayController = new PlayController(config.Instance.directories.player_cache);
            LogViewControl lvc = logViewContainer1.CreateLogTab("Check");
            fMenuCommmandController = new MenuCommmandController(lvc, fPlayController);

            repeatedItems = new SortedList<string, AxElement>(1000, StringComparer.OrdinalIgnoreCase);

            try
            {
                if (fModel.LoadDataFromXml(config.Instance.directories.tracks, config.Instance.directories.lyrics, config.Instance.directories.album_art))
                    RebuildTreeView();
                else
                    NbMessageBox.OK("Can't open xml file for '{0}'", config.Instance.directories.tracks);
            }
            catch (Exception ex)
            {
                ShowExceptionMessage(ex);
            }

        }

        void SelectElementInTheTree(AxElement aElem)
        {
            TreeNode node = aElem.Tag as TreeNode;
            if (node != null)
            {
                treeView1.BeginUpdate();
                //treeView1.CollapseAll();

                /*TreeNode topMost = node; //Show all the parents of the selected node.
                while (topMost.Parent != null)
                    topMost = topMost.Parent;
                topMost.EnsureVisible();*/

                node.EnsureVisible();
                treeView1.SelectedNode = node;
                treeView1.EndUpdate();
            }
        }

        void fPlayer_OnStateChanged(string aStateName, string aFile)
        {
            AxElement el = fModel.Root.FindElement(aFile);
            fStatusPlayer.Text = aStateName;

            if (aStateName == "Playing" && el != null)
                SelectElementInTheTree(el);

            /*if (aStateName == "Stopped" && treeView1.SelectedNode != null)
            {
                AxFile nextFile = fPlayController.NextFile(aFile);
                if (nextFile != null)
                {
                    AtmwPlayer.ExecuteAsync(new ApCommandPlay(nextFile, ApCommandPlay.PlayTimeEnum.Immediate));
                }
            }

            if (aStateName == "Playing" && MainToolbarPlayerSelectsButton.Checked == true)
            {
                TreeNode node = aFile.Tag as TreeNode;
                if (node != null)
                {
                    treeView1.SelectedNode = node;
                    node.EnsureVisible();
                }
                //Debug.WriteLine("Select in tree: " + aFile.Name);
                //TODO: show album picture
            }*/
        }

        private void ShowExceptionMessage(Exception ex)
        {
            StringBuilder str = new StringBuilder("Exception was encountered: \r\n\r\n" + ex.Message + "\r\n");
            while (ex.InnerException != null)
            {
                ex = ex.InnerException;
                str.AppendLine(ex.Message);
            }
            NbMessageBox.OK(str.ToString());
        }




        private void RebuildTreeView()
        {
            if (InvokeRequired)
            {
                Invoke(new Action(() => RebuildTreeView()));
                return;
            }

            SuspendLayout();
            treeView1.BeginUpdate();
            this.treeView1.Nodes.Clear();

            TreeNode rootNode = CreateTreeNode(treeView1.Nodes, fModel.Root);
            RebuildTreeRecursive(fModel.Root, rootNode);

            rootNode.Expand();
            treeView1.SelectedNode = rootNode;
            treeView1.EndUpdate();
            ResumeLayout();
        }



        private void RebuildTreeRecursive(AxDirectory baseAx, TreeNode baseNode)
        {
            foreach (AxDirectory dir in baseAx.dirs)
            {
                TreeNode dirNode = CreateTreeNode(baseNode.Nodes, dir);
                RebuildTreeRecursive(dir, dirNode);
            }

            foreach (AxFile file in baseAx.files)
            {
                if (file is AxFileAudio)  //Create tree only out of Audio Files
                {
                    TreeNode fileNode = CreateTreeNode(baseNode.Nodes, file);
                }
            }
        }

        private TreeNode CreateTreeNode(TreeNodeCollection aParentCollection, AxElement anElement)
        {
            int iconIndex = IconIndex(anElement);
            TreeNode treeNode = new TreeNode(anElement.Name, iconIndex, iconIndex);
            treeNode.Tag = anElement;
            anElement.Tag = treeNode;

            if (aParentCollection != null)
                aParentCollection.Add(treeNode);

            return treeNode;
        }

        private int IconIndex(AxElement aEl)
        {
            string iconName = aEl.IconName;
            if (String.IsNullOrEmpty(iconName))
                iconName = aEl.GetType().Name;

            int res = MainImageList.Images.IndexOfKey(iconName);
            return (res == -1) ? 1 : res;
        }

        private void lvAlphabeticList_RetrieveVirtualItem(object sender, RetrieveVirtualItemEventArgs e)
        {
            AxElement file = repeatedItems.Values[e.ItemIndex];
            e.Item = new ListViewItem(repeatedItems.Keys[e.ItemIndex], IconIndex(file));
            e.Item.Tag = file;
        }

        private void RebuildList(AxElement aSelElement)
        {
            AxDirectory fRootNode = aSelElement as AxDirectory;
            if (fRootNode == null) //This is a file, so don't rebuild the list
                return;

            repeatedItems.Clear();
            BuildListRecursive(fRootNode, repeatedItems, quickSearchTextBox.Text);
            lvAlphabeticList.VirtualListSize = repeatedItems.Count;
            lvAlphabeticList.Refresh();
        }

        private void BuildListRecursive(AxDirectory baseAx, SortedList<string, AxElement> aRepeatedItems, string aFilter)
        {
            foreach (AxDirectory dir in baseAx.dirs)
            {
                if (dir.Name.IndexOf(aFilter, StringComparison.CurrentCultureIgnoreCase) >= 0)
                    AddElementToRepeatedItems(dir, aRepeatedItems);

                BuildListRecursive(dir, aRepeatedItems, aFilter);
            }

            foreach (AxFile file in baseAx.files)
            {
                if (file is AxFileAudio)
                {
                    if (file.Name.IndexOf(aFilter, StringComparison.CurrentCultureIgnoreCase) >= 0)
                        AddElementToRepeatedItems(file, aRepeatedItems);
                }
            }
        }

        private static void AddElementToRepeatedItems(AxElement file, SortedList<string, AxElement> aRepeatedItems)
        {
            string name = file.Name;

            AxElement el;
            if (aRepeatedItems.TryGetValue(name, out el))
            {
                AxAlbum album;
                file.ParentOfType(out album);
                if (album != null)
                    name += " [" + album.Name + "]";
                else
                    name += " [" + el.Parent.Name + "]"; //If album is not found use simply a Parent
            }

            while (aRepeatedItems.ContainsKey(name)) //Make sure there are no repetitions
            {
                name = name + "~";
            }
            aRepeatedItems.Add(name, file);
        }





        #region Progress Bar and Text
        private bool fProgressBarMouseDown = false;
        void fPlayer_OnProgressChanged(int aPercent, string aTime)
        {
            if (!fProgressBarMouseDown) //Don't update is mouse is down
            {
                fProgressBar.Value = aPercent;
                fProgressLabel.Text = aTime;
            }
        }

        private void fProgressBar_MouseDown(object sender, MouseEventArgs e)
        {
            fProgressBarMouseDown = true;
            fProgressBar.Value = Convert.ToInt32(X2Percent(e.X));

            fProgressBar.MouseMove += fProgressBarMouseMoveHandler; //Start listening to mouse move
        }

        private void fProgressBar_MouseMove(object sender, MouseEventArgs e)
        {
            fProgressBar.Value = Convert.ToInt32(X2Percent(e.X));
        }

        private double X2Percent(int X)
        {
            double percent = X * 100 / (fProgressBar.Width - 3); //2 for margin
            return Math.Min(100, Math.Max(0, percent));
        }
        #endregion




        #region Toolbar
        private void mtlbFileSave_Click(object sender, EventArgs e)
        {
            fModel.SaveXmlFile();
        }

        private void mtlbFileExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainToolBarLoadButton_Click(object sender, EventArgs e)
        {
            Task tsk = new Task(() =>
            {
                try
                {
                    Directories dirs = config.Instance.directories;
                    fModel.LoadDataFromDisk(dirs.tracks, dirs.lyrics, dirs.album_art);
                    RebuildTreeView();
                }
                catch (Exception ex)
                {
                    ShowExceptionMessage(ex);
                }
            }, TaskCreationOptions.LongRunning);

            tsk.ContinueWith(t => NbMessageBox.Show("Disk loading finished", "ATMW", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Asterisk));
            tsk.Start();
        }

        private void MainToolbarUpdateButton_Click(object sender, EventArgs e)
        {
            try
            {
                fModel.UpdateDataInXml(GetSelectedElement());
                RebuildTreeView();
            }
            catch (Exception ex)
            {
                ShowExceptionMessage(ex);
            }
        }


        private void MainToolbarShuffleButton_Click(object sender, EventArgs e)
        {
            //fPlayController.Play(GetSelectedElement(), true);
        }

        private void MainToolbarPlayButton_Click(object sender, EventArgs e)
        {
            //TODO: reuse code with tree view and list view
        }

        //Play mode selectors
        private void justTheNodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainToolbarPlayModeButton.Text = "Just the Node";
            fPlayController.PlaySequenceMode = PlaySequenceModeEnum.JustTheNode;
        }

        private void sequenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainToolbarPlayModeButton.Text = "Sequence";
            fPlayController.PlaySequenceMode = PlaySequenceModeEnum.Sequence;
        }

        private void shuffleTracksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainToolbarPlayModeButton.Text = "Shuffle tracks";
            fPlayController.PlaySequenceMode = PlaySequenceModeEnum.ShuffleTracks;
        }

        private void shuffleAlbumsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainToolbarPlayModeButton.Text = "Shuffle Albums";
            fPlayController.PlaySequenceMode = PlaySequenceModeEnum.ShuffleAlbums;
        }

        private void loopTrackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainToolbarPlayModeButton.Text = "Loop Track";
            fPlayController.PlaySequenceMode = PlaySequenceModeEnum.LoopTrack;
        }

        private void loopAlbumToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainToolbarPlayModeButton.Text = "Loop Album";
            fPlayController.PlaySequenceMode = PlaySequenceModeEnum.LoopAlbum;
        }


        private AxElement GetSelectedElementN()
        {
            if (treeView1.SelectedNode == null)
            {
                if (DialogResult.OK == NbMessageBox.Show("There is no selected elements on the tree.\r\nDo you want to run the operation on the root node?",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Question))
                    return fModel.Root;
                else
                    return null;
            }
            else
            {
                AxElement selElement = treeView1.SelectedNode.Tag as AxElement;
                if (selElement == null)
                    throw new NbException("Node '{0}' doesn't contain an Element", treeView1.SelectedNode.Text);
                else
                    return selElement;
            }
        }

        private AxElement GetSelectedElement()
        {
            AxElement el = GetSelectedElementN();
            if (el == null)
                throw new NbException("The node for this operation was not selected");
            else
                return el;
        }

        #endregion


        private void treeViewContextMenu_Opening(object sender, CancelEventArgs e)
        {
            AxElement el = GetSelectedElementN();
            if (el != null)
            {
                treeViewContextMenu.Items.Clear();

                foreach (MenuCommand mCmd in fMenuCommmandController.GetElementMenuCommands(el, VisitorAbstract.Invocation.RightClick))
                {
                    ToolStripItem menuItem = new ToolStripMenuItem(mCmd.Name);
                    menuItem.Tag = mCmd;
                    menuItem.Click += mCmd.HandleClick;
                    treeViewContextMenu.Items.Add(menuItem);
                }

                if (treeViewContextMenu.Items.Count > 0)
                    return; //The menu was built successfully - don't cancel
            }
            e.Cancel = true;
        }

        private void treeView1_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            AxElement el = e.Node.Tag as AxElement;
            if (el == null)
                throw new NbException("Node '{0}' doesn't contain an Element", treeView1.SelectedNode.Text);

            foreach (MenuCommand mCmd in fMenuCommmandController.GetElementMenuCommands(el, VisitorAbstract.Invocation.DoubleClick))
            {
                mCmd.Execute();
                break;
            }
        }

        private void treeView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter)
                return;

            AxElement el = treeView1.SelectedNode.Tag as AxElement;
            if (el == null)
                throw new NbException("Node '{0}' doesn't contain an Element", treeView1.SelectedNode.Text);

            foreach (MenuCommand mCmd in fMenuCommmandController.GetElementMenuCommands(el, VisitorAbstract.Invocation.DoubleClick))
            {
                mCmd.Execute();
                break;
            }
        }

        private void treeView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (!(e.Button == MouseButtons.Right))
                return;

            TreeNode tn = treeView1.GetNodeAt(e.Location);
            if (tn == null)
                return;

            treeView1.SelectedNode = tn;    //Select the node, where the right button was clicked
        }



        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            AxElement selElement = e.Node.Tag as AxElement;
            if (selElement == null)
                throw new NbException("Node '{0}' doesn't contain an Element", treeView1.SelectedNode.Text);

            fListUpdateTimer.Stop(); //Restart
            fListUpdateTimer.Start();
        }




        private void listViewContextMenu_Opening(object sender, CancelEventArgs e)
        {
            SortedList<string, List<MenuCommand>> cmdMap = new SortedList<string, List<MenuCommand>>(20);
            foreach (int index in lvAlphabeticList.SelectedIndices)
            {
                AxElement el = repeatedItems.Values[index];
                if (el == null)
                    continue;

                foreach (MenuCommand cmd in fMenuCommmandController.GetElementMenuCommands(el, VisitorAbstract.Invocation.RightClick))
                {
                    List<MenuCommand> cmdList;
                    if (!cmdMap.TryGetValue(cmd.Name, out cmdList))
                    {
                        cmdList = new List<MenuCommand>(20);
                        cmdMap.Add(cmd.Name, cmdList);
                    }
                    cmdList.Add(cmd);
                }
            }

            listViewContextMenu.Items.Clear();
            foreach (KeyValuePair<string, List<MenuCommand>> pair in cmdMap)
            {
                ToolStripMenuItem item = new ToolStripMenuItem(pair.Key);
                item.Tag = pair.Value;
                foreach (MenuCommand cmd in pair.Value)
                    item.Click += cmd.HandleClick; //Many handles
                listViewContextMenu.Items.Add(item);
            }

            if (listViewContextMenu.Items.Count == 0)
                e.Cancel = true;
        }

        private void lvAlphabeticList_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lvAlphabeticList.SelectedIndices.Count != 1)
                return;

            int index = lvAlphabeticList.SelectedIndices[0];
            AxElement el = repeatedItems.Values[index]; //TODO: support multiple select
            if (el == null)
                throw new NbException("Node '{0}' doesn't contain an Element", treeView1.SelectedNode.Text);

            if (el is AxFile || el is AxAlbum)
            {
                foreach (MenuCommand mCmd in fMenuCommmandController.GetElementMenuCommands(el, VisitorAbstract.Invocation.DoubleClick))
                {
                    mCmd.Execute();
                    break;
                }
            }
            else
                SelectElementInTheTree(el);
        }




        private void quickSearchTextBox_TextChanged(object sender, EventArgs e)
        {
            fListUpdateTimer.Stop(); //Restart
            fListUpdateTimer.Start();
        }

        void fListUpdateTimer_Tick(object sender, EventArgs e)
        {
            fListUpdateTimer.Stop();
            AxElement sel = GetSelectedElement();
            propertyGrid1.SelectedObject = sel;
            RebuildList(sel);
        }

        private void btCheckerOptions_Click(object sender, EventArgs e)
        {
            SettingsForm frm = new SettingsForm(config.Instance.checker);
            if (frm.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
                config.Instance.Save();
            else
                config.Reload();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            config.Instance.Save();
        }

        private void statsByExtensionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder str = new StringBuilder();
            str.AppendLine("Tracks:");
            foreach (var line in DirExtensionReport(config.Instance.directories.tracks))
                str.AppendLine(line);

            str.AppendLine();
            str.AppendLine("Graphics:");
            foreach (var line in DirExtensionReport(config.Instance.directories.album_art))
                str.AppendLine(line);

            str.AppendLine();
            str.AppendLine("Lyrics:");
            foreach (var line in DirExtensionReport(config.Instance.directories.lyrics))
                str.AppendLine(line);



            var a = Directory.EnumerateFiles(config.Instance.directories.tracks, "*.*", SearchOption.AllDirectories)
                  .Where(f => f.Substring(f.LastIndexOf('.')).ToLowerInvariant() == ".jpg").Take(10);
            foreach (var line in a)
                str.AppendLine(line);


            NbMessageBox.Show(str.ToString(), "File extension statistics");
        }

        private static IEnumerable<string> DirExtensionReport(string dir)
        {
            return Directory.EnumerateFiles(dir, "*.*", SearchOption.AllDirectories)
                  .Select(f => f.Substring(f.LastIndexOf('.')).ToLowerInvariant())
                  .GroupBy(f => f).Select(g => Tuple.Create(g.Key, g.Count())).OrderByDescending(t => t.Item2)
                  .Select(t => String.Format("{0}: {1}", t.Item1, t.Item2));
        }
    }
}