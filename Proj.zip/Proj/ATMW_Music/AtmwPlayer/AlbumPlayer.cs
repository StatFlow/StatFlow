using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Atmw.Xml;

namespace Atmw.Player
{
    public partial class AlbumPlayer : UserControl
    {
        public delegate double GetPosition(out AxFile aFile);
        

        private List<AlbumPlayerEntry> fItems;
        public const int fMargin = 10;
        public const int fHeight = 15;
        public const int fSecondPerPixel = 10;

        private Rectangle fTheBar;

        public event AlbumPlayerEntryEventHandler OnItemClick; 


        public AlbumPlayer()
        {
            InitializeComponent();
            fItems = new List<AlbumPlayerEntry>(100);
            fTheBar = new Rectangle(fMargin, fMargin, 0, fHeight);
        }

        public void AddItem(AxFile aFile, object aTag)
        {
            AlbumPlayerEntry entry = new AlbumPlayerEntry(aFile, aTag, fMargin, fTheBar.Right);
            fTheBar.Width += entry.Rectangle.Width + 1;
            fItems.Add(entry);
        }

        internal void Clear()
        {
            fItems.Clear();
            fTheBar.Width = 0;
        }

        //Setting position delegate
        public GetPosition SetPositionDelegate
        {
            set { fGetPosition = value; }
        } private GetPosition fGetPosition;

        protected override void OnPaint(PaintEventArgs e)
        {
            for(int i = 0; i < fItems.Count; ++i)
            {
                AlbumPlayerEntry ent = fItems[i];
                e.Graphics.FillRectangle(new SolidBrush(ent.Color), ent.Rectangle);
                if (i != fItems.Count - 1) //Do not draw divider for the last one
                    e.Graphics.DrawLine(Pens.Black, ent.Rectangle.Right, ent.Rectangle.Top, ent.Rectangle.Right, ent.Rectangle.Bottom); //Divider
            }

            int bott = fTheBar.Bottom + fMargin;

            int pixPer10Min = 10*60 / fSecondPerPixel;
            for(int i = fTheBar.Left; i <= fTheBar.Right; i+= pixPer10Min)
            {
                int height = ((i - fTheBar.Left) / pixPer10Min % 6 == 0) ? 6 : 2; //Long marks on hours, short on 10 min.
                e.Graphics.DrawLine(Pens.Black, i, bott, i, bott + height); //Minute marks
            }

            e.Graphics.DrawRectangle(Pens.DarkGray, fTheBar);
        }


        protected override void OnMouseMove(MouseEventArgs e)
        {
            if (fTheBar.Contains(e.Location))
            {
                Cursor = Cursors.Hand;
            }
            else
            {
                Cursor = Cursors.Default;
            }
       }

        protected override void OnMouseLeave(EventArgs e)
        {
            Cursor = Cursors.Default;
        }

        protected override void OnMouseClick(MouseEventArgs e)
        {
            AlbumPlayerEntryEventHandler evt = OnItemClick;
            if (evt == null)
                return;
            
            foreach (AlbumPlayerEntry entr in fItems)
            {
                if (entr.Rectangle.Contains(e.Location))
                {
                    evt.Invoke(entr);
                    break;
                }
            }
        }
    }
}
