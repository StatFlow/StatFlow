﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace Atmw.Player
{
    public partial class AlarmSettings : Form
    {
        private DateTime fStart;

        public AlarmSettings()
        {
            InitializeComponent();
        }

        private void tbStart_Validating(object sender, CancelEventArgs e)
        {
            if (!DateTime.TryParseExact(tbStart.Text, "HH:mm", Thread.CurrentThread.CurrentCulture, System.Globalization.DateTimeStyles.None, out fStart))
            {
                e.Cancel = true;
                tbStart.BackColor = Color.PaleVioletRed;
            }
            else
                tbStart.BackColor = SystemColors.Window;
        }
    }
}
