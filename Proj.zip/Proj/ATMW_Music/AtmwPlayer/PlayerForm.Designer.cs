namespace Atmw.Player
{
    partial class PlayerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlayerForm));
            this.fWindowsMediaPlayer = new AxWMPLib.AxWindowsMediaPlayer();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stStatusText = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.enableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.disableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.albumPlayer1 = new Atmw.Player.AlbumPlayer();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.lvPlayList = new System.Windows.Forms.ListView();
            this.clTitle = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clDuration = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            ((System.ComponentModel.ISupportInitialize)(this.fWindowsMediaPlayer)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // fWindowsMediaPlayer
            // 
            this.fWindowsMediaPlayer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fWindowsMediaPlayer.Enabled = true;
            this.fWindowsMediaPlayer.Location = new System.Drawing.Point(0, 368);
            this.fWindowsMediaPlayer.Name = "fWindowsMediaPlayer";
            this.fWindowsMediaPlayer.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("fWindowsMediaPlayer.OcxState")));
            this.fWindowsMediaPlayer.Size = new System.Drawing.Size(759, 45);
            this.fWindowsMediaPlayer.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stStatusText});
            this.statusStrip1.Location = new System.Drawing.Point(0, 413);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(759, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // stStatusText
            // 
            this.stStatusText.Name = "stStatusText";
            this.stStatusText.Size = new System.Drawing.Size(39, 17);
            this.stStatusText.Text = "Status";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSplitButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(759, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enableToolStripMenuItem,
            this.disableToolStripMenuItem,
            this.changeToolStripMenuItem});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton1.Text = "toolStripSplitButton1";
            this.toolStripSplitButton1.ButtonClick += new System.EventHandler(this.toolStripSplitButton1_ButtonClick);
            // 
            // enableToolStripMenuItem
            // 
            this.enableToolStripMenuItem.Checked = true;
            this.enableToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.enableToolStripMenuItem.Name = "enableToolStripMenuItem";
            this.enableToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.enableToolStripMenuItem.Text = "Enable";
            // 
            // disableToolStripMenuItem
            // 
            this.disableToolStripMenuItem.Name = "disableToolStripMenuItem";
            this.disableToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.disableToolStripMenuItem.Text = "Disable";
            // 
            // changeToolStripMenuItem
            // 
            this.changeToolStripMenuItem.Name = "changeToolStripMenuItem";
            this.changeToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.changeToolStripMenuItem.Text = "Change...";
            this.changeToolStripMenuItem.Click += new System.EventHandler(this.changeToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.albumPlayer1);
            this.panel1.Controls.Add(this.splitter1);
            this.panel1.Controls.Add(this.lvPlayList);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(759, 343);
            this.panel1.TabIndex = 3;
            // 
            // albumPlayer1
            // 
            this.albumPlayer1.AutoScroll = true;
            this.albumPlayer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.albumPlayer1.Location = new System.Drawing.Point(270, 0);
            this.albumPlayer1.Name = "albumPlayer1";
            this.albumPlayer1.Size = new System.Drawing.Size(489, 343);
            this.albumPlayer1.TabIndex = 2;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(267, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 343);
            this.splitter1.TabIndex = 1;
            this.splitter1.TabStop = false;
            // 
            // lvPlayList
            // 
            this.lvPlayList.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clTitle,
            this.clDuration});
            this.lvPlayList.Dock = System.Windows.Forms.DockStyle.Left;
            this.lvPlayList.HideSelection = false;
            this.lvPlayList.LabelWrap = false;
            this.lvPlayList.Location = new System.Drawing.Point(0, 0);
            this.lvPlayList.MultiSelect = false;
            this.lvPlayList.Name = "lvPlayList";
            this.lvPlayList.Size = new System.Drawing.Size(267, 343);
            this.lvPlayList.TabIndex = 0;
            this.lvPlayList.UseCompatibleStateImageBehavior = false;
            this.lvPlayList.View = System.Windows.Forms.View.Details;
            this.lvPlayList.DoubleClick += new System.EventHandler(this.lvPlayList_DoubleClick);
            // 
            // clTitle
            // 
            this.clTitle.Text = "Text";
            this.clTitle.Width = 194;
            // 
            // clDuration
            // 
            this.clDuration.Text = "Duration";
            this.clDuration.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.clDuration.Width = 68;
            // 
            // PlayerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 435);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.fWindowsMediaPlayer);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PlayerForm";
            this.Text = "PlayerForm";
            ((System.ComponentModel.ISupportInitialize)(this.fWindowsMediaPlayer)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer fWindowsMediaPlayer;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel stStatusText;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView lvPlayList;
        private System.Windows.Forms.ColumnHeader clTitle;
        private System.Windows.Forms.ColumnHeader clDuration;
        private System.Windows.Forms.Splitter splitter1;
        private AlbumPlayer albumPlayer1;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem enableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem disableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeToolStripMenuItem;


    }
}