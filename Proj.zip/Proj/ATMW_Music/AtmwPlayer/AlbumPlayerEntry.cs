using System;
using System.Collections.Generic;
using System.Text;
using Atmw.Xml;
using System.Drawing;

namespace Atmw.Player
{

    public delegate void AlbumPlayerEntryEventHandler(AlbumPlayerEntry aFile);

    public class AlbumPlayerEntry
    {
        public readonly AxFile File;
        public readonly Rectangle Rectangle;
        public readonly Color Color;
        public readonly object Tag;


        internal AlbumPlayerEntry(AxFile fl, object aTag, int top, int left)
        {
            File = fl;
            Tag = aTag;
            int width = Convert.ToInt32(fl.duration / AlbumPlayer.fSecondPerPixel);
            Rectangle = new Rectangle(left, top, width, AlbumPlayer.fHeight);
            Color = StringToColor(fl.Name);
        }

        public static Color StringToColor(string aStr)
        {
            int hash = aStr.GetHashCode();
            byte b = (byte)((hash & 0x7f) + 0x70);
            byte g = (byte)(((hash >> 8) & 0x7f) + 0x70);
            byte r = (byte)(((hash >> 16) & 0x7f) + 0x70);

            return Color.FromArgb(r, g, b);
        }
    }
}
