using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;
using System.Diagnostics;
using Atmw.Xml;
using Nb.Library;
using System.IO;
using NbTools;

namespace Atmw.Player
{
    public static class AtmwPlayer
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                fPlayer = new PlayerForm(fEvents, null);
                if (args.GetLength(0) > 0)
                {
                    ApCommandPlay cmd = new ApCommandPlay(ApCommandPlay.Type.Start);
                    AxRoot dir = GetAxDirByPath(args[0], null, null); //Do not provide lyrics path and graphic path to the player
                    dir.BuildListOfElements(cmd.Files);
                    fPlayer.ExecuteCommand(cmd);
                }
                fPlayer.ShowDialog();
                fPlayer = null;
            }
            catch (Exception ex)
            {
                NbMessageBox.OK(NbException.Exception2String(ex));
            }
        }

        public static AxRoot GetAxDirByPath(string aTrackPath, string aLyricsPath, string aGraphicsPath)
        {
            DirectoryInfo di;
            if (File.Exists(aTrackPath))
                di = new FileInfo(aTrackPath).Directory;
            else if (Directory.Exists(aTrackPath))
                di = new DirectoryInfo(aTrackPath);
            else
                throw new NbException("Can't find tracks path: '{0}'", aTrackPath);

            DirectoryInfo li = new DirectoryInfo(aLyricsPath);
            if (!li.Exists)
                throw new NbException("Can't find lyrics path: '{0}'", aLyricsPath);

            DirectoryInfo gr = new DirectoryInfo(aGraphicsPath);
            if (!gr.Exists)
                throw new NbException("Can't find graphics path: '{0}'", aGraphicsPath);

            AxRoot root = AxRoot.CreateRoot(di, li, gr);
            return root;
        }


        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Exception ex = e.ExceptionObject as Exception;
            if (ex == null)
                NbMessageBox.OK("Unhadled domain exception with unknown type: '{0}'", e.ExceptionObject.GetType().Name);
            else
                NbMessageBox.OK("Domain Exception: \r\n" + NbException.Exception2String(ex));
        }

        static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
        {
            if (e.Exception is NbExceptionUserCancelled)
                return; //Do not show "User cancelled exception"
            else
                NbMessageBox.OK("Thread Exception: \r\n" + NbException.Exception2String(e.Exception));
        }










        static Thread fPlayerThread;

        [STAThread]
        private static void ThreadFunc(object obj)
        {
            Debug.Write("Player thread started");
            try
            {
                fPlayer = new PlayerForm(fEvents, obj as String);
                fPlayer.ShowDialog();
                fPlayer = null;
            }
            catch (Exception e)
            {
                NbMessageBox.Show("Player thread exception " + e.Message);
            }
        }

        private static PlayerForm PlayerForm(string cachePathN)
        {
            if (fPlayer == null)
            {
                fPlayerThread = new Thread(ThreadFunc);
                if (!fPlayerThread.TrySetApartmentState(ApartmentState.STA)) //Otherwise the Media Player complains
                    throw new Exception("Can't set player window thread state to STA");
                fPlayerThread.Start(cachePathN);

                while (fPlayer == null)
                {
                    Thread.Sleep(300);
                }
            }
            return fPlayer;
        }
        private static PlayerForm fPlayer;


        public static ApEvents Events(Form aForm)
        {
            if (fEvents.fForm == null)
            {
                fEvents.Inititilise(aForm);
            }
            return fEvents;
        }
        private static ApEvents fEvents = new ApEvents();


        public static void ExecuteAsync(ApCommand aCommand, string cacheDirN)
        {
            PlayerForm form = PlayerForm(cacheDirN);
            form.BeginInvoke(new PlayerForm.ExecuteCommandDelegate(form.ExecuteCommand),
                new object[] { aCommand });
        }

        public static void ExecuteSync(ApCommand aCommand, string cacheDirN)
        {
            PlayerForm form = PlayerForm(cacheDirN);
            form.Invoke(new PlayerForm.ExecuteCommandDelegate(form.ExecuteCommand),
                new object[] { aCommand });
        }
    }

    public class ApEvents
    {
        public delegate void PlayStateDelegate(string aPlayState, string aPath);

        internal Form fForm;
        internal void Inititilise(Form aForm) //Must be initialised with the main form in order to raise events in the proper thread
        {
            fForm = aForm;
        }

        public event PlayStateDelegate PlayStateChanged;
        internal void PlayStateChanges(string aPlayState, string aPath)
        {
            if (PlayStateChanged != null)
            {
                PlayStateChanged(aPlayState, aPath);
            }
        }
    }



    public abstract class ApCommand
    {
    }

    public class ApCommandPlay : ApCommand
    {
        public enum Type { Start, Enqueue };

        public readonly List<AxFileAudio> Files;
        public readonly Type PlayTime;

        public ApCommandPlay(AxFileAudio aFile, Type aPlayType)
            : this(aPlayType)
        {
            AddFile(aFile);
        }

        public ApCommandPlay(Type aPlayType)
        {
            Files = new List<AxFileAudio>(100);
            PlayTime = aPlayType;
        }

        public void AddFile(AxFileAudio aFile)
        {
            Files.Add(aFile);
        }
    }
}