using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Diagnostics;
using WMPLib;
using Atmw.Xml;
using System.IO;

using Nb.Library.Clr;
using NbTools;

namespace Atmw.Player
{
    public partial class PlayerForm : Form
    {
        internal delegate void ExecuteCommandDelegate(ApCommand aCommand);
        private readonly ApEvents fEvents;

        private List<PlayListItem> CurrentPlayList;
        private readonly Timer fPositionTimer;
        private readonly Random fRnd;
        private readonly string fMusicCacheDirN;

        public PlayerForm(ApEvents aEvents, string musicCacheDirN)
        {
            CurrentPlayList = new List<PlayListItem>(100);
            fEvents = aEvents;
            fMusicCacheDirN = musicCacheDirN;
            fRnd = new Random();
            InitializeComponent();

            fWindowsMediaPlayer.PlayStateChange += new AxWMPLib._WMPOCXEvents_PlayStateChangeEventHandler(fWindowsMediaPlayer_PlayStateChange);
            fWindowsMediaPlayer.PositionChange += new AxWMPLib._WMPOCXEvents_PositionChangeEventHandler(fWindowsMediaPlayer_PositionChange);

            albumPlayer1.OnItemClick += new AlbumPlayerEntryEventHandler(albumPlayer1_OnItemClick);

            fPositionTimer = new Timer();
            fPositionTimer.Interval = 1000;
            fPositionTimer.Tick += new EventHandler(fPositionTimer_Tick);
        }

        void fPositionTimer_Tick(object sender, EventArgs e)
        {
            throw new Exception("The method or operation is not implemented.");
        }


        private enum ClearOld { Yes, No };

        private void FilesToPlayList(IEnumerable<AxFileAudio> aFiles, ClearOld aClear)
        {
            lvPlayList.BeginUpdate();

            if (aClear == ClearOld.Yes)
            {
                fWindowsMediaPlayer.Ctlcontrols.stop();
                fWindowsMediaPlayer.currentPlaylist.clear();
                CurrentPlayList.Clear();
                lvPlayList.Items.Clear();
                albumPlayer1.Clear();
            }

            double totDur = 0.0;
            foreach (var tuple in CacheFiles(aFiles, fMusicCacheDirN))
            {
                var media = fWindowsMediaPlayer.newMedia(tuple.Item2);
                PlayListItem pli = new PlayListItem(media);
                CurrentPlayList.Add(pli);
                totDur += media.duration;

                lvPlayList.Items.Add(pli.LvItem);
                albumPlayer1.AddItem(tuple.Item1, pli);
                fWindowsMediaPlayer.currentPlaylist.appendItem(media);
            }

            ListViewItem item1 = new ListViewItem();
            item1.ForeColor = Color.Gray;
            item1.Text = "Total";
            item1.SubItems.Add(AxFile.DurationString(totDur));
            lvPlayList.Items.Add(item1);

            albumPlayer1.Refresh();
            lvPlayList.EndUpdate();
        }

        private static List<Tuple<AxFile, string>> CacheFiles(IEnumerable<AxFile> files, string cachePathN)
        {
            if (String.IsNullOrEmpty(cachePathN))
                return files.Select(f => Tuple.Create(f, f.PathName)).ToList();
            else
            {
                //Clean cache
                var di = new DirectoryInfo(cachePathN);
                NbDir.CreateDirRecursive(di);
                foreach (var file in di.GetFiles())
                    file.Delete();
                System.Threading.Thread.Sleep(300);

                var list = new List<Tuple<AxFile, string>>(20);
                foreach(var axFile in files)
                {
                    var cachePath = Path.Combine(di.FullName, axFile.Filename);
                    File.Copy(axFile.PathName, cachePath);
                    list.Add(Tuple.Create(axFile, cachePath));
                }
                return list;
            }
        }

        private void FilesToPlayList(IEnumerable<FileInfo> aFileInfos, ClearOld aClear)
        {
            lvPlayList.BeginUpdate();

            if (aClear == ClearOld.Yes)
            {
                fWindowsMediaPlayer.currentPlaylist.clear();
                CurrentPlayList.Clear();
                lvPlayList.Items.Clear();
                albumPlayer1.Clear();
            }

            double totDur = 0.0;
            foreach (FileInfo fi in aFileInfos)
            {
                var media = fWindowsMediaPlayer.newMedia(fi.FullName);
                PlayListItem pli = new PlayListItem(media);
                CurrentPlayList.Add(pli);
                totDur += media.duration;

                lvPlayList.Items.Add(pli.LvItem);
                //albumPlayer1.AddItem(file, pli);
                fWindowsMediaPlayer.currentPlaylist.appendItem(media);
            }

            ListViewItem item1 = new ListViewItem();
            item1.ForeColor = Color.Gray;
            item1.Text = "Total";
            item1.SubItems.Add(AxFile.DurationString(totDur));
            lvPlayList.Items.Add(item1);

            albumPlayer1.Refresh();
            lvPlayList.EndUpdate();
        }

        internal void ExecuteCommand(ApCommand aCommand)
        {
            if (aCommand is ApCommandPlay)
            {
                ApCommandPlay cmd = aCommand as ApCommandPlay;
                //IWMPMedia media;
                switch (cmd.PlayTime)
                {
                    case ApCommandPlay.Type.Start:
                        FilesToPlayList(cmd.Files, ClearOld.Yes);
                        fWindowsMediaPlayer.Ctlcontrols.play();
                        break;

                    case ApCommandPlay.Type.Enqueue:
                        FilesToPlayList(cmd.Files, ClearOld.No);
                        break;

                    default:
                        throw new NbException("Unsupported ApCommandPlay play time: '{0}'", aCommand);
                }

                if (cmd.PlayTime == ApCommandPlay.Type.Start)
                {

                }
            }


        }

        protected override void OnClosed(EventArgs e)
        {
            this.Visible = false;
            fWindowsMediaPlayer.Dispose();
            base.OnClosed(e);
        }


        void fWindowsMediaPlayer_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            WMPPlayState state = (WMPPlayState)e.newState;
            string eventName = state.ToString().Substring(5);


            string status;
            switch (state)
            {
                case WMPPlayState.wmppsPlaying:
                    IWMPMedia media = fWindowsMediaPlayer.currentMedia;

                    status = String.Format("P> {0}: {1}", eventName, media.sourceURL);

                    SetPlayListSelection(media.sourceURL);

                    if (fEvents.fForm != null)
                    {   //TODO: blows when the main window is closed
                        fEvents.fForm.BeginInvoke(new ApEvents.PlayStateDelegate(fEvents.PlayStateChanges),
                            new object[] { eventName, media.sourceURL });
                    }
                    break;

                default:
                    status = String.Format("P> {0}", eventName);
                    break; //Do nothing
            }


            Debug.WriteLine(status);
            stStatusText.Text = status;
        }

        private void SetPlayListSelection(string aUrl)
        {
            foreach (ListViewItem lvItem in lvPlayList.Items)
            {
                PlayListItem pli = lvItem.Tag as PlayListItem;
                if (pli.Media.sourceURL == aUrl)
                {
                    lvPlayList.SelectedItems.Clear();
                    lvItem.Selected = true;
                    break;
                }
            }
        }

        void fWindowsMediaPlayer_PositionChange(object sender, AxWMPLib._WMPOCXEvents_PositionChangeEvent e)
        {
            double pos = e.newPosition;
            Debug.WriteLine("Pos: " + pos);
        }

        private void lvPlayList_DoubleClick(object sender, EventArgs e)
        {
            if (lvPlayList.SelectedItems.Count == 0)
                return;
            PlayListItem pli = lvPlayList.SelectedItems[0].Tag as PlayListItem;
            if (pli == null || pli.Media == null)
                return;
            fWindowsMediaPlayer.Ctlcontrols.playItem(pli.Media);
        }

        void albumPlayer1_OnItemClick(AlbumPlayerEntry aFile)
        {
            PlayListItem pli = aFile.Tag as PlayListItem;
            if (pli == null || pli.Media == null)
                return;
            fWindowsMediaPlayer.Ctlcontrols.playItem(pli.Media);
        }

        private void changeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new AlarmSettings();
            dialog.ShowDialog(this);
        }


        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e)
        {
            var softeners = NbDir.ListFilesRecursively(new DirectoryInfo(@"E:\_MUSIC.other\Minecraft"), AxFileAudio.AudioFileExtensions.Select(ext => "*" + ext)).ToList();

            FileInfo fi1 = NbExt.OneOf(fRnd, softeners);
            FilesToPlayList(fi1.YieldSafe(), ClearOld.Yes);

            var rotation = NbDir.ListFilesRecursively(new DirectoryInfo(@"E:\_MUSIC.other\Sansa64\�-�����\2004 - ����������"), AxFileAudio.AudioFileExtensions.Select(ext => "*" + ext)).ToList();

            foreach (var fi in fRnd.Randomize(rotation).Take(4))
            {
                FilesToPlayList(fi.YieldSafe(), ClearOld.No);
            }

            ApCommandPlay cmd = new ApCommandPlay(ApCommandPlay.Type.Start);
            ExecuteCommand(cmd);
        }
    }
}