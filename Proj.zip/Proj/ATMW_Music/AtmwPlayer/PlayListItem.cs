using System;
using System.Collections.Generic;
using System.Text;
using Atmw.Xml;
using WMPLib;
using System.Windows.Forms;

namespace Atmw.Player
{
    internal class PlayListItem
    {
        internal readonly IWMPMedia Media;
        internal readonly ListViewItem LvItem;

        internal PlayListItem(IWMPMedia aMedia)
        {
            Media = aMedia;

            LvItem = new ListViewItem();
            LvItem.SubItems.Add(AxFile.DurationString(aMedia.duration));
            LvItem.Text = aMedia.name;
            LvItem.Tag = this;
        }
    }
}
