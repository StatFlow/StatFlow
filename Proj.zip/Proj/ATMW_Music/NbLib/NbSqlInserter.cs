using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace Nb.Library
{
    public class NbSqlInserter : IDisposable
    {
        private readonly SqlConnection fConnection;
        private readonly string fTableName;
        private readonly Dictionary<string, object> fFields;

        private bool fIndentityInsertSet = false;

        public NbSqlInserter(SqlConnection aConnection, string aTableName)
        {
            fConnection = aConnection;
            fTableName = aTableName;
            fFields = new Dictionary<string, object>(20);
        }

        public object this[string aFieldName]
        {
            set { fFields[StripAt(aFieldName)] = value; }
            get { return fFields[aFieldName]; }
        }

        private string StripAt(string aStr)
        {
            if (String.IsNullOrEmpty(aStr) || aStr[0] != '@')
                return aStr;
            else
                return aStr.Substring(1, aStr.Length - 1);
        }

        public int Run()
        {
            StringBuilder insert = new StringBuilder(String.Format("insert into {0} (", fTableName));
            StringBuilder values = new StringBuilder("values (");

            bool first = true;
            foreach (KeyValuePair<string, object> pair in fFields)
            {
                if (!first)
                {
                    insert.Append(",");
                    values.Append(",");
                }
                first = false;

                insert.Append(pair.Key);
                values.Append(String.Format("@{0}", pair.Key));
            }
            insert.AppendLine(") ");
            values.AppendLine(") ");
            values.AppendLine("; select @@IDENTITY");
            insert.Append(values.ToString());

            using (SqlCommand cmd = new SqlCommand(insert.ToString(), fConnection))
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandTimeout = 1000;
                foreach (KeyValuePair<string, object> pair in fFields)
                {
                    cmd.Parameters.AddWithValue("@" + pair.Key, pair.Value == null ? DBNull.Value : pair.Value);
                }

                object res;
                try
                {
                    res = cmd.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    foreach (KeyValuePair<string, object> pair in fFields)
                        insert.AppendFormat("\r\n {0} = {1}", pair.Key, pair.Value);

                    throw new NbException(ex, "Exception executing command:\r\n{0}", insert.ToString());
                }

                if (res == DBNull.Value)
                    return -1;
                else
                    return Convert.ToInt32(res);
            }
        }

        public int CreateUniqueId(string aNameField, string aNamePrefix, string aIdField, int aFrom, int aUpTo)
        {
            using (SqlCommand cmd = new SqlCommand(String.Format("SET IDENTITY_INSERT [{0}] ON", fTableName), fConnection))
            {
                cmd.ExecuteScalar();
                fIndentityInsertSet = true;
            }

            for (int j = aFrom; j <= aUpTo; ++j)
            {
                try
                {
                    this[aIdField] = String.Format("{0}", j);
                    this[aNameField] = String.Format("{0}{1}", aNamePrefix, j);
                    return Run();
                }
                catch (Exception ex)
                {
                    SkipUniqueKeyException(ex);
                }
            }
            throw new NbException("Inserter could not create the record after {0} attempts", aUpTo - aFrom + 1);
        }

        public int CreateUniqueName(string aNameField, string aNamePrefix, int aFrom, int aUpTo)
        {
            for (int j = aFrom; j <= aUpTo; ++j)
            {
                try
                {
                    this[aNameField] = String.Format("{0}{1}", aNamePrefix, j);
                    return Run();
                }
                catch (Exception ex)
                {
                    SkipUniqueKeyException(ex);
                }
            }
            throw new NbException("Inserter could not create the record after {0} attempts", aUpTo - aFrom + 1);
        }

        private static void SkipUniqueKeyException(Exception ex)
        {
            if (!ex.Message.Contains("UNIQUE KEY constraint"))
                throw new Exception("Inserter has failed to create a record", ex);
        }

        public void Dispose()
        {
            if (fIndentityInsertSet)
                try
                {
                    using (SqlCommand cmd = new SqlCommand(String.Format("SET IDENTITY_INSERT [{0}] OFF", fTableName), fConnection))
                    {
                        cmd.ExecuteScalar();
                        fIndentityInsertSet = true;
                    }
                    fIndentityInsertSet = false;
                }
                catch
                { } //Ignore the problems with setting identity off
        }
    }

}
