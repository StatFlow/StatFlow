using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Nb.Library
{
    public class CsvWriter : IDisposable
    {
        private readonly StreamWriter fWriter;

        public CsvWriter(string aFilename)
        {
            fWriter = new StreamWriter(aFilename);
        }

        public void WriteCell(string aStr)
        {
            fWriter.Write('"');
            fWriter.Write(SafeString(aStr));
            fWriter.Write('"');
            fWriter.Write(',');
        }

        public void WriteLastCell(string aStr)
        {
            fWriter.Write('"');
            fWriter.Write(SafeString(aStr));
            fWriter.WriteLine('"');
        }

        public static string SafeString(string aStr)
        {
            if (aStr == null)
                return null;
            else
                return aStr.Replace("\"", "''");
        }

        public void Dispose()
        {
            if (fWriter != null)
                fWriter.Close();
        }
    }
}
