using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Threading;
using System.Xml.Serialization;
using System.Text.RegularExpressions;

namespace Nb.Library
{
    public class NbDir
    {
        public readonly DirectoryInfo DirInfo;
        private string fPreviousFilename;

        private NbDir(DirectoryInfo aDi)
        {
            DirInfo = aDi;
        }

        public string TimestampedFile(string aPrefix, string aExtension)
        {
            DateTime timestamp = DateTime.Now;
            string file = String.Format("{0}\\{1} {2}.{3}",
                DirInfo.FullName, aPrefix,
                TimeOfDay(timestamp),
                aExtension);

            if (file.Equals(fPreviousFilename))
            {
                Thread.Sleep(1);
                return TimestampedFile(aPrefix, aExtension);
            }
            else
            {
                fPreviousFilename = file;
                return file;
            }
        }

        public static string TimeStampTheFile(FileInfo fi)
        {
            DateTime timestamp = DateTime.Now;
            string file = String.Format("{0} {1} {2}{3}",
                fi.FullName.Substring(0, fi.FullName.Length - fi.Extension.Length),
                DayOfYear(timestamp),
                TimeOfDay(timestamp),
                fi.Extension);

            FileInfo fl = new FileInfo(file);
            if (!fl.Exists)
            {   //Create the directory to ensure that the file can be created
                CreateDirRecursive(fl.Directory);
                return file;
            }
            Thread.Sleep(1);
            return TimeStampTheFile(fi);
        }

        public static string TimeOfDay(DateTime timestamp)
        {
            return String.Format("{0:d2}-{1:d2}-{2:d2}.{3:d3}",
                timestamp.Hour, timestamp.Minute, timestamp.Second, timestamp.Millisecond);
        }

        public static string DayOfYear(DateTime timestamp)
        {
            return String.Format("{0:d4}-{1:d2}-{2:d2}",
                timestamp.Year, timestamp.Month, timestamp.Day);
        }


        public static NbDir CreateTimestampedDir(string aPathAndPrefix)
        {
            DateTime timestamp = DateTime.Now;
            string dir = String.Format("{0} {1:d2}.{2:d2} {3:d2}-{4:d2}-{5:d2}",
                aPathAndPrefix, timestamp.Month, timestamp.Day, timestamp.Hour, timestamp.Minute, timestamp.Second);

            DirectoryInfo di = new DirectoryInfo(dir);
            CreateDirRecursive(di);
            return new NbDir(di);
        }

        public NbDir TimestampedDir(string aPrefix)
        {
            DateTime timestamp = DateTime.Now;
            string dir = String.Format("{0}\\{1} {2:d2}.{3:d2} {4:d2}-{5:d2}-{6:d2}",
                DirInfo.FullName, aPrefix, 
                timestamp.Month, timestamp.Day, timestamp.Hour, timestamp.Minute, timestamp.Second);

            NbDir newDir = new NbDir(new DirectoryInfo(dir));
            CreateDirRecursive(newDir.DirInfo);
            return newDir;
        }

        public static void CreateDirRecursive(DirectoryInfo di) //Recursive
        {
            if (!di.Exists)
            {
                CreateDirRecursive(di.Parent);
                Directory.CreateDirectory(di.FullName);
            }
        }

        public static string Legalize(string aFileName)
        {
            // / ? < > \ : * | �
            aFileName = Regex.Replace(aFileName, "\"", "''");
            aFileName = Regex.Replace(aFileName, @"/|\?|<|>|\\|:|\*|\|", "_");
            return aFileName;
        }

        public override string ToString()
        {
            return DirInfo.FullName;
        }
    }

    public static class NbSerial
    {
        private static Dictionary<Type, XmlSerializer> fSerializers = null;

        public static void Serialize<T>(T aDirDesc, string aFileName)
            where T : class
        {
            Serialize<T>(aDirDesc, new FileInfo(aFileName));
        }

        public static void Serialize<T>(T aDirDesc, FileInfo aFileInfo)
            where T : class
        {
            NbDir.CreateDirRecursive(aFileInfo.Directory);

            using (StreamWriter wr = new StreamWriter(aFileInfo.FullName))
            {
                if (fSerializers == null)
                    fSerializers = new Dictionary<Type, XmlSerializer>(5);

                XmlSerializer ser;
                if (!fSerializers.TryGetValue(typeof(T), out ser))
                {
                    ser = new XmlSerializer(typeof(T));
                    fSerializers.Add(typeof(T), ser);
                }
                ser.Serialize(wr, aDirDesc);
            }
        }

        public static void Deserialize<T>(FileInfo aFileInfo, out T aResult)
            where T : class
        {
            Deserialize<T>(aFileInfo.FullName, out aResult);
        }

        public static void Deserialize<T>(string aFileName, out T aResult)
            where T : class
        {
            if (fSerializers == null)
                fSerializers = new Dictionary<Type, XmlSerializer>(5);

            XmlSerializer ser;
            if (!fSerializers.TryGetValue(typeof(T), out ser))
            {
                ser = new XmlSerializer(typeof(T));
                fSerializers.Add(typeof(T), ser);
            }

            if (File.Exists(aFileName))
            {
                using (FileStream src = new FileStream(aFileName, FileMode.Open, FileAccess.Read))
                {
                    aResult = (T)ser.Deserialize(src);
                }
            }
            else
                aResult = default(T);
        }

        /// <summary>
        /// Tryis to deserialize the file, if the file is not found or corrupted, the emply object will be created
        /// </summary>
        /// <typeparam name="T">The type of the root XML object to be deserialized</typeparam>
        /// <param name="aFileName">Source file</param>
        /// <param name="aResult">Deserialized object</param>
        public static void DeserializeSafe<T>(string aFileName, out T aResult) 
            where T : class, new()
        {
            try
            {
                Deserialize<T>(aFileName, out aResult);
                if (aResult == null)
                    aResult = new T();
            }
            catch
            {
                aResult = new T();
            }
        }
    }
}
