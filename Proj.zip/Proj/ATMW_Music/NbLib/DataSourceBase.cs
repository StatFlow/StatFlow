using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Threading;
using System.Data.SqlTypes;
using System.IO;
using System.Diagnostics;

namespace Nb.Library
{
    public class DataSourceBase : IDisposable
    {
        protected readonly ConnectInfo fConnectionInfo;
        private readonly Dictionary<int, SqlConnection> fConnectionPool;

        public DataSourceBase(ConnectInfo aConnectionInfo)
        {
            fConnectionInfo = aConnectionInfo;
            fConnectionPool = new Dictionary<int, SqlConnection>(10);
        }

        public SqlConnection ReusableConnection
        {
            get
            {
                SqlConnection conn;
                int treadId = Thread.CurrentThread.ManagedThreadId;
                if (!fConnectionPool.TryGetValue(treadId, out conn))
                {
                    conn = new SqlConnection(fConnectionInfo.ConnectionString);
                    conn.Open();
                    fConnectionPool.Add(treadId, conn);
                }
                return conn;
            }
        }

        /// <summary>
        /// Uses reusable connection, which shouldn't be held for long.
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="aArg"></param>
        /// <returns></returns>
        public NbSqlReader CreateTempReader(string sql, params object[] aArg)
        {
            return new NbSqlReader(ReusableConnection, NbSqlReader.Mode.Sql, sql, aArg);
        }

        /// <summary>
        /// Uses reusable connection, which shouldn't be held for long.
        /// </summary>
        /// <param name="sql"></param>
        /// <param name="transaction"></param>
        /// <param name="aArg"></param>
        /// <returns></returns>
        public NbSqlReader CreateTempReader(SqlTransaction transaction, string sql, params object[] aArg)
        {
            return new NbSqlReader(ReusableConnection, NbSqlReader.Mode.Sql, sql, transaction, aArg);
        }

        /// <summary>
        /// Runs a stored procedure
        /// </summary>
        /// <param name="aSp">One of the stored procedures defined in the dedicated Enum</param>
        /// <param name="par">Pairs of parameters for the stored procedure. Example: "@UserName", "John Doe"</param>
        /// <returns>The integer specified in the return statement of the stored procedure</returns>
        protected int RunSp(string aSp, params object[] par)
        {
            int rem;
            Math.DivRem(par.GetLength(0), 2, out rem);
            if (rem != 0)
                throw new ArgumentException("Odd number of parameters passed to RunSp procedure");

            using (SqlCommand cmd = new SqlCommand(aSp, ReusableConnection))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandTimeout = 1000;
                SqlCommandBuilder.DeriveParameters(cmd);

                foreach (SqlParameter sqlPar in cmd.Parameters)
                {
                    sqlPar.SqlValue = DBNull.Value;
                }

                for (int i = 0; i < par.GetLength(0); i += 2)
                {
                    foreach (SqlParameter sqlPar in cmd.Parameters)
                    {
                        if (sqlPar.ParameterName == par[i].ToString())
                        {
                            sqlPar.Value = par[i + 1];
                            break;
                        }
                    }
                }

                cmd.ExecuteNonQuery();

                int retVal = Convert.ToInt32(cmd.Parameters["@RETURN_VALUE"].Value);
                return retVal;
            }
        }

        public void BulkInsert(string aTable, string aFileFullName, bool aUseBcp, bool aCsvMode, bool aKeepIdentity)
        {
            if (aUseBcp) //TODO: support native mode here
            {
                WaitForFileToBeReleased(aFileFullName, 3000); //Wait for up to 3 seconds

                string bcpParams = String.Format("\"{0}.dbo.{1}\" in \"{2}\" -c -C RAW -S\"{3}\" -F 1 -t , ",
                    fConnectionInfo.Database, aTable, aFileFullName, fConnectionInfo.Server);

                if (fConnectionInfo.Trusted)
                    bcpParams += "-T";
                else
                    bcpParams += String.Format("-U\"{0}\" -P\"{1}\" ", fConnectionInfo.User, fConnectionInfo.Password);

                bcpParams += " -m 1";//set maximal number of errors to 1

                if (aKeepIdentity)
                    bcpParams += " -E";

                try
                {
                    string errStr, outStr;
                    RunExecGetStdError("bcp", bcpParams, out errStr, out outStr);
                    if (outStr.Trim().ToLower().EndsWith("failed") ||
                        errStr.Trim().ToLower().EndsWith("failed"))
                        throw new NbException((outStr.Trim() + "\r\n" + errStr.Trim()).Trim());
                }
                catch (NbException ex)
                {
                    throw new NbException(ex, "Failed to bulk insert with \r\nbcp {0}", bcpParams);
                }
            }
            else
            {
                string sqlString;
                if (aCsvMode)
                {
                    sqlString = String.Format(@"BULK INSERT {0} FROM '{1}' ", aTable, aFileFullName) +
                        "WITH (BATCHSIZE=1000, CODEPAGE='RAW', DATAFILETYPE='char', FIRSTROW=1" +
                        ", FIELDTERMINATOR=',', TABLOCK";

                    if (aKeepIdentity)
                        sqlString += ", KEEPIDENTITY";

                    sqlString += ")";
                }
                else
                {
                    sqlString = String.Format(@"BULK INSERT {0} FROM '{1}' ", aTable, aFileFullName) +
                        "WITH (BATCHSIZE=1000, DATAFILETYPE='native', TABLOCK";

                    if (aKeepIdentity)
                        sqlString += ", KEEPIDENTITY";

                    sqlString += ")";
                }
                int maxAttempts = 5;
                for (int attempt = maxAttempts; attempt >= 0; --attempt)
                {
                    if (attempt != maxAttempts)
                        Thread.Sleep(500); //Half a second, except for the first time

                    try
                    {
                        using (SqlCommand myCommand = new SqlCommand(sqlString, ReusableConnection))
                        {
                            myCommand.CommandTimeout = 30000; //30 seconds
                            myCommand.ExecuteNonQuery();
                            return; //Success - leave the for loop
                        }
                    }
                    catch (SqlException ex)
                    {
                        if (attempt == 0)
                            throw new NbException(ex, "{0} attempt to bulk insert '{1}' have failed: \r\n{2}", maxAttempts, aFileFullName, sqlString);
                        /*else
                            Log.Write(attempt < maxAttempts ? TraceLevel.Verbose : TraceLevel.Error, ex, "Attempt #{0} to bulk insert the file '{1}' has failed", attempt, aFileFullName);*/
                    }
                }
            }
        }

        private void WaitForFileToBeReleased(string aFileName, int aMilliSeconds)
        {
            const int timeStep = 250;
            for (int time = aMilliSeconds; time >= 0; time -= timeStep) //Four attempts per second
            {
                try
                {
                    FileStream rdr = File.OpenRead(aFileName);
                    rdr.Close();
                    return; //File is free
                }
                catch (IOException)
                {
                    Thread.Sleep(timeStep);
                } //Do nothing
            }
        }

        private void RunExecGetStdError(string aCommand, string aParameters, out string aErr, out string aOut)
        {
            Process MyProc = new Process();
            MyProc.StartInfo.FileName = aCommand;
            MyProc.StartInfo.Arguments = aParameters;
            MyProc.StartInfo.CreateNoWindow = true;

            MyProc.StartInfo.UseShellExecute = false;
            MyProc.StartInfo.RedirectStandardOutput = true;
            MyProc.StartInfo.RedirectStandardError = true;
            //MyProc.StartInfo.RedirectStandardInput = true;

            //fLogFile.WriteLine(MyProc.StartInfo.FileName);
            //fLogFile.WriteLine(MyProc.StartInfo.Arguments);

            MyProc.Start();
            aOut = MyProc.StandardOutput.ReadToEnd();
            aErr = MyProc.StandardError.ReadToEnd();
            //fLogFile.WriteLine(mess1);
            //fLogFile.WriteLine(mess2);

            MyProc.WaitForExit();
            if (MyProc.ExitCode != 0)
                throw new NbException("{0} exit code is {1}.\r\n{2}\r\n{3}", aCommand, MyProc.ExitCode, aOut, aErr);
        }

        public int ExecuteScalar(string aSql)
        {
            using (SqlCommand createCmd = new SqlCommand(aSql, ReusableConnection))
            {
                object result = createCmd.ExecuteScalar();
                return Convert.IsDBNull(result) ? 0 : Convert.ToInt32(result);
            }
        }

        public int ExecuteInsert(string aSql)
        {
            using (SqlCommand createCmd = new SqlCommand(aSql + "; select @@IDENTITY", ReusableConnection))
            {
                return Convert.ToInt32(createCmd.ExecuteScalar());
            }
        }

        public void Dispose()
        {
            foreach (SqlConnection cnn in fConnectionPool.Values)
                cnn.Close();
        }
    }

}
