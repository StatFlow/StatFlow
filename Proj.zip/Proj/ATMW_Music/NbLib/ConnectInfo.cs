using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Nb.Library
{
    public class ConnectInfo
    {
        //Can't be readonly because of the serialization
        public string Server;
        public string Database;
        public string User;
        public string Password;

        public bool Trusted;

        public ConnectInfo() //For serialization
        { }

        public ConnectInfo(string aServer, string aDatabase, string aUser, string aPassword)
        {
            Server = aServer;
            Database = aDatabase;
            User = aUser;
            Password = (aPassword != null) ? aPassword : "";
            Trusted = string.IsNullOrEmpty(aUser);
        }

        public ConnectInfo(ConnectInfo aCopyFrom)
            :
            this(aCopyFrom.Server, aCopyFrom.Database, aCopyFrom.User, aCopyFrom.Password)
        {

        }

        /*
        public string ConnectionString
        {
            get
            {
                if (Trusted || (String.IsNullOrEmpty(User) && String.IsNullOrEmpty(Password)))
                    return "data source=" + Server + "; Initial Catalog=" + Database + "; Integrated Security=SSPI";
                else
                    return "trusted_connection=false;server=" + Server + ";database=" + Database + ";user id=" + User + ";pwd=" + Password;
            }
        }*/

        public string ConnectionString
        {
            get
            {
                string connectionString = String.Format("trusted_connection = {0};", Trusted.ToString());

                if (!String.IsNullOrEmpty(Server))
                    connectionString += String.Format("server={0};", Server);
                else if (!Trusted) //empty server and not trusted
                    throw new NbException("Connection is not trusted and server name is not specified");


                if (!String.IsNullOrEmpty(Database))
                    connectionString += String.Format("database={0};", Database);
                else
                    throw new Exception("Can't connect to SQL database. Database name was not specified.");

                if (!String.IsNullOrEmpty(User))
                    connectionString += String.Format("user id={0};", User);

                if (!String.IsNullOrEmpty(Password))
                    connectionString += String.Format("pwd={0};", Password);

                return connectionString;
            }
        }

    }

}
