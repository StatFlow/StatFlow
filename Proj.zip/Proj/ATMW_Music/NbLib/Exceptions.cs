using System;
using System.Collections.Generic;
using System.Text;

namespace Nb.Library
{
    public class NbException : Exception
    {
        public NbException(string aFormat, params object[] args)
            : base(String.Format(aFormat, args))
        { }

        public NbException(Exception ex, string aFormat, params object[] args)
            : base(String.Format(aFormat, args), ex)
        { }

        public static string Exception2String(Exception ex)
        {
            StringBuilder bld = new StringBuilder();
            bld.AppendLine(ex.Message);
            while (ex.InnerException != null)
            {
                ex = ex.InnerException;
                bld.AppendLine(ex.Message);
            }
            return bld.ToString();
        }

        public override string ToString()
        {
            return Exception2String(this);
        }
    }

    public class NbExceptionUserCancelled : NbException
    {
        public NbExceptionUserCancelled()
            :base("User cancelled the operation")
        {}
    }

}
