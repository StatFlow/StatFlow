using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Data.SqlTypes;

namespace Nb.Library
{
    public class NbSqlReader : IDisposable
    {
        public enum Mode { Sql, Sp };

        private readonly SqlCommand fCommand;
        private readonly SqlDataReader fReader;

        public NbSqlReader(SqlConnection aConnection, Mode aMode, string aCommand, params object[] aArg)
        {
            switch (aMode)
            {
                case Mode.Sql:
                    fCommand = new SqlCommand(String.Format(aCommand, aArg), aConnection);
                    break;
                case Mode.Sp:
                    int length = aArg.GetLength(0);
                    if (length % 2 == 1)
                        throw new Exception("NbReader: odd number of parameters passed to the constructror");
                    fCommand = new SqlCommand(aCommand, aConnection);
                    fCommand.CommandType = CommandType.StoredProcedure;

                    for (int i = 0; i < length; i += 2)
                    {
                        fCommand.Parameters.AddWithValue(aArg[i].ToString(), aArg[i + 1]);
                    }
                    break;
                default:
                    throw new Exception("Unsupported Mode in NbSqlReader: " + aMode.ToString());
            }
            fCommand.CommandTimeout = 300;
            fReader = fCommand.ExecuteReader();
        }

        public NbSqlReader(SqlConnection aConnection, Mode aMode, string aCommand, SqlTransaction aTransaction, params object[] aArg)
        {
            switch (aMode)
            {
                case Mode.Sql:
                    fCommand = new SqlCommand(String.Format(aCommand, aArg), aConnection, aTransaction);
                    break;
                case Mode.Sp:
                    int length = aArg.GetLength(0);
                    if (length % 2 == 1)
                        throw new Exception("NbReader: odd number of parameters passed to the constructror");
                    fCommand = new SqlCommand(aCommand, aConnection, aTransaction);
                    fCommand.CommandType = CommandType.StoredProcedure;

                    for (int i = 0; i < length; i += 2)
                    {
                        fCommand.Parameters.AddWithValue(aArg[i].ToString(), aArg[i + 1]);
                    }
                    break;
                default:
                    throw new Exception("Unsupported Mode in NbSqlReader: " + aMode.ToString());
            }
            fCommand.CommandTimeout = 300;
            fReader = fCommand.ExecuteReader();
        }

        public void Dispose()
        {
            fReader.Close();
            fCommand.Dispose();
        }

        public bool Read()
        {
            return fReader.Read();
        }

        public int FieldCount
        {
            get { return fReader.FieldCount; }
        }

        public object this[int aIndex]
        {
            get
            {
                if (fReader.IsDBNull(aIndex))
                    return null;

                return fReader[aIndex];
            }
        }

        public bool NextResult()
        {
            return fReader.NextResult();
        }

        public SqlDataReader Reader
        {
            get { return fReader; }
        }

        public double DoubleNull(object aFieldIndex)
        {
            return DoubleNull(aFieldIndex, Double.NaN);
        }

        public double DoubleNull(object aFieldIndex, double aNullValue)
        {
            SqlDecimal val = fReader.GetSqlDecimal(ObjToInt(aFieldIndex));
            if (val.IsNull)
                return aNullValue;
            else
                return Convert.ToDouble(val.Value);
        }

        public double DoubleFail(object aFieldIndex)
        {
            SqlDecimal val = fReader.GetSqlDecimal(ObjToInt(aFieldIndex));
            if (val.IsNull)
                throw new NbSqlException(aFieldIndex, "double", fCommand);
            else
                return Convert.ToDouble(val.Value);
        }

        public float FloatFail(object aFieldIndex)
        {
            SqlDecimal val = fReader.GetSqlDecimal(ObjToInt(aFieldIndex));
            if (val.IsNull)
                throw new NbSqlException(aFieldIndex, "float", fCommand);
            else
                return Convert.ToSingle(val.Value);
        }

        public double RealDoubleFail(object aFieldIndex)
        {
            SqlDouble val = fReader.GetDouble(ObjToInt(aFieldIndex));
            if (val.IsNull)
                throw new NbSqlException(aFieldIndex, "double", fCommand);
            else
                return Convert.ToDouble(val.Value);
        }

        public int IntNull(object aFieldIndex, int aNullValue)
        {
            object obj = fReader.GetValue(ObjToInt(aFieldIndex)); //Allows to read integers of any size
            if (obj == null || obj == DBNull.Value)
                return aNullValue;
            else
                return Convert.ToInt32(obj);
        }

        public int IntFail(object aFieldIndex)
        {
            object obj = fReader.GetValue(ObjToInt(aFieldIndex)); //Allows to read integers of any size
            if (obj == null || obj == DBNull.Value)
                throw new NbSqlException(aFieldIndex, "int", fCommand);
            else
                return Convert.ToInt32(obj);
        }

        public DateTime DateTimeNull(object aFieldIndex)
        {
            SqlDateTime val = fReader.GetSqlDateTime(ObjToInt(aFieldIndex));
            if (val.IsNull)
                return DateTime.MinValue;
            else
                return val.Value;
        }

        public DateTime DateTimeFail(object aFieldIndex)
        {
            SqlDateTime val = fReader.GetSqlDateTime(ObjToInt(aFieldIndex));
            if (val.IsNull)
                throw new NbSqlException(aFieldIndex, "datetime", fCommand);
            else
                return val.Value;
        }

        /*public Date DateNull(object aFieldIndex)
        {
            SqlDateTime val = fReader.GetSqlDateTime(ObjToInt(aFieldIndex));
            if (val.IsNull)
                return Date.Null;
            else
                return new Date(val.Value);
        }

        public Date DateFail(object aFieldIndex)
        {
            SqlDateTime val = fReader.GetSqlDateTime(ObjToInt(aFieldIndex));
            if (val.IsNull)
                throw new NbSqlException(aFieldIndex, "date", fCommand);
            else
                return new Date(val.Value);
        }*/


        public double OaDateNull(object aFieldIndex)
        {
            return this.DateTimeNull(aFieldIndex).ToOADate();
        }

        public double OaDateFail(object aFieldIndex)
        {
            return this.DateTimeFail(aFieldIndex).ToOADate();
        }

        public string StringNull(object aFieldIndex)
        {
            SqlString val = fReader.GetSqlString(ObjToInt(aFieldIndex));
            if (val.IsNull)
                return "";
            else
                return val.Value.Trim();
        }

        public string StringFail(object aFieldIndex)
        {
            SqlString val = fReader.GetSqlString(ObjToInt(aFieldIndex));
            if (val.IsNull)
                throw new NbSqlException(aFieldIndex, "string", fCommand);
            else
                return val.Value;
        }

        private int ObjToInt(object aFieldIndex)
        {
            int index = Convert.ToInt32(aFieldIndex);
            if (index < fReader.FieldCount)
                return index;

            throw new NbException("Error reading field '{0}'. Index {1} exceeds the number of columns in the table {2}",
                aFieldIndex.ToString(), index, fReader.FieldCount);
        }

        /*internal bool BooleanFail(object aFieldIndex)
        {
            SqlBoolean val = fReader.GetSqlBoolean(Convert.ToInt32(aFieldIndex));
            if (val.IsNull)
                throw new NbSqlException(aFieldIndex, "boolean", fCommand);
            else
                return val.Value;
        }*/

        public class NbSqlException : Exception
        {
            public readonly int FieldIndex;
            public readonly string FieldName;
            public readonly string FieldContainer;

            public NbSqlException(object aIndex, string aFldType, SqlCommand aCmd)
                : base(String.Format("Error reading {2} field #{0} '{1}' of {3}. Null values are not allowed",
                Convert.ToInt32(aIndex), aIndex.ToString(), aFldType, ContainterString(aCmd)))
            {
                FieldIndex = Convert.ToInt32(aIndex);
                FieldName = aIndex.ToString();
                FieldContainer = ContainterString(aCmd);
            }

            private static string ContainterString(SqlCommand aCmd)
            {
                const int MaxSqlLength = 100;
                switch (aCmd.CommandType)
                {
                    case CommandType.StoredProcedure:
                        return aCmd.CommandText;
                    case CommandType.TableDirect:
                        return aCmd.CommandText;
                    case CommandType.Text:
                        if (aCmd.CommandText.Length > MaxSqlLength)
                            return aCmd.CommandText.Substring(0, MaxSqlLength - 3) + "...";
                        else
                            return aCmd.CommandText;
                    default:
                        throw new NbException("Unsupported CommandType: " + aCmd.CommandType.ToString());
                }
            }
        }

        public string FieldName(int aFieldIndex)
        {
            return fReader.GetName(ObjToInt(aFieldIndex));
        }

        public object JsonValue(int aFieldIndex)
        {
            object obj = fReader.GetValue(ObjToInt(aFieldIndex)); //Allows to read integers of any size
            if (obj == null || obj == DBNull.Value)
                return "\"\"";

            string type = obj.GetType().Name;
            switch (type)
            {
                case "String":
                    return String.Format("\"{0}\"", CsvWriter.SafeString(obj.ToString()));

                case "Int32":
                case "Double":
                    return obj.ToString();

                default:
                    throw new NbException("Unsupported type name '{0}' is JsonValue", type);
            }

        }
    }
}
