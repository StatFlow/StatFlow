using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Nb.Library
{
    internal partial class MessBoxDialog : Form
    {
        private readonly string fCancelResult;
        private readonly string fAcceptResult;
        private readonly Button[] fButtons;
        private readonly string[] fButtonTexts;
        private readonly int fDeltaH;

        internal MessBoxDialog(
            Form aOwner,
            string aMessageText,
            string aTitle,
            string[] aButtons,
            MboxIcon aImageIndex,
            int aAcceptBtnIndex,
            int aCancelBtnIndex)
        {
            InitializeComponent();
            if (aOwner != null)
            {
                Owner = aOwner;
                StartPosition = FormStartPosition.CenterParent;
                if (Owner.TopMost)
                    TopMost = true;
            }
            else
            {
                TopMost = true;
                StartPosition = FormStartPosition.CenterScreen;
            }
            SuspendLayout();

            fButtonTexts = aButtons;
            fButtons = new Button[aButtons.Length];
            for (int i = 0; i < fButtons.Length; i++ )
            {
                if (string.IsNullOrEmpty(aButtons[i]))
                {//add label
                    Label label = new Label();
                    label.AutoSize = true;
                    label.Text = "                 ";
                    panelButtons.Controls.Add(label);
                }
                else
                {                 
                    Button btn = new Button();
                    btn.Click += new EventHandler(btn_Click);
                    panelButtons.Controls.Add(btn);
                    btn.TabIndex = i;
                    btn.Text = aButtons[i];
                    btn.UseVisualStyleBackColor = true;
                    fButtons[i] = btn;
                }
            }
            int img = (int)aImageIndex;
            if (img < imageList.Images.Count && img >= 0)
            {
                pictureBox.Image = imageList.Images[img];
            }
            else
            {
                tableLayoutPanel.Visible = false;
                tableLayoutPanel.Size = new Size(-20, -10);//trick to simplify AdjustSize() code
            }
            if (aAcceptBtnIndex >= 0 && aAcceptBtnIndex < fButtons.Length && fButtons[aAcceptBtnIndex] != null)
            {
                fButtons[aAcceptBtnIndex].DialogResult = DialogResult.OK;
                AcceptButton = fButtons[aAcceptBtnIndex];
                fAcceptResult = aButtons[aAcceptBtnIndex];
            }
            if (aCancelBtnIndex >= 0 && aCancelBtnIndex < fButtons.Length && fButtons[aCancelBtnIndex] != null)
            {
                fButtons[aCancelBtnIndex].DialogResult = DialogResult.Cancel;
                CancelButton = fButtons[aCancelBtnIndex];
                fCancelResult = aButtons[aCancelBtnIndex];
            }
            else
            {//enable Cancel command using ESC key shortcut
                this.KeyUp += new KeyEventHandler(ExtendedMessageBox_KeyUp);
            }

            fDeltaH = this.Size.Height - richTextBox.Size.Height;

            Screen scr = Screen.FromControl(richTextBox);
            Rectangle r = scr.Bounds;
            richTextBox.MaximumSize = new Size(r.Width * 2 / 3 - tableLayoutPanel.Width - 38,
                r.Height * 2 / 3 - fDeltaH);
            this.MaximumSize = new Size(r.Width * 2 / 3, r.Height * 2 / 3);

            SetMessageText(aMessageText);

            if (fWindowIcon != null)
                this.Icon = fWindowIcon;

            if (aTitle != null)
                Text = aTitle;
            else if (fDefaultCaption != null)
                Text = fDefaultCaption;

            ResumeLayout();
        }

        public bool EnableEsc
        {
            get { return fEnableEsc; }
            set 
            {
                fEnableEsc = value;
                this.ControlBox = fEnableEsc;
            }
        }bool fEnableEsc = true;

        void ExtendedMessageBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (fEnableEsc && e.KeyCode == Keys.Cancel)
            {
                fResult = string.IsNullOrEmpty(fCancelResult) ? "Cancel" : fCancelResult;
                DialogResult = DialogResult.Cancel;
                if (e != null)
                {
                    e.Handled = true;
                    Close();
                }
            }
        }

        internal MessBoxDialog(
            string aMessageText,
            string[] aButtons,
            MboxIcon aImageIndex,
            int aAcceptBtnIndex,
            int aCancelBtnIndex):
            this(null, aMessageText, null, aButtons, aImageIndex, aAcceptBtnIndex, aCancelBtnIndex)
        {
        }


        void btn_Click(object sender, EventArgs e)
        {
            fResult = (sender as Button).Text;
            DialogResult = (sender as Button).DialogResult;
            Close();
        }

        public string Result
        {
            get 
            {
                if (fResult == null)
                {
                    if (DialogResult == DialogResult.Cancel)
                        return fCancelResult;
                    else if (DialogResult == DialogResult.OK)
                        return fAcceptResult;
                }
                return fResult;
            }
        } private string fResult;

        public int ResultInd
        {
            get
            {
                return Array.FindIndex<string>(fButtonTexts, delegate(string item) { return item == Result; });
            }
        }

        static public Icon WindowIcon
        {
            set  { fWindowIcon = value; }
        } static Icon fWindowIcon;

        static public string DefaultCaption
        {
            set { fDefaultCaption = value; }
        } static string fDefaultCaption;


        private void AdjustButtonsPanelPosition(object sender, EventArgs e)
        {
            Point p = new Point();
            p.X = (panelBottom.Size.Width - panelBottom.Padding.Left - panelBottom.Padding.Right - panelButtons.Size.Width) / 2;
            p.Y = (panelBottom.Size.Height - panelBottom.Padding.Bottom - panelBottom.Padding.Top - panelButtons.Size.Height) / 2;
            panelButtons.Location = p; 
        }

        void SetMessageText(string aMessageText)
        {
            richTextBox.Text = aMessageText;
            AdjustSize();
        }

        void AdjustSize()
        {
            Size tb = richTextBox.PreferredSize;
            int height = tb.Height;
            if(height >= richTextBox.MaximumSize.Height)
            {
                //richTextBox.ScrollBars |= RichTextBoxScrollBars.Vertical;
                tb = richTextBox.PreferredSize;
                height = richTextBox.MaximumSize.Height;
            }
            int width = tb.Width;
            //int tableLayoutPanelWidth = tableLayoutPanel.Visible ?  : 0;
            if (panelButtons.PreferredSize.Width - tableLayoutPanel.Width > width)
            {
                width = panelButtons.PreferredSize.Width - tableLayoutPanel.Width;
                if (width > richTextBox.MaximumSize.Width)
                {
                    width = richTextBox.MaximumSize.Width;
                    //richTextBox.ScrollBars |= RichTextBoxScrollBars.Horizontal;
                }
            }
            width += (tableLayoutPanel.Width + 42); //38
            height += fDeltaH;
            int minHight = pictureBox.Image == null ? 108 : 125;
            if (height < minHight)
                height = minHight;
            
            this.MinimumSize = this.Size = new Size(width, height);
        }
    }

    public enum MboxIcon
    { 
        None = -1,
        Error = 0,
        Warning,
        Info,
        Question,
    }
}