using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Nb.Library
{
    public class MessageBox
    {
        //Allows easy detection of Windows.Forms.MessageBox usage
    }

    public class NbMessageBox
    {
        public static int MaxLines
        {
            get { return fMaxLines; }
            set { fMaxLines = value; }
        }static int fMaxLines = 25;

        public static int MaxChars
        {
            get { return fMaxChars; }
            set { fMaxChars = value; }
        }static int fMaxChars = 4096;

        //todo: implement smarter behaviour
        public static string FilterMessage(string aMessage)
        {
            aMessage = aMessage.Trim();
            string result = aMessage;

            // limit number of characters in string
            if (aMessage.Length > MaxChars)
                result = aMessage.Substring(0, MaxChars - 3);

            // limit number of lines
            int nLines = 1;
            for (int i = 0; i < result.Length; i++)
            {
                i = result.IndexOf('\n', i);
                if (i < 0)
                    break;
                nLines++;
                if (nLines >= MaxLines)
                {
                    result = aMessage.Substring(0, i).Trim();
                    break;
                }
            }
            if (result.Length < aMessage.Length)
                result += "...";
            return result;
        }

        public static void OK(string aFormat, params object[] par)
        {
            Show(String.Format(aFormat, par)); //TODO: do a direct call to dialog window?
        }

        public static bool YesNo(Exception ex, string aFormat, params object[] par)
        {
            DialogResult res = Show(null, NbException.Exception2String(ex) + "\r\n" + String.Format(aFormat, par),
                null, MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
            return (res == DialogResult.OK);
        }



        public static DialogResult Show(string text)
        {
            return Show(text, null);
        }

        public static DialogResult Show(string text, string caption)
        {
            return Show(null, text, caption, MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return Show(null, text, caption, buttons, icon, MessageBoxDefaultButton.Button1);
        }

        public static DialogResult Show(string text, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return Show(null, text, null, buttons, icon, MessageBoxDefaultButton.Button1);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
        {
            return Show(null, text, caption, buttons, icon, defaultButton);
        }

        /*public static DialogResult Show(Form owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
        {
            return Show(owner, text, caption, buttons, icon, MessageBoxDefaultButton.Button1);
        }*/

        private static DialogResult Show(Form owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
        {
            try
            {
                string[] theButtons = Buttons(buttons);
                int shift = 0;
                if (defaultButton == MessageBoxDefaultButton.Button2)
                    shift = 1;
                else if (defaultButton == MessageBoxDefaultButton.Button3)
                    shift = 2;
                int defIndex = 0;
                for (; defIndex < theButtons.Length && shift >= 0; defIndex++)
                {
                    if (string.IsNullOrEmpty(theButtons[defIndex]))
                        continue;
                    shift--;
                }
                int cancelIndex = 0;
                for (; cancelIndex < theButtons.Length && theButtons[cancelIndex] != strCancel; cancelIndex++) ;
                if (buttons == MessageBoxButtons.AbortRetryIgnore || buttons == MessageBoxButtons.YesNo)
                    cancelIndex = -1;//suppress ESC
                string result = ShowMsg(owner as Form, text, caption, theButtons, Icon(icon), defIndex, cancelIndex);
                if (buttons == MessageBoxButtons.OK) return DialogResult.OK;
                DialogResult res = Result(result);
                return res == DialogResult.None ? DialogResult.Cancel : res;
            }
            catch (Exception)
            {
                return System.Windows.Forms.MessageBox.Show(owner, FilterMessage(text), caption, buttons, icon, defaultButton);
            }
        }

        static DialogResult Result(string aResult)
        {
            switch (aResult)
            {
                case strAbort:
                    return DialogResult.Abort;
                case strCancel:
                    return DialogResult.Cancel;
                case strIgnore:
                    return DialogResult.Ignore;
                case strNo:
                    return DialogResult.No;
                case strOk:
                    return DialogResult.OK;
                case strRetry:
                    return DialogResult.Retry;
                case strYes:
                    return DialogResult.Yes;
                default:
                    return DialogResult.None;
            }
        }

        //These constacts can be used from outside of the class when contructing the buttons
        public const string strYes = "&Yes";
        public const string strYesToAll = "Yes to &All";
        public const string strNo = "&No";
        public const string strNoToAll = "No to All";
        public const string strCancel = "&Cancel";
        public const string strOk = "&OK";
        public const string strAbort = "&Abort";
        public const string strIgnore = "&Ignore";
        public const string strRetry = "&Retry";


        static string[] Buttons(MessageBoxButtons aButtons)
        {
            switch (aButtons)
            {
                case MessageBoxButtons.AbortRetryIgnore:
                    return new string[] { strAbort, strRetry, strIgnore };
                case MessageBoxButtons.OK:
                    return new string[] { strOk };
                case MessageBoxButtons.OKCancel:
                    return new string[] { strOk, strCancel };
                case MessageBoxButtons.RetryCancel:
                    return new string[] { strRetry, strCancel };
                case MessageBoxButtons.YesNo:
                    return new string[] { strYes, strNo };
                case MessageBoxButtons.YesNoCancel:
                    return new string[] { strYes, strNo, strCancel };
            }
            return new string[0];
        }

        static MboxIcon Icon(MessageBoxIcon aIcon)
        {
            switch (aIcon)
            {
                case MessageBoxIcon.Asterisk:
                    return MboxIcon.Info;
                case MessageBoxIcon.Error:
                    return MboxIcon.Error;
                case MessageBoxIcon.Exclamation:
                    return MboxIcon.Warning;
                case MessageBoxIcon.None:
                    return MboxIcon.None;
                case MessageBoxIcon.Question:
                    return MboxIcon.Question;
            }
            return MboxIcon.None;
        }

        /*
        public static DialogResult Show(IWin32Window owner, string text)
        {
            return MessageBox.Show(owner, FilterMessage(text));
        }
        
        public static DialogResult Show(IWin32Window owner, string text, string caption)
        {
            return MessageBox.Show(owner, FilterMessage(text), caption);
        }
                
        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons)
        {
            return MessageBox.Show(owner, FilterMessage(text), caption, buttons);
        }
       
        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options)
        {
            return MessageBox.Show(FilterMessage(text), caption, buttons, icon, defaultButton, options);
        }

        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options)
        {
            return MessageBox.Show(owner, FilterMessage(text), caption, buttons, icon, defaultButton, options);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, bool displayHelpButton)
        {
            return MessageBox.Show(FilterMessage(text), caption, buttons, icon, defaultButton, options, displayHelpButton);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath)
        {
            return MessageBox.Show(FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath);
        }

        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath)
        {
            return MessageBox.Show(owner, FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator)
        {
            return MessageBox.Show(FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath, navigator);
        }

        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, string keyword)
        {
            return MessageBox.Show(FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath, keyword);
        }
        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator)
        {
            return MessageBox.Show(owner, FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath, navigator);
        }
        
        
        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, string keyword)
        {
            return MessageBox.Show(owner, FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath, keyword);
        }
        
        public static DialogResult Show(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator, object param)
        {
            return MessageBox.Show(FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath, navigator, param);
        }

        
        public static DialogResult Show(IWin32Window owner, string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton, MessageBoxOptions options, string helpFilePath, HelpNavigator navigator, object param)
        {
            return MessageBox.Show(owner, FilterMessage(text), caption, buttons, icon, defaultButton, options, helpFilePath, navigator, param);
        }*/

        public static string ShowMsg(Form aOwner,
            string aText,
            string aCaption,
            string[] aButtons,
            MboxIcon aImage,
            int aAcceptBtnIndex,
            int aCancelBtnIndex)
        {
            InstallMessageFilter();
            using (MessBoxDialog dlg = new MessBoxDialog(aOwner, aText.Trim(), aCaption, aButtons, aImage, aAcceptBtnIndex, aCancelBtnIndex))
            {
                if (aCancelBtnIndex < 0)
                    dlg.EnableEsc = false;
                dlg.ShowDialog();
                return dlg.Result;
            }
        }

        public static int ShowMsgInd(Form aOwner,
            string aText,
            string aCaption,
            string[] aButtons,
            MboxIcon aImage,
            int aAcceptBtnIndex,
            int aCancelBtnIndex)
        {
            InstallMessageFilter();
            using (MessBoxDialog dlg = new MessBoxDialog(aOwner, aText, aCaption, aButtons, aImage, aAcceptBtnIndex, aCancelBtnIndex))
            {
                dlg.ShowDialog();
                return dlg.ResultInd;
            }
        }

        public static IMessageFilter MessageFilter
        {
            set
            {
                fMessageFilter = value;
            }
        }static IMessageFilter fMessageFilter;

        static void InstallMessageFilter()
        {
            if (fMessageFilter == null)
                return;
            int id = System.Threading.Thread.CurrentThread.ManagedThreadId;
            if (ThreadsHavingFilterInstalled.Contains(id))
                return;
            try
            {
                Application.RemoveMessageFilter(fMessageFilter);//avoid double installing
            }
            catch (Exception) { }
            Application.AddMessageFilter(fMessageFilter);
            ThreadsHavingFilterInstalled.Add(id);
        }

        static List<int> ThreadsHavingFilterInstalled = new List<int>();


    }
}
