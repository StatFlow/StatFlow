using System.IO;
using System.Linq;
using System.Text.Json;
using System.Collections.Generic;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using MuzQuiz.Models;
using KindleCreator;

namespace MuzQuizTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void SongTxtToJson()
        {
            SongDataModel mdl = new SongDataModel(); //Use WriteTo JsonWriter
            var json = mdl.JsonForJstree().ToString();
        }

        [TestMethod]
        public void LoarLrcDir()
        {
            const string lrcDir = @"C:\App\MuzQuiz.data\lrc\Queen";
            LrcArtist art = new LrcArtist(new DirectoryInfo(lrcDir));
        }
    }
}
