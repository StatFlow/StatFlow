﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using MuzQuiz.Models;

namespace MuzQuiz.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly SongDataModel SongModel;
        public const string Answer = "_Answer";
        public const string Mp3File = "_Mp3File";
        

        public const int NumOfLinesInLyrics = 2;

        public HomeController(ILogger<HomeController> logger, SongDataModel songModel)
        {
            _logger = logger;
            SongModel = songModel;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return Index(null);
        }
        /*{
            // Requires: using Microsoft.AspNetCore.Http;
            //var cnt = HttpContext.Session.GetInt32(CounterName) ?? 0;
            //ViewBag.Counter = $"Page has been loaded {cnt} times";

            //New question
            var (sng, lyr) = SongModel.RandomLyrics(NumOfLinesInLyrics);
            ViewBag.Song = String.Join("\n", lyr.Select(l => l.Text));
            ViewBag.Correct = null;
            HttpContext.Session.SetString(Answer, sng.Id);
            return View();
        }*/

        [HttpGet("{songId}")]
        public IActionResult Index(string songId)
        {
            // Requires: using Microsoft.AspNetCore.Http;
            //var cnt = HttpContext.Session.GetInt32(CounterName) ?? 0;
            //ViewBag.Counter = $"Page has been loaded {cnt} times";
            Debug.WriteLine(HttpContext.Session.Id);

            //Check answer
            var ans = HttpContext.Session.GetString(Answer);

            if (ans != null)
            {
                var correctSong = SongModel.SongById(ans);
                ViewBag.Correct = songId == ans ? "Correct!" : $"Wrong, the correct answer is: '{correctSong.Album.Title}' / '{correctSong.Title}'";
                ViewBag.PrevFile = HttpContext.Session.GetString(Mp3File);
            }

            //New question
            var (sng, lyr, mp3File) = SongModel.RandomLyrics(NumOfLinesInLyrics);
            ViewBag.Song = String.Join("\n", lyr.Select(l => l.Text));
            ViewBag.CurrFile = mp3File;

            HttpContext.Session.SetString(Answer, sng.Id);
            HttpContext.Session.SetString(Mp3File, mp3File);
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
