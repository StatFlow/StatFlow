﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbOrmTest;
using NbTools;
using System.IO;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using NbOrm.Ms;
using NbOrm.Ora;

namespace NbToolsTest
{
    [TestClass]
    public class UnitTest1
    {
        //const string msConnString = @"Data Source=localhost\SQLEXPRESS;Initial Catalog=Test;integrated security=True;Trusted_Connection=True;MultipleActiveResultSets=True";
        const string msConnString = "data source=localhost;initial catalog=Test;user=sa;password=123;MultipleActiveResultSets=True;";

        [TestMethod, Ignore]
        public void UniMsCRUD()
        {
            using (NbMsConn conn = new NbMsConn(msConnString))
            {
                UniCRUD(conn);
                //Join(conn);
                //Aggregate(conn);
            }
        }

        [TestMethod, Ignore]
        public void UniOraCRUD()
        {
            string oraConnString = File.ReadAllText(@"C:\!Work\Code\connString");
            using (NbOraConn conn = new NbOraConn(oraConnString))
            {
                UniCRUD(conn);
                //Join(conn);
            }
        }

        const string some = "Some";
        private void Aggregate(INbConn conn)
        {
            ClearTables(conn);
            new Parent { String10 = some, StringMax = some, DecimalNull = 10M }.Insert(conn);
            new Parent { String10 = some, StringMax = some, DecimalNull = 20M }.Insert(conn);
            new Parent { String10 = some, StringMax = some, DecimalNull = null }.Insert(conn);
            var avg = GrpAverage.Select(conn).Single();
            Assert.AreEqual(15M, avg.Num);
            Assert.AreEqual(some, avg.Str);

            var countStar = GrpCountStar.Select(conn).Single();
            Assert.AreEqual(some, countStar.Str);
            Assert.AreEqual(3, countStar.Count);

            var countField = GrpCountField.Select(conn).Single();
            Assert.AreEqual(some, countField.Str);
            Assert.AreEqual(2, countField.Count); //One field is null
        }

        private void Join(INbConn conn)
        {
            ClearTables(conn);
            var par = new Parent { String10 = some, StringMax = some, DecimalVar = 10M };
            par.Insert(conn);
            var ch = new Child { ParentId = par.Id, Bool = false, DateVar = DateTime.Now };
            ch.Insert(conn);

            var parCh = ParentAndChild.Select(conn).Single();
            Assert.AreEqual(par.Id, parCh.ParentId);
            Assert.AreEqual(ch.Id, parCh.ChildId);
            Assert.IsTrue(DatesAreEqual(ch.DateVar, parCh.ChildDate));
            Assert.AreEqual(par.String10, parCh.ParentString);
        }

        private void UniCRUD(INbConn conn)
        {
            ClearTables(conn);

            Parent par = new Parent  { Id = CreateAndUpdateParent(conn) };

            var ch = new Child { ParentId = par.Id, Bool = true, BoolNull = null, DateVar = DateTime.Now, DateNull = null };
            ch.Insert(conn);
            var ch2 = Child.Select(conn, "WHERE Id = " + ch.Id.ToString()).Single();
            Assert.AreEqual(ch.ParentId, ch2.ParentId);
            Assert.AreEqual(ch.Bool, ch2.Bool);
            Assert.AreEqual(ch.BoolNull, ch2.BoolNull);
            Assert.IsTrue(DatesAreEqual(ch.DateVar, ch2.DateVar));
            Assert.IsTrue(DatesAreEqual(ch.DateNull, ch2.DateNull));

            ch.ParentId++; //There is no such id
            ExpectException(() => ch.Insert(conn));

            //Delete parent
            ExpectException(() => par.Delete(conn)); //can't delete parent, because the child exists and no delete cascase in place

            ch2.Delete(conn);
            par.Delete(conn);

            var tps = Parent.Select(conn).ToList();
            Assert.AreEqual(0, tps.Count);
        }

        private int CreateAndUpdateParent(INbConn conn)
        {
            var tp = new Parent
            {
                StringMax = "Maximum string, Maximum string, Maximum string, Maximum string, Maximum string, Maximum string, Maximum string, Maximum string, Maximum string, Maximum string, Maximum string, Maximum string",
                String10 = "0123456789",
                StringNull = null,
                IntNull = null,
                DecimalVar = 3.1415m,
                DecimalNull = null
            };
            tp.Insert(conn);

            //Check insertion
            var tps = Parent.Select(conn).ToList();
            Assert.AreEqual(1, tps.Count);
            var tp1 = tps[0];

            Assert.AreEqual(tp.StringMax, tp1.StringMax);
            Assert.AreEqual(tp.String10, tp1.String10);
            Assert.AreEqual(tp.StringNull, tp1.StringNull);
            Assert.AreEqual(tp.IntNull, tp1.IntNull);
            Assert.AreEqual(tp.DecimalVar, tp1.DecimalVar);
            Assert.AreEqual(tp.DecimalNull, tp1.DecimalNull);

            tp1.StringMax = "Some";
            tp1.String10 = "sdf";
            tp1.IntNull = 25;
            tp1.DecimalVar = 0;
            tp1.DecimalNull = 2.18M;
            tp1.Update(conn);

            //Check update
            var tp2 = Parent.Select(conn).Single();
            Assert.AreEqual(tp2.StringMax, tp1.StringMax);
            Assert.AreEqual(tp2.String10, tp1.String10);
            Assert.AreEqual(tp2.StringNull, tp1.StringNull);
            Assert.AreEqual(tp2.IntNull, tp1.IntNull);
            Assert.AreEqual(tp2.DecimalVar, tp1.DecimalVar);
            Assert.AreEqual(tp2.DecimalNull, tp1.DecimalNull);

            return tp.Id;
        }

        private void ClearTables(INbConn conn)
        {
            Child.DeleteAll(conn);
            Parent.DeleteAll(conn);
        }

        private void ExpectException(Action action)
        {
            Assert.IsNotNull(action);
            try
            {
                action();
                Assert.Fail("Action '{0}' didn't throw an expected exception", action.ToString());
            }
            catch { }
        }

        private bool DatesAreEqual(DateTime? a, DateTime? b)
        {
            if (!a.HasValue && !b.HasValue)
                return true;
            else if (!a.HasValue || !b.HasValue)
                return false;
            else
                return DatesAreEqual(a.Value, b.Value);
        }

        private bool DatesAreEqual(DateTime a, DateTime b)
        {
            const int ticksPrecision = 10000000;
            return a.Ticks / ticksPrecision == b.Ticks / ticksPrecision;
        }




        [TestMethod, Ignore]
        public void FromOracle1()
        {
            string connStr = File.ReadAllText(@"C:\!Work\Code\connString");
            using (OracleConnection connection = new OracleConnection(connStr))
            {
                connection.Open();
                var tableSizes = TableSizes.Load(connection);
                var tableGroups = tableSizes.GroupBy(t => t.ParentName)
                    .Select(g => Tuple.Create(g.Key, g.Sum(t => t.Mbytes), g.OrderByDescending(t => t.Type).ThenByDescending(t => t.Name).ToList()))
                    .OrderByDescending(tp => tp.Item2).ToList();

                using (StreamWriter wtrt = new StreamWriter(@"C:\Temp\tablestat.csv"))
                {
                    wtrt.WriteLine("Object Name,Object Type,Size Kb,Row count");
                    foreach (var grp in tableGroups)
                    {
                        var rowCount = CountRows(connection, grp.Item1);

                        wtrt.WriteLine("{0},TBL&IND,{1},{2}", grp.Item1, grp.Item2, rowCount);
                        foreach (var obj in grp.Item3)
                        {
                            wtrt.WriteLine("|--{0},{1},{2},", obj.Name, obj.Type, obj.Mbytes);
                        }
                    }

                    wtrt.WriteLine("TOTAL,DATABASE,{0},", tableGroups.Sum(g => g.Item2));
                }
            }
        }

        private static long CountRows(OracleConnection conn, string tableName)
        {
            string sql = @"select count(*) from " + tableName;
            using (var cmd = new OracleCommand(sql, conn))
            {
                using (OracleDataReader r = cmd.ExecuteReader())
                {
                    if (r.Read())
                    {
                        decimal dec = r.GetDecimal(0);
                        return (long)dec;
                    }
                    else
                        return -1;
                }
            }
        }
    }

    public class TableSizes
    {
        public string Name { set; get; }
        public string Type { set; get; }
        public string ParentName { set; get; }
        public decimal Mbytes { set; get; }

        internal static List<TableSizes> Load(OracleConnection conn)
        {
            string sql = @"select tbl.Name, tbl.Type, NVL(ind.TABLE_NAME, tbl.Name) ParentName, tbl.mbytes from 
(select segment_name Name, segment_type Type, sum(bytes) / 1024 / 1024 mbytes
from user_extents group by segment_name, segment_type) tbl 
left outer join user_indexes ind on tbl.Name = ind.index_name";

            using (var cmd = new OracleCommand(sql, conn))
            {
                using (OracleDataReader r = cmd.ExecuteReader())
                {
                    //return NbOrm.FromOracle<TableSizes>(r).ToList();
                    return null;
                }
            }
        }

    }
}
