﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using NbOrm.Nbq;
using NbOrm.Xml;

namespace NbOrmTest
{
    [TestClass]
    public class NbqTest
    {
        private model fModelDwHome;
        //private model fModelNorthWind;

        [TestInitialize()]
        public void Initialize()
        {
            fModelDwHome = model.MergeXmls(@"..\..\..\DataWalker\Data\Home*.xml"); //C:\Repo\NbTools\DataWalker\Data\
            //fModelNorthWind = model.MergeXmls(@"..\..\..\DataWalker\Data\NorthWind.xml");
        }

        [TestMethod]
        public void TableAndFieldPrefixes_InTheModel()
        {
            var mdl = model.MergeXmls(@"..\..\NorthwindWithPrefixes.xml"); //C:\Repo\NbTools\DataWalker\Data\
            Assert.AreEqual("TBL_", mdl.config.table_prefix);
            Assert.AreEqual("FLD_", mdl.config.field_prefix);

            string req = "dbo.Shippers[ShipperID=18]";
            NbqRecordset parsed = NbqParser.Parse(req, mdl);
            recordset recSet = parsed.Recordset;

            var sqlByUri = recSet.SqlSelectStatementByUri(NbqQueryType.nbsql, req, mdl, env: null); //Enviroment is only required for Custom Sql builders
            var oneLineSql = sqlByUri.Replace("\r\n", " ");
            //Trace.WriteLine(oneLineSql);
            Assert.AreEqual(oneLineSql, "SELECT FLD_ShipperID ,FLD_CompanyName ,FLD_Phone FROM TBL_dbo.Shippers  WHERE FLD_ShipperID = 18");

        }

        //var dic = new Dictionary<string, int>{ ["Bob"] = 32, ["Alice"] = 17 }; - Another style for dictionary initialization
        private static readonly Dictionary<string, string> nbq_test1 = new Dictionary<string, string>
        {
            {"COUNTRIES['FR','IT']", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE COUNTRY_ID = 'FR'  AND COUNTRY_ID = 'IT'" },                                  
            {"DOMAIN.COUNTRIES[REGION_ID=12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB FROM DOMAIN.COUNTRIES  WHERE REGION_ID = 12" },
            {"JOB_HISTORY[^13-JAN-01^]", "SELECT EMPLOYEE_ID ,START_DATE ,END_DATE ,JOB_ID ,DEPARTMENT_ID FROM JOB_HISTORY  WHERE START_DATE = '13-Jan-2001'" },
            {"COUNTRIES['Côte d''Ivoire', 12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE COUNTRY_ID = 'Côte d'Ivoire'  AND COUNTRY_ID = 12" },
            {"COUNTRIES[REGION_ID=12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE REGION_ID = 12" },
            {"COUNTRIES[REGION_ID=12,COUNTRY_NAME='Belgium']", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE REGION_ID = 12  AND COUNTRY_NAME = 'Belgium'" },
            {"COUNTRIES[12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE COUNTRY_ID = 12" },
        };

        [TestMethod]
        public void ParserTests()
        {
            foreach (var (nbq_str,  exp_sql) in nbq_test1)
            {
                NbqRecordset parsed = NbqParser.Parse(nbq_str, fModelDwHome);
                recordset recSet = parsed.Recordset;

                var sqlByUri = recSet.SqlSelectStatementByUri(NbqQueryType.nbsql, nbq_str, fModelDwHome, env: null); //Enviroment is only required for Custom Sql builders
                var oneLineSql = sqlByUri.Replace("\r\n", " ");
                //Trace.WriteLine(oneLineSql);
                Assert.AreEqual(exp_sql, oneLineSql);
            }
        }



    }

    public static class Ext
    {
        public static void Deconstruct<T1, T2>(this KeyValuePair<T1, T2> tuple, out T1 key, out T2 value)
        {
            key = tuple.Key;
            value = tuple.Value;
        }
    }
}

//country[AR]
//country[country_name:'United & kindom']<>regions[1566]<id=Id_a>locations/

/*COUNTRIES[12] - с id 12 - может быть как key = "primary" так и default_search="int"
COUNTRIES['Belgium'] -  COUNTRY_NAME  - может быть как key = "primary" так и default_search="int"

COUNTRIES[REGION_ID = 12] прямое указание поля
COUNTRIES[REGION_ID = 12, COUNTRY_NAME = 'Belgium'] прямое указание двух полей
    COUNTRIES['Belgium', REGION_ID = 12] - дефолтное поле и прямое поле

       COUNTRIES[REGION_ID <= 12]
COUNTRIES[REGION_ID != 12]
COUNTRIES[REGION_ID != null]

COUNTRIES[L'B?lg%']
COUNTRIES[R'^B\d+lg$']


COUNTRIES[10 <= REGION_ID < 12, ]

COUNTRIES(name = COUNTRY_NAME)[REGION_ID!=null]

OMBI(PARAM(CUS = VALUE)[OMNI_ID=ID, TYPE='CUS'],*) - must me null or single
OMBI(*, INTERN(*_I)[ID=INTERN_ID]) - must me null or single


COUNTRIES<> REGIONS  - inner join by the existing foreign key
 COUNTRIES<REGION_ID=REGION_ID>REGIONS - inner join by the existing foreign key*/

//В крулых скобках - какие поля выводить ,особенно полезно для PIVOT tables


/*
[AssemblyInitialize()]
public static void AssemblyInit(TestContext context) { }

[ClassInitialize()]
public static void ClassInit(TestContext context) { }

[TestInitialize()]
public void Initialize() { }

[TestCleanup()]
public void Cleanup() { }

[ClassCleanup()]
public static void ClassCleanup() { }

[AssemblyCleanup()]
public static void AssemblyCleanup() { }*/
