﻿using HtmlAgilityPack;
using Nb.WebLib;
using System;
using System.IO;
using System.Linq;
using Xunit;

namespace NbWebLibTest
{
    public class HelperMethods
    {
        [Fact]
        public void DownloadFavIcon_1()
        {
            string[] urls = new string[]
            {
                "http://corei3:8800/doku.php",
                "https://www.youtube.com/watch?v=c4NvDaMQs6g",
                //"https://www.tesco.com",
                "https://www.bbc.co.uk/weather/2643558",
                "https://www.metoffice.gov.uk/public/weather/forecast/map/u10jcedg4#?map=Rainfall&fcTime=1534100400&zoom=8&lon=-0.19&lat=51.66",
            };

            int cnt = 1;
            foreach (var url in urls)
            {
                var (IconBytes, FileName) = WebLib.DownloadFavIcon(new Uri(url));
                Assert.True(IconBytes.Length > 0);
                File.WriteAllBytes($@"C:\AutoDelete\{cnt++}.ico", IconBytes);
            }
        }
    }
}
