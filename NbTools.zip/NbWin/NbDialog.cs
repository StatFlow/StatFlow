﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NbWin
{
    public static class NbDialog
    {
        public static Control ParentWindow
        {
            get
            {
                return m_ParWnd ?? throw new ArgumentNullException($"NbDialog.{nameof(ParentWindow)} property should be initialized or program startup");
            }
            set { m_ParWnd = value; }
        }
        private static Control m_ParWnd = null;

        public static string Title { get; set; }

        delegate DialogResult CallDialog(string mess, string title);

        private static readonly CallDialog OkDelegate = (string mess, string title) => MessageBox.Show(ParentWindow, mess, title ?? Title, MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
        private static readonly CallDialog YesNoDelegate = (string mess, string title) => MessageBox.Show(ParentWindow, mess, title ?? Title, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
        private static readonly CallDialog YesNoCancelDelegate = (string mess, string title) => MessageBox.Show(ParentWindow, mess, title ?? Title, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);

        public static bool YesNo(string mess, string title = null) => (ParentWindow.InvokeRequired ? ParentWindow.Invoke(YesNoDelegate, mess, title) : OkDelegate(mess, title)) switch
        {
            DialogResult.Yes => true,
            _ => false,
        };

        public static bool? YesNoCancel(string mess, string title = null) => (ParentWindow.InvokeRequired ? ParentWindow.Invoke(YesNoCancelDelegate, mess, title) : OkDelegate(mess, title)) switch
        {
            DialogResult.Yes => true,
            DialogResult.No => false,
            _ => null,
        };

        public static void OK(string mess, string title = null)
        {
            if (ParentWindow.InvokeRequired)
                ParentWindow.Invoke(OkDelegate, mess, title);
            else
                OkDelegate(mess, title);
        }
    }
}

