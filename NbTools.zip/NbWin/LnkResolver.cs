﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbWin
{
    public class LnkResolver
    {

        //https://stackoverflow.com/questions/31403956/exception-when-using-shell32-to-get-file-extended-properties
        public static string GetLnkTarget(string lnkPath)
        {
            var shl = new Shell32.Shell();         // Move this to class scope
            lnkPath = System.IO.Path.GetFullPath(lnkPath);
            var dir = shl.NameSpace(System.IO.Path.GetDirectoryName(lnkPath));
            var itm = dir.Items().Item(System.IO.Path.GetFileName(lnkPath));
            var lnk = (Shell32.ShellLinkObject)itm.GetLink;
            return lnk.Target.Path;
        }
    }
}
