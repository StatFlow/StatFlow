﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Threading.Tasks;

#if NETSTANDARD2_0
using Microsoft.Data.SqlClient;
#else
using System.Data.SqlClient;
#endif

using NbTools;

namespace NbOrm.Ms
{
    public class NbMsConn : INbConn, IDisposable
    {
        //private readonly SqlConnection fConn;
        private readonly string ConnString;
        public ConnectionType ConnType => ConnectionType.MsSql;

        public NbMsConn(string connString)
        {
            ConnString = connString;
        }

        public INbCommand CreateCommand(string sql) => new NbMsCommand(ConnString, sql);
        public INbTrans BeginTransaction() => throw new NotImplementedException();
        public INbReader CreateReader(string sql) => new NbMReader(ConnString, sql);

        public void Dispose() { } //fConn.Dispose();

        public DataTable ReadDataTableAsync(string query)
        {
            using var conn = new SqlConnection(ConnString);
            conn.Open();

            using var da = new SqlDataAdapter();
            using (da.SelectCommand = conn.CreateCommand())
            {
                da.SelectCommand.CommandText = query;
                //da.SelectCommand.Connection.ConnectionString = _connectionString;
                DataSet ds = new DataSet(); //conn is opened by dataadapter
                da.Fill(ds);
                return ds.Tables[0];
            }
        }

        /// <summary>
        /// Creates a throw-away connection in order to initialize the pool
        /// </summary>
        /// <returns></returns>
        public Task Initialize()
        {
            using var conn = new SqlConnection(ConnString);
            return conn.OpenAsync();
        }

        public async Task<T> ReadSingleAsync<T>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? rdr.GetValue<T>(0) : default;
        }

        public async Task<(T, U)> ReadSingleAsync<T, U>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? (rdr.GetValue<T>(0), rdr.GetValue<U>(1)) : default;
        }

        public async Task<(T, U, V)> ReadSingleAsync<T, U, V>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? (rdr.GetValue<T>(0), rdr.GetValue<U>(1), rdr.GetValue<V>(1)) : default;
        }

        public async Task<List<T>> ReadListAsync<T>(string sql)
        {
            var list = new List<T>();
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                list.Add(rdr.GetValue<T>(0));
            return list;
        }

        public async Task<List<(T, U)>> ReadListAsync<T, U>(string sql)
        {
            var list = new List<(T, U)>();
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                list.Add((rdr.GetValue<T>(0), rdr.GetValue<U>(1)));
            return list;
        }

        public async Task<List<(T, U, V)>> ReadListAsync<T, U, V>(string sql)
        {
            var list = new List<(T, U, V)>();
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                list.Add((rdr.GetValue<T>(0), rdr.GetValue<U>(1), rdr.GetValue<V>(2)));
            return list;
        }

        public async Task<NbDictionary<K, V>> ReadDictionaryAsync<K, V>(string sql, string dictDecr = null)
        {
            var dict = new NbDictionary<K, V>(description: dictDecr);
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                dict.Add(rdr.GetValue<K>(0), rdr.GetValue<V>(0));
            return dict;
        }
    }

    public class NbMsCommand : INbCommand
    {
        private readonly SqlConnection fConn;
        private readonly SqlCommand fCmd;

        public NbMsCommand(string connStr, string sql)
        {
            fConn = new SqlConnection(connStr);
            fCmd = fConn.CreateCommand();
            fCmd.CommandText = sql;
            fCmd.CommandType = System.Data.CommandType.Text;
        }

        public void AddParam(string name, object value) => fCmd.Parameters.AddWithValue("@" + name, (object)value ?? DBNull.Value);
        public void AddParam(string name, bool value) => fCmd.Parameters.AddWithValue("@" + name, value);
        public void AddParam(string name, bool? value) => fCmd.Parameters.AddWithValue("@" + name, (object)value ?? DBNull.Value);
        public void AddBlob(string name, byte[] value) => throw new NotImplementedException();

        public async Task RunAsync()
        {
            await fConn.OpenAsync();
            await fCmd.ExecuteNonQueryAsync();
        }
        public async Task<int> RunGetInt32Async()
        {
            await fConn.OpenAsync();
            object res = await fCmd.ExecuteScalarAsync();
            return Convert.ToInt32(res);
        }

        public void Dispose()
        {
            fCmd?.Dispose();
            fConn?.Dispose();
        }

        public T ReadSingle<T>() => throw new NotImplementedException();
        public Tuple<T, U> ReadSingle<T, U>() => throw new NotImplementedException();
        public Tuple<T, U, V> ReadSingle<T, U, V>() => throw new NotImplementedException();
    }

    public class NbMReader : INbReader, IDisposable
    {
        private readonly SqlConnection fConn;
        private readonly SqlCommand fCmd;
        private SqlDataReader fRdr;

        public Type GetFieldType(int ordinal) => fRdr.GetFieldType(ordinal);
        public bool IsDBNull(int ordinal) => fRdr.IsDBNull(ordinal);
        public async Task<int> FieldCount() => (await Rdr()).FieldCount;

        public NbMReader(string connStr, string sql)
        {
            fConn = new SqlConnection(connStr);
            fCmd = fConn.CreateCommand();
            fCmd.CommandText = sql;
            fCmd.CommandType = System.Data.CommandType.Text;
        }

        private async Task<SqlDataReader> Rdr()
        {
            if (fRdr == null)
            {
                await fConn.OpenAsync();
                fRdr = await fCmd.ExecuteReaderAsync();
            }
            return fRdr;
        }

        public async Task<bool> ReadAsync()
        {
            var rdr = await Rdr();
            return await rdr.ReadAsync();
        }

        public void Dispose()
        {
            fRdr?.Dispose();
            fCmd?.Dispose();
            fConn?.Dispose();
        }


        public T GetValue<T>(int index) => fRdr.IsDBNull(index) ? default : (T)Convert.ChangeType(fRdr.GetValue(index), typeof(T));

        public T GetNullableNumber<T>(int index) where T : struct =>
            fRdr.IsDBNull(index) ? default : GetNumber<T>(index);

        public T GetNumber<T>(int index) where T : struct
        {
            return typeof(T).Name switch
            {
                nameof(Byte) => (T)(object)fRdr.GetByte(index),
                nameof(Int16) => (T)(object)fRdr.GetInt16(index),
                nameof(Int32) => (T)(object)fRdr.GetInt32(index),
                _ => throw new Exception($"Unsupported type in GetNumber<{typeof(T).Name}>"),
            };
        }

        public string GetString(int index) => fRdr.GetString(index);
        public string GetNullableString(int index) => fRdr.IsDBNull(index) ? (string)null : fRdr.GetString(index);


        public Int16? GetNullableInt16(int index) => fRdr.IsDBNull(index) ? (Int16?)null : GetInt16(index);

        public Int16 GetInt16(int index)
        {
            var a = fRdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Boolean) => fRdr.GetBoolean(index) ? (short)1 : (short)0,
                nameof(Byte) => fRdr.GetByte(index),
                nameof(Int16) => fRdr.GetInt16(index),
                _ => throw new Exception($"Unsupported type in GetNullableInt16: {a}"),
            };
        }

        public int? GetNullableInt32(int index) => fRdr.IsDBNull(index) ? (int?)null : GetInt32(index);

        public int GetInt32(int index)
        {
            var a = fRdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Byte) => fRdr.GetByte(index),
                nameof(Int16) => fRdr.GetInt16(index),
                nameof(Int32) => fRdr.GetInt32(index),
                _ => throw new Exception($"Unsupported type in GetInt32: {a}"),
            };
        }

        public long? GetNullableInt64(int index) => fRdr.IsDBNull(index) ? (long?)null : fRdr.GetInt64(index);
        public long GetInt64(int index)
        {
            var a = fRdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Byte) => fRdr.GetByte(index),
                nameof(Int16) => fRdr.GetInt16(index),
                nameof(Int32) => fRdr.GetInt32(index),
                nameof(Int64) => fRdr.GetInt64(index),
                _ => throw new Exception($"Unsupported type in GetInt64: {a}"),
            };
        }

        public decimal GetDecimal(int index) => fRdr.GetDecimal(index);
        public decimal? GetNullableDecimal(int index) => fRdr.IsDBNull(index) ? (decimal?)null : fRdr.GetDecimal(index);
        public double GetDouble(int index) => fRdr.GetDouble(index);
        public double? GetNullableDouble(int index) => fRdr.IsDBNull(index) ? (double?)null : fRdr.GetDouble(index);
        public DateTime GetDateTime(int index) => fRdr.GetDateTime(index);
        public DateTime? GetNullableDateTime(int index) => fRdr.IsDBNull(index) ? (DateTime?)null : fRdr.GetDateTime(index);
        public bool GetBoolean(int index) => fRdr.GetBoolean(index);
        public bool? GetNullableBoolean(int index) => fRdr.IsDBNull(index) ? (bool?)null : fRdr.GetBoolean(index);
        public char GetChar(int index) => fRdr.GetString(index)[0];
        public char? GetNullableChar(int index) => fRdr.IsDBNull(index) ? (char?)null : fRdr.GetString(index)[0];
        public string GetName(int index) => fRdr.GetName(index);

        public string GetBlob(int v) => throw new NotImplementedException();

        public byte[] GetBytes(int index)
        {
            throw new NotImplementedException();
        }

        public DataTable FillDataTable()
        {
            throw new NotImplementedException();
        }
    }

    /*public class NbMsTrans : INbTrans, IDisposable
    {
        private readonly SqlTransaction fTrans;

        public NbMsTrans(SqlConnection conn) => fTrans = conn.BeginTransaction(); //TODO: Isolation level
        public void Commit() => fTrans.Commit();
        public void Dispose() => fTrans.Dispose();
    }*/
}
