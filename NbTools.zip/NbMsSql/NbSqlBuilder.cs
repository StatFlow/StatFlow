﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NbTools.SqlGen.Xml;
using A2aTypes.Xml;

namespace NbTools
{
    public class NbSqlBuilder
    {
        private readonly NbSqlXml SqlXml;
        private readonly Dictionary<string, SubTreeInfo> SubTreeInfosN;

        public NbSqlBuilder(NbSqlXml sqlXml, Dictionary<string, SubTreeInfo> subTreeInfosN)
        {
            SqlXml = sqlXml;
            if (SqlXml.table == null || SqlXml.table.Length == 0) throw new ArgumentException("Tables were not provided with SqlXml");
            SubTreeInfosN = subTreeInfosN;
        }

        public int FieldCount => SqlXml.table.Sum(t => t.field?.Length ?? 0);

        [Obsolete("store the styles on the UI sid")]
        public IEnumerable<(string fieldName, DisplayStyles displayStyle)> ColumnNamesAndStyles()
        {
            foreach (NbSqlField fld in SqlXml.table.SelectMany(t => t.field).Where(f => !f.exclude))
            {
                if (fld.name == "Size")
                    yield return (fld.name, DisplayStyles.FileSize);
                else
                    yield return (fld.name, DisplayStyles.String);
            }
        }

        /*public void AddField(string sqlName, string outName = null, string where = null, bool groupBy = false, int orderBy = 0)
            => Fields.Add(new Field { SqlName = sqlName, OutName = outName, Where = where, GroupBy = groupBy, OrderBy = orderBy });*/

        public string GetMsSqlString()
        {
            StringBuilder bld = new StringBuilder();
            StringBuilder preSelects = new StringBuilder(); //Selects that will be inserted before the current one which then will be used in where in  statements

            //SELECT
            string fromStatement = CreateFromStatement(SqlXml.table);

            CommaList(bld, $"select top {SqlXml.top} ", CreateSelectList(SqlXml.table), separator: ", ");
            bld.Append($" from {fromStatement}\r\n");

            //WHERE
            var wheresAndPreselectsN = SqlXml.filter.Safe().Select((f, cntr) => CreateWhereExpr(f, cntr)).ToList();

            foreach (var fld in SqlXml.table.SelectMany(t => t.field))
            {
                var flt = CreateInlineWhereExpr(fld);
                if (flt != null)
                    wheresAndPreselectsN.Add((flt, null));
            }

            if (wheresAndPreselectsN != null)
            {
                CommaList(preSelects, "with", wheresAndPreselectsN.Select(ws => ws.preselect), separator: ",\r\n");
                CommaList(bld, "where\r\n", wheresAndPreselectsN.Select(ws => ws.where), separator: "\r\n  and ");
            }

            //ORDER BY
            var orderFields = SqlXml.table.SelectMany(t => t.field).Where(f => f.order_ind >= 0).OrderBy(f => f.order_ind).ToList();
            if (orderFields.Count > 0)
                CommaList(bld, "order by ", orderFields.Select(s => s.OrderBySql), separator: ", ");

            string sql = preSelects.ToString() + Environment.NewLine + bld.ToString();
            return sql;
        }

        private string CreateInlineWhereExpr(NbSqlField fld)
        {
            if (!String.IsNullOrWhiteSpace(fld.filter_eq) && !String.IsNullOrWhiteSpace(fld.filter_like))
                throw new NbExceptionInfo($"Both filter_eq and filter_like are not allowed on the same field: {fld}");
            else if (!String.IsNullOrWhiteSpace(fld.filter_eq))
                return $"{fld.name} = {fld.filter_eq}"; //TODO: be aware of the type - do not use quotes for int and process dates properly - do it in one place
            else if (!String.IsNullOrWhiteSpace(fld.filter_like))
            {
                if (fld.filter_like.Contains('%')) //The user may provide it.
                    return $"{fld.name} like '{fld.filter_like}'"; //TODO: be aware of the type - do not use quotes for int and process dates properly - do it in one place
                else
                    return $"{fld.name} like '%{fld.filter_like}%'"; //TODO: be aware of the type - do not use quotes for int and process dates properly - do it in one place
            }
            else
                return null;
        }

        internal IEnumerable<string> CreateSelectList(NbSqlTable[] table)
        {
            foreach (NbSqlTable tbl in table)
            {
                foreach (NbSqlField fld in tbl.field.Where(f => !f.exclude))
                {
                    yield return $"{tbl.alias}.{fld.name}";
                }
            }
        }


        internal string CreateFromStatement(NbSqlTable[] table)
        {
            StringBuilder bld = new StringBuilder($"{table[0].name} {table[0].alias}\r\n");

            for (int i = 1; i < table.Length; i++)
            {
                NbSqlTable tb = table[i];
                NbSqlTable joinTb = table.FirstOrDefault(t => t.name == tb.join.to_table) ?? throw new Exception($"Table {tb.name} is joined to table {tb.join.to_table}, which can't be found");
                NbSqlField joinFld = joinTb.field.FirstOrDefault(f => f.name == tb.join.to_field) ?? throw new Exception($"Table {tb.name} is joined to table's '{tb.join.to_table}' field '{tb.join.to_field}', which can't be found");


                NbSqlJoin join = tb.join;

                bld.Append($"\tleft join {tb.name} {tb.alias} on {joinTb.alias}.{joinFld.name} = {tb.alias}.Id"); //TODO: ask for field to join or primary key
            }

            return bld.ToString();
        }


        private (string where, string preselect) CreateWhereExpr(FilterBase f, int cntr)
        {
            switch (f)
            {
                case Subtree subtree:
                    SubTreeInfo sti = null;
                    if (!SubTreeInfosN?.TryGetValue(subtree.tree_table, out sti) ?? false) //SubTree info - database (server)-side additional information on how to traverse trees on the database.
                        throw new Exception($"Can't find subtree info for the '{subtree.field}' inSubtree filter criteria");

                    //TODO: think about dealing with Id (used to Id to TagId links) and ParentDirId - used to link a record within the same table, These are two different cases.

                    string inNotIn = subtree.exclude ? "not in" : "in";

                    if (subtree.root_node_only) //One node only, preselect is not required
                    {
                        if (!String.IsNullOrEmpty(sti.ManyToManyTable))
                            return ($"{subtree.TableResolved.alias}.Id {inNotIn} (select {sti.ManyToManyLeftField} from {sti.ManyToManyTable} where {sti.ManyToManyRightField} = {subtree.root_node_id})", null);
                        else
                            return ($"{subtree.TableResolved.alias}.ParentDirId {inNotIn} ({subtree.root_node_id})", null); //= would be better, but keeping in for code reuse
                    }
                    else //Subtree preselect statement is required to traverse the tree
                    {
                        string preselName = "presel" + cntr;
                        string preselect = subtree.root_node_only ? null : TreeTraversal(subtree.root_node_id, sti, preselName);

                        if (!String.IsNullOrEmpty(sti.ManyToManyTable))
                            return ($"{subtree.TableResolved.alias}.Id {inNotIn} (select {sti.ManyToManyLeftField} from {sti.ManyToManyTable} inner join {preselName} on {preselName}.Id = {sti.ManyToManyTable}.{sti.ManyToManyRightField})", preselect);
                        else
                            return ($"{subtree.TableResolved.alias}.ParentDirId {inNotIn} (select {sti.PrimaryKeyName} from {preselName})", preselect);
                    }

                case FltContain cnt: return ($"{cnt.field} like '%{cnt.val}%'", null);
                case FltEqual eq: return ($"{eq.field} = {eq.val}", null);//TODO: be aware of the type - do not use quotes for int and process dates properly
                default: throw new Exception($"Filter type '{f.GetType().Name}' is not yet supported");
            }
        }


        /// <summary>
        /// Creates tree-traversing sql sub-request that will be used in   "in ()" statement in the main select
        /// </summary>
        /// <param name="rootNodeId">The Id of the node that acts a root of the subtree</param>
        /// <param name="sti"></param>
        /// <param name="preselName"></param>
        /// <returns></returns>
        private string TreeTraversal(string rootNodeId, SubTreeInfo sti, string preselName)
        {
            //TODO: assign the name of the temp table from the list preSel01 - preSel99
            string preselect = $@" {preselName}({sti.PrimaryKeyName},{sti.ParentFieldName}) as (
		select Id,{sti.ParentFieldName} from {sti.TableName} where {sti.PrimaryKeyName} = {rootNodeId}
			union all
		select e.{sti.PrimaryKeyName}, e.{sti.ParentFieldName}
		from {sti.TableName} e inner join {preselName} on e.{sti.ParentFieldName} = {preselName}.{sti.PrimaryKeyName})";
            return preselect;
        }

        /*private string TreeTraversal2(string dirId)
		{
			//TODO: assign the name of the temp table from the list preSel01 - preSel99
			string preselect = $@" with t(level,path,Id,ParentDirId,Name) as (
		select 0,Name,Id,ParentDirId,Name from Dirs where Id = {dirId}
	union all
		select
			level + 1,
			e.name + '\' + path,
			e.Id,
			e.ParentDirId,
			e.Name 
		from 
			Dirs e
			inner join t on e.ParentDirId = t.Id
)";
			return preselect;
		}*/


        /*public string GetOracleString()
        {
            //Checks if filed is unique
            if (Fields.Count == 0)
                throw new Exception("No fields in the request");
            //NbDictionary<string, int> fieldNames = 

            bool isGroupBy = false;
            foreach (var fl in Fields)
            {
                if (fl.GroupBy)
                    isGroupBy = true;
            }

            StringBuilder bld = new StringBuilder();
            if (isGroupBy)
            {
                //Only allow groupby fields in group by select
                var fldList = isGroupBy ? Fields.Where(f => f.GroupBy).Select(f => f.OracleFieldStatement)
                    : Fields.Where(f => f.GroupBy).Select(f => f.OracleFieldStatement);

                CommaList(bld, "select\r\n", fldList, separator: ",\r\n");
                CommaList(bld, "from", Tables.Select(t => t.Name));
                CommaList(bld, "where", Fields.Select(f => f.WhereStatement), separator: " and ");
                CommaList(bld, "group by", Fields.Where(f => f.GroupBy && !f.SqlName.EqIC("NULL")).Select(f => f.SqlName));
                //TODO: support descending
                CommaList(bld, "order by", Fields.Where(f => f.OrderBy != 0).OrderBy(f => Math.Abs(f.OrderBy)).Select(f => f.SqlName));
            }
            else
                throw new NotImplementedException("NbSqlBuilder fo non-group bys");

            return bld.ToString().TrimStart('\r', '\n');
        }*/

        private void CommaList(StringBuilder bld, string prefix, IEnumerable<string> entries, string separator = null)
        {
            bool first = true;
            foreach (var entry in entries.Where(e => !String.IsNullOrWhiteSpace(e)))
            {
                if (first)
                {
                    first = false;
                    bld.AppendLine(); //Start prefix from a new line
                    bld.Append(prefix).Append(' ');
                }
                else
                    bld.Append(separator ?? ", ");

                bld.Append(entry);
            }
            //bld.AppendLine();
        }

        class Field
        {
#pragma warning disable CS0649 //This will be set via serialization
            internal string SqlName;
            internal string OutName;
            internal string Where;
            internal bool GroupBy;
            internal int OrderBy;
#pragma warning restore CS0649

            internal string OracleFieldStatement => String.IsNullOrEmpty(OutName) ? SqlName : $"{SqlName} as \"{OutName}\"";
            internal string MsSqlFieldStatement => String.IsNullOrEmpty(OutName) ? SqlName : $"{SqlName} as {OutName}";
            internal string WhereStatement => String.IsNullOrEmpty(Where) ? "" : $"{SqlName} {Where}";

        }

        /// <summary>
        /// Keeps info about building the preselect for tree traversal for in_subtree 
        /// </summary>
        public class SubTreeInfo
        {
            public string TableName;
            public string PrimaryKeyName; //Primary key in the table containing the tree, the ParentFieldName refers to it.
            public string ParentFieldName; //The name of the field in the table keeping tree structure that refers to the parent Id .
            public string ManyToManyTable;
            public string ManyToManyLeftField;
            public string ManyToManyRightField;
        }
    }
}
