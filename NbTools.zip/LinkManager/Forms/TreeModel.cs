﻿using LinkManager.Data;
using NbTools;
using NbTools.Collections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Data;
using System.Windows.Media;

namespace LinkManager.Forms
{
    public class TreeNodeViewModel : INotifyPropertyChanged
    {
        public readonly int Ind;
        private readonly TreeManager fTreeMan;

        public TreeNodeViewModel(int ind, TreeManager treeMan)
        {
            Ind = ind;
            fTreeMan = treeMan;

            fTreeMan.fEnt.Changed += Entities_Changed;
            fTreeMan.fEnt.ValueChanged += Entities_ValueChanged;
        }

        private void Entities_ValueChanged(IDfColumnBase col, int ind)
        {
            if (ind != Ind)
                return; //Update for a different node

            if (col == fTreeMan.fEnt.Name)
                NotifyPropertyChanged(nameof(Name));
            else if (col == fTreeMan.fEnt.Icon)
                NotifyPropertyChanged(nameof(Icon));
        }

        private void Entities_Changed(DfCollChangedEventType eventType)
        {
            switch (eventType)
            {
                case DfCollChangedEventType.Reset:
                    fChildrenFiltered = null; //invalidate collection
                    NotifyPropertyChanged(nameof(ChildrenFiltered)); break;
                default:
                    throw new NbExceptionEnum<DfCollChangedEventType>(eventType);
            }
        }

        public IEnumerable<int> GetAllCheckedInds()
        {
            if (IsChecked)
                yield return Ind;
            foreach (int subInd in ChildrenFiltered.Cast<TreeNodeViewModel>().SelectMany(ch => ch.GetAllCheckedInds()))
                yield return subInd;
        }

        public string Name => fTreeMan.fEnt.Name.GetText(Ind);
        public ImageSource Icon => fTreeMan.fImgDict[fTreeMan.fEnt.Icon.GetText(Ind)];
        public bool IsChecked
        {
            get { return fChecked; }
            set
            {
                fChecked = value;
                fTreeMan.NodeCheckedChanged();
            }
        }
        private bool fChecked;

        public bool IsNodeExpanded => true;

        public void SetFolderNameFilter(string filter)
        {
            //Show non-empty folders + those that have the substring
            if (!String.IsNullOrEmpty(filter)) //!ChildrenFiltered.IsEmpty ||
            {
                foreach (TreeNodeViewModel fldView in ChildrenFiltered) //Start filtering from the bottom, parents must have their chidren already filtered
                    fldView.SetFolderNameFilter(filter);

                ChildrenFiltered.Filter = obj =>
                {
                    TreeNodeViewModel tvf = obj as TreeNodeViewModel;
                    return !tvf.ChildrenFiltered.IsEmpty || tvf.Name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0; //Ignore case "contains"
                };
            }
            else
            {
                ChildrenFiltered.Filter = null;

                foreach (TreeNodeViewModel fldView in ChildrenFiltered) //Start removing filter from the top. Children must have their parents existing.
                    fldView.SetFolderNameFilter(filter);
            }
        }


        public ICollectionView ChildrenFiltered
        {
            get
            {
                if (fChildrenFiltered == null)  //Create collectin of node view models with children items
                {
                    var nodes = fTreeMan.fEnt.Type.Where(v => fTreeMan.Sett.ShowInTree[v], fTreeMan.fEnt.GetTreeChildren(Ind))
                        .Select(i => new TreeNodeViewModel(i, fTreeMan)).ToList();
                    fChildrenFiltered = CollectionViewSource.GetDefaultView(nodes);
                }
                //fChildrenFiltered = CollectionViewSource.GetDefaultView(Ent.Children.EntOfType(EntType.Folder).Select(f => new TreeNodeViewModel(f, _imgDict)));
                return fChildrenFiltered;
            }
            set { fChildrenFiltered = value; NotifyPropertyChanged(); }
        }
        private ICollectionView fChildrenFiltered;

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
