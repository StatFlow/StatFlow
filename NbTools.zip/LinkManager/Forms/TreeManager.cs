﻿using LinkManager.Data;
using LinkManSettV1.Xml;
using NbTools.Graphics;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

namespace LinkManager.Forms
{
    public class TreeManager : INotifyPropertyChanged
    {
        public readonly DfEntitiesColletion fEnt;
        public readonly ImageDictionary fImgDict;
        private readonly TreeView fTreeView;
        private readonly TextBox fSearchTextBox;
        private readonly EntityCommandManager fCmdMan;
        internal readonly LinkManSett Sett;

        public event Action<int[]> NodesCheckedInd;
        public event Action<int> NodeSelected;

        public List<TreeNodeViewModel> RootNodes
        {
            get { return fRootNodes; }
            set { fRootNodes = value; NotifyPropertyChanged(); }
        }
        private List<TreeNodeViewModel> fRootNodes;

        private readonly DispatcherTimer fTreeSearchStringTimer;

        //Constructor
        internal TreeManager(TreeView treeView, TextBox treeSearchText, DfRepository rep, ImageDictionary imgDict, EntityCommandManager cmdMan, LinkManSett sett)
        {
            fEnt = rep.Entities;
            Sett = sett;
            
            fImgDict = imgDict;
            fCmdMan = cmdMan;
            fTreeView = treeView;
            fTreeView.MouseUp += FTreeView_MouseUp;

            fSearchTextBox = treeSearchText;
            fSearchTextBox.TextChanged += (_, __) => fTreeSearchStringTimer.Start();

            RootNodes = fEnt.Parents.WhereInList(s => s.Count == 0, fEnt.Type.Where(v => Sett.ShowInTree[v], fEnt.All))
                .Select(i => new TreeNodeViewModel(i, this)).ToList();

            fTreeView.ItemsSource = RootNodes;
            fTreeView.ContextMenuOpening += TreeView_ContextMenuOpening;
            fTreeView.SelectedItemChanged += TreeView_SelectedItemChanged;
            //fTreeView.MouseRightButtonDown += FTreeView_MouseRightButtonDown; Makes right button select the tree node

            fTreeSearchStringTimer = new DispatcherTimer { Interval = new TimeSpan(0, 0, 0, 0, 500) };
            fTreeSearchStringTimer.Tick += TreeSearchStringTimer_Tick;
        }

        /*private void FTreeView_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            TreeViewItem treeViewItem = VisualUpwardSearch(e.OriginalSource as DependencyObject);

            if (treeViewItem != null)
            {
                treeViewItem.Focus();
                e.Handled = true;
            }
        }*/

        static TreeViewItem VisualUpwardSearch(DependencyObject source)
        {
            while (source != null && !(source is TreeViewItem))
                source = VisualTreeHelper.GetParent(source);

            return source as TreeViewItem;
        }

        private void TreeView_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            TreeViewItem treeViewItem = VisualUpwardSearch(e.OriginalSource as DependencyObject);
            if (treeViewItem == null)
            {
                MessageBox.Show("Context Menu is only available for tree nodes");
                return;
            }

            ContextMenu theMenu = null;

            FrameworkElement fe = e.Source as FrameworkElement;
            var tvItem = treeViewItem.Header as TreeNodeViewModel;
            if (fe != null && tvItem != null)
            {
                theMenu = new ContextMenu();

                bool prevSeparator = false;

                foreach (NbCommand comm in fCmdMan.GetCommands(tvItem.Ind)) //fEnt.GetCommands(lvItem.Ind, mainWindow)
                {
                    if (comm == null)
                    {
                        if (!prevSeparator)
                            theMenu.Items.Add(new Separator());

                        prevSeparator = true;
                        continue;
                    }

                    MenuItem mia = new MenuItem { Command = comm, Header = comm.Title, ToolTip = comm.TooltipN };
                    ToolTipService.SetShowOnDisabled(mia, true); //Attached property: show tooltip on disabled items
                    theMenu.Items.Add(mia);
                    prevSeparator = false;
                }
            }
            fe.ContextMenu = theMenu;
        }

        private void TreeSearchStringTimer_Tick(object sender, EventArgs e)
        {
            fTreeSearchStringTimer.Stop();

            if (!String.IsNullOrEmpty(fSearchTextBox.Text) && !String.IsNullOrEmpty(tbTreeSearchPrev)) //If search text changed from text to text
                RootNodes[0].SetFolderNameFilter(null); //Remove the filter before applying the new one (solves some problems)

            RootNodes[0].SetFolderNameFilter(fSearchTextBox.Text);
            tbTreeSearchPrev = fSearchTextBox.Text;
        }
        private string tbTreeSearchPrev = null;


        private void FTreeView_MouseUp(object sender, MouseButtonEventArgs e)
        {
            /*var selectedArr = RootNodes.SelectMany(ch => ch.GetAllCheckedInds()).ToArray(); //Recursive tree traverse
            NodesCheckedInd?.Invoke(selectedArr.Length > 0 ? selectedArr : null);*/
        }

        public void NodeCheckedChanged()
        {
            var selectedArr = RootNodes.SelectMany(ch => ch.GetAllCheckedInds()).ToArray(); //Recursive tree traverse
            NodesCheckedInd?.Invoke(selectedArr.Length > 0 ? selectedArr : null);
        }

        private void TreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            var sel = e.NewValue as TreeNodeViewModel;
            NodeSelected(sel?.Ind ?? -1);
        }

        public void RemoveSelection()
        {
            if (fTreeView.SelectedItem == null)
                return;

            var container = FindTreeViewSelectedItemContainer(fTreeView, fTreeView.SelectedItem);
            if (container != null)
                container.IsSelected = false;

            NodesCheckedInd?.Invoke(null);
        }

        private static TreeViewItem FindTreeViewSelectedItemContainer(ItemsControl root, object selection)
        {
            var item = root.ItemContainerGenerator.ContainerFromItem(selection) as TreeViewItem;
            if (item == null)
            {
                foreach (var subItem in root.Items)
                {
                    item = FindTreeViewSelectedItemContainer((TreeViewItem)root.ItemContainerGenerator.ContainerFromItem(subItem), selection);
                    if (item != null)
                        break;
                }
            }
            return item;
        }


        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
