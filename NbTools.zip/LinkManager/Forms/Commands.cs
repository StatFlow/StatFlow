﻿using Doer.Logic;
using LinkManager.Data;
using LinkManSettV1.Xml;
using NbTools;
using NbTools.Collections;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace LinkManager.Forms
{
    public static class TransactionCommands
    {
        //public static RoutedUICommand Edit = new RoutedUICommand("Edit", "Edit", typeof(TransactionCommands));
        public static RoutedUICommand SwapFocus = new RoutedUICommand(nameof(SwapFocus), nameof(SwapFocus), typeof(TransactionCommands));
        public static RoutedUICommand EditDialog = new RoutedUICommand(nameof(EditDialog), nameof(EditDialog), typeof(TransactionCommands));
        public static RoutedUICommand ResetUi = new RoutedUICommand(nameof(ResetUi), nameof(ResetUi), typeof(TransactionCommands));
        public static RoutedUICommand PlayCommand = new RoutedUICommand(nameof(PlayCommand), nameof(PlayCommand), typeof(TransactionCommands));
    }

    public class OpenLinkCommand : ICommand
    {
        private readonly IMainWindow fMainUI;
        private readonly LinkManSett Sett;

        public OpenLinkCommand() { }

        public OpenLinkCommand(IMainWindow mainWindow, LinkManSett sett)
        {
            fMainUI = mainWindow;
            Sett = sett;
        }

        async void ICommand.Execute(object parameter) => await ExecuteAsync(parameter);

        public async Task ExecuteAsync(object parameter)
        {
            try
            {
                if (parameter is ListModel lstModel)
                    await ExecuteAsync(lstModel.Ind, lstModel.Lm.fDfRep);
                else
                    MessageBox.Show($"Unsupported command Name: '{parameter}'");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing command: '{NbException.Exception2String(ex)}'");
            }
        }

        internal async Task ExecuteAsync(int Ind, DfRepository rep)
        {
            string laucherId = rep.Entities.Launcher[Ind];
            string url = rep.Entities.Url[Ind];
            if (!String.IsNullOrEmpty(laucherId)) //If launcher is provided
            {
                if (laucherId.EqIC("Function"))
                {
                    switch (url)
                    {
                        //case "Work": await Nb.Library.Web.Selenium.Work.Run(fStatusN.GetTxt()); break;
                        case "Work":
                            using (var os = new Os(@"NbSelenium.exe"))  //C:\Repo\NbTools\NbSelenium\bin\Debug\
                            {
                                var res = await os.Start("Barc " + fMainUI.GetTxt());
                            }
                            break;
                            //await Nb.Library.Web.Selenium.Work.Run(fStatusN.GetTxt()); break;
                        case "EncodePass": Clipboard.SetText(new NbTools.Crypto.TripleDESStringEncryptor().EncryptBase64(fMainUI.GetTxt().Trim())); break;
                        case "DecodePass": Clipboard.SetText(new NbTools.Crypto.TripleDESStringEncryptor().DecryptBase64(fMainUI.GetTxt().Trim())); break;
                        case "Base64ToFile": CustomFunctions.Base64ToFile(Clipboard.GetText()); break;
                        default: throw new NbException($"Unsupported local function: {url} in the entry #{rep.Entities.Name[Ind]}");
                    }

                }
                else //Normal Launch
                {
                    var launcher = Sett.Lauchers[laucherId];
                    FileInfo fi = new FileInfo(Environment.ExpandEnvironmentVariables(launcher.path));
                    if (!fi.Exists)
                        throw new NbException($"Laucher '{fi.FullName}' is not found");

                    var resolvedDoc = ResolveVariables(url);
                    fMainUI?.ShowStatus($"Starting {fi.Name}");
                    await Task.Run(() => Process.Start(new ProcessStartInfo { FileName = fi.FullName, Arguments = $"{launcher.cl_params} \"{resolvedDoc}\"" }));
                    fMainUI?.ShowStatus(""); //DfTodo*/
                }
            }
            else //Laucher is not provided
            {
                var resolvedDoc = ResolveVariables(url);

                fMainUI?.ShowStatus($"Verb for {resolvedDoc}");
                await Task.Run(() =>
                {
                    Process p;
                    int exeLocation = resolvedDoc.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
                    if (exeLocation != -1)
                    {
                        exeLocation = Math.Min(exeLocation + 5, resolvedDoc.Length); //Could end with exe of "my.exe"
                        string exe = resolvedDoc.Substring(0, exeLocation); //+1 if case of "my.exe"
                        string args = resolvedDoc.Substring(exeLocation);
                        p = Process.Start(new ProcessStartInfo { Verb = "open", FileName = $"\"{exe}\"", Arguments = args });
                    }
                    else
                    {
                        p = Process.Start(new ProcessStartInfo { Verb = "open", FileName = $"\"{resolvedDoc}\"" });
                    }
                });
                fMainUI?.ShowStatus("");
            }

            var ctc = rep.Entities.CopyToClipboard[Ind];
            if (!String.IsNullOrWhiteSpace(ctc))
            {
                ctc = ResolveVariables(ctc);
                Clipboard.SetText(ctc);
            }

            rep.Entities.EditLine(Ind);
            rep.Entities.AccessTime.SetValue(DateTime.Now);
            rep.Entities.ReleaseLine();
        }

        internal string ResolveVariables(string url)
        {
            var resolvedDoc = url.Replace("%TXT%", fMainUI.GetTxt() ?? String.Empty);
            resolvedDoc = Environment.ExpandEnvironmentVariables(Sett.ResolveVariablesInString(resolvedDoc));
            return resolvedDoc;
        }


        public bool CanExecute(object parameter) => true;

#pragma warning disable 67
        public event EventHandler CanExecuteChanged; //Can execute if always true and can't change
#pragma warning restore

    }

    /*public class CmdRemoveDuplicates : ICommand
    {
        private readonly Repository fRep;

        public CmdRemoveDuplicates(Repository rep)
        {
            fRep = rep;
        }

        public void Execute(object parameter)
        {
            //Remove duplicate links
            var toKeep = new HashSet<string>();
            var indexesToRemove = new List<int>();

            for (int i = fRep.Links.Count - 1; i >= 0; --i)
            {
                Entity curLink = fRep.Links[i];
                if (toKeep.Contains(curLink.Url))
                    indexesToRemove.Add(i);
                else
                    toKeep.Add(curLink.Url);
            }

            foreach (var i in indexesToRemove)
                fRep.Links.RemoveAt(i);

            MessageBox.Show(String.Format("'{0}' duplicates were removed", indexesToRemove.Count));
            fRep.Save();
        }

        public bool CanExecute(object parameter) => true;

#pragma warning disable 67
        public event EventHandler CanExecuteChanged; //Can execute if always true and can't change
#pragma warning restore
    }*/

    public class RelayCommand : ICommand
    {
        private readonly Action _action;
        public RelayCommand(Action action)
        {
            Debug.Assert(action != null);
            _action = action;
        }

        public void Execute(object parameter) => _action();
        public bool CanExecute(object parameter) => true;

#pragma warning disable 67
        public event EventHandler CanExecuteChanged; //Can execute if always true and can't change
#pragma warning restore
    }

    public class EntityCommandManager
    {
        private readonly Window fMainWindow;
        private readonly DfRepository DfRep;
        private readonly LinkManSett Sett;

        public EntityCommandManager(Window mainWindow, DfRepository dfRep, LinkManSett sett)
        {
            fMainWindow = mainWindow;
            DfRep = dfRep;
            Sett = sett;
        }

        public IEnumerable<NbCommand> GetCommands(int ind)
        {
            string typeName = DfRep.Entities.Type[ind];
            bool showInTree = Sett.ShowInTree[typeName];

            if (showInTree)
            {
                foreach (string treeType in Sett.ShowInTree.Where(p => p.Value).Select(p => p.Key))
                {
                    yield return new NbCommand($"New child {treeType}", () => CreateEntry(ind, treeType));
                }
                yield return new NbCommand("Edit", () => EditEntry(isClone: false, ind: ind));
                yield return new NbCommand("Delete", () => DfRep.Entities.Delete(ind));
            }
            else
            {
                yield return new NbCommand("Edit", () => EditEntry(isClone: false, ind: ind));
                yield return new NbCommand("Clone", () => EditEntry(isClone: true, ind: ind));

                /*yield return new NbCommand("Clone", () =>
                {
                    Links.Add(link.Clone()); //Registers with parents
                });*/

                yield return new NbCommand("Archive", () => DfRep.Entities.ArchiveRestore(ind));
                yield return new NbCommand("Delete", () => DfRep.Entities.Delete(ind));
                if (!String.IsNullOrWhiteSpace(DfRep.Entities.Url[ind]))
                    yield return new NbCommand("Copy Url", () => Clipboard.SetData(System.Windows.DataFormats.Text, DfRep.Entities.Url[ind]));


                yield return new NbCommand("To the bottom", () =>
                {
                    DfRep.Entities.EditLine(ind);
                    DfRep.Entities.AccessTime.SetValue(DateTime.MinValue);
                    DfRep.Entities.ReleaseLine();
                });
            }
        }


        public void CreateEntry(int ind, string entryType)
        {
            var dict = new Dictionary<IDfColumnBase, string>(2)
            {
                { DfRep.Entities.Parents, DfRep.Entities.Id.GetText(ind) },
                { DfRep.Entities.Type, entryType }
            };

            ObjectEditor obEd = new ObjectEditor(true, -1, DfRep.Entities, dict) { Owner = fMainWindow };
            obEd.ShowDialog();
        }

        public void EditEntry(bool isClone, int ind)
        {
            if (ind == -1) //Still don't have the index
                return;

            ObjectEditor obEd = new ObjectEditor(isClone, ind, DfRep.Entities) { Owner = fMainWindow };
            obEd.ShowDialog();
        }
    }
}
