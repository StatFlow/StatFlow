﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media;

using LinkManager.Data;
using NbTools;
using NbTools.Collections;

namespace LinkManager.Forms
{
    public class ListModel : INotifyPropertyChanged, IDfValueChangeListener, IIndHolder
    {
        public int Ind { get; private set; }

        internal DfEntitiesColletion Ent => Lm.fDfRep.Entities;

        internal readonly ListManager Lm;
        private readonly List<ImageSource> fIcons;

        internal ListModel(int ind, ListManager lm)
        {
            Ind = ind;
            Lm = lm;
            fIcons = new List<ImageSource>(8);
            UpdateIcons();
        }

        private void UpdateIcons()
        {
            fIcons.Clear();
            var iconName = Ent.Icon.GetText(Ind);

            Lm.GetIconN(iconName)?.AddTo(fIcons);

            foreach (var parInd in Ent.Parents.GetReferences(Ind))
                Lm.GetIconN(Ent.Icon.GetText(parInd))?.AddTo(fIcons);
        }

        public string ToDisplay
        {
            get
            {
                if (String.IsNullOrEmpty(Ent.ShortCut.GetText(Ind)))
                    return Ent.Name.GetText(Ind);
                else
                    return $"{Ent.Name.GetText(Ind)} ({Ent.ShortCut.GetText(Ind)})";
                //{String.Join("-", Link.ShortCut.Select(l => l.ToString()))} //DfTODO
            }
        }

        public override string ToString() => ToDisplay;

        public string Col0 => Lm.GetText(0, Ind);
        public string Col1 => Lm.GetText(1, Ind);
        public string Col2 => Lm.GetText(2, Ind);
        public string Col3 => Lm.GetText(3, Ind);

        public void OnValueChanged(IDfColumnBase col, int ind)
        {
            if (col == Ent.Name || col == Ent.ShortCut)
                NotifyPropertyChanged(nameof(ToDisplay));
            else if (col == Ent.Url)
                NotifyPropertyChanged(nameof(Col1));
            else if (col == Ent.Icon || col == Ent.Parents)
            {
                UpdateIcons();
                for (int i = 1; i <= 8; ++i) //TODO: Use smarter algorithm to notify about the change only
                {
                    NotifyPropertyChanged("Icon" + i.ToString());
                    NotifyPropertyChanged("Vis" + i.ToString());
                }
            }
        }

        public ImageSource Icon1 => fIcons.Count < 1 ? null : fIcons[0];
        public ImageSource Icon2 => fIcons.Count < 2 ? null : fIcons[1];
        public ImageSource Icon3 => fIcons.Count < 3 ? null : fIcons[2];
        public ImageSource Icon4 => fIcons.Count < 4 ? null : fIcons[3];
        public ImageSource Icon5 => fIcons.Count < 5 ? null : fIcons[4];
        public ImageSource Icon6 => fIcons.Count < 6 ? null : fIcons[5];
        public ImageSource Icon7 => fIcons.Count < 7 ? null : fIcons[6];
        public ImageSource Icon8 => fIcons.Count < 8 ? null : fIcons[7];

        public Visibility Vis1 => fIcons.Count < 1 ? Visibility.Collapsed : Visibility.Visible;
        public Visibility Vis2 => fIcons.Count < 2 ? Visibility.Collapsed : Visibility.Visible;
        public Visibility Vis3 => fIcons.Count < 3 ? Visibility.Collapsed : Visibility.Visible;
        public Visibility Vis4 => fIcons.Count < 4 ? Visibility.Collapsed : Visibility.Visible;
        public Visibility Vis5 => fIcons.Count < 5 ? Visibility.Collapsed : Visibility.Visible;
        public Visibility Vis6 => fIcons.Count < 6 ? Visibility.Collapsed : Visibility.Visible;
        public Visibility Vis7 => fIcons.Count < 7 ? Visibility.Collapsed : Visibility.Visible;
        public Visibility Vis8 => fIcons.Count < 8 ? Visibility.Collapsed : Visibility.Visible;

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
