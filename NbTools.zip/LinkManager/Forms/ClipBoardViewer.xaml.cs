﻿using Nb.Graphics;
using NbTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;

namespace LinkManager.Forms
{
    /// <summary>
    /// Interaction logic for ClipBoardViewer.xaml
    /// </summary>
    public partial class ClipBoardViewer : Window
    {
        public ClipBoardViewer(IDataObject dataObj)
        {
            InitializeComponent();
            DisplayDataObject(dataObj);
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            HwndSource source = PresentationSource.FromVisual(this) as HwndSource;
            source.AddHook(WndProc);
            NativeMethods.AddClipboardFormatListener(source.Handle);
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            HwndSource source = PresentationSource.FromVisual(this) as HwndSource;
            NativeMethods.RemoveClipboardFormatListener(source.Handle);
            base.OnClosing(e);
        }

        private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == NativeMethods.WM_CLIPBOARDUPDATE)
            {
                OnClipboardUpdate(null);
            }
            return IntPtr.Zero;
        }

        private void OnClipboardUpdate(EventArgs e) => DisplayDataObject(Clipboard.GetDataObject());



        private void DisplayDataObject(IDataObject dataObj)
        {
            grMainGrid.Children.Clear();
            grMainGrid.RowDefinitions.Clear();

            string[] formats = dataObj.GetFormats();
            //int rowCounter = 0;

            foreach (string format in formats)
            {
                grMainGrid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

                TextBlock tb = new TextBlock { Text = format };

                grMainGrid.Children.Add(tb);
                Grid.SetColumn(tb, 0);
                Grid.SetRow(tb, grMainGrid.RowDefinitions.Count - 1);

                if (Extensions.TryGetImageSource(format, dataObj, out BitmapSource imgSrc))  //Try Image field first
                {
                    Image img = new Image() { Source = imgSrc };

                    grMainGrid.Children.Add(img);
                    Grid.SetColumn(img, 1);
                    Grid.SetRow(img, grMainGrid.RowDefinitions.Count - 1);
                }
                else //Text field
                {
                    string infa;
                    try
                    {
                        switch (format)
                        {
                            case "DragContext":
                                infa = "ignored";
                                break;
                            default:
                                infa = DropObjectToString(dataObj, format);
                                if (infa != null && infa.Length > 200)
                                    infa = infa.Substring(0, 200) + "...";
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        infa = NbException.Exception2String(ex);
                    }

                    TextBox tx = new TextBox() { Text = infa, TextWrapping = TextWrapping.Wrap };

                    grMainGrid.Children.Add(tx);
                    Grid.SetColumn(tx, 1);
                    Grid.SetRow(tx, grMainGrid.RowDefinitions.Count - 1);
                }
            }
        }



        public static string DropObjectToString(IDataObject dataObj, string format)
        {
            switch (format)
            {
                case "FileGroupDescriptor":
                    var a = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORA>((MemoryStream)dataObj.GetData("FileGroupDescriptor")).ToList();
                    return "'" + String.Join("', '", a.Select(d => d.cFileName)) + "'";

                case "FileGroupDescriptorW":
                    var a1 = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORW>((MemoryStream)dataObj.GetData("FileGroupDescriptorW")).ToList();
                    return "'" + String.Join("', '", a1.Select(d => d.cFileName)) + "'";

                case "FileContents":
                    //TODO: show image on the screen without saving it to the disk
                    OutlookDataObject odo = new OutlookDataObject(dataObj);
                    using (MemoryStream ms = (MemoryStream)odo.GetData("FileContents", 0))
                    {
                        using (var fileStream = new FileStream(@"c:\Temp\tempfile.png", FileMode.Create))
                        {
                            ms.WriteTo(fileStream);
                        }
                    }
                    return @"Saved to c:\Temp\tempfile.png";

                case "application/x-moz-nativeimage":
                case "MetaFilePict": //Selection from paint
                case "DeviceIndependentBitmap": //Selection from paint
                    return "Ignored";

                default:
                    break;
            }

            object obj = dataObj.GetData(format);
            switch (obj.GetType().Name)
            {
                case "String":
                    return obj as String;

                case "String[]":
                    string[] strs = obj as String[];
                    return "'" + String.Join("', '", strs) + "'";

                case "MemoryStream":
                    using (StreamReader sr = new StreamReader(obj as MemoryStream, Encoding.Unicode))
                    {
                        string mess = sr.ReadToEnd().Replace("\0", " ");
                        return mess;
                    }

                default:
                    return "Unsupported DropObject Type: " + obj.GetType().Name;
            }
        }
    }
}
