﻿using LinkManager.Data;
using Nb.Graphics;
using NbTools;
using NbTools.Collections;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LinkManager.Forms
{
    /// <summary>
    /// Interaction logic for ClipBoardViewer.xaml
    /// </summary>
    public partial class ObjectEditor : Window
    {
        private readonly int Ind;
        private readonly DfEntitiesColletion fColl;
        private readonly Brush fDefaultBackground;

        private const string Ok = "OK";
        private const string Create = "Create";

        public ObjectEditor(bool isClone, int ind, DfEntitiesColletion coll, Dictionary<IDfColumnBase, string> values = null)
        {
            InitializeComponent();
            SizeToContent = SizeToContent.WidthAndHeight;
            Ind = ind;
            fColl = coll;
            btOk.Content = isClone ? Create : Ok;

            foreach (var col in fColl.GetColumns())
            {
                grMainGrid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

                TextBlock tb = new TextBlock { Text = col.Name };

                grMainGrid.Children.Add(tb);
                Grid.SetColumn(tb, 0);
                Grid.SetRow(tb, grMainGrid.RowDefinitions.Count - 1);

                if (values == null || !values.TryGetValue(col, out string text))  //if not found or dictionary doesn't exist
                    if (Ind == -1 || (isClone && col == fColl.PrimaryKeyColumn))
                        text = null;
                    else
                        text = col.GetText(Ind);

                TextBox tx = new TextBox() { Text = text, TextWrapping = TextWrapping.Wrap };
                grMainGrid.Children.Add(tx);
                Grid.SetColumn(tx, 1);
                Grid.SetRow(tx, grMainGrid.RowDefinitions.Count - 1);
                tx.Tag = col;

                if (fDefaultBackground == null)
                    fDefaultBackground = tx.Background;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string button = (sender as Button).Content.ToString();
            if (button == "Cancel")
            {
                Close();
                return;
            }

            ///Validation
            var validationMessages = new Dictionary<TextBox, string>(grMainGrid.Children.Count);
            foreach (var textBox in grMainGrid.Children.OfType<TextBox>())
            {
                if (textBox.Background != fDefaultBackground) //Reset backgrounds from last run
                    textBox.Background = fDefaultBackground;

                var pi = textBox.Tag as IDfColumnBase;
                if (pi == null)
                    throw new NbExceptionInfo("IDfColumnBase info was not set as a tag for TextBox");

                var oldText = Ind == -1 ? null : pi.GetText(Ind);
                if (!textBox.Text.Equals(oldText)) //Set only if the value has changed, reducing the amount of events
                {
                    var mess = pi.ValidateTextN(textBox.Text);
                    if (mess != null)
                    {
                        validationMessages.Add(textBox, mess);
                        textBox.Background = Brushes.Salmon;
                    }
                }
            }

            if (validationMessages.Count > 0)
            {
                MessageBox.Show(String.Join(Environment.NewLine, validationMessages.Values));
                return;
            }

            //// Saving
            switch (button)
            {
                case Ok:
                    fColl.EditLine(Ind);
                    foreach (var textBox in grMainGrid.Children.OfType<TextBox>())
                    {
                        var pi = textBox.Tag as IDfColumnBase;
                        if (pi == null)
                            throw new NbExceptionInfo("IDfColumnBase info was not set as a tag for TextBox");

                        var oldText = pi.GetText(Ind);
                        if (!textBox.Text.Equals(oldText)) //Set only if the value has changed, reducing the amount of events
                        {
                            pi.SetText(textBox.Text);
                        }
                    }
                    fColl.ReleaseLine();
                    break;

                case Create:
                    var dict = new Dictionary<IDfColumnBase, string>(20);
                    foreach (var textBox in grMainGrid.Children.OfType<TextBox>())
                    {
                        var pi = textBox.Tag as IDfColumnBase;
                        if (pi == null)
                            throw new NbExceptionInfo("IDfColumnBase info was not set as a tag for TextBox");

                        dict.Add(pi, textBox.Text);
                    }

                    fColl.Add(dict);
                    break;

                default:
                    throw new NbExceptionInfo($"Unsupported button caption {sender.GetType().Name}: '{(sender as Button).Content}'");
            }

            Close();
        }
    }
}
