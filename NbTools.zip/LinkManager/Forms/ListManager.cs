﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Runtime.CompilerServices;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Data;

using LinkManager.Data;
using LinkManager.Forms;

using NbTools;
using NbTools.Collections;
using NbTools.Graphics;
using LinkManSettV1.Xml;

namespace LinkManager
{
    public partial class ListManager : INotifyPropertyChanged
    {
        private readonly DataGrid grid;
        private readonly Window mainWindow;
        private readonly TextBox tbSearch;

        internal readonly DfRepository fDfRep;
        private readonly EntityCommandManager fCmdMan;

        private readonly OpenLinkCommand hwc;

        private readonly DfEntitiesColletion fEnt;
        private readonly DfFilter fDfFilter;
        private readonly DfOrder fDfOrder;

        private readonly ImageDictionary fImdDict;
        private readonly List<IDfColumnBase> fColumnMapping;
        private readonly LinkManSett Sett;

        public NbVirtualList<ListModel> MainList
        {
            get { return fMainList; }
            private set { fMainList = value; NotifyPropertyChanged(); }
        }
        private NbVirtualList<ListModel> fMainList;

        private static readonly DfFilter.FilterFunction filFunct = new DfFilter.FilterFunction { Name = "OneAndOnly", Complexity = 10, Function = null };
        private readonly DfFilter.FilterFunction archivedFilter;
        private readonly DfFilter.FilterFunction showInTreeFilter;

        //Constructor
        internal ListManager(DataGrid dataGrid, TextBox searchTextBox, DfRepository rep, ImageDictionary imgDict, OpenLinkCommand aHwc, EntityCommandManager cmdMan, LinkManSett sett)
        {
            fDfRep = rep;
            fEnt = rep.Entities;
            fImdDict = imgDict;
            hwc = aHwc;
            fCmdMan = cmdMan;
            Sett = sett;

            grid = dataGrid;
            grid.DataContext = this;
            grid.SelectionChanged += LvList_SelectionChanged;
            grid.MouseDoubleClick += LvList_MouseDoubleClick;
            grid.ContextMenuOpening += LvList_ContextMenuOpening;

            mainWindow = (Window)PresentationSource.FromVisual(grid).RootVisual;

            tbSearch = searchTextBox;
            tbSearch.PreviewKeyDown += TbSearch_PreviewKeyDown;

            var typesToShowInList = Sett.ShowInTree.Where(p => !p.Value).Select(p => p.Key).ToArray();
            showInTreeFilter = new DfFilter.FilterFunction { Name = "NotShownInTree", Complexity = 2, Function = i => typesToShowInList.Contains(fEnt.Type[i]) };
            //Setting up filter with Archived by default
            archivedFilter = new DfFilter.FilterFunction { Name = "Archived", Complexity = 1, Function = i => fEnt.ArchivedDate[i] == DateTime.MinValue };
            fDfFilter = new DfFilter(fEnt);
            fDfFilter.AddFunction(archivedFilter);  //Do not show archived entries
            fDfFilter.AddFunction(showInTreeFilter); //Do not show Folders and other tree living entries

            fDfOrder = new DfOrder(fDfFilter);
            //fDfOrder.Order = (x, y) => fEnt.AccessTime[x].CompareTo(fEnt.AccessTime[y]);
            fDfOrder.ByColumn(fEnt.AccessTime, desc: true);

            fColumnMapping = CreateColumnMapping(grid);

            MainList = new NbVirtualList<ListModel>(fEnt, fDfOrder,
                itemGetter: i => new ListModel(i, this),
                indexGetter: lm => lm.Ind);
        }

        /// <summary>
        /// Creates columns in the data grid based on DfColumnMapColletion collection.
        /// </summary>
        /// <param name="columnMap"></param>
        /// <param name="grid"></param>
        /// <returns></returns>
        private List<IDfColumnBase> CreateColumnMapping(DataGrid grid)
        {
            var ret = new List<IDfColumnBase>();
            int i = 0;
            foreach (ListColumn lc in Sett.list_columns)
            {
                var col = fDfRep.Entities.GetColumn(lc.name);
                ret.Add(col);

                var gridCol = new DataGridTextColumn
                {
                    Header = lc.label ?? lc.name,
                    Binding = new Binding($"Col{i++}"),
                    Width = lc.width
                };
                grid.Columns.Add(gridCol);
            }
            return ret;
        }

        //Called from ListModel (for every line)
        internal string GetText(int col, int row) => fColumnMapping.Count > col ? fColumnMapping[col].GetText(row) : null;
        internal ImageSource GetIconN(string name) => fImdDict.GetN(name);

        private void TbSearch_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            int cnt;
            switch (e.Key)
            {
                case Key.Down:
                    cnt = grid.Items.Count;
                    if (grid.SelectedIndex == cnt - 1)
                        grid.SelectedIndex = 0;
                    else
                        grid.SelectedIndex++;
                    grid.ScrollIntoView(grid.SelectedItem);
                    break;

                case Key.Up:
                    cnt = grid.Items.Count;
                    if (grid.SelectedIndex == 0)
                        grid.SelectedIndex = cnt - 1;
                    else
                        grid.SelectedIndex--;
                    grid.ScrollIntoView(grid.SelectedItem);
                    break;

                case Key.Enter:
                    LvList_MouseDoubleClick(sender, null); //TODO
                    break;

                default: break;
            }
        }

        private async void LvList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            await Task.Delay(500); //The list has to update for ScrollIntoView to work
            if (grid.SelectedItem != null)
                grid.ScrollIntoView(grid.SelectedItem);
        }

        private async void LvList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (grid.SelectedItem == null && sender is TextBox) //If enter pressed on the search box and there is no selected item
                {
                    if (grid.HasItems)
                    {
                        grid.SelectedIndex = 0;
                        //grid.SelectedItem = grid.Items[0];  //Worked with list, doesn't work with grid
                        grid.ScrollIntoView(grid.SelectedItem);
                    }
                    else
                        return;
                }

                tbSearch.Text = null;
                await hwc?.ExecuteAsync(grid.SelectedItem);
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
        }

        private void LvList_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            if (!(e.Source is FrameworkElement fe))
                return;

            if ((sender as Selector)?.SelectedItem is ListModel lvItem) //If selection exists
            {
                var theMenu = new ContextMenu();
                bool prevSeparator = false;

                foreach (NbCommand comm in fCmdMan.GetCommands(lvItem.Ind)) //fEnt.GetCommands(lvItem.Ind, mainWindow)
                {
                    if (comm == null)
                    {
                        if (!prevSeparator)
                            theMenu.Items.Add(new Separator());

                        prevSeparator = true;
                        continue;
                    }

                    MenuItem mia = new MenuItem { Command = comm, Header = comm.Title, ToolTip = comm.TooltipN };
                    ToolTipService.SetShowOnDisabled(mia, true); //Attached property: show tooltip on disabled items
                    theMenu.Items.Add(mia);
                    prevSeparator = false;
                }
                fe.ContextMenu = theMenu;
            }
            else //Selection doesn't exist
            {
                var theMenu = new ContextMenu();
                MenuItem mia = new MenuItem { Command = null, Header = "Choose columns" };
                ToolTipService.SetShowOnDisabled(mia, true); //Attached property: show tooltip on disabled items
                theMenu.Items.Add(mia);
                fe.ContextMenu = theMenu;
            }
        }

        public void InvokeShortCut(ICollection<Key> keys)
        {
            var keysStr = String.Join("|", keys.Select(k => k.ToString()));
            try
            {
                foreach (var matchingInd in fDfRep.Entities.All.Wher(fDfRep.Entities.ShortCut, sc => keysStr.Equals(sc, StringComparison.OrdinalIgnoreCase)))
                {
                    hwc?.ExecuteAsync(matchingInd, fDfRep);
                    break; //Open only the first match
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error executing command: '{NbException.Exception2String(ex)}'");
            }
        }

        private DfFilter.FilterFunction FiltersByReference;
        internal void SetFilterByReference(int[] parentFolderIndsN)
        {
            if (parentFolderIndsN != null)
            {
                //TODO: deside how to select each reference column - come up with matrix?
                var func = new DfFilter.FilterFunction
                {
                    Name = "Filter by reference - all fields",
                    Complexity = 10,
                    Function = i => !parentFolderIndsN.Except(fEnt.Parents[i]).Any()
                    //And logic - selected ids must be subset of element's parents. In this case selected - parents = empty set, hence !Any()
                };

                //
                // Function = i => fEnt.Parents[i].Intersect(parentFolderIndsN).Any() ||
                //fEnt.Path[i].Intersect(parentFolderIndsN).Any()
                //Or logic - more selects more elements
                //Include if Parent refereces of a given record contains at least one of the selected folders


                FiltersByReference = func;
                fDfFilter.AddFunction(func);
            }
            else if (FiltersByReference != null)
            {
                fDfFilter.RemoveFunction(FiltersByReference);
                FiltersByReference = null;
            }
        }

        private string FilterStringN;
        internal void SetFilter(string searchString)
        {
            FilterStringN = searchString;
            GenerateFilterFunc();
        }

        private readonly List<Key> FilterKeys = new List<Key>(5); //Up to 5 control keys pressed at the same time
        internal void SetFilter(Dictionary<Key, bool> keyStates)
        {
            FilterKeys.Clear(); //Reuse list to avoid allocations
            foreach (Key key in keyStates.Where(p => p.Value).Select(p => p.Key))
                FilterKeys.Add(key);
            GenerateFilterFunc();
        }


        //TODO: Use separate FilterFunctions for each type of filter
        private void GenerateFilterFunc()
        {
            if (String.IsNullOrWhiteSpace(FilterStringN) && FilterKeys.Count == 0)
            {
                fDfFilter.RemoveFunction(filFunct);
            }
            else
            {
                filFunct.Function = i =>
                {
                    if (!String.IsNullOrWhiteSpace(FilterStringN) && //Filter by string is set
                      !fEnt.Name[i].ContainsIC(FilterStringN) && //Substring can't be found in name
                      !fEnt.Parents[i].Any(j => fEnt.Name[j].ContainsIC(FilterStringN))) //Can't be found in parent name
                        return false;

                    if (FilterKeys.Count > 0 && //Filter by Control key exists
                        !ContainsShortcut(fEnt.ShortCut[i], FilterKeys))
                        return false;

                    return true;
                };
                fDfFilter.AddFunction(filFunct);
            }
            
            //Set selection to the first entry
            if (grid.HasItems && grid.SelectedIndex == -1)
            {
                grid.SelectedIndex = 0;
                //grid.SelectedItem = grid.Items[0];  //Worked with list, doesn't work with grid
                grid.ScrollIntoView(grid.SelectedItem);
            }
        }

        internal static bool ContainsShortcut(string ShortCut, IEnumerable<Key> filterKeys)
        {
            if (String.IsNullOrWhiteSpace(ShortCut))
                return false;

            return filterKeys.Any(fk =>
            {
                var fkStr = fk.ToString();
                return ShortCut.ContainsIC(fkStr);
            }); //OK if any of the given keys are contained in the shortcut list
        }





        public object SelectedItem
        {
            get { return fSelectedItem; }
            set
            {
                fSelectedItem = value; NotifyPropertyChanged();
                //Trace.WriteLine("Selected: " + (value == null ? "NULL" : value.ToString()));
            }
        }
        private object fSelectedItem;

        //Command section fDfRep.GetCommands(obj);
        /*public ICommand CmdRemoveDuplicates => new CmdRemoveDuplicates(fDfRep);
        public ICommand CmdRemoveEmtpyFolders => new RelayCommand(fDfRep.RemoveEmtpyFolders);
        public ICommand CmdNew => new RelayCommand(fDfRep.Save);*/

        public ICommand CmdSave => new RelayCommand(fDfRep.Save);
        public ICommand CmdCleanMPC => new RelayCommand(CustomFunctions.CleanMPCRegistry);

        internal void BrowseDataDir() => Task.Run(() => Process.Start("explorer.exe", "/root,\"" + fDfRep.Dir + "\""));

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
