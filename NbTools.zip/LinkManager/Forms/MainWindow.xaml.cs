﻿using All2All;
using All2All.Model;
using all2allv1.Xml;
using LinkManager.Data;
using LinkManager.Forms;
using LinkManSettV1.Xml;
using Nb.Graphics;
using NbTools;
using NbTools.Graphics;
using NbWpfLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace LinkManager
{
    public interface IStatus
    {
        void ShowStatus(string status);
    }


    public interface IMainWindow : IStatus
    {
        string GetTxt();

    }

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IMainWindow
    {
        private const string SettingFile = "LinkManSett.xml";

        private readonly Random fRnd = new Random();
        private readonly DispatcherTimer fSearchStringTimer;

        private DfRepository fDfRep;
        private LinkManSett Sett;
        private EntityCommandManager fEntCommands;

        private ListManager fListManager;
        private ImageDictionary ImageDictionary;

        private TreeManager fTreeManager;
        //#pragma warning disable IDE0052 // Remove unread private members
        private MngDropper fMngDropper; //Required for Drag and Drop
        private DndManager fDndManager;
        //#pragma warning restore IDE0052 // Remove unread private members

        public string[] CommandLineParams;

        private OpenLinkCommand hwc;

        public void ShowStatus(string status) => Dispatcher.Invoke(() => { StatusText.Text = status; });

        public string GetTxt() => tbText.Text;

        public MainWindow()
        {
            InitializeComponent();
            NbDialog.MainWindow = this;
            NbDialog.Title = Title;
            fSearchStringTimer = new DispatcherTimer { Interval = new TimeSpan(0, 0, 0, 0, 500) };
            fSearchStringTimer.Tick += SearchStringTimer_Tick;

            //Setting up notification icon
            //"pack://application:,,,/YourReferencedAssembly;component/YourPossibleSubFolder/YourResourceFile.ico" "pack://application:,,,/shell32_239.ico"

            /*using (Stream iconStream = Application.GetResourceStream(new Uri("pack://application:,,,/shell32_239.ico")).Stream)
            {
                var ico = new System.Drawing.Icon(iconStream);
                fTrayIcon = new TrayIcon(ico);
                fTrayIcon.Icon.BalloonTipText = "Link Manager";
                fTrayIcon.Icon.ShowBalloonTip(2000);
            }*/

            Height = 600;
            Width = 800;
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            tbSearch.Focus();
            //Console.WriteLine("Activated");
        }

        //Search Links in the whole list
        private void Search_TextChanged(object sender, TextChangedEventArgs e) => fSearchStringTimer.Start();

        private void SearchStringTimer_Tick(object sender, EventArgs e)
        {
            fSearchStringTimer.Stop();
            fListManager.SetFilter(tbSearch.Text);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                if (CommandLineParams.Length == 0)
                    throw new NbException("At least one command line parameter with repository folder should be supplied");
                string DataDir = CommandLineParams[0];
                string fullSettFileName = Path.Combine(DataDir, SettingFile);
                if (!File.Exists(fullSettFileName))
                    CreateNewDataDirectory(DataDir);

                string txt = Clipboard.GetText();
                int newLineIndex = txt.IndexOf('\r');
                if (newLineIndex != -1)
                    txt = txt.Substring(0, newLineIndex);
                tbText.Text = txt;
                tbText.SelectAll();


                Sett = LinkManSett.LoadFile(fullSettFileName);
                hwc = new OpenLinkCommand(this, Sett);
                SetTitle();

                fDfRep = new DfRepository();
                StringBuilder loadErr = new StringBuilder();
                fDfRep.Load(DataDir, s => loadErr.AppendLine(s));
                var loadErrStr = loadErr.ToString();
                if (!String.IsNullOrWhiteSpace(loadErrStr))
                    MessageBox.Show(loadErrStr);

                fMngDropper = new MngDropper(tbDropper, Sett.paths?.IconDir);
                fDndManager = new DndManager(fDfRep.Entities, dgList, tvTree);
                if (Sett.paths?.IconDir != null)
                    ImageDictionary = new ImageDictionary(Sett.paths.IconDir);

                fEntCommands = new EntityCommandManager(this, fDfRep, Sett);
                fListManager = new ListManager(dgList, tbSearch, fDfRep, ImageDictionary, hwc, fEntCommands, Sett);

                //Tree manager
                fTreeManager = new TreeManager(tvTree, tbTreeSearch, fDfRep, ImageDictionary, fEntCommands, Sett);
                fTreeManager.NodesCheckedInd += inds => fListManager.SetFilterByReference(inds); //Set filter if folder is selected, reset filter if unselected
                fTreeManager.NodeSelected += id => fListManager.SetFilterByReference(id < 0 ? null : new int[] { id });

                ImageSource imgSrc = new BitmapImage(new Uri(@"Graphics\folder1.ico", UriKind.Relative));

                PopulateQuickLinks();
                //DfTODO
                /*foreach (var fld in fViewModel.FoldersWithLinks())
                {
                    MenuItem topMenu = new MenuItem
                    {
                        Width = 28,
                        Height = 28,
                        Margin = new Thickness(0),
                        Padding = new Thickness(0),
                        ToolTip = fld.Name,
                        Tag = fld,
                        Icon = new Image { Source = ImageDictionary[fld.Icon], Height = 16, Width = 16 }, //TODO: Next icon not used on the menu button should be chosen
                        IsTabStop = false
                    }; //Every button needs its own image

                    foreach (var link in fld.Children)
                    {
                        MenuItem subMenu = new MenuItem
                        {
                            Header = link.Name,
                            Tag = link,
                            Command = hwc,
                            CommandParameter = link,
                            Icon = new Image { Source = ImageDictionary[link.Icon], Height = 16, Width = 16 } //TODO: Next icon not used on the menu button should be chosen
                        };
                        topMenu.Items.Add(subMenu);
                    }

                    tbLinks.Items.Add(topMenu);
                }*/
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
                Close();
            }
            //tvTree.Items.Add(fViewModel.CreateTreeItem(null));
        }

        private void CreateNewDataDirectory(string dataDir)
        {
            NbExt.DirCreateRecursive(dataDir);

            fDfRep = new DfRepository();
            fDfRep.CreateNew(dataDir);

            LinkManSett sett = new LinkManSett();
            sett.Save(Path.Combine(dataDir, SettingFile));
        }

        private void SetTitle()
        {
            string productVersion = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).ProductVersion;
            if (String.IsNullOrWhiteSpace(Sett.title))
            {
                string productName = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).ProductName;
                Title = $"{productName} - {productVersion}";
            }
            else
            {
                Title = $"{Sett.title} ({productVersion})";
            }
        }

        //Goes over the "quick_links" tag in XML and creates the buttons
        private void PopulateQuickLinks()
        {
            foreach (string id in Sett.quick_links.Safe())
            {
                var ind = fDfRep.Entities.PrimaryKeyColumn.Find(id);
                if (ind == -1)
                    throw new Exception($"Quick Link {id} is not found");

                string iconName = fDfRep.Entities.Icon.GetText(ind);
                if (String.IsNullOrWhiteSpace(iconName))
                {
                    foreach (var parInd in fDfRep.Entities.Parents.GetReferences(ind))
                    {
                        iconName = fDfRep.Entities.Icon.GetText(parInd);
                        if (!String.IsNullOrWhiteSpace(iconName))
                            break;
                    }
                }

                Image img = new Image() { Source = ImageDictionary[iconName] };
                StackPanel stackPnl = new StackPanel();
                stackPnl.Children.Add(img);

                string name = fDfRep.Entities.Name.GetText(ind);

                var butt = new Button() { Content = stackPnl, Tag = ind, ToolTip = name };
                butt.Click += Butt_Click;
                tbQuickLinks.Items.Add(butt);
            }
        }

        private async void Butt_Click(object sender, RoutedEventArgs e)
        {
            var ind = (int)((sender as Button).Tag ?? throw new Exception($"Sender is not button in {nameof(Butt_Click)}"));
            await hwc.ExecuteAsync(ind, fDfRep);
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            try
            {
                fDfRep?.Save();
                Sett?.Save();
            }
            catch (Exception ex) { MessageBox.Show(NbException.Exception2String(ex)); }
            //fTrayIcon?.Dispose();
        }

        private void TreeFilterButton_click(object sender, RoutedEventArgs e) => fTreeManager.RemoveSelection();
        private void EditCharacter(object sender, ExecutedRoutedEventArgs e) => MessageBox.Show("EditCharacter");

        private void Window_SwapFocus(object sender, ExecutedRoutedEventArgs e)
        {
            if (sender == tbSearch)
                Keyboard.Focus(tbText);
            //tbText.Focus();
            else if (sender == tbText)
                Keyboard.Focus(tbSearch);
            //tbSearch.Focus();
        }

        private void Window_EditDialog(object sender, ExecutedRoutedEventArgs e)
        {
            var ind = sender switch
            {
                DataGrid dg => (dg.SelectedItem as ListModel)?.Ind ?? -1,
                TreeView tv => (tv.SelectedItem as TreeNodeViewModel)?.Ind ?? -1,
                TextBox _ => (dgList.SelectedItem as ListModel)?.Ind ?? -1,
                _ => throw new NbExceptionPatternMatching(sender, "Edit dialog sender object"),
            };
            fEntCommands.EditEntry(isClone: false, ind: ind);
        }

        private void Window_ResetUi(object sender, ExecutedRoutedEventArgs e)
        {
            fTreeManager.RemoveSelection();
            tbSearch.Text = String.Empty;
            tbSearch.Focus();
        }

        private void Window_PlayCommand(object sender, ExecutedRoutedEventArgs e)
        {
            try
            {
                int ind = -1;
                ind = sender switch
                {
                    DataGrid dg => (dg.SelectedItem as ListModel)?.Ind ?? -1,
                    TreeView tv => (tv.SelectedItem as TreeNodeViewModel)?.Ind ?? -1,
                    _ => throw new NbExceptionPatternMatching(sender, "Edit dialog sender object"),
                };

                var url = fDfRep.Entities.Url[ind];
                if (String.IsNullOrEmpty(url))
                    return;
                if (!File.Exists(url))
                    throw new Exception($"Video file '{url}' is not found");

                if (Sett.paths.VideoPlayerN == null)
                    throw new Exception($"{nameof(Sett.paths.video_player)} setting was not provided");
                else
                    NbProcess.FireAndForget(Sett.paths.VideoPlayerN, null, url);
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
        }

        private static readonly Dictionary<Key, bool> modifierKeyStates = new Dictionary<Key, bool>
        {
            { Key.RightCtrl, false }, { Key.RightAlt, false }, { Key.RightShift, false }, { Key.LeftCtrl, false }, { Key.LeftAlt, false },
            { Key.F1, false }, /*{ Key.F2, false },*/ { Key.F3, false }, /*{ Key.F4, false }, { Key.F5, false }, { Key.F6, false },*/
            { Key.F7, false }, { Key.F8, false }, { Key.F9, false }, { Key.F10, false }, { Key.F11, false }, { Key.F12, false }
        };

        private const bool LogKeys = true;

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Tab)
            {
                e.Handled = false;
                return;
            }

            Key k = (e.Key == Key.System) ? e.SystemKey : e.Key;

            if (LogKeys)
                Trace.WriteLine($"Down '{k}'");

            if (modifierKeyStates.ContainsKey(k))
            {
                modifierKeyStates[k] = true;
                fListManager.SetFilter(modifierKeyStates);
                KeyModifiers.Text = ModifToString;
            }
            else if (modifierKeyStates.Values.Any(b => b))
            {
                var modifKeyCombination = $"{ModifToString}-{k}";
                KeyModifiers.Text = modifKeyCombination;

                var keys = modifierKeyStates.Where(p => p.Value).Select(p => p.Key).ToList();
                keys.Add(k);
                fListManager.InvokeShortCut(keys);
                if (ResetKeyModifiers()) //if any least one modifier was set
                    fListManager.SetFilter(modifierKeyStates);
            }
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Tab)
            {
                e.Handled = false;
                return;
            }

            Key k = (e.Key == Key.System) ? e.SystemKey : e.Key;

            if (LogKeys)
            {
                if (e.Key != Key.None)
                    Trace.WriteLine($"Up '{k}'");
                if (e.SystemKey != Key.None)
                    Trace.WriteLine($"Up system '{e.SystemKey}'");
            }

            if (modifierKeyStates.ContainsKey(k))
            {
                modifierKeyStates[k] = false;
                fListManager.SetFilter(modifierKeyStates);
            }
            else
            {
                if (ResetKeyModifiers()) //if any least one modifier was set
                    fListManager.SetFilter(modifierKeyStates);
            }
            KeyModifiers.Text = ModifToString;
        }

        private bool ResetKeyModifiers()
        {
            //Clear modifiers - If combination like Ctrl-S is pressed Ctrl Up event doesn't arrive
            //TODO: not efficient, use something instead of the Dictionary
            bool modifierWasEnabled = false;
            foreach (var key in modifierKeyStates.Where(p => p.Value).Select(p => p.Key).ToArray()) //Button up - reset 
            {
                modifierKeyStates[key] = false;
                modifierWasEnabled = true;
            }
            return modifierWasEnabled;
        }

        private string ModifToString => String.Join("-", modifierKeyStates.Where(p => p.Value).Select(p => p.Key));

        private void UpdateKeyModifiers(string mess) => KeyModifiers.Text = mess;

        private void MenuBrowseDataDir_Click(object sender, RoutedEventArgs e)
        {
            fListManager.BrowseDataDir();
            Close();
        }

        private void MenuBrowseGraphicsDir_Click(object sender, RoutedEventArgs e)
        {
            _ = Task.Run(() => Process.Start("explorer.exe", $"/root,\"{Sett.paths.IconDir}\""));
        }

        private void SaveAll2All_Click(object sender, RoutedEventArgs e)
        {
            string dstFile = @"C:\Temp\LinkManager.a2a.xml";

            var Model = new FlavoursModel(new NullUI());
            var _ = fDfRep.Dir;
            var fEnt = fDfRep.Entities;

            //var RootNodes = fEnt.Parents.WhereInList(s => s.Count == 0, fEnt.Type.Where(v => Sett.ShowInTree[v], fEnt.All)).ToList();
            Node rootNode = Model.AddNode(fEnt.Id.GetText(0), fEnt.Name.GetText(0), fEnt.Icon.GetText(0), parentNodeN: null, refType: null,
                new FlavFolder { icon = fEnt.Icon.GetText(0), created = fEnt.AccessTime.GetValue(0) });
            ProcessChildrenRecursive(0, rootNode, fEnt, Model);

            var newXmlModel = Model.SaveToXmlModel();
            newXmlModel.Save(dstFile);
        }

        private void ProcessChildrenRecursive(int parNodeId, Node parentNode, DfEntitiesColletion fEnt, FlavoursModel model)
        {
            var treeNodes = fEnt.Type.Where(v => Sett.ShowInTree[v], fEnt.GetTreeChildren(parNodeId)).ToList();
            foreach (int currId in treeNodes)
            {
                Node curNode = model.AddNode(fEnt.Id.GetText(currId), fEnt.Name.GetText(currId), fEnt.Icon.GetText(currId), parentNode, refType: null, new FlavFolder
                {
                    icon = fEnt.Icon.GetText(currId),
                    created = fEnt.AccessTime.GetValue(0)
                });
                ProcessChildrenRecursive(currId, curNode, fEnt, model);
            }

            var leafNodes = fEnt.Type.Where(v => !Sett.ShowInTree[v], fEnt.GetTreeChildren(parNodeId)).ToList();
            foreach (int currId in leafNodes)
            {
                string newid = fEnt.Id.GetText(currId);
                if (model.TryGetNode(newid, out Node existingNode)) //Node was referenced in the tree once
                {
                    model.ConnectNodes(existingNode, parentNode, null);

                }
                else //Node appears for the first time
                {
                    Node curNode = model.AddNode(fEnt.Id.GetText(currId), fEnt.Name.GetText(currId), fEnt.Icon.GetText(currId), parentNode, refType: null, new FlavLmLink
                    {
                        accessed = fEnt.AccessTime.GetValue(currId),
                        archived = fEnt.ArchivedDate.GetValue(currId),
                        clipboard = fEnt.CopyToClipboard.GetValue(currId),
                        shortcut = fEnt.ShortCut.GetValue(currId),
                        url = fEnt.Url.GetValue(currId)
                    });
                    ProcessChildrenRecursive(currId, curNode, fEnt, model); //Assumes there is no loops
                }
            }
        }

        private void MenuSave_Click(object sender, RoutedEventArgs e) => fDfRep.Save();
        private void Menu_CleanMPC(object sender, RoutedEventArgs e) => CustomFunctions.CleanMPCRegistry();

        private void TestButton_Click(object sender, RoutedEventArgs e)
        {
            //var a =  UniversalDialog.GetUserString(this, "Type in the new Entry name", "New entry");
            //bool a = NbDialog.YesNo("Do it?");
        }

        private void ButtonRandom_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var allList = fDfRep.Entities.All.ToList();
                int ind = fRnd.Next(0, allList.Count);
                if (ind < 0)
                    return;

                var url = fDfRep.Entities.Url[ind];
                if (String.IsNullOrEmpty(url))
                    return;
                if (!File.Exists(url))
                    throw new Exception($"Video file '{url}' is not found");

                if (Sett.paths.VideoPlayerN == null)
                    throw new Exception($"{nameof(Sett.paths.video_player)} setting was not provided");
                else
                    NbProcess.FireAndForget(Sett.paths.VideoPlayerN, null, url);
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
        }
    }
}
