﻿using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

using GongSolutions.Wpf.DragDrop;
using LinkManSettV1.Xml;
using Microsoft.Win32;

using Nb.Library.Web; //For DownloadFavIcon()
using NbTools;
using NbWpfLib;

namespace LinkManager.Forms
{
    internal interface IIndHolder
    {
        int Ind { get; }
    }

    class MngDropper : IDropTarget
    {
        private readonly TextBlock fText;
        private readonly string IconDir;

        public MngDropper(TextBlock tbText, string iconDir)
        {
            fText = tbText;
            IconDir = iconDir;
            tbText.SetValue(GongSolutions.Wpf.DragDrop.DragDrop.IsDropTargetProperty, true); //dd:DragDrop.IsDropTarget="True"
            tbText.SetValue(GongSolutions.Wpf.DragDrop.DragDrop.DropHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            //dd: DragDrop.IsDragSource = "False"  dd: DragDrop.DragHandler = "{Binding}"
            //dd: DragDrop.DragAdornerTemplate = "{StaticResource DragAdorner}"
        }

        public bool CanStartDrag(IDragInfo dragInfo) => throw new NotImplementedException();
        public void DragCancelled() { }

        public void DragOver(IDropInfo dropInfo)
        {
            dropInfo.Effects = DragDropEffects.Copy;
        }

        const string OnlyUrl = "UniformResourceLocatorW";

        public void Drop(IDropInfo dropInfo)
        {
            if (!(dropInfo.Data is DataObject dat))
                MessageBox.Show($"Dropped object is of type '{dropInfo.Data.GetType().Name}'");
            else
            {
                fText.ContextMenu.Items.Clear();

                NbCommand comm = new NbCommand("Clipboard Viewer", () =>
                {
                    var a = new ClipBoardViewer(dat);
                    a.ShowDialog();
                });
                fText.ContextMenu.Items.Add(new MenuItem { Command = comm, Header = comm.Title });

                string[] formats = dat.GetFormats();
                if (formats.Contains(OnlyUrl))
                {
                    var ulr = ClipBoardViewer.DropObjectToString(dat, OnlyUrl);
                    NbCommand favComm = new NbCommand("Save favicon", () => SaveFavIcon(ulr, IconDir));

                    fText.ContextMenu.Items.Add(new MenuItem { Command = favComm, Header = favComm.Title });
                }

                fText.ContextMenu.IsOpen = true;
            }
        }

        public static void SaveFavIcon(string url, string dstDir)
        {
            try
            {
                Tuple<byte[], string> iconBytesAndExt = null;
                string targetFileName = null;
                Uri uri = new Uri(url);

                var tasks = new Task[] {
                        Task.Factory.StartNew(() =>
                        {
                            try  { iconBytesAndExt = WebLib.DownloadFavIcon(uri); }
                            catch (Exception exp) { NbDialog.Error(exp); }
                        }),
                        Task.Factory.StartNew(() =>
                        {
                            string suggName = NbExt.LegalizeForFilename(Regex.Replace(Regex.Replace(uri.Host, @"\.\w+$", String.Empty), @"^www\.", String.Empty),  128);

                            var dlg = new SaveFileDialog
                            {
                                Filter = "Icon file (*.ico)|*.ico",
                                FileName = suggName.Substring(0, 1).ToUpperInvariant() + suggName.Substring(1) + ".ico",
                                InitialDirectory = dstDir
                            };

                            targetFileName = (dlg.ShowDialog() ?? false) ? dlg.FileName : null;
                        }),
                    };

                var ex = tasks.Select(t => t.Exception).FirstOrDefault();
                if (ex != null)
                {
                    MessageBox.Show(NbException.Exception2String(ex));
                    return;
                }

                if (!Task.WaitAll(tasks, new TimeSpan(0, 0, 30)))
                {
                    MessageBox.Show("Favicon loading has timed out");
                    return;
                }

                if (iconBytesAndExt == null)
                {
                    MessageBox.Show("The favicon was not found");
                    return;
                }
                File.WriteAllBytes(NbDir.ReplaceExtension(targetFileName, iconBytesAndExt.Item2), iconBytesAndExt.Item1);
            }
            catch (Exception ex)
            {
                throw new Exception($"Can't download favicon from '{url}'", ex);
            }
        }

        public void Dropped(IDropInfo dropInfo) { }

        public void StartDrag(IDragInfo dragInfo) => throw new NotImplementedException();
        public bool TryCatchOccurredException(Exception exception) => throw new NotImplementedException();
    }
}
