﻿using LinkManager.Data;
using LinkManager.Forms;
using NbTools;
using NbTools.Collections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
//using System.Windows;
using System.Windows.Controls;
using DragDropEffects = System.Windows.DragDropEffects;
using GongDnd = GongSolutions.Wpf.DragDrop.DragDrop;
using GongSolutions.Wpf.DragDrop;
using NbWpfLib;

namespace LinkManager
{
    public class DndManager : IDragSource, IDropTarget
    {
        private const string entityTypeToCreateOnListDrop = nameof(EntType.Entity);
        private Tuple<DragDropEffects, Adorn, string> TplNoDrop = Tuple.Create(DragDropEffects.None, Adorn.Highlight, String.Empty);
        private Tuple<DragDropEffects, Adorn, string> TplDropMove = Tuple.Create(DragDropEffects.Move, Adorn.Highlight, String.Empty);
        private Tuple<DragDropEffects, Adorn, string> TplDropCopy = Tuple.Create(DragDropEffects.Copy, Adorn.Highlight, String.Empty);

        private const string fileDrop = "FileDrop";
        private const string ulrDrop = "UniformResourceLocatorW";
        private const string xMozUrl = "text/x-moz-url";

        private readonly DfEntitiesColletion fEnt;

        public DndManager(DfEntitiesColletion entColl, DataGrid dg, TreeView tv)
        {
            fEnt = entColl;

            dg.SetValue(GongDnd.IsDragSourceProperty, true); //DragDrop.IsDragSource = "True"
            dg.SetValue(GongDnd.DragHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            dg.SetValue(GongDnd.IsDropTargetProperty, true); //dd:DragDrop.IsDropTarget="True"
            dg.SetValue(GongDnd.DropHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            tv.SetValue(GongDnd.IsDragSourceProperty, true); //DragDrop.IsDragSource = "True"
            tv.SetValue(GongDnd.DragHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            tv.SetValue(GongDnd.IsDropTargetProperty, true); //dd:DragDrop.IsDropTarget="True"
            tv.SetValue(GongDnd.DropHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            //dd: DragDrop.DragAdornerTemplate = "{StaticResource DragAdorner}"
        }

        //private object fCurrentDropObject;

        public void StartDrag(IDragInfo dragInfo)
        {
            // nothing special here, use the default way
            //dragInfo.Effects = DragDropEffects.Link; //Link doesn't work yet
            GongDnd.DefaultDragHandler.StartDrag(dragInfo);
        }

        public bool CanStartDrag(IDragInfo dragInfo)
        {
            return true; //dragInfo.SourceItem is IDndSource;
        }

        public void Dropped(IDropInfo dropInfo)
        {
            // fCurrentDropObject = null;
        }

        public void DragCancelled()
        {
            //SetStatusMessage("ViewModel DragCancelled");
            // fCurrentDropObject = null;
        }

        public bool TryCatchOccurredException(Exception exception)
        {
            MessageBox.Show(NbException.Exception2String(exception));
            return true;
        }

        enum Adorn { Highlight, Insert }

        public void DragOver(IDropInfo dropInfo)
        {
            var res = OverAndDrop(dropInfo, run: false);
            if (res == null)
                return;

            if (!String.IsNullOrEmpty(res.Item3))
                MessageBox.Show(res.Item3);  //TODO: replace with the status bar messaging

            dropInfo.Effects = res.Item1;
            dropInfo.DropTargetAdorner = res.Item2 switch
            {
                Adorn.Highlight => DropTargetAdorners.Highlight,
                Adorn.Insert => DropTargetAdorners.Insert,
                _ => throw new NbExceptionEnum<Adorn>(res.Item2)
            };

            //Debug.Print(res.ToString());
        }

        public void Drop(IDropInfo dropInfo) => OverAndDrop(dropInfo, run: true);


        //TODO: think about possible matrix of what is dropped on what

        /// <summary>
        /// Combined logic for DragOver and for Drop - the difference is the run flag
        /// </summary>
        Tuple<DragDropEffects, Adorn, string> OverAndDrop(IDropInfo dropInfo, bool run)
        {
            if (!(dropInfo.VisualTarget is FrameworkElement _))
                return Tuple.Create(DragDropEffects.None, Adorn.Highlight, $"Drop VisualTarget is not a FrameworkElement: '{dropInfo.VisualTarget}'"); ;

            return dropInfo.TargetItem switch
            {
                TreeNodeViewModel targTree => dropInfo.Data switch
                {
                    DataObject srcDataObj => ListOrTreeView_ExternalObject(dropInfo, srcDataObj, run, targTree.Ind), //Create external object and place into category
                    IIndHolder src => NodeOnNode(src.Ind, targTree.Ind, run),
                    _ => throw new Exception($"Unsupported sorce in Drap&Drop: {dropInfo.Data}"),
                },
                ListModel targList => dropInfo.Data switch
                {
                    DataObject srcDataObj => ListOrTreeView_ExternalObject(dropInfo, srcDataObj, run),
                    IIndHolder src => NodeOnNode(src.Ind, targList.Ind, run),
                    _ => throw new Exception($"Unsupported sorce in Drap&Drop: {dropInfo.Data}"),
                },
                null => TplNoDrop,
                _ => throw new Exception($"Unsupported target in Drap&Drop: {dropInfo.TargetItem}"),
            };
        }

        private Tuple<DragDropEffects, Adorn, string> NodeOnNode(int src, int dst, bool run)
        {
            switch (fEnt.Type[src])
            {
                case nameof(EntType.Entity):
                    switch (fEnt.Type[dst])
                    {
                        case nameof(EntType.Folder): return AssignEntityToFolder(cat: dst, ent: src, run);
                    }
                    break;

                case nameof(EntType.Folder):
                    switch (fEnt.Type[dst])
                    {
                        case nameof(EntType.Entity): return AssignEntityToFolder(cat: src, ent: dst, run);
                    }
                    break;
            }

            return TplNoDrop;
        }

        private Tuple<DragDropEffects, Adorn, string> AssignEntityToFolder(int cat, int ent, bool run)
        {
            if (!run)
                return TplDropMove;

            if (fEnt.Parents[ent].Contains(cat))
            {
                if (NbDialog.YesNo($"Entity '{fEnt.Name[ent]}' already assigned to the category '{fEnt.Name[cat]}'\r\nDo you want to remove the assignment?"))
                    fEnt.Parents.RemoveReference(ent, cat);
            }
            else
                fEnt.Parents.AddReference(ent, cat);
            return null; //No complaints
        }

        private Tuple<DragDropEffects, Adorn, string> ListOrTreeView_ExternalObject(IDropInfo dropInfo, DataObject dat, bool run, int folderId = -1)
        {
            int addedEntityInd = -1;
            string[] formats = dat.GetFormats();

            if (formats.Contains(xMozUrl))
            {
                if (!run)
                    return TplDropCopy;

                string urlAndTitle = DropObjectToString(dat, xMozUrl);
                string[] str = urlAndTitle.Split('\n');
                if (str.Count() != 2)
                    throw new NbException($"Malformed {xMozUrl} message: 2 lines expected:\r\n{urlAndTitle}");

                addedEntityInd = fEnt.Add(DataForNewEntity(str[0], str[1]));
            }
            else if (formats.Contains(ulrDrop))
            {
                if (!run)
                    return TplDropCopy;

                using StreamReader sr = new StreamReader(dat.GetData(ulrDrop) as MemoryStream, Encoding.Unicode);
                string mess = sr.ReadToEnd().Replace("\0", " ");
                addedEntityInd = fEnt.Add(DataForNewEntity(mess, mess));
            }
            else if (formats.Contains(fileDrop))
            {
                foreach (var fileOrDir in dat.GetFileDropList())
                {
                    FileInfo fi = new FileInfo(fileOrDir);
                    if (fi.Exists)
                    {
                        var (tuple, id) = ProcessFileDrop(dropInfo, fi, run);
                        if (id == -1)
                            return tuple;
                        else
                            addedEntityInd = id;
                    }
                    else
                    {
                        DirectoryInfo di = new DirectoryInfo(fileOrDir);
                        if (di.Exists) //Process Directory drop
                        {
                            if (!run)
                                return TplDropCopy;

                            addedEntityInd = fEnt.Add(DataForNewEntity(di.FullName, di.Name));
                        }
                    }
                }
            }

            if (addedEntityInd != -1 && folderId != -1)
                return AssignEntityToFolder(folderId, addedEntityInd, run);

            return null; //No warning messages
        }

        //Create entity out of various dropping files
        private (Tuple<DragDropEffects, Adorn, string>, int) ProcessFileDrop(IDropInfo dropInfo, FileInfo fi, bool run)
        {
            string ext = fi.ExtensionWithoutDot().ToLowerInvariant();
            switch (ext)
            {
                case "url":
                    return ProcessUrlLinkFile(dropInfo, fi, run);
                default:
                    if (!run)
                        return (TplDropCopy, -1);

                    var dat = DataForNewEntity(fi.FullName, fi.Name);
                    return (TplDropCopy, fEnt.Add(dat));
            }
        }

        private (Tuple<DragDropEffects, Adorn, string>, int) ProcessUrlLinkFile(IDropInfo dropInfo, FileInfo fi, bool run)
        {
            if (!run)
                return (dropInfo.ControlPressed() ? TplDropMove : TplDropCopy, -1);

            var lines = File.ReadAllLines(fi.FullName);
            try
            {   //Simplified Parse Ini
                if (lines.Length == 0) throw new Exception("No lines in URL file");
                if (lines[0].Trim() != "[InternetShortcut]") throw new Exception("URL file doesn't start with [InternetShortcut]");
                var dict = new NbDictionary<string, string>(lines.Length - 1, StringComparer.InvariantCultureIgnoreCase, $"Lines of {fi.Name} file");
                foreach (var line in lines.Skip(1))
                {
                    int eqInd = line.IndexOf("=");
                    if (eqInd == -1) throw new Exception($"Line '{line}' doesn't contain '='");
                    var key = line.Substring(0, eqInd);
                    var val = line.Substring(eqInd + 1);
                    dict.Add(key, val);
                }

                var ent = DataForNewEntity(dict["url"], fi.NameWithoutExtension());
                int entInd = fEnt.Add(ent);

                if (dropInfo.ControlPressed()) //Delete file if endtity was created
                {
                    fi.Delete();
                    return (TplDropMove, entInd);
                }
                else
                    return (TplDropCopy, entInd);
            }
            catch (Exception ex) { throw new Exception($"Error processing URL file '{fi.FullName}'\r\n{String.Join(Environment.NewLine, lines)}", ex); }
        }

        private static string DropObjectToString(System.Windows.IDataObject dataObj, string format)
        {
            object obj = dataObj.GetData(format);

            switch (obj.GetType().Name)
            {
                case nameof(String):
                    return obj as String;

                case nameof(String) + "[]":
                    string[] strs = obj as String[];
                    return "'" + String.Join("', '", strs) + "'";

                case nameof(MemoryStream):
                    using (StreamReader sr = new StreamReader(obj as MemoryStream, Encoding.Unicode))
                    {
                        string mess = sr.ReadToEnd().Replace("\0", " ");
                        return mess;
                    }

                default:
                    return "Unsupported DropObject Type: " + obj.GetType().Name;
            }
        }

        public void DragDropOperationFinished(DragDropEffects operationResult, IDragInfo dragInfo)
        {
            //throw new NotImplementedException();
        }

        private Dictionary<IDfColumnBase, string> DataForNewEntity(string url, string name) => new Dictionary<IDfColumnBase, string>
        {
            { fEnt.Url, url },
            { fEnt.Name, name },
            { fEnt.Type, entityTypeToCreateOnListDrop},
            { fEnt.AccessTime, DateTime.Now.ToString(NbExt.ddMMMyyyyHHmmss) }, //TODO: think about passing the actual value?
        };
    }

    static class DndHelpers
    {
        internal static bool LeftButton(this IDropInfo dropInfo) => (dropInfo.KeyStates & DragDropKeyStates.LeftMouseButton) > 0;
        internal static bool RightButton(this IDropInfo dropInfo) => (dropInfo.KeyStates & DragDropKeyStates.RightMouseButton) > 0;
        internal static bool MiddleButton(this IDropInfo dropInfo) => (dropInfo.KeyStates & DragDropKeyStates.MiddleMouseButton) > 0;

        internal static bool ShiftPressed(this IDropInfo dropInfo) => (dropInfo.KeyStates & DragDropKeyStates.ShiftKey) > 0;
        internal static bool ControlPressed(this IDropInfo dropInfo) => (dropInfo.KeyStates & DragDropKeyStates.ControlKey) > 0;
        internal static bool AltPressed(this IDropInfo dropInfo) => (dropInfo.KeyStates & DragDropKeyStates.AltKey) > 0;
    }
}
