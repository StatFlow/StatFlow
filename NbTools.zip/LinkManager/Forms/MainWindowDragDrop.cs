﻿using LinkManager.Data;
using LinkManager.Forms;
using NbTools;
using NbTools.Collections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
//using System.Windows;
using System.Windows.Controls;
using DragDropEffects = System.Windows.DragDropEffects;
using GongDnd = GongSolutions.Wpf.DragDrop.DragDrop;
using GongSolutions.Wpf.DragDrop;
using NbWpfLib;

namespace LinkManager
{
    public class DndManager : IDragSource, IDropTarget
    {
        private const string entityTypeToCreateOnListDrop = nameof(EntType.Entity);

        private const string fileDrop = "FileDrop";
        private const string ulrDrop = "UniformResourceLocatorW";
        private const string xMozUrl = "text/x-moz-url";

        private readonly DfEntitiesColletion fEnt;

        public DndManager(DfEntitiesColletion entColl, DataGrid dg, TreeView tv)
        {
            fEnt = entColl;

            dg.SetValue(GongDnd.IsDragSourceProperty, true); //DragDrop.IsDragSource = "True"
            dg.SetValue(GongDnd.DragHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            dg.SetValue(GongDnd.IsDropTargetProperty, true); //dd:DragDrop.IsDropTarget="True"
            dg.SetValue(GongDnd.DropHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            tv.SetValue(GongDnd.IsDragSourceProperty, true); //DragDrop.IsDragSource = "True"
            tv.SetValue(GongDnd.DragHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            tv.SetValue(GongDnd.IsDropTargetProperty, true); //dd:DragDrop.IsDropTarget="True"
            tv.SetValue(GongDnd.DropHandlerProperty, this); //dd:DragDrop.DropHandler="{Binding}"

            //dd: DragDrop.DragAdornerTemplate = "{StaticResource DragAdorner}"
        }

        //private object fCurrentDropObject;

        public void StartDrag(IDragInfo dragInfo)
        {
            // nothing special here, use the default way
            //dragInfo.Effects = DragDropEffects.Link; //Link doesn't work yet
            GongDnd.DefaultDragHandler.StartDrag(dragInfo);
        }

        public bool CanStartDrag(IDragInfo dragInfo)
        {
            return true; //dragInfo.SourceItem is IDndSource;
        }

        public void Dropped(IDropInfo dropInfo)
        {
            // fCurrentDropObject = null;
        }

        public void DragCancelled()
        {
            //SetStatusMessage("ViewModel DragCancelled");
            // fCurrentDropObject = null;
        }

        public bool TryCatchOccurredException(Exception exception)
        {
            MessageBox.Show(NbException.Exception2String(exception));
            return true;
        }

        //List Item is dropped onto something
        public void DragOver(IDropInfo dropInfo)
        {
            if (!(dropInfo.VisualTarget is FrameworkElement fe))
                return;

            if (fe.Name == nameof(MainWindow.tvTree))
            {
                if (dropInfo.Data is DataObject && dropInfo.TargetItem != null)
                {
                    dropInfo.Effects = DragDropEffects.Copy;
                    dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
                }
                if (dropInfo.Data is ListModel && dropInfo.TargetItem != null)
                {
                    dropInfo.Effects = DragDropEffects.Copy;
                    dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
                }
                if (dropInfo.Data is TreeNodeViewModel && dropInfo.TargetItem != null)
                {
                    dropInfo.Effects = DragDropEffects.Copy;
                    dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
                }
            }
            else if (fe.Name == nameof(MainWindow.dgList))
            {
                switch (dropInfo.Data)
                {
                    case DataObject _:
                        dropInfo.Effects = DragDropEffects.Link;
                        dropInfo.DropTargetAdorner = DropTargetAdorners.Insert;
                        break;

                    case TreeNodeViewModel _:
                        dropInfo.Effects = DragDropEffects.Copy;
                        dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;
                        break;

                    case ListModel _:
                        dropInfo.Effects = DragDropEffects.Copy;
                        dropInfo.DropTargetAdorner = DropTargetAdorners.Highlight;

                        break;
                    default:
                        dropInfo.Effects = DragDropEffects.Copy;
                        break;
                }
            }
        }

        //TODO: Combine DragOver and Drop to determine what allowed and what is not allowed
        //TODO: think about possible matrix of what is dropped on what

        public void Drop(IDropInfo dropInfo)
        {
            var dat = dropInfo.Data as DataObject;
            if (!(dropInfo.VisualTarget is FrameworkElement fe))
                return;


            if (fe.Name == nameof(MainWindow.tvTree))
            {
                if (!(dropInfo.TargetItem is TreeNodeViewModel tModel))
                    throw new NbExceptionInfo($"Drop target in not {nameof(TreeNodeViewModel)}");

                if (dropInfo.Data is DataObject dt)
                {
                    ListView_ExternalObject(dt, tModel.Ind); //Create external object and place into category
                    return;
                }

                if (!(dropInfo.Data is ListModel lModel))
                    throw new NbExceptionInfo($"Drop object in not {nameof(ListModel)}");

                var res = NodeOnNode(lModel.Ind, tModel.Ind, lModel.Ent);
                if (!String.IsNullOrEmpty(res))
                    MessageBox.Show(res);
            }
            else if (fe.Name == nameof(MainWindow.dgList))
            {
                switch(dropInfo.Data)
                {
                    case DataObject dt:
                        ListView_ExternalObject(dt);
                        break;

                    case TreeNodeViewModel tr:
                        if (!(dropInfo.TargetItem is ListModel lModel))
                            throw new NbExceptionInfo($"Drop object in not {nameof(ListModel)}");

                        var res = NodeOnNode(lModel.Ind, tr.Ind, lModel.Ent);
                        if (!String.IsNullOrEmpty(res))
                            MessageBox.Show(res);
                        break;
                    default:
                        throw new NbExceptionInfo($"Unsupported clipboard drop type: {dropInfo.Data.GetType().Name}");
                }
            }
        }

        private string NodeOnNode(int src, int dst, DfEntitiesColletion ent)
        {
            switch (ent.Type[src])
            {
                case "Entity":
                    switch (ent.Type[dst])
                    {
                        case "Folder": return AddCategoryToEntity(cat: dst, ent: src, entColl: ent);
                    }
                    break;

                case "Folder":
                    switch (ent.Type[dst])
                    {
                        case "Entity": return AddCategoryToEntity(cat: src, ent: dst, entColl: ent);
                    }
                    break;
            }

            return $"Dropping {ent.Type[src]} onto the {ent.Type[dst]} is not supported";
        }

        private string AddCategoryToEntity(int cat, int ent, DfEntitiesColletion entColl)
        {
            if (entColl.Parents[ent].Contains(cat))
            {
                if (NbDialog.YesNo($"Entity '{entColl.Name[ent]}' already assigned to the category '{entColl.Name[cat]}'\r\nDo you want to remove the assignment?"))
                    entColl.Parents.RemoveReference(ent, cat);
            }
            else
                entColl.Parents.AddReference(ent, cat);
            return null; //No complains
        }

        private string ListView_ExternalObject(DataObject dat, int category = -1)
        {
            int addedEntityInd = -1;

            string[] formats = dat.GetFormats();
            if (formats.Contains(xMozUrl))
            {
                string urlAndTitle = DropObjectToString(dat, xMozUrl);
                string[] str = urlAndTitle.Split('\n');
                if (str.Count() != 2)
                    throw new NbException($"Malformed {xMozUrl} message: 2 lines expected:\r\n{urlAndTitle}");
                else
                {
                    var dict = new Dictionary<IDfColumnBase, string>
                    {
                        { fEnt.Url, str[0] },
                        { fEnt.Name, str[1] },
                        { fEnt.Type, entityTypeToCreateOnListDrop},
                        { fEnt.AccessTime, DateTime.Now.ToString(NbExt.ddMMMyyyyHHmmss) }, //TODO: think about passing the actual value?
                    };
                    addedEntityInd = fEnt.Add(dict);
                }
            }
            else if (formats.Contains(ulrDrop))
            {
                using (StreamReader sr = new StreamReader(dat.GetData(ulrDrop) as MemoryStream, Encoding.Unicode))
                {
                    string mess = sr.ReadToEnd().Replace("\0", " ");
                    var dict = new Dictionary<IDfColumnBase, string>
                    {
                        { fEnt.Url, mess },
                        { fEnt.Name, mess },
                        { fEnt.Type, entityTypeToCreateOnListDrop},
                        { fEnt.AccessTime, DateTime.Now.ToString(NbExt.ddMMMyyyyHHmmss) }, //TODO: think about passing the actual value?
                    };
                    addedEntityInd = fEnt.Add(dict);
                }
            }
            else if (formats.Contains(fileDrop))
            {
                foreach (var fileOrDir in dat.GetFileDropList())
                {
                    FileInfo fi = new FileInfo(fileOrDir);
                    if (fi.Exists)
                    {
                        var dict = new Dictionary<IDfColumnBase, string>
                        {
                            { fEnt.Url, fi.FullName },
                            { fEnt.Name, fi.Name },
                            { fEnt.Type, entityTypeToCreateOnListDrop},
                            { fEnt.AccessTime, DateTime.Now.ToString(NbExt.ddMMMyyyyHHmmss) }, //TODO: think about passing the actual value?
                        };
                        addedEntityInd = fEnt.Add(dict);
                    }
                    else
                    {
                        DirectoryInfo di = new DirectoryInfo(fileOrDir);
                        if (di.Exists)
                        {
                            var dict = new Dictionary<IDfColumnBase, string>
                            {
                                { fEnt.Url, di.FullName },
                                { fEnt.Name, di.Name },
                                { fEnt.Type, entityTypeToCreateOnListDrop},
                                { fEnt.AccessTime, DateTime.Now.ToString(NbExt.ddMMMyyyyHHmmss) }, //TODO: think about passing the actual value?
                            };
                            addedEntityInd = fEnt.Add(dict);
                        }
                    }
                }
            }

            if (addedEntityInd != -1 && category != -1)
                return AddCategoryToEntity(category, addedEntityInd, fEnt);

            return null; //No warning messages
        }

        private static string DropObjectToString(System.Windows.IDataObject dataObj, string format)
        {
            object obj = dataObj.GetData(format);

            switch (obj.GetType().Name)
            {
                case nameof(String):
                    return obj as String;

                case nameof(String) + "[]":
                    string[] strs = obj as String[];
                    return "'" + String.Join("', '", strs) + "'";

                case nameof(MemoryStream):
                    using (StreamReader sr = new StreamReader(obj as MemoryStream, Encoding.Unicode))
                    {
                        string mess = sr.ReadToEnd().Replace("\0", " ");
                        return mess;
                    }

                default:
                    return "Unsupported DropObject Type: " + obj.GetType().Name;
            }
        }

        public void DragDropOperationFinished(DragDropEffects operationResult, IDragInfo dragInfo)
        {
            //throw new NotImplementedException();
        }
    }
}
