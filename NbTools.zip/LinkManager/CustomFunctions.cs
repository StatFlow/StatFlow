﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using System.Windows.Forms;

using Microsoft.Win32;

namespace LinkManager
{
    internal static class CustomFunctions
    {
        internal static void Base64ToFile(string base64)
        {
            var dlg = new SaveFileDialog();
            var a = dlg.ShowDialog();
            if (String.IsNullOrEmpty(dlg.FileName))
                return;

            File.WriteAllBytes(dlg.FileName, Convert.FromBase64String(base64));
            Process.Start("explorer.exe", $"/select,\"{dlg.FileName}\"");
        }

        internal static void CleanMPCRegistry()
        {
            const string root = @"HKEY_CURRENT_USER\Software\MPC-HC\MPC-HC\Recent File List";
            for(int i = 1; i<=20; ++i)
                Registry.SetValue(root, $"File{i}", String.Empty, RegistryValueKind.String);

            //Registry.CurrentUser.DeleteSubKey(subkey);*/

            const string recentFile1 = @"%APPDATA%\Microsoft\Windows\Recent\AutomaticDestinations\dcca9f644b806738.automaticDestinations-ms";
            var recentFile = Environment.ExpandEnvironmentVariables(recentFile1);
            //const string recentFile = @"C:\Users\budan\AppData\Roaming\Microsoft\Windows\Recent\AutomaticDestinations\dcca9f644b806738.automaticDestinations-ms";
            if (File.Exists(recentFile))
                File.Delete(recentFile);

            const string recentFile2 = @"%APPDATA%\MPC-HC\default.mpcpl";
            recentFile = Environment.ExpandEnvironmentVariables(recentFile2);
            if (File.Exists(recentFile))
                File.Delete(recentFile);

            //const string recentFile3 = @"%APPDATA%\Microsoft\Windows\Recent\CustomDestinations";

        }
    }
}
