﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace LinkManager
{
    public class NbCommand : ICommand
    {
        public readonly string Title;
        public readonly string TooltipN;

        private readonly Action _action;
        private readonly Func<bool> _canExecuteN;

        public static readonly NbCommand Separator = null;

        public NbCommand(string aTitle, Action aAction, Func<bool> canExecute = null, string aTooltip = null)
        {
            Debug.Assert(!String.IsNullOrWhiteSpace(aTitle), "NbCommand title should not be emtpty");
            Debug.Assert(aAction != null, "NbCommand Action should not be null");

            Title = aTitle;
            _action = aAction;
            _canExecuteN = canExecute;
            TooltipN = aTooltip;
        }


        public void Execute(object parameter)
        {
            _action();
        }

#pragma warning disable 67
        public event EventHandler CanExecuteChanged; //Can execute if always true and can't change
#pragma warning restore 67

        public bool CanExecute(object parameter)
        {
            return _canExecuteN == null ? true : _canExecuteN();
        }
    }
}
