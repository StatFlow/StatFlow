﻿using NbTools;
using System;
using System.IO;
using System.Xml.Serialization;

namespace LinkManSettV1.Xml
{
    public partial class LinkManSett
    {
        [XmlIgnore]
        internal NbDictionary<string, string> VarsResolved = new NbDictionary<string, string>(50, StringComparer.OrdinalIgnoreCase, "Variables from XML");
        [XmlIgnore]
        internal NbDictionary<string, bool> ShowInTree = new NbDictionary<string, bool> (5, StringComparer.OrdinalIgnoreCase, "Entities show in tree property");


        internal void Resolve()
        {
            var crypto = new NbTools.Crypto.TripleDESStringEncryptor();
            foreach (var xmlVar in variables.Safe())
            {
                if (String.IsNullOrWhiteSpace(xmlVar.name))
                    throw new Exception("Xml with empty variable name found");

                if (!String.IsNullOrWhiteSpace(xmlVar.encoded_val))
                    VarsResolved.Add(xmlVar.name, crypto.DecryptBase64(xmlVar.encoded_val));
                else if (!String.IsNullOrWhiteSpace(xmlVar.value))
                    VarsResolved.Add(xmlVar.name, Environment.ExpandEnvironmentVariables(xmlVar.value));
                else
                    throw new Exception($"Xml Variable '{xmlVar.name}' has neither value not encoded_val set");
            }

            foreach(var entity in entitys.Safe())
            {
                ShowInTree.Add(entity.name, entity.show_in_tree);
            }

            paths?.Resolve();
            proxy?.Resolve(this);
        }

        public string ResolveVariablesInString(string src)
        {
            foreach (var (name, value) in VarsResolved)
                src = src.Replace($"%{name}%", value);
            return src;
        }
    }

    public partial class Proxy
    {
        [XmlIgnore]
        internal string PassResoved;

        internal void Resolve(LinkManSett parent)
        {
            PassResoved = parent.ResolveVariablesInString(this.pass_variable);
        }
    }

    public partial class Paths
    {
        [XmlIgnore]
        internal string IconDir;
        [XmlIgnore]
        internal string VideoPlayerN;

        internal void Resolve()
        {
            IconDir = Environment.ExpandEnvironmentVariables(icons);
            if (!Directory.Exists(IconDir))
                throw new Exception($"Icon directory '{icons}' doesn't exist");

            if (!String.IsNullOrWhiteSpace(video_player))
            {
                VideoPlayerN = Environment.ExpandEnvironmentVariables(video_player);
                if (!Directory.Exists(IconDir))
                    throw new Exception($"Video Player '{video_player}' doesn't exist");
            }
        }
    }
}