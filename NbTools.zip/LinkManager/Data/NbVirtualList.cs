﻿using NbTools.Collections;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LinkManager.Data
{
    /// <summary>
    /// Implements a List of TView items, suitable to use for the Items controls to diplay lists in the use, supports propery change events
    /// </summary>
    /// <typeparam name="TView">The view model class that represents a single line in the UI</typeparam>
    public class NbVirtualList<TView> : IList<TView>, IList, INotifyCollectionChanged, INotifyPropertyChanged
        where TView : IDfValueChangeListener
    {
        //Permanent
        private readonly List<TView> fList;
        private readonly Dictionary<int, TView> fDict;
        private readonly DfEntitiesColletion fEnt;
        private readonly Func<int, TView> ItemGetter;
        private readonly Func<TView, int> IndexGetter;

        private readonly IDfCollection Inds; //Some entries may be filtered out or ordered differently

        //Current state

        public int Count => fList.Count;


        /// <summary>
        /// Implements a List of TView items, suitable to use for the Items controls to disblay 
        /// </summary>
        /// <param name="columns">Collections of entitities to display in the items control</param>
        /// <param name="inds">Colection of Ids together with events, represent the desired order of the items to be shown</param>
        /// <param name="itemGetter">Function that contructs View class for each line for a given index</param>
        /// <param name="indexGetter">Function that extracts an intex in the colletion form the View class representing a line</param>
        public NbVirtualList(DfEntitiesColletion columns, IDfCollection inds, Func<int, TView> itemGetter, Func<TView, int> indexGetter)
        {
            fEnt = columns;
            ItemGetter = itemGetter;
            IndexGetter = indexGetter;
            Inds = inds;
            Inds.Changed += Inds_Changed;
            Inds.ValueChanged += Inds_ValueChanged;

            columns.ValueChanged += Columns_ValueChanged;

            //Populate list initially TODO: populate lazily
            fList = new List<TView>();
            fDict = new Dictionary<int, TView>();
            RebuildList();
        }

        private void Columns_ValueChanged(IDfColumnBase col, int ind)
        {
            if (fDict.TryGetValue(ind, out TView item)) //If not found in the dictionary - it is normal it might have been filtered out
                item.OnValueChanged(col, ind);
        }

        private void Inds_ValueChanged(IDfColumnBase col, int ind)
        {
        }

        private void Inds_Changed(DfCollChangedEventType eventType)
        {
            RebuildList();
            OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
        }

        private void RebuildList()
        {
            fList.Clear();
            fDict.Clear();
            foreach (var ind in Inds.All)
            {
                var item = ItemGetter(ind);
                fList.Add(item);
                fDict.Add(ind, item);
            }

            NotifyPropertyChanged(nameof(Count));
        }

        //DfTODO
        /*private void UnderlyingList_Changed(TUnder item, NotifyCollectionChangedAction action, int index = -1, int newCount_oldInd = -1)
        {
            switch (action)
            {
                case NotifyCollectionChangedAction.Add: //Propagate addition up
                    {
                        if (index < 0) throw new Exception($"Index is not set in Add event");

                        TView viewItem = ItemGetter(item);
                        fList.Insert(index, viewItem);

                        NotifyCollectionChangedEventArgs e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, viewItem, index);
                        Count = fUnderlying.Count;
                        OnCollectionChanged(e);
                    }
                    break;

                case NotifyCollectionChangedAction.Remove: //Propagate removal up
                    {
                        if (index < 0) throw new Exception($"Index is not set in Remove event");

                        TView viewItem = fList[index];
                        fList.RemoveAt(index);
                        NotifyCollectionChangedEventArgs e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, viewItem, index);
                        Count = fUnderlying.Count;
                        OnCollectionChanged(e);
                    }
                    break;

                case NotifyCollectionChangedAction.Move:
                    {
                        TView viewItem = this[newCount_oldInd]; //New item to send in event
                        fList.RemoveAt(newCount_oldInd);
                        fList.Insert(index, viewItem);
                        NotifyCollectionChangedEventArgs e = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Move, viewItem, index, newCount_oldInd);
                        OnCollectionChanged(e);
                    }
                    break;

                case NotifyCollectionChangedAction.Reset:
                    {
                        RebuildList();
                        Count = fUnderlying.Count;
                        OnCollectionChanged(new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset));
                    }
                    break;

                default:
                    throw new NbExceptionInfo($"Event '{action}' is not supported");
            }
        }*/

        public TView this[int index]
        {
            get { return fList[index]; }
            set { throw new NotImplementedException("this[].set"); }
        }

        object IList.this[int index]
        {
            get { return this[index]; }
            set { throw new NotImplementedException("IList.this[].set"); }
        }

        #region INotifyCollectionChanged Members
        protected void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            if (CollectionChanged != null) /*IsNotifying &&*/
                try
                {
                    CollectionChanged(this, e);
                }
                catch (NotSupportedException)
                {
                    NotifyCollectionChangedEventArgs alternativeEventArgs = new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset);
                    OnCollectionChanged(alternativeEventArgs);
                }
        }
        public event NotifyCollectionChangedEventHandler CollectionChanged;
        #endregion

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        private T NotImp<T>([CallerMemberName] string caller = "") => throw new NotImplementedException($"NbVirtualList<TView, TUnder> doesn't implement {caller}");

        //A collection with a fixed size does not allow the addition or removal of elements after the collection is created, but it allows the modification of existing elements.
        public bool IsFixedSize => false;

        public bool IsReadOnly => NotImp<bool>();
        public bool IsSynchronized => NotImp<bool>();
        public object SyncRoot => NotImp<bool>();
        public int Add(object value) => NotImp<int>();
        public void Add(TView item) => NotImp<int>();
        public void Clear() => NotImp<int>();
        public void CopyTo(Array array, int index) => NotImp<int>();
        public void CopyTo(TView[] array, int arrayIndex) => NotImp<int>();
        public void Insert(int index, object value) => NotImp<int>();
        public void Insert(int index, TView item) => NotImp<int>();
        public void Remove(object value) => NotImp<int>();
        public bool Remove(TView item) => NotImp<bool>();

        public void RemoveAt(int index) => fEnt.Delete(IndexGetter(fList[index]));

        //Dummies
        public bool Contains(object value) => false;
        public bool Contains(TView item) => false;

        public int IndexOf(object value)
        {
            var i = fList.IndexOf((TView)value);
            return i;
        }
        public int IndexOf(TView item) => fList.IndexOf(item);

        public IEnumerator<TView> GetEnumerator() { yield break; }
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
