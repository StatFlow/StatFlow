﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

using NbTools.Collections;
using NbTools;

using NbOrm.Xml;
using NbCollV1;

namespace LinkManager.Data
{
    public enum EntType { Entity = 0, Folder = 1 }

    public class DfRepository
    {
        private layout_info Layout;
        private bool SuccessfullyLoaded;
        private readonly List<DfDynamicCollection> Tables;

        public string Dir { get; private set; }
        private static readonly CsvParameters ParamsUni = new CsvParameters { FieldDelimiterN = '\t', EncodingN = Encoding.Unicode };

        internal DfEntitiesColletion Entities { get; } = new DfEntitiesColletion("Entity");
        internal DfLauncherColletion Launchers { get; } = new DfLauncherColletion("Launcher");

        public DfRepository()
        {
            Tables = new List<DfDynamicCollection>();
        }

        internal void Load(string dataDir, Action<string> _)
        {
            Dir = dataDir;
            Layout = layout_info.LoadXml(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Layout.xml"));

            Launchers.LoadFromCsv(Path.Combine(dataDir, "Launcher.csv"), null, ParamsUni);

            var entLayout = Layout[Entities.CollectionName];
            Entities.LoadFromCsv(Path.Combine(dataDir, Entities.CollectionName + ".csv"), Layout[Entities.CollectionName], ParamsUni);
            Tables.Add(Entities);

            Entities.Resolve(Tables, entLayout);
            SuccessfullyLoaded = true;
        }

        public void Save()
        {
            if (SuccessfullyLoaded && Entities.Count > 0)
               Entities.Save(Dir, ParamsUni);
        }
    }

    public class DfLauncherColletion : DfCollection
    {
        public readonly DfColumnStringIndex Id;
        public readonly DfColumnString Path;
        public readonly DfColumnString Parameters;
        public readonly DfColumnString Extensions;
        public readonly DfColumnString LauchAtStart;

        public override IDfColumnBase PrimaryKeyColumn => Id;
        public override IEnumerable<int> SavingOrder => Id.InOrder;

        public DfLauncherColletion(string name) : base(name)
        {
            Id = new DfColumnStringIndex(nameof(Id), this, false);
            Path = new DfColumnString(nameof(Path), this, false);
            Parameters = new DfColumnString(nameof(Parameters), this, isNull: true);
            Extensions = new DfColumnString(nameof(Extensions), this, isNull: true);
            LauchAtStart = new DfColumnString(nameof(LauchAtStart), this, isNull: true);
        }

        public override IEnumerable<IDfColumnBase> GetColumns()
        {
            yield return Id;
            yield return Path;
            yield return Parameters;
            yield return Extensions;
            yield return LauchAtStart;
        }

        protected override void ProcessCsvHeaders(IEnumerable<string> headers, DfTable recSetN) {}
    }

    /// <summary>
    /// Column-based collection of entitie's columns
    /// </summary>
    public class DfEntitiesColletion : DfDynamicCollection
    {
        public DfColumnStringIndex Id { get; private set; }
        public DfColumnString Name { get; private set; }
        public DfColumnString Type { get; private set; }
        public DfColumnReference Parents { get; private set; }
        public DfColumnString Icon { get; private set; }
        public DfColumnString Launcher { get; private set; }
        public DfColumnString CopyToClipboard { get; private set; }
        public DfColumnString ShortCut { get; private set; }
        public DfColumnDateTime AccessTime { get; private set; }
        public DfColumnDateTime ArchivedDate { get; private set; }
        public DfColumnString Url { get; private set; }
        public DfColumnReference Path { get; private set; }

        public DfEntitiesColletion(string name) : base(name) { }

        public IEnumerable<NbCommand> GetCommands(int ind, Window mainWindowN = null)
        {
            yield break;
        }

        public override IDfColumnBase PrimaryKeyColumn => Id;

        /// <summary>
        /// Resolves all reference fields in the collection. Creates backreferece fields in the referenced table
        /// </summary>
        /// <param name="tables"></param>
        /// <param name="recSet"></param>
        internal void Resolve(List<DfDynamicCollection> tables, DfTable recSet)
        {
            var newRefFields = new List<IDfColumnBase>(fCols.Count);

            //ValueTuple
            foreach (var fldAndDesc in fCols.Where(p => p.Item2.IsFieldRef))
            {
                var fldRef = fldAndDesc.Item2.link[0];
                DfDynamicCollection refTable = tables.SingleVerbose(t => t.CollectionName.EqIC(fldRef.ref_table),
                    () => $"Can't find table '{fldRef.ref_table}' referenced in the {recSet.name}.{fldAndDesc.Item2.name} field",
                    i => $"There are '{i}' tables with the name '{fldRef.ref_table}'");


                if (!(refTable.GetColumn(fldRef.ref_field) is DfColumnStringIndex))
                    throw new Exception($"Referenced field {recSet.name}.{fldAndDesc.Item2.name} must be a primary key or in other words of type {nameof(DfColumnStringIndex)} for the reference to work");
                var refCol = refTable.GetColumn(fldRef.ref_field) as DfColumnStringIndex;

                //Depending on the presense of split_by we determine wether the references are single or multiple
                IDfReferenceColumn dfColRef;
                if (String.IsNullOrEmpty(fldAndDesc.Item2.split_by))
                    dfColRef = new DfColumnSingleReference(fldAndDesc.Item1.Name, refCol, (fldAndDesc.Item1 as DfColumnString).fColl, fldAndDesc.Item2.@null);
                else
                    dfColRef = new DfColumnReference(fldAndDesc.Item1.Name, refCol, (fldAndDesc.Item1 as DfColumnString).fColl, (fldAndDesc.Item1 as DfColumnString).Vals);

                refTable.AddBackreferenceField(dfColRef.ResolveAndCreateBackeferenceColumn($"{recSet.name}_{fldAndDesc.Item2.name}_backreference", fldAndDesc.Item1 as DfColumnString));
                newRefFields.Add(dfColRef); //Can't replace in the loop if the reference inside the same table
            }

            foreach (var refFld in newRefFields)
                ReplaceColumn(refFld);

            Id = GetColumn<DfColumnStringIndex>(nameof(Id)); //DfColumnStringIndex
            Name = GetColumn<DfColumnString>(nameof(Name));
            Type = GetColumn<DfColumnString>(nameof(Type)); //DfColumnEnum<EntType>
            Parents = GetColumn<DfColumnReference>(nameof(Parents));
            Icon = GetColumn<DfColumnString>(nameof(Icon));
            Launcher = GetColumn<DfColumnString>(nameof(Launcher));
            CopyToClipboard = GetColumn<DfColumnString>(nameof(CopyToClipboard));
            ShortCut = GetColumn<DfColumnString>(nameof(ShortCut));
            AccessTime = GetColumn<DfColumnDateTime>(nameof(AccessTime));
            ArchivedDate = GetColumn<DfColumnDateTime>(nameof(ArchivedDate));
            Url = GetColumn<DfColumnString>(nameof(Url));
            Path = GetColumn<DfColumnReference>(nameof(Path));
        }

        internal void ArchiveRestore(int ind)
        {
            EditLine(ind);
            if (ArchivedDate[ind] == DateTime.MinValue) //
                ArchivedDate.SetValue(DateTime.UtcNow.Date); //Archive
            else
                ArchivedDate.SetValue(DateTime.MinValue); //Restore
            ReleaseLine();
        }

        public override void Delete(int ind)
        {
            Parents.DeleteAllBackReferences(ind); //Show be first, because base.Delete raises the event
            Path.DeleteAllBackReferences(ind);

            foreach(var backRef in fBackReferenceFields)
                backRef.DeleteAllReferences(ind);

            //ContaintedTags.DeleteAllReferences(ind); //Deletes the references from children to this Node
            //ContaintedFiles.DeleteAllReferences(ind);
            base.Delete(ind);
        }

        internal IEnumerable<int> GetTreeChildren(int ind) => fBackReferenceFields.SelectMany(b => b.GetReferences(ind)).Distinct();
    }
}

