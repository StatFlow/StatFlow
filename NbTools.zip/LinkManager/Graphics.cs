using System;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections.Generic;
using NbTools;

namespace Nb.Graphics
{
    public static partial class Extensions
    {
        public const string strDragImageBits = "DragImageBits";
        public const string strBitmap = "Bitmap";
        public const string strSystemDrawingBitmap = "System.Drawing.Bitmap";
        public const string strSystemWindowsMediaImagingBitmapSource = "System.Windows.Media.Imaging.BitmapSource";

        public static bool TryGetImageSource(string format, IDataObject dataObj, out BitmapSource imgSrc)
        {
            switch (format)
            {
                case strDragImageBits:
                    imgSrc = GetDragImageBits(dataObj);
                    return true;

                case strBitmap:
                case strSystemWindowsMediaImagingBitmapSource:
                    imgSrc = dataObj.GetData(format) as System.Windows.Interop.InteropBitmap; //Only run GetData on recognized format
                    return true;

                case strSystemDrawingBitmap: //Only run GetData on recognized format
                    System.Drawing.Bitmap bmp = dataObj.GetData(format) as System.Drawing.Bitmap; //GDI+ style 
                    imgSrc = bmp.ToBitmapSource();
                    return true;

                default: break;
            }

            imgSrc = null;
            return false;
        }

        public static BitmapSource GetDragImageBits(IDataObject obj)
        {
            MemoryStream imageStream = obj.GetData(strDragImageBits) as MemoryStream;
            imageStream.Seek(0, SeekOrigin.Begin);
            BinaryReader br = new BinaryReader(imageStream);
            ShDragImage shDragImage;
            shDragImage.sizeDragImage.cx = br.ReadInt32();
            shDragImage.sizeDragImage.cy = br.ReadInt32();
            shDragImage.ptOffset.x = br.ReadInt32();
            shDragImage.ptOffset.y = br.ReadInt32();
            shDragImage.hbmpDragImage = new IntPtr(br.ReadInt32()); // I do not know what this is for!
            shDragImage.crColorKey = br.ReadInt32();
            int stride = shDragImage.sizeDragImage.cx * 4;
            var imageData = new byte[stride * shDragImage.sizeDragImage.cy];
            // We must read the image data as a loop, so it's in a flipped format
            for (int i = (shDragImage.sizeDragImage.cy - 1) * stride; i >= 0; i -= stride)
            {
                br.Read(imageData, i, stride);
            }
            var bitmapSource = BitmapSource.Create(shDragImage.sizeDragImage.cx, shDragImage.sizeDragImage.cy,
                                                        96, 96,
                                                        System.Windows.Media.PixelFormats.Bgra32,
                                                        null,
                                                        imageData,
                                                        stride);
            return bitmapSource;
        }



        public static void SaveToFile(this BitmapSource bmpSource, string aFilename)
        {
            BitmapEncoder bme = new PngBitmapEncoder();
            bme.Frames.Add(BitmapFrame.Create(bmpSource));
            using (var fileStream = new FileStream(aFilename, FileMode.Create))
            {
                bme.Save(fileStream);
            }
        }


        /// <summary>
        /// Converts a <see cref="System.Drawing.Image"/> into a WPF <see cref="BitmapSource"/>.
        /// </summary>
        /// <param name="source">The source image.</param>
        /// <returns>A BitmapSource</returns>
        public static BitmapSource ToBitmapSource(this System.Drawing.Image source)
        {
            System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(source);

            var bitSrc = bitmap.ToBitmapSource();

            bitmap.Dispose();
            bitmap = null;

            return bitSrc;
        }

        /// <summary>
        /// Converts a <see cref="System.Drawing.Bitmap"/> into a WPF <see cref="BitmapSource"/>.
        /// </summary>
        /// <remarks>Uses GDI to do the conversion. Hence the call to the marshalled DeleteObject.
        /// </remarks>
        /// <param name="source">The source bitmap.</param>
        /// <returns>A BitmapSource</returns>
        public static BitmapSource ToBitmapSource(this System.Drawing.Bitmap source)
        {
            BitmapSource bitSrc = null;

            var hBitmap = source.GetHbitmap();

            try
            {
                bitSrc = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                    hBitmap,
                    IntPtr.Zero,
                    Int32Rect.Empty,
                    BitmapSizeOptions.FromEmptyOptions());
            }
            catch (System.ComponentModel.Win32Exception)
            {
                bitSrc = null;
            }
            finally
            {
                NativeMethods.DeleteObject(hBitmap);
            }

            return bitSrc;
        }
    }
}