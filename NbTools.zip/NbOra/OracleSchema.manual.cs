﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NbTools;

namespace OracleSchema
{
    public class SchemaTable
    {
        public string Name;
        public USER_CONSTRAINTS PrimaryKeyN;

        public List<USER_TAB_COLUMNS> Columns;
        public List<USER_CONSTRAINTS> Constrains = new List<USER_CONSTRAINTS>(10);


        public static NbDictionary<string, SchemaTable> LoadAndResolve(INbConn conn)
        {
            var tblDict = USER_TAB_COLUMNS.Select(conn).GroupBy(i => i.TABLE_NAME)
                .ToNbDictionary(g => g.Key, g => new SchemaTable { Name = g.Key, Columns = new List<USER_TAB_COLUMNS>(g) }, description: "Oracle SchemaTables");

            //Add contraints to tables
            var constrDict = new NbDictionary<Tuple<string, string>, USER_CONSTRAINTS>(description: "Oracle USER_CONSTRAINTS");
            var constrList = USER_CONSTRAINTS.Select(conn).Where(cn => !cn.CONSTRAINT_NAME.StartsWith("BIN$")).OrderBy(c => c.CONSTRAINT_NAME).ToList();
            foreach (var constr in constrList)
            {
                var refTable = tblDict[constr.TABLE_NAME];
                refTable.Constrains.Add(constr);
                if (constr.CONSTRAINT_TYPE == 'P')
                {
                    if (refTable.PrimaryKeyN != null)
                        throw new NbException($"Conflicting primary keys in the table {refTable.Name}: {refTable.PrimaryKeyN} and {constr}");
                    refTable.PrimaryKeyN = constr;
                }

                constr.Table = refTable;
                constrDict.Add(Tuple.Create(constr.TABLE_NAME, constr.CONSTRAINT_NAME), constr);
            }

            //Resolve contraints references to fields
            foreach (var constrCol in USER_CONS_COLUMNS.Select(conn).Where(uc => !uc.COLUMN_NAME.StartsWith("BIN$"))) //.OrderBy(cc => cc.POSITION ?? 0) Make sure the order in the list preserved
            {
                var tbl = tblDict[constrCol.TABLE_NAME];
                var fld = tbl.Columns.Single(c => c.COLUMN_NAME == constrCol.COLUMN_NAME);

                if (constrCol.CONSTRAINT_TYPE == "P")
                {
                    tbl.PrimaryKeyN.Columns.Add(fld);
                }
                else if (constrCol.CONSTRAINT_TYPE == "R")
                {
                    if (String.IsNullOrEmpty(constrCol.REF_TABLE_NAME))
                        continue;

                    var ref_tbl = tblDict[constrCol.REF_TABLE_NAME];
                    var ref_fld = ref_tbl.Columns.Single(c => c.COLUMN_NAME == constrCol.REF_COLUMN_NAME);
                    fld.ForeignFieldN = ref_fld;
                }


                //var refConstr = constrDict[constrCol.CONSTRAINT_NAME];
                //refConstr.Columns.Add(tbl.Columns.Single(c => c.COLUMN_NAME == constrCol.COLUMN_NAME)); //Save reference to the real column
            }

            /*foreach (var fk in constrDict.Values.Where(c => c.CONSTRAINT_TYPE == 'R')) //Second pass is required because foreign constraints refer to primary constraints
            {
                if (String.IsNullOrEmpty(fk.COLUMN_NAME))
                    throw new NbException($"Foreign key Constrait {fk} has empty COLUMN_NAME field");

                var ref_tbl = tblDict[fk.TABLE_NAME];

                var prim = constrDict[fk.R_CONSTRAINT_NAME];
                if (fk.Columns.Count != prim.Columns.Count)
                    throw new NbException($"Foreign key Constrait {fk} and the referenced Primary key {prim} have different number of fields: {fk.Columns.Count} and {prim.Columns.Count}");

                foreach (var pair in fk.Columns.Zip(prim.Columns, (b, c) => Tuple.Create(b, c)))
                {
                    pair.Item1.ForeignFieldN = pair.Item2;
                }
            }*/

            return tblDict;
        }

        public override string ToString() => $"{Name}";
    }

    public class ColumnTypeComparer : IEqualityComparer<USER_TAB_COLUMNS>
    {
        public bool Equals(USER_TAB_COLUMNS x, USER_TAB_COLUMNS y)
        {
            return String.Equals(x.DATA_TYPE, y.DATA_TYPE) &&
                    int.Equals(x.DATA_PRECISION, y.DATA_PRECISION) &&
                    int.Equals(x.DATA_SCALE, y.DATA_SCALE) &&
                    int.Equals(x.CHAR_LENGTH, y.CHAR_LENGTH);
        }

        public int GetHashCode(USER_TAB_COLUMNS x)
        {
            unchecked // Overflow is fine, just wrap
            {
                int hash = 17;
                // Suitable nullity checks etc, of course :)
                hash = hash * 16777619 + x.DATA_TYPE.GetHashCode();
                hash = hash * 16777619 + (x.DATA_PRECISION.HasValue ? x.DATA_PRECISION.Value.GetHashCode() : 0);
                hash = hash * 16777619 + (x.DATA_SCALE.HasValue ? x.DATA_SCALE.Value.GetHashCode() : 0);
                hash = hash * 16777619 + (x.CHAR_LENGTH.HasValue ? x.CHAR_LENGTH.Value.GetHashCode() : 0);
                return hash;
            }
        }
    }

    public partial class USER_TAB_COLUMNS
    {
        public USER_TAB_COLUMNS ForeignFieldN;

        public string GetTypeName ()
        {
            StringBuilder bld = new StringBuilder(DATA_TYPE, 30);
            if (CHAR_LENGTH.HasValue && CHAR_LENGTH.Value != 0)
                bld.Append("_").Append(CHAR_LENGTH.Value.ToString());
            if (DATA_PRECISION.HasValue && DATA_PRECISION.Value != 0)
                bld.Append("_").Append(DATA_PRECISION.Value.ToString());
            if (DATA_SCALE.HasValue && DATA_SCALE.Value != 0)
                bld.Append("_").Append(DATA_SCALE.Value.ToString());
            return bld.ToString();
        }
        public override string ToString() => $"{TABLE_NAME}.{COLUMN_NAME} {DATA_TYPE} ";
    }

    public partial class USER_CONSTRAINTS
    {
        public SchemaTable Table;
        public List<USER_TAB_COLUMNS> Columns = new List<USER_TAB_COLUMNS>(3);

        public override string ToString() => $"{CONSTRAINT_NAME} {ConstrTypeDescr(CONSTRAINT_TYPE)} ({String.Join(",", Columns.Select(c => c.COLUMN_NAME))}) table {TABLE_NAME}";

        public string ConstrTypeDescr(char? constr)
        {
            if (!constr.HasValue)
                return "NULL constraint type";

            switch (constr.Value)
            {
                case 'C': return "Check";
                case 'P': return "Primary Key";
                case 'U': return "Unique Key";
                case 'R': return "Foreign Key";
                case 'V': return "View check option";
                case 'O': return "View readonly";
                default: return $"Unknown constrains type {constr}";
            }
        }
    }

    public partial class USER_CONS_COLUMNS
    {
        public USER_TAB_COLUMNS RefField;

        public override string ToString() => $"{CONSTRAINT_NAME} '{TABLE_NAME}.{COLUMN_NAME}'";
    }

}
