﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

using NbTools;
using Oracle.ManagedDataAccess.Client;

namespace NbOra
{
    public class CsvOracleToObject : CsvObjectSetter<OracleDataReader>
    {
        public static CsvOracleToObject[] Create(Type type, ICollection<string> headers, CsvParameters csvParamN)
        {
            return CsvFieldInfo.Create<CsvOracleToObject>(type, headers, csvParamN,
                (fi, ind, specFunc, _fmt) => new CsvOracleToObject(fi, ind, specFunc, csvParamN),  //TODO: special function fields are ignored
                (pi, ind, specFunc, _fml) => new CsvOracleToObject(pi, ind, specFunc, csvParamN)); //TODO: special function fields are ignored
        }

        protected CsvOracleToObject(FieldInfo fi, int index, SpecialFunction specFunc, CsvParameters csvParamN)
            : base(fi, index, specFunc, csvParamN, formatN: null) //No need for format when reading from Oracle
        { }

        protected CsvOracleToObject(PropertyInfo pi, int index, SpecialFunction specFunc, CsvParameters csvParamN)
            : base(pi, index, specFunc, csvParamN, formatN: null) //No need for format when reading from Oracle
        { }

        protected Action<object, OracleDataReader> GetSettingAction(Type fldType)
        {
            string mainTypeName = fldType.Name;
            if (!fldType.IsGenericType)
            {   //Not generic
                if (fldType.IsSubclassOf(typeof(IdHolder)))
                {
                    return IdHolderSetter;
                }
                switch (mainTypeName)
                {
                    case "String": return StringSetter; //Strings can't be non-nullable
                    case "Int64": return Int64Setter;
                    //case "TimeSpan": return TimeSpanSetter;
                    default: return SimpleSetter;
                }
            }
            else //Generic
            {
                if (mainTypeName.Contains(GenTypeSeparator))
                    mainTypeName = mainTypeName.Substring(0, mainTypeName.IndexOf(GenTypeSeparator));
                switch (mainTypeName)
                {
                    case "Nullable": return NullableSetter;
                    default:
                        throw new Exception(String.Format("Unsupported generic type '{0}' for field '{1}' in FromCsv", mainTypeName, this.Name));
                }
            }
        }

        protected override Func<OracleDataReader, object> GetGonverter(Type fldType, string formatN)
        {
            string mainTypeName = fldType.Name;
            if (!fldType.IsGenericType)
            {   //Not generic
                if (fldType.IsSubclassOf(typeof(IdHolder)))
                {
                    return IdHolderConv;
                }
                switch (mainTypeName)
                {
                    case nameof(Int16): return NbNullInt16;
                    case nameof(Int32): return NbNullInt32;
                    case nameof(Int64): return NbNullInt64;
                    case nameof(Decimal): return r => r.GetDecimal(Index);
                    case nameof(String): return r => r.IsDBNull(Index) ? null : r.GetString(Index);

                    case nameof(TimeSpan): return r => r.GetDateTime(Index);
                    case nameof(DateTime): return r => r.GetDateTime(Index);
                    case nameof(Boolean): return BooleanConv;
                    default:
                        {
                            if (fldType.BaseType.Name == nameof(Enum))
                                return s => EnumConv(s, fldType);
                            else
                                throw new NbExceptionInfo($"Unsupported type when getting Oracle converter: '{mainTypeName}'");
                        }
                }
            }
            else //Generic
            {
                if (mainTypeName.Contains(GenTypeSeparator))
                    mainTypeName = mainTypeName.Substring(0, mainTypeName.IndexOf(GenTypeSeparator));

                var underlyingConv = GetGonverter(FieldType.GetGenericArguments()[0], formatN); //Recursive converter getter

                switch (mainTypeName)
                {
                    case nameof(Nullable): return s => s.IsDBNull(Index) ? null : underlyingConv(s);
                    //case "List": return s => ListConv(s, underlyingConv); //TODO: support later
                    //case "ObservableList": return s => ListConv(s, underlyingConv);
                    default:
                        throw new NbExceptionInfo($"Unsupported generic type '{mainTypeName}' for field '{Name}' in FromCsv");
                }
            }
        }

        private object IdHolderConv(OracleDataReader rdr)
        {
            if (rdr.IsDBNull(Index)) //Allow null pointers //TODO: Make attribute to throw exceptions on NULL pointers
                return null;

            if (Resolve == null)
                throw new CsvException("No resolver available for type '{0}'", this.FieldType);

            var fldVal = rdr.GetString(Index);
            IdHolder idHolderN = Resolve(fldVal);
            if (idHolderN == null)
                throw new CsvException("Can't resolve '{0}' for Id='{1}'", this.FieldType, fldVal);

            return idHolderN;
        }

        private decimal NotNullDecimal(OracleDataReader rdr)
        {
            if (rdr.IsDBNull(Index))
                throw new Exception($"Can't cast DbNull to interger in column #{Index}"); //TODO: can we get a name here?
            else
            {
                var typeName = rdr.GetDataTypeName(Index);
                switch (typeName)
                {
                    case "NVarchar2": //Converting a number stored in a string
                    case "Varchar2":
                    case "Char":
                        var str = rdr.GetString(Index);
                        decimal ret;
                        if (!Decimal.TryParse(str, out ret))
                            throw new Exception($"Can't parse decimal out of '{str}'");
                        return ret;
                    default:
                        return rdr.GetDecimal(Index); //Required for Oracle 11
                }
            }
        }

        private object NbNullInt64(OracleDataReader rdr)
        {
            if (TryNullDecimal(rdr, out decimal dec))
                return (Int64)dec;
            else
                return Int64.MinValue;
        }

        private object NbNullInt32(OracleDataReader rdr)
        {
            if (TryNullDecimal(rdr, out decimal dec))
                return (Int32)dec;
            else
                return Int32.MinValue;
        }

        private object NbNullInt16(OracleDataReader rdr)
        {
            if (TryNullDecimal(rdr, out decimal dec))
                return (Int16)dec;
            else
                return Int16.MinValue;
        }

        private bool TryNullDecimal(OracleDataReader rdr, out decimal res)
        {
            if (rdr.IsDBNull(Index))
            {
                res = default;
                return false;
            }

            var typeName = rdr.GetDataTypeName(Index);
            switch (typeName)
            {
                case "NVarchar2": //Converting a number stored in a string
                case "Varchar2":
                case "Char":
                    var str = rdr.GetString(Index);
                    if (!Decimal.TryParse(str, out res))
                        throw new Exception($"Can't parse decimal out of '{str}'");
                    return true;
                default:
                    res = rdr.GetDecimal(Index); //Required for Oracle 11
                    return true;
            }
        }


        private object EnumConv(OracleDataReader rdr, Type fldType)
        {
            string fldVal = String.Empty;
            try
            {
                if (rdr.IsDBNull(Index))
                    return 0;

                fldVal = rdr.GetString(Index);
                return Enum.Parse(fldType, fldVal); //Support for NULL, assuming NULL = 0
            }
            catch (Exception ex)
            {
                throw new Exception($"Can't parse '{fldType.FullName}' enum out of '{fldVal}': '{ex.Message}'");
            }
        }

        private object BooleanConv(OracleDataReader rdr)
        {
            var fldVal = rdr.GetString(Index);
            bool booVal = "true".Equals(fldVal, StringComparison.OrdinalIgnoreCase) ||
                "1".Equals(fldVal, StringComparison.OrdinalIgnoreCase) ||
                "Y".Equals(fldVal, StringComparison.OrdinalIgnoreCase);
            return booVal;
        }

        private object ListConv(OracleDataReader rdr, Func<string, object> underlyingAction)
        {
            IList instance = (IList)Activator.CreateInstance(FieldType);
            if (rdr.IsDBNull(Index))
                return instance;

            var fldVal = rdr.GetString(Index);
            foreach (string val in fldVal.Split('|').Select(s => s.Trim()))
                instance.Add(underlyingAction(val));
            return instance;
        }



        private void StringSetter(object mainObj, OracleDataReader fldVal)
        {
            try
            {
                if (fldVal.IsDBNull(Index))
                    FldPropSetter(mainObj, null);
                else
                    FldPropSetter(mainObj, fldVal.GetString(Index));
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Field Name: '{fldVal.GetName(Index)}', type: '{fldVal.GetFieldType(Index).Name}'");
            }
        }


        private void Int64Setter(object mainObj, OracleDataReader fldVal)
        {
            try
            {
                object obj = fldVal[Index];
                FldPropSetter(mainObj, (obj == DBNull.Value) ? long.MinValue : (Int64)obj);
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Field Name: '{fldVal.GetName(Index)}', type: Int64");
            }
        }

        private void SimpleSetter(object mainObj, OracleDataReader fldVal)
        {
            try
            {
                object obj = fldVal[Index];
                if (obj == DBNull.Value)
                {
                    throw new NbException($"Can't set '{mainObj.GetType().Name} {FldPropSetter.Target}' to DbNull");
                } //DbNulls are not allowed
                else
                    FldPropSetter(mainObj, Convert.ChangeType(fldVal[Index], FieldType)); //TODO: replace with proper code
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Field Name: '{ fldVal.GetName(Index)}', type: '{fldVal.GetFieldType(Index).Name}'");
            }
        }

        private void IdHolderSetter(object mainObj, OracleDataReader fldVal)
        {
            try
            {
                string id = fldVal.GetString(Index);
                if (Resolve == null)
                    throw new CsvException("No resolver available for type '{0}'", this.FieldType, id);
                IdHolder idHolderN = Resolve(id);
                if (idHolderN == null)
                    throw new CsvException("Can't resolve '{0}' for Id={1}", this.FieldType, id);
                FldPropSetter(mainObj, idHolderN);
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Field Name: '{fldVal.GetName(Index)}', type: '{fldVal.GetFieldType(Index).Name}'");
            }
        }

        private void TimeSpanSetter(object mainObj, OracleDataReader fldVal)
        {
            try
            {
                FldPropSetter(mainObj, fldVal.GetTimeSpan(Index));
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Field Name: '{fldVal.GetName(Index)}', type: '{fldVal.GetFieldType(Index).Name}'");
            }
        }

        private void NullableSetter(object mainObj, OracleDataReader fldVal)
        {
            try
            {
                if (fldVal.IsDBNull(Index))
                    FldPropSetter(mainObj, null);
                else
                {
                    Type underlyingType = FieldType.GetGenericArguments()[0];
                    FldPropSetter(mainObj, Convert.ChangeType(fldVal[Index], underlyingType));
                }
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Field Name: '{fldVal.GetName(Index)}', type: '{fldVal.GetFieldType(Index).Name}'");
            }
        }
    }

    public static partial class NbExt1
    {
        public static IEnumerable<T> FromOracle<T>(string sql, string connString, CsvParameters csvParamN = null)
            where T : class, new()
        {
            using OracleConnection connection = new OracleConnection(connString);
            connection.Open();
            using var cmd = new OracleCommand(sql, connection);
            using OracleDataReader r = cmd.ExecuteReader();
            foreach (var item in FromOracle<T>(r, csvParamN)) //To prevent connection and reader from closing
                yield return item;
        }

        public static IEnumerable<T> FromOracle<T>(string sql, OracleConnection connection, CsvParameters csvParamN = null)
            where T : class, new()
        {
            using (var cmd = new OracleCommand(sql, connection))
            {
                cmd.CommandTimeout = 6 * 60 * 60; //6 hours
                using (OracleDataReader r = cmd.ExecuteReader())
                {
                    foreach (var item in FromOracle<T>(r, csvParamN)) //To prevent reader from closing
                        yield return item;
                }
            }
        }

        public static IEnumerable<T> FromOracle<T>(string sql, string keyField, IEnumerable<string> keyValues, int batchSize, OracleConnection connection, CsvParameters csvParam)
            where T : class, new()
        {
            var enumer = keyValues.GetEnumerator();
            StringBuilder bld = new StringBuilder();
            string batchSql = CreateSqlBatch(sql, keyField, enumer, batchSize, bld);
            while (!String.IsNullOrEmpty(batchSql))
            {
                using (var cmd = new OracleCommand(batchSql, connection))
                {
                    cmd.CommandTimeout = 6 * 60 * 60; //6 hours
                    using (OracleDataReader r = cmd.ExecuteReader())
                    {
                        foreach (var item in FromOracle<T>(r, csvParam)) //To prevent reader from closing
                            yield return item;
                    }
                }
                batchSql = CreateSqlBatch(sql, keyField, enumer, batchSize, bld);
            }
        }
        private static string CreateSqlBatch(string sql, string keyField, IEnumerator<string> keyValues, int batchSize, StringBuilder bld)
        {
            bool IsEof = true;
            bld.Clear();
            bld.Append($" {keyField} in (");
            bool first = true;
            for (int i = 0; i < batchSize; ++i)
            {
                if (!keyValues.MoveNext())
                    break;
                if (first)
                {
                    first = false;
                    IsEof = false;
                }
                else
                    bld.AppendLine(",");
                bld.Append('\'').Append(keyValues.Current).Append('\'');
            }
            bld.AppendLine(") ");
            return IsEof ? null : String.Format(sql, bld.ToString()); //Assuming that sql has {0} after where
        }
        public static IEnumerable<T> FromOracle<T>(OracleDataReader reader, CsvParameters csvParamN = null)
            where T : class, new()
        {
            DataTable schema = reader.GetSchemaTable();
            int columnNameId = schema.Columns["ColumnName"].Ordinal;
            //int columnOrdinalId = schema.Columns["ColumnOrdinal"].Ordinal;
            var headers = schema.Rows.Cast<DataRow>().Select(r => r[columnNameId].ToString()).ToList();

            var fieldsAndProps = CsvOracleToObject.Create(typeof(T), headers, csvParamN);


            while (reader.Read())
            {
                yield return NbExt.BuildObject<T, OracleDataReader>(reader, fieldsAndProps, csvParamN?.LoggerN);
            }
        }

        public static string WherePartitionInt64(string field, int i, int numberOfParts)
        {
            long from = (i == 0) ? -1 : (Int64.MaxValue / numberOfParts * i); //First point exclusive except for 0
            long to = (i == numberOfParts - 1) ? Int64.MaxValue : Int64.MaxValue / numberOfParts * (i + 1); //Last point inclusive
            string partRule = String.Format(" {0} > {1} AND {0} <= {2} ", field, from, to);
            return partRule;
        }

        public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty));
        public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num, string otherLine) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty)).Concat(Yield(otherLine));
        public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num, IEnumerable<string> otherLines) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty)).Concat(otherLines);

        public static IEnumerable<T> Yield<T>(T arg) { yield return arg; }
    }
}
