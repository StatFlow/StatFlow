﻿using System;
using System.Collections.Generic;
using System.Text;
using NbTools;
using NbOrm.Ms;
using NbOrm.Ora;


namespace NbOrm
{
    public class ConnectionPool : IDisposable
    {
        private readonly NbDictionary<string, BasePool> Pools = new NbDictionary<string, BasePool>(5, StringComparer.OrdinalIgnoreCase, "Named connections");

        public ConnectionPool()
        { } //TODO: max connection, connect as soon as possible, logger to use, e.t.c. l

        public void RegisterConnection(string connName, ConnectionType connType, string connString)
        {
            Pools.Add(connName, connType switch
            {
                ConnectionType.MsSql => new NbMsPool(connName, connString),
                ConnectionType.Oracle => new NbOraPool(connName, connString),
                _ => throw new NbExceptionEnum<ConnectionType>(connType)

            });
        }

        public INbConn GetConnection(string name) => Pools[name].GetConn();


        public void Dispose()
        {
            Pools.Values.ForEachSafe(p => p.Dispose());
        }
    }

    public abstract class BasePool : IDisposable
    {
        private readonly string Name;
        private readonly string ConnString;

        public BasePool(string connName, string connString)
        {
            Name = connName;
            ConnString = connString;
        }

        public abstract INbConn GetConn();

        public abstract void Dispose();
    }
}