﻿using System;
using System.Data;
using System.Data.Common;
using Microsoft.Data.SqlClient;
using NbTools;

namespace NbOrm.Ms
{
    public class NbMsConn : INbConn, IDisposable
    {
        private readonly SqlConnection fConn;
        public ConnectionType ConnType => ConnectionType.MsSql;

        public NbMsConn(string connString)
        {
            fConn = new SqlConnection(connString);
            fConn.Open();
        }

        public INbCommand CreateCommand(string sql) => new NbMsCommand(fConn, sql);
        public INbTrans BeginTransaction() => new NbMsTrans(fConn);
        public INbReader CreateReader(string sql) => new NbMReader(fConn, sql);

        public void Dispose() => fConn.Dispose();

        public DataTable Read(string query)
        {
            using var da = new SqlDataAdapter();
            using (da.SelectCommand = fConn.CreateCommand())
            {
                da.SelectCommand.CommandText = query;
                //da.SelectCommand.Connection.ConnectionString = _connectionString;
                DataSet ds = new DataSet(); //conn is opened by dataadapter
                da.Fill(ds);
                return ds.Tables[0];
            }
        }


        public T ReadSingle<T>(string sql)
        {
            throw new NotImplementedException();
        }
    }

    public class NbMsCommand : INbCommand
    {
        private readonly SqlCommand fCmd;

        public NbMsCommand(SqlConnection conn, string sql)
        {
            fCmd = conn.CreateCommand();
            fCmd.CommandText = sql;
            fCmd.CommandType = System.Data.CommandType.Text;
        }

        public void AddParam(string name, object value) => fCmd.Parameters.AddWithValue("@" + name, (object)value ?? DBNull.Value);
        public void AddParam(string name, bool value) => fCmd.Parameters.AddWithValue("@" + name, value);
        public void AddParam(string name, bool? value) =>  fCmd.Parameters.AddWithValue("@" + name, (object)value ?? DBNull.Value);
        public void AddBlob(string name, byte[] value) => throw new NotImplementedException();

        public void Run() => fCmd.ExecuteNonQuery();
        public int RunGetInt32()
        {
            object res = fCmd.ExecuteScalar();
            return Convert.ToInt32(res);
        }

        public void Dispose()
        {
            fCmd.Dispose();
        }

        public T ReadSingle<T>() => throw new NotImplementedException();
        public Tuple<T, U> ReadSingle<T, U>() => throw new NotImplementedException();
        public Tuple<T, U, V> ReadSingle<T, U, V>() => throw new NotImplementedException();
    }

    public class NbMReader : INbReader, IDisposable
    {
        private readonly SqlCommand fCmd;
        private readonly SqlDataReader fRdr;

        public Type GetFieldType(int ordinal) => fRdr.GetFieldType(ordinal);
        public bool IsDBNull(int ordinal) => fRdr.IsDBNull(ordinal);
        public int FieldCount => fRdr.FieldCount;

        public NbMReader(SqlConnection conn, string sql)
        {
            fCmd = conn.CreateCommand();
            fCmd.CommandText = sql;
            fCmd.CommandType = System.Data.CommandType.Text;
            fRdr = fCmd.ExecuteReader();
        }

        public bool Read() => fRdr.Read();

        public void Dispose()
        {
            fRdr.Dispose();
            fCmd.Dispose();
        }

        public T GetNullableNumber<T>(int index) where T : struct
        {
            return fRdr.IsDBNull(index) ? default : GetNumber<T>(index);
        }
        public T GetNumber<T>(int index) where T : struct
        {
            return typeof(T).Name switch
            {
                nameof(Byte) => (T)(object)fRdr.GetByte(index),
                nameof(Int16) => (T)(object)fRdr.GetInt16(index),
                nameof(Int32) => (T)(object)fRdr.GetInt32(index),
                _ => throw new Exception($"Unsupported type in GetNumber<{typeof(T).Name}>"),
            };
        }

        public string GetString(int index) => fRdr.GetString(index);
        public string GetNullableString(int index) => fRdr.IsDBNull(index) ? (string)null : fRdr.GetString(index);


        public Int16? GetNullableInt16(int index) => fRdr.IsDBNull(index) ? (Int16?)null : GetInt16(index);

        public Int16 GetInt16(int index)
        {
            var a = fRdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Boolean) => fRdr.GetBoolean(index) ? (short)1 : (short)0,
                nameof(Byte) => fRdr.GetByte(index),
                nameof(Int16) => fRdr.GetInt16(index),
                _ => throw new Exception($"Unsupported type in GetNullableInt16: {a}"),
            };
        }

        public int? GetNullableInt32(int index) => fRdr.IsDBNull(index) ? (int?)null : GetInt32(index);

        public int GetInt32(int index)
        {
            var a = fRdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Byte) => fRdr.GetByte(index),
                nameof(Int16) => fRdr.GetInt16(index),
                nameof(Int32) => fRdr.GetInt32(index),
                _ => throw new Exception($"Unsupported type in GetInt32: {a}"),
            };
        }

        public long? GetNullableInt64(int index) => fRdr.IsDBNull(index) ? (long?)null : fRdr.GetInt64(index);
        public long GetInt64(int index)
        {
            var a = fRdr.GetFieldType(index).Name;
            return a switch
            {
                nameof(Byte) => fRdr.GetByte(index),
                nameof(Int16) => fRdr.GetInt16(index),
                nameof(Int32) => fRdr.GetInt32(index),
                nameof(Int64) => fRdr.GetInt64(index),
                _ => throw new Exception($"Unsupported type in GetInt64: {a}"),
            };
        }

        public decimal GetDecimal(int index) => fRdr.GetDecimal(index);
        public decimal? GetNullableDecimal(int index) => fRdr.IsDBNull(index) ? (decimal?)null : fRdr.GetDecimal(index);
        public double GetDouble(int index) => fRdr.GetDouble(index);
        public double? GetNullableDouble(int index) => fRdr.IsDBNull(index) ? (double?)null : fRdr.GetDouble(index);
        public DateTime GetDateTime(int index) => fRdr.GetDateTime(index);
        public DateTime? GetNullableDateTime(int index) => fRdr.IsDBNull(index) ? (DateTime?)null : fRdr.GetDateTime(index);
        public bool GetBoolean(int index) => fRdr.GetBoolean(index);
        public bool? GetNullableBoolean(int index) => fRdr.IsDBNull(index) ? (bool?)null : fRdr.GetBoolean(index);
        public char GetChar(int index) => fRdr.GetString(index)[0];
        public char? GetNullableChar(int index) => fRdr.IsDBNull(index) ? (char?)null : fRdr.GetString(index)[0];
        public string GetName(int index) => fRdr.GetName(index);

        public string GetBlob(int v) => throw new NotImplementedException();

        public byte[] GetBytes(int index)
        {
            throw new NotImplementedException();
        }

        public DataTable FillDataTable()
        {
            throw new NotImplementedException();
        }
    }

    public class NbMsTrans : INbTrans, IDisposable
    {
        private readonly SqlTransaction fTrans;

        public NbMsTrans(SqlConnection conn) => fTrans = conn.BeginTransaction(); //TODO: Isolation level
        public void Commit() => fTrans.Commit();
        public void Dispose() => fTrans.Dispose();
    }

    public class NbMsPool : BasePool
    {
        public NbMsPool(string connName, string connString)
            : base(connName, connString) { }

        public override INbConn GetConn()
        {
            throw new NotImplementedException();
        }

        public override void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
