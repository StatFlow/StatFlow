﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using NbTools;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace NbOrm.Ora
{
    public class NbOraConn : INbConn, IDisposable
    {
        private readonly OracleConnection fConn;

        public ConnectionType ConnType => ConnectionType.Oracle;

        public NbOraConn(string connString)
        {
            fConn = new OracleConnection(connString);
            fConn.Open();
        }

        public INbCommand CreateCommand(string sql) => new NbOraCommand(this.fConn, sql);
        public INbTrans BeginTransaction() => new NbOraTrans(this.fConn);
        public void Dispose() => fConn.Dispose();
        public INbReader CreateReader(string sql) => new NbOraReader(fConn, sql);

        public string CreateConnectionString(string host, int port, string service, string password) 
            => $"SERVER=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST={host})(PORT={port}))(CONNECT_DATA=(SERVICE_NAME={service})));uid=hr;pwd={password};";


        public async Task<T> ReadSingle<T>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? rdr.GetValue<T>(0) : default;
        }

        public async Task<(T, U)> ReadSingle<T, U>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? (rdr.GetValue<T>(0), rdr.GetValue<U>(1)) : default;
        }

        public async Task<(T, U, V)> ReadSingle<T, U, V>(string sql)
        {
            using var rdr = CreateReader(sql);
            return await rdr.ReadAsync() ? (rdr.GetValue<T>(0), rdr.GetValue<U>(1), rdr.GetValue<V>(1)) : default;
        }

        public async Task<List<T>> ReadList<T>(string sql)
        {
            var list = new List<T>();
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                list.Add(rdr.GetValue<T>(0));
            return list;
        }

        public async Task<NbDictionary<K, V>> ReadDictionary<K, V>(string sql, string dictDecr = null)
        {
            var dict = new NbDictionary<K, V>(description: dictDecr);
            using var rdr = CreateReader(sql);
            while (await rdr.ReadAsync())
                dict.Add(rdr.GetValue<K>(0), rdr.GetValue<V>(0));
            return dict;
        }

        public List<(T, U)> ReadList<T, U>(string sql)
        {
            throw new NotImplementedException();
        }

        public List<(T, U, V)> ReadList<T, U, V>(string sql)
        {
            throw new NotImplementedException();
        }

        public Task<T> ReadSingleAsync<T>(string sql)
        {
            throw new NotImplementedException();
        }

        public Task<(T, U)> ReadSingleAsync<T, U>(string sql)
        {
            throw new NotImplementedException();
        }

        public Task<(T, U, V)> ReadSingleAsync<T, U, V>(string sql)
        {
            throw new NotImplementedException();
        }

        public Task<List<T>> ReadListAsync<T>(string sql)
        {
            throw new NotImplementedException();
        }

        public Task<List<(T, U)>> ReadListAsync<T, U>(string sql)
        {
            throw new NotImplementedException();
        }

        public Task<List<(T, U, V)>> ReadListAsync<T, U, V>(string sql)
        {
            throw new NotImplementedException();
        }

        public Task<NbDictionary<K, V>> ReadDictionaryAsync<K, V>(string sql, string dictDecr = null)
        {
            throw new NotImplementedException();
        }
    }

    public class NbOraCommand : INbCommand
    {
        private readonly OracleCommand fCmd;
        public const string OraOutParam = ":pOut_id";

        public NbOraCommand(OracleConnection conn, string sql)
        {
            fCmd = conn.CreateCommand();
            fCmd.CommandText = sql;
            fCmd.CommandType = System.Data.CommandType.Text;
        }

        public void AddParam(string name, object value) => fCmd.Parameters.Add(":p_" + name, value);
        public void AddParam(string name, bool value) => fCmd.Parameters.Add(":p_" + name, value ? "Y" : "N");

        public void AddParam(string name, bool? value)
        {
            if (value.HasValue)
                fCmd.Parameters.Add(":p_" + name, value.Value ? "Y" : "N");
            else
                fCmd.Parameters.Add(":p_" + name, null);
        }
        public void AddBlob(string name, byte[] value)
        {
            OracleParameter blb = fCmd.Parameters.Add(":p_" + name, OracleDbType.Blob);
            blb.Direction = ParameterDirection.Input;
            blb.Value = value;
        }

        public void Run() => fCmd.ExecuteNonQuery();

        public int RunGetInt32()
        {
            var pOut = fCmd.Parameters.Add(OraOutParam, OracleDbType.Int32, ParameterDirection.Output);
            fCmd.ExecuteNonQuery();
            OracleDecimal dec = (OracleDecimal)pOut.Value;
            return Convert.ToInt32(dec.Value);
        }

        public void Dispose() => fCmd.Dispose();

        public T ReadSingle<T>()
        {
            using var rdr = fCmd.ExecuteReader();
            if (!rdr.Read())
                throw new Exception($"Command didn't return any line '{fCmd.CommandText}'");

            object obj = rdr.GetValue(0);

            if (rdr.Read())
                throw new Exception($"Command returned more than one line '{fCmd.CommandText}'");

            return (T)Convert.ChangeType(obj, typeof(T));
        }

        public Tuple<T, U> ReadSingle<T, U>()
        {
            using var rdr = fCmd.ExecuteReader();
            if (!rdr.Read())
                throw new Exception($"Command didn't return any line '{fCmd.CommandText}'");

            object objT = rdr.GetValue(0);
            object objU = rdr.GetValue(1);

            if (rdr.Read())
                throw new Exception($"Command returned more than one line '{fCmd.CommandText}'");

            return Tuple.Create((T)Convert.ChangeType(objT, typeof(T)), (U)Convert.ChangeType(objT, typeof(U)));
        }

        public Tuple<T, U, V> ReadSingle<T, U, V>()
        {
            using var rdr = fCmd.ExecuteReader();
            if (!rdr.Read())
                throw new Exception($"Command didn't return any line '{fCmd.CommandText}'");

            object objT = rdr.GetValue(0);
            object objU = rdr.GetValue(1);
            object objV = rdr.GetValue(2);

            if (rdr.Read())
                throw new Exception($"Command returned more than one line '{fCmd.CommandText}'");

            return Tuple.Create((T)Convert.ChangeType(objT, typeof(T)), (U)Convert.ChangeType(objT, typeof(U)), (V)Convert.ChangeType(objV, typeof(V)));
        }

        public Task RunAsync()
        {
            throw new NotImplementedException();
        }

        public Task<int> RunGetInt32Async()
        {
            throw new NotImplementedException();
        }
    }

    public class NbOraReader : INbReader, IDisposable
    {
        private readonly OracleCommand fCmd;
        private readonly OracleDataReader fRdr;

        public Type GetFieldType(int ordinal) => fRdr.GetFieldType(ordinal);
        public bool IsDBNull(int ordinal) => fRdr.IsDBNull(ordinal);
        public int FieldCount => fRdr.FieldCount;
      
        public NbOraReader(OracleConnection conn, string sql)
        {
            try
            {
                fCmd = conn.CreateCommand();
                fCmd.CommandText = sql;
                fCmd.CommandType = System.Data.CommandType.Text;
                fRdr = fCmd.ExecuteReader();
            }
            catch(OracleException ex)
            {
                throw new NbException(ex, $"Error while running sql statement:\r\n{sql}");
            }
        }

        public bool Read() => fRdr.Read();

        public void Dispose()
        {
            fRdr.Dispose();
            fCmd.Dispose();
        }

        public string GetString(int index) => fRdr.GetString(index);
        public string GetNullableString(int index) => fRdr.IsDBNull(index) ? (string)null : fRdr.GetString(index);

        public char GetChar(int index)
        {
            string str = GetNullableString(index);
            return (str != null && str.Length > 0) ? str[0] : default;
        }

        public char? GetNullableChar(int index)
        {
            string str = GetNullableString(index);
            return (str != null && str.Length > 0) ? str[0] : (char?)null;
        }

        public Int16 GetInt16(int index) => (Int16)fRdr.GetDecimal(index);
        public Int16? GetNullableInt16(int index) => fRdr.IsDBNull(index) ? (Int16?)null : (Int16)fRdr.GetDecimal(index);

        public int GetInt32(int index) => (int)fRdr.GetDecimal(index);
        public int? GetNullableInt32(int index) => fRdr.IsDBNull(index) ? (int?)null : (int)fRdr.GetDecimal(index);

        public long GetInt64(int index) => (long)fRdr.GetDecimal(index);
        public long? GetNullableInt64(int index) => fRdr.IsDBNull(index) ? (long?)null : (long)fRdr.GetDecimal(index);

        public decimal GetDecimal(int index) => fRdr.GetDecimal(index);
        public decimal? GetNullableDecimal(int index) => fRdr.IsDBNull(index) ? (decimal?)null : fRdr.GetDecimal(index);

        public double GetDouble(int index) => fRdr.GetDouble(index);
        public double? GetNullableDouble(int index) => fRdr.IsDBNull(index) ? (double?)null : fRdr.GetDouble(index);

        public DateTime GetDateTime(int index) => fRdr.GetDateTime(index);
        public DateTime? GetNullableDateTime(int index) => fRdr.IsDBNull(index) ? (DateTime?)null : fRdr.GetDateTime(index);

        public bool GetBoolean(int index) => "Y".Equals(fRdr.GetString(index), StringComparison.OrdinalIgnoreCase);
        public bool? GetNullableBoolean(int index) => fRdr.IsDBNull(index) ? (bool?)null : GetBoolean(index);

        public string GetName(int index) => fRdr.GetName(index);

        public string GetBlob(int index)
        {
            using OracleBlob blob = fRdr.GetOracleBlob(index);
            using var t = new StreamReader(blob, Encoding.UTF8);
            var res = t.ReadToEnd();
            return res;
        }
        private static readonly byte[] Buff = new byte[1000 * 1000];

        public byte[] GetBytes(int index)
        {
            long bytesRead = fRdr.GetBytes(index, 0, Buff, 0,  1000 * 1000);
            byte[] ret = new byte[bytesRead];
            Array.Copy(Buff, ret, bytesRead);
            return ret;
        }

        public DataTable FillDataTable()
        {
            var dataTable = new DataTable();
            dataTable.Load(fRdr);
            return dataTable;
        }

        public T GetValue<T>(int index)
        {
            throw new NotImplementedException();
        }

        public Task<bool> ReadAsync()
        {
            throw new NotImplementedException();
        }

        Task<int> INbReader.FieldCount()
        {
            throw new NotImplementedException();
        }
    }

    public class NbOraTrans : INbTrans, IDisposable
    {
        private readonly OracleTransaction fTrans;

        public NbOraTrans(OracleConnection conn) => fTrans = conn.BeginTransaction(); //TODO: Isolation level
        public void Commit() => fTrans.Commit();
        public void Dispose() => fTrans.Dispose();
    }

    public class NbOraPool : BasePool
    {
        public NbOraPool(string connName, string connString)
            : base(connName, connString) { }

        public override INbConn GetConn()
        {
            throw new NotImplementedException();
        }

        public override void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
