﻿using NbOrm.Ms;
using NbOrm.Xml;
using NbTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using OracleSchema;
using NbOrm.Ora;

namespace NbOrm.Ms
{
    public class SchemaToDb
    {
        private const SqlScriptOracle.Db2XmlConversionMode typeConvMode = SqlScriptOracle.Db2XmlConversionMode.CsDriven;

        public static List<recordset> GetTables(INbConn conn, out NbDictionary<string, type_scalar> types)
        {
            var tbls = SchemaTable.LoadAndResolve(conn);
            var tps = new NbDictionary<string, type_scalar>(100, description: "Sql Model scalar types");
            var recordsets = new List<recordset>();

            foreach (var tbl in tbls.Values.OrderBy(t => t.Name))
            {
                var fields = tbl.Columns.OrderBy(f1 => f1.COLUMN_ID).Select<USER_TAB_COLUMNS, field_base>(f =>
                {
                    //Find existin or create a new type
                    var typeName = f.GetTypeName();
                    if (!tps.TryGetValue(typeName, out type_scalar tp))
                    {
                        CType ct = SqlScriptOracle.OraType2CType(f.DATA_TYPE, f.DATA_PRECISION, f.DATA_SCALE, typeConvMode);
                        tp = new type_scalar { name = typeName, Ctype = ct, ora_type = f.DATA_TYPE };
                        switch (ct)
                        {
                            case CType.@string:
                                tp.length = f.CHAR_LENGTH.Value;
                                break;
                            case CType.@int:
                            case CType.@char:
                            case CType.@long:
                                tp.length = f.DATA_PRECISION.Value;
                                break;

                            case CType.@decimal:
                                tp.length = f.DATA_PRECISION ?? 38;
                                tp.precision = f.DATA_SCALE ?? 20; //This is assumed to be max precision and scale
                                break;

                            case CType.@byte:
                            case CType.@bool:
                            case CType.@float:
                            case CType.@double:
                            case CType.DateTime: //Do nothing
                            case CType.blob: //Do nothing
                                break;

                            default:
                                throw new Exception($"Unsupported type '{ct}' in xml generation from Oracle schema");
                        }

                        tps.Add(typeName, tp);
                    }



                    bool isPrimary = tbl.PrimaryKeyN?.Columns?.Any(c => c.COLUMN_NAME == f.COLUMN_NAME) ?? false; //If such field is mentioned in primary key field list

                    if (f.ForeignFieldN != null)
                    {
                        //Field foreign doen't have its onw type
                        var res = new field_ref
                        {
                            name = f.COLUMN_NAME,
                            ref_type = RefTypes.foreign,
                            ref_table = f.ForeignFieldN.TABLE_NAME,
                            ref_field = f.ForeignFieldN.COLUMN_NAME,
                            @null = f.NULLABLE ?? false
                        };
                        if (isPrimary)
                            res.key = field_baseKey.primary;
                        return res;
                    }

                    CType cType = SqlScriptOracle.OraType2CType(f.DATA_TYPE, f.DATA_PRECISION, f.DATA_SCALE, typeConvMode);
                    var fld = new field { name = f.COLUMN_NAME, type = tp.name, @null = f.NULLABLE ?? false };
                    if (isPrimary)
                        fld.key = field_baseKey.primary;

                    return fld;
                });

                recordsets.Add(new table { name = tbl.Name, Items = fields.ToArray() });
            }
            types = tps;
            return recordsets;
        }
    }
}
