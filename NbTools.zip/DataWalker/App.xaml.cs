﻿using Microsoft.VisualBasic.ApplicationServices;
using NbTools;
using System;
using System.Windows;

namespace DataWalker
{
    // Using VB bits to detect single instances and process accordingly:
    //  * OnStartup is fired when the first instance loads
    //  * OnStartupNextInstance is fired when the application is re-run again
    //    NOTE: it is redirected to this instance thanks to IsSingleInstance
    public class SingleInstanceManager : WindowsFormsApplicationBase
    {
        App app;

        public SingleInstanceManager()
        {
            this.IsSingleInstance = true;
        }

        protected override bool OnStartup(Microsoft.VisualBasic.ApplicationServices.StartupEventArgs e)
        {
            // First time app is launched
            app = new App();
            try
            {
                app.Run();
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
            return false;
        }

        protected override void OnStartupNextInstance(StartupNextInstanceEventArgs eventArgs)
        {
            // Subsequent launches
            base.OnStartupNextInstance(eventArgs);
            app.Activate();
            app.MainWindow.WindowState = WindowState.Normal;
        }
    }

    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static NbLog Log;
        /*private void Application_Startup(object sender, StartupEventArgs e)
        {
            try
            {
                MainWindow wnd = new MainWindow();
                wnd.CommandLineParams = e.Args;
                wnd.Show();
            }
            catch(Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
        }*/

        /// <summary>
        /// Application Entry Point.
        /// </summary>
        [System.STAThreadAttribute()]
        //[System.Diagnostics.DebuggerNonUserCodeAttribute()]
        [System.CodeDom.Compiler.GeneratedCodeAttribute("PresentationBuildTasks", "4.0.0.0")]
        public static void Main(string[] args)
        {
            try
            {
                Log = new NbLog();
                SingleInstanceManager manager = new SingleInstanceManager();
                manager.Run(args);
            }
            finally
            {
                Log?.Dispose();
            }
        }

        protected override void OnStartup(System.Windows.StartupEventArgs e)
        {
            base.OnStartup(e);
            try
            {
                MainWindow window = new MainWindow { CmdArgs = e.Args }; // Create and show the application's main window
                window.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(NbException.Exception2String(ex));
            }
        }

        public void Activate() => this.MainWindow.Activate();

        private void Application_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show(NbException.Exception2String(e.Exception), "Exception Caught", MessageBoxButton.OK, MessageBoxImage.Error);
            e.Handled = true;
        }
    }
}

