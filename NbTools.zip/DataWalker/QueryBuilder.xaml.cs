﻿using DataWalker.Xml;
using NbTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DataWalker
{
    /// <summary>
    /// Interaction logic for QueryBuilder.xaml
    /// </summary>
    public partial class QueryBuilder : Window
    {
        private QuerySnapshot fSnap;

        public delegate void QuerySnapshotChangedDel(QuerySnapshot qs);
        public event QuerySnapshotChangedDel QuerySnapshotChanged;

        public QueryBuilder()
        {
            InitializeComponent();
        }

        public QuerySnapshot QuerySnapshot
        {
            get { return fSnap; }
            set
            {
                fSnap = value;
                this.Title = $"QueryBuilder - {fSnap?.name}";
                grMainGrid.Children.Clear();

                foreach (var par in NbExt.Safe(fSnap?.param))
                {
                    grMainGrid.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

                    TextBlock tb = new TextBlock();
                    tb.Text = par.name;

                    grMainGrid.Children.Add(tb);
                    Grid.SetColumn(tb, 0);
                    Grid.SetRow(tb, grMainGrid.RowDefinitions.Count - 1);

                    TextBox tx = new TextBox() { Text = par.value, TextWrapping = TextWrapping.Wrap, MinWidth= 100 };
                    grMainGrid.Children.Add(tx);
                    Grid.SetColumn(tx, 1);
                    Grid.SetRow(tx, grMainGrid.RowDefinitions.Count - 1);
                    tx.Tag = par;

                    /*if (fDefaultBackground == null)
                        fDefaultBackground = tx.Background;*/
                }
            }
        }

        private void btOk_Click(object sender, RoutedEventArgs e)
        {
            foreach (var textBox in grMainGrid.Children.OfType<TextBox>())
            {
                var pr = textBox.Tag as QuerySnapshotParameter;
                if (pr == null)
                    throw new NbExceptionInfo("QuerySnapshotParameter info was not set as a tag for TextBox");

                pr.value = textBox.Text;
            }

            QuerySnapshotChanged?.Invoke(QuerySnapshot);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
