﻿using NbTools;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace DataWalker
{
    internal static class Extensions
    {
        public static T CastVerbose<T>(this object val, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
            where T : class
        {
            if (val == null)
                throw new Exception($"Null value passed to NotNull class in {filePath}({lineNum}) method: '{name}'");
            if (!(val is T t))
                throw new Exception($"Object of type '{val.GetType().Name}' can't be cast to type '{typeof(T).Name}' in {filePath}({lineNum}) method: '{name}'");
            return t;
        }

        public static ImageSource ToImageSource(this string filename)
        {
            try
            {
                const int IconSize = 16;
                BitmapDecoder decoder = BitmapDecoder.Create(new Uri(filename, UriKind.Absolute), BitmapCreateOptions.None, BitmapCacheOption.OnDemand);
                return decoder.Frames.FirstOrDefault(f => f.Width == IconSize) ?? decoder.Frames.OrderBy(f => f.Width).First(); //Returns bitmap frame
            }
            catch (Exception ex)
            {
                throw new Exception($"Can't load an icon from the file: '{filename}'", ex);
            }
        }
    }

    interface IUiCallback
    {
        void ShowStatus(string message);
    }



    public class ComboBoxController
    {
        private readonly ComboBox fCb;
        private readonly List<string> fFullList;
        private readonly DispatcherTimer fTimer;
        private bool KeyDownPressed = false;

        public ComboBoxController(ComboBox cb, IEnumerable<string> items)
        {
            fCb = cb;
            fCb.IsTextSearchCaseSensitive = false;
            fCb.IsTextSearchEnabled = true;
            fCb.IsEditable = true;

            fCb.KeyUp += FCb_KeyUp;
            fCb.GotFocus += FCb_GotFocus;

            fFullList = new List<string>();
            foreach (var str in items)
            {
                fCb.Items.Add(str);
                fFullList.Add(str);
            }

            fTimer = new DispatcherTimer();
            fTimer.Tick += FTimer_Tick; ;
            fTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
        }

        private void FCb_GotFocus(object sender, System.Windows.RoutedEventArgs e)
        {
            KeyDownPressed = false;
            fCb.Items.Clear();
            foreach (var str in fFullList)
                fCb.Items.Add(str);
        }

        private void FTimer_Tick(object sender, EventArgs e)
        {
            var toSearch = fCb.Text.Trim();
            if (!String.IsNullOrEmpty(toSearch) && !KeyDownPressed)
            {
                fCb.Items.Clear();
                foreach (var str in String.IsNullOrEmpty(toSearch) ? fFullList : fFullList.Where(s => s.ContainsIC(toSearch)))
                    fCb.Items.Add(str);

                fCb.IsDropDownOpen = true;
            }
            fTimer.Stop();
        }



        private void FCb_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            switch(e.Key)
            {
                case Key.Down:
                    KeyDownPressed = true;
                    break;
                case Key.Enter:
                  
                    var element = e.OriginalSource as UIElement;
                    if (element != null)
                        element.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
                    break;
            }

            //Debug.WriteLine($"Text: {fCb.Text}, IsFocused: {fCb.IsFocused}, ISKeybFocused {fCb.IsKeyboardFocused}, IsKeyboardFocusWithin: {fCb.IsKeyboardFocusWithin}");
            fTimer.Start();
        }
    }
}
