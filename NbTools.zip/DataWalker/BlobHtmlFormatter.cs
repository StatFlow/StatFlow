﻿using System;
using NbTools;

namespace DataWalker
{
    class BlobHtmlFormatter
    {
        internal static string Load(INbConn nbConn, string sqlByUri)
        {
            string res;
            using (var rdr = nbConn.CreateReader(sqlByUri))
            {
                if (!rdr.Read())
                    throw new NbExceptionInfo($"Blob request '{sqlByUri}' didn't return any lines");

                res = rdr.GetBlob(0);

                if (rdr.Read())
                    throw new NbExceptionInfo($"Blob request '{sqlByUri}' returned more than one line");

                return res;
            }
        }
    }
}
