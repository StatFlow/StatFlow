﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NbTools;
using NbTools.Collections;
using NbOrm.Nbq;
using NbOrm.Xml;

using DataWalker.Xml;
using Microsoft.Win32;
using NbCollV1;

namespace DataWalker
{
    internal abstract class QueryTypeBase
    {
        public abstract string Name { get; }
        public abstract NbqQueryType NbqType { get; } // { nbquery, nbsql, nbblob, nbdgml, nbcsv };
        public override string ToString() => Name;

        public abstract QueryResult GetQueryResult(NbqQueryType qType, string query, configEnvironment env, model mod, layout_info layoutTables);

        protected static QueryTypeSqlData sqlData = new QueryTypeSqlData();
        protected static QueryTypeSqlText sqlText = new QueryTypeSqlText();
        protected static QueryTypeSqlBlob sqlBlob = new QueryTypeSqlBlob();
        protected static QueryTypeSqlDgml sqlDgml = new QueryTypeSqlDgml();
        protected static QueryTypeCsv csv = new QueryTypeCsv();

        public static QueryTypeBase[] All = new QueryTypeBase[] { sqlData, sqlText, sqlBlob, sqlDgml, csv };

        public static QueryTypeBase ByName(string name)
        {
            if (String.IsNullOrEmpty(name))
                throw new NbExceptionInfo($"Query type is not specified");

            var qt = All.FirstOrDefault(i => i.Name.EqIC(name));
            if (qt == null)
                throw new NbExceptionInfo($"Unsupported QueryTypeBase: '{name}'");
            return qt;
        }

        [Obsolete("Use ByQType instead")]
        public static QueryTypeBase ByUri(Uri uri)
        {
            if (uri == null)
                throw new Exception("Empty Uri provided");

            if (!Enum.TryParse(uri.Scheme, out NbqQueryType enumType))
                throw new Exception($"Unsupported query type in uri: {uri.ToString()}. Supported types are: {String.Join(", ", Enum.GetValues(typeof(NbqQueryType)).Cast<NbqQueryType>().Select(t => t.ToString())) }");

            var qt = All.FirstOrDefault(i => i.NbqType == enumType);
            if (qt == null)
                throw new NbExceptionInfo($"Unsupported QueryTypeBase: '{enumType}'");
            return qt;
        }

        public static QueryTypeBase ByQType(NbqQueryType enumType)
        {
            var qt = All.FirstOrDefault(i => i.NbqType == enumType);
            if (qt == null)
                throw new NbExceptionInfo($"Unsupported QueryTypeBase: '{enumType}'");
            return qt;
        }
    }

    internal class QueryTypeSqlData : QueryTypeBase
    {
        public override string Name => "Sql Data";
        public override NbqQueryType NbqType => NbqQueryType.nbquery;

        public override QueryResult GetQueryResult(NbqQueryType qType, string query, configEnvironment env, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;
            DfTable layoutTable = layoutTables.GetOrCreate(recSet.name, recSet);

            var connName = recSet.GetConnectionName();

            DfDynamicCollection collN = recSet.DfDynamicCollectionByUriN(qType, query, mod, layoutTable, env.name);
            string sqlByUriN = null;
            if (collN == null)
            {
                sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, env.name);

                collN = new DfDynamicCollection(recSet.name);
                collN.LoadFromDb(env.GetNbConnection(connName), sqlByUriN, layoutTable, env.max_row_count);
            }

            if (collN != null)
                return new QueryResultRecordset(query, this, collN, recSet, layoutTable);
            else
                return new QueryResultFile(query, this, sqlByUriN);
        }
    }

    internal class QueryTypeSqlText : QueryTypeBase
    {
        public override string Name => "Sql Text";
        public override NbqQueryType NbqType => NbqQueryType.nbsql;


        public override QueryResult GetQueryResult(NbqQueryType qType, string query, configEnvironment env, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;
            string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, env.name);

            return new QueryResultFile(query, this, sqlByUriN);
        }
    }

    internal class QueryTypeSqlBlob : QueryTypeBase
    {
        public override string Name => "Sql Blob";
        public override NbqQueryType NbqType => NbqQueryType.nbblob;

        public override QueryResult GetQueryResult(NbqQueryType qType, string query, configEnvironment env, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;
            var connName = recSet.GetConnectionName();
            string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, env.name);

            return new QueryResultFile(query, this, BlobHtmlFormatter.Load(env.GetNbConnection(connName), sqlByUriN));
        }
    }

    internal class QueryTypeSqlDgml : QueryTypeBase
    {
        public override string Name => "Dgml";
        public override NbqQueryType NbqType => NbqQueryType.nbdgml;

        public override QueryResult GetQueryResult(NbqQueryType qType, string query, configEnvironment env, model mod, layout_info layoutTables)
        {
            NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
            recordset recSet = parsed.Recordset;
            layoutTables.TryGetValue(recSet.name, out DfTable layoutTableN);
            var connName = recSet.GetConnectionName();
            string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, env.name);

            var dlg = new SaveFileDialog
            {
                Filter = "Dgml file (*.dgml)|*.dgml",
                FileName = query.Substring(0, 1).ToUpperInvariant() + query.Substring(1) + ".dgml"
            };
            //dlg.InitialDirectory = "C://Temp//";

            var targetFileName = (dlg.ShowDialog() ?? false) ? dlg.FileName : null;
            if (targetFileName != null)
            {
                DfDynamicCollection coll2 = new DfDynamicCollection("Bla");
                coll2.LoadFromDb(env.GetNbConnection(connName), sqlByUriN, layoutTableN, env.max_row_count);
                var dgmlWriter = new DgmlExporter(coll2);
                dgmlWriter.Write(targetFileName, title: query);
            }

            return null;
        }
    }

    internal class QueryTypeCsv : QueryTypeBase
    {
        public override string Name => "Csv";
        public override NbqQueryType NbqType => NbqQueryType.nbcsv;

        public override QueryResult GetQueryResult(NbqQueryType qType, string query, configEnvironment env, model mod, layout_info layoutTables)
        {
            //TODO: think about saving to csv withouth repeating the request
            var dlg = new SaveFileDialog
            {
                Filter = "Csv file (*.csv)|*.csv",
                FileName = query.Substring(0, 1).ToUpperInvariant() + query.Substring(1) + ".csv"
            };

            var targetFileName = (dlg.ShowDialog() ?? false) ? dlg.FileName : null;
            if (targetFileName != null)
            {
                NbqRecordset parsed = NbqParser.Parse(query, mod);  //TODO: avoid double parsing
                recordset recSet = parsed.Recordset;
                layoutTables.TryGetValue(recSet.name, out DfTable layoutTableN);
                var connName = recSet.GetConnectionName();

                DfDynamicCollection collN = recSet.DfDynamicCollectionByUriN(qType, query, mod, layoutTableN, env.name);
                if (collN == null)
                {
                    string sqlByUriN = recSet.SqlSelectStatementByUri(qType, query, mod, env.name);
                    collN = new DfDynamicCollection(recSet.name);
                    collN.LoadFromDb(env.GetNbConnection(connName), sqlByUriN, layoutTableN, env.max_row_count);
                }

                if (collN != null)
                    collN.Save("Pass dir here, name should be in colletion name", new CsvParameters { FieldDelimiterN = ',' });
            }

            return null; //Don't save csv export into history
        }
    }
}