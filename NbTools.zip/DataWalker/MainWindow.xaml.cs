﻿using NbOrm.Xml;
using NbTools;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Threading;
using Microsoft.Win32;
using DataWalker.Xml;
using System.Collections.Generic;

using NbTools.Collections;
using NbTools.Graphics;
using NbOrm.Nbq;
using NbCollV1;
using System.Diagnostics;
using NbHtmlGen;

namespace DataWalker
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IUiCallback
    {
        private config Conf;
        private model Model;
        private layout_info HtmlLayout;
        public string[] CmdArgs;

        internal QueryResult fCurrentQueryResult;

        private ImageDictionary Icons;
        private QueryManager QueryMgr;
        //private readonly QueryBuilder QueryBuilder;

        public MainWindow()
        {
            InitializeComponent();
            //QueryBuilder = new QueryBuilder();
            //QueryBuilder.QuerySnapshotChanged += QueryBuilder_QuerySnapshotChanged;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                App.Log.Info("Start window loaded");
                if (CmdArgs.Length == 0)
                {
                    MessageBox.Show("DataWalker need one command line parameter: the wildcarded path to the database model xmls files");
                    return;
                }
                string modelFiles = CmdArgs[0];

                Conf = config.Load(Path.Combine(Path.GetDirectoryName(modelFiles), "DataWalker.Config.xml"));
                HtmlLayout = layout_info.LoadXml(Path.Combine(Path.GetDirectoryName(modelFiles), "Layout.xml"));
                Conf.toolbar1.PropertyChanged += Toolbar1_PropertyChanged;
                Icons = new ImageDictionary(Conf.folders?.graphics);

                ToolbarMain.DataContext = Conf.toolbar1;
                ToolbarQueries.DataContext = Conf.toolbar1;

                foreach (var env in Conf.environments)
                {
                    RadioButton rb;
                    if (String.IsNullOrWhiteSpace(env.icon_file))
                        rb = new RadioButton { Name = env.name, Content = env.name, ToolTip = env.name, IsChecked = env.selected };
                    else
                        rb = new RadioButton { Name = env.name, Content = new Image { Source = Icons.GetN(env.icon_file), Stretch = Stretch.None }, ToolTip = env.name, IsChecked = env.selected };
                    rb.Checked += Conn_Checked;
                    rb.Unchecked += Conn_Unchecked;
                    ToolbarMain.Items.Add(rb);
                    if (env.selected)
                        Task.Run(() => env.OpenConnections(this)); //As UI callback
                }

                try
                {
                    //Schema would have to load from xml, because some databases will not allow to use the API to get the schema
                    Model = model.MergeXmls(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, modelFiles));
                    QueryMgr = new QueryManager(Model, HtmlLayout);

                    //fCbc = new ComboBoxController(cbTables, QueryMgr.OrderedNames);
                    foreach (var tblGroup in QueryMgr.TableGroups)
                        cbTableGroups.Items.Add(tblGroup);

                    cbTableGroups.SelectedIndex = 0;

                    foreach (var resForm in QueryTypeBase.All)
                        cbResultFormat.Items.Add(resForm.Name);
                }
                catch (Exception ex)
                { throw new Exception($"Error loading the database model '{modelFiles}'", ex); }

                //Load toolbar with queries from config
                ToolbarMain.Items.Add(new Separator());
                foreach (var qDesc in Conf.toolbar2.Safe())
                {
                    var q = QueryMgr[qDesc.name]; //Throws exception if not found
                    Button bt = new Button { Name = qDesc.name, Content = new Image { Source = Icons.GetN(qDesc.icon_file), Stretch = Stretch.None }, ToolTip = qDesc.description ?? q.description };
                    bt.Click += Toolbar2_Click;
                    ToolbarMain.Items.Add(bt);
                }
                //QueryBuilder.Show();
            }
            catch (Exception ex)
            {
                Task.Run(() => MessageBox.Show(NbException.Exception2String(ex)));
            }
        }

        private void Toolbar1_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (Model == null)
                return;

            switch (e.PropertyName)
            {
                case nameof(Xml.configToolbar1.LastTable):
                    var recSetName = Conf.toolbar1.LastTable;
                    if (String.IsNullOrEmpty(recSetName))
                    {
                        //QueryBuilder.QuerySnapshot = null;
                        return;
                    }

                    var recSet = Model.GetRecordset(recSetName);
                    var qSnap = QuerySnapshot.FromRecordset(recSet);
                    //QueryBuilder.QuerySnapshot = qSnap;
                    break;
            }

        }

        private void Toolbar2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //var qs = QueryBuilder.QuerySnapshot;
                //var nbqPar = qs?.GetNbqParameters();
                Uri uri;
                /*if ((nbqPar?.Count ?? 0) > 0)
                    uri = NbqUriBuilder.Build(qs.name, nbqPar, NbqQueryType.nbquery);
                else*/
                {
                    string reqName = sender.CastVerbose<Button>().Name;
                    var recSet = Model.GetRecordset(reqName);
                    cbTableGroups.SelectedItem = recSet.TableSet.MergeName;
                    cbTables.SelectedItem = recSet.MergeName;
                    uri = NbqUriBuilder.Build(recSet.name, tbParameter.Text, NbqQueryType.nbquery);
                }
                LoadDataForUri(uri);
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void QueryBuilder_QuerySnapshotChanged(QuerySnapshot qs)
        {
            try
            {
                List<NbqInParameter> nbqPar = qs.GetNbqParameters();
                var uri = NbqUriBuilder.Build(qs.name, nbqPar, NbqQueryType.nbquery);
                LoadDataForUri(uri);
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void TbParameter_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                if (e.Key == Key.Enter)
                {
                    var tbl = cbTables.SelectedItem as string;
                    var uri = NbqUriBuilder.Build(tbl, tbParameter.Text, NbqQueryType.nbquery);
                    LoadDataForUri(uri);
                }
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                //None = 0, Alt = 1, Control = 2 ,Shift = 4, Windows = 8
                if (e.KeyboardDevice.Modifiers != 0)
                {
                    var str = $"{e.KeyboardDevice.Modifiers}, {e.Key}";
                    var qName = Conf.QueryNameByShortcut(str);
                    if (qName == null)
                    {
                        ShowStatus($"Shortcut {str} is not mapped to anything");
                        return;
                    }

                    var uri = NbqUriBuilder.Build(qName, tbParameter.Text, NbqQueryType.nbquery);
                    LoadDataForUri(uri);
                }
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void Conn_Checked(object sender, RoutedEventArgs e)
        {
            var env = Conf.Env(sender.CastVerbose<RadioButton>().Name);
            env.selected = true;
            Task.Run(() => env.OpenConnections(this)); //As Ui callback
        }

        private void Conn_Unchecked(object sender, RoutedEventArgs e)
        {
            var env = Conf.Env(sender.CastVerbose<RadioButton>().Name);
            env.selected = false;
            Task.Run(() => env.CloseConnections());
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            HtmlLayout?.SaveXml();
            Conf?.Save();
            Conf?.CloseConnections();
            statusTimer?.Stop();
            //QueryBuilder?.Close();
        }

        private void BtQueryUrl_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                QueryTypeBase qBase = QueryTypeBase.ByName(cbResultFormat.SelectedItem as string);
                /*var qs = QueryBuilder.QuerySnapshot;
                var nbqPar = qs?.GetNbqParameters();
                Uri uri;
                if ((nbqPar?.Count ?? 0) > 0)
                    uri = NbqUriBuilder.Build(qs.name, nbqPar, qBase.NbqType);
                else*/
                var tbl = cbTables.SelectedItem as string;
                //var bt = sender.CastVerbose<Button>().Name;
                Uri uri = NbqUriBuilder.Build(tbl, tbParameter.Text, qBase.NbqType);
                LoadDataForUri(uri);
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void WebControl_Navigating(object sender, NavigatingCancelEventArgs e) //TODO: pass nbquery and nbsql as parameters when building URI
        {
            if (e.Uri != null)
            {
                if (e.Uri.Scheme.StartsWith("nbhttp"))
                {
                    Process.Start(@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", '"' + e.Uri.ToString().Substring(2) + '"');
                    e.Cancel = true;
                }
                else if (NbqParser.IsSupportedQueryType(e.Uri))
                {
                    e.Cancel = true;
                    LoadDataForUri(e.Uri);
                }
            }
        }


        /// <summary>
        /// Executes the sql request by given Uri asynchronosly and displays in on the web control, updating the status message in the process
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="runPar"></param>
        /// <param name="saveToNavHistory"></param>
        async private void LoadDataForUri(Uri uri)
        {
            ShowStatus($"Loading {uri.LocalPath.TrimStart('/')}");

            try
            {
                var qType = NbqParser.GetQueryType(uri);
                var query = uri.LocalPath.TrimStart('/');
                var qRes = await Task.Run(() => QueryMgr.LoadDataForUri(qType, query, Conf, Conf.EnvSelected.name)); //Always save to history
                if (qRes == null)
                    return;

                fCurrentQueryResult = qRes;
                QueryMgr.PushToHistory(fCurrentQueryResult);
                NavToQueryResult();
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }

            ShowStatus($"{uri.LocalPath.TrimStart('/')}");
        }

        private void CbFields_SelectionChanged(object sender, SelectionChangedEventArgs e) { }
        private void CbTableGroups_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbTableGroups.SelectedIndex == -1)
                return;

            var list = QueryMgr.GetTableGroup(cbTableGroups.SelectedValue.ToString());
            cbTables.Items.Clear();
            foreach (var rc in list)
                cbTables.Items.Add(rc.name);
            cbTables.SelectedIndex = 0;
        }

        private void Navigate(QueryManager.NavDirection navDir, bool reloadFromDb = false)
        {
            if (QueryMgr == null) //If on Window_loaded fails
                return;

            fCurrentQueryResult = QueryMgr.GetFromHistoryN(navDir, Conf, Conf.EnvSelected.name, reloadFromDb);
            if (fCurrentQueryResult == null)
                return;
            NavToQueryResult();
        }

        private void NavToQueryResult()
        {
            var htmlCssIsUri = fCurrentQueryResult.Format(CurrentQueryFormat, Icons.Dir);
            if (htmlCssIsUri.Item3) //Treat as Uri
                webControl.Navigate(new Uri(htmlCssIsUri.Item1));
            else
                webControl.NavigateToString(htmlCssIsUri.Item1);
        }

        private void NavigateBack_Exec(object sender, ExecutedRoutedEventArgs e) => Navigate(QueryManager.NavDirection.Back);
        private void NavigateBack_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Back) ?? false;

        private void NavigateForward_Exec(object sender, ExecutedRoutedEventArgs e) => Navigate(QueryManager.NavDirection.Forward);
        private void NavigateForward_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Forward) ?? false;

        //private void NavigateRefresh_Exec(object sender, ExecutedRoutedEventArgs e) => Navigate(QueryManager.NavDirection.Refresh, reloadFromDb: true); //Only reload from db by command
        private void NavigateRefresh_Exec(object sender, ExecutedRoutedEventArgs e) => BtQueryUrl_Click(null, null); //Only reload from db by command

        private void NavigateRefresh_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Refresh) ?? false;

        private void NavigateRefresh(object sender, RoutedEventArgs e) { Navigate(QueryManager.NavDirection.Refresh); } //Quick refresh, without reloading from DB

        private DfExportFormat CurrentQueryFormat => new DfExportFormat //Think about simplifying
        {
            Format = DfExportFormat.Formats.Html,
            isMergeCells = btMergeCells.IsChecked ?? false,
            isVertical = btVertical.IsChecked ?? false,
            isRemoveNullColumns = btNullLines.IsChecked ?? false
        };


        private void CommandSave_Exec(object sender, ExecutedRoutedEventArgs e)
        {
            if (fCurrentQueryResult == null)
                return;

            var dlg = new SaveFileDialog
            {
                Filter = "Html file (*.html)|*.html|Text file (*.txt)|*.txt",
                FileName = NbExt.LegalizeForFilename(fCurrentQueryResult.Query, 248) + ".html"
            };
            //TODO: save current dir
            if (dlg.ShowDialog() == true)
            {   //TODO: support the saving of BLOBs
                File.WriteAllText(dlg.FileName, fCurrentQueryResult.Format(CurrentQueryFormat, Icons.Dir).Item1); //Reformat for saving
            }
        }

        private void CommandSave_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Refresh) ?? false;



        // Status message


        private DispatcherTimer statusTimer = null;

        delegate void StatusInvoker(string mess);
        public void ShowStatus(string message)
        {
            if (!Dispatcher.CheckAccess()) // CheckAccess returns true if you're on the dispatcher thread
            {
                Dispatcher.Invoke(new StatusInvoker(ShowStatus), message);
                return;
            }

            if (statusTimer == null)
            {
                statusTimer = new DispatcherTimer();
                statusTimer.Tick += StatusTimer_Tick;
                statusTimer.Interval = new TimeSpan(0, 0, 5);
            }

            statusTimer.Stop(); //If previous timer is still going
            tbStatus.Text = message;
            statusTimer.Start();
        }

        private void StatusTimer_Tick(object sender, EventArgs e)
        {
            tbStatus.Text = String.Empty;
            statusTimer.Stop();
        }


        private DispatcherTimer clipboardTimer = null;
        private string clipboardText;

        private void BtMonitorClipboard_Checked(object sender, RoutedEventArgs e)
        {
            bool turnOn = sender.CastVerbose<CheckBox>().IsChecked ?? false;
            if (turnOn)
            {
                if (clipboardTimer == null)
                {
                    clipboardTimer = new DispatcherTimer();
                    clipboardTimer.Tick += ClipboardTimer_Tick;
                    clipboardTimer.Interval = new TimeSpan(0, 0, 1);
                }

                clipboardText = ClipText(); //Don't jump on the value already in the clipboard
                clipboardTimer.Start();
            }
            else
            {
                clipboardTimer.Stop();
            }
        }

        private void ClipboardTimer_Tick(object sender, EventArgs e)
        {
            var newText = ClipText();
            if (newText.Equals(clipboardText))
                return;

            clipboardText = newText;
            if (String.IsNullOrWhiteSpace(newText)) //Don't use empty text as a new value
                return;

            tbParameter.Text = clipboardText;
            var tbl = cbTables.SelectedItem as string;
            var uri = NbqUriBuilder.Build(tbl, tbParameter.Text, NbqQueryType.nbquery);
            LoadDataForUri(uri);

        }

        private static string ClipText()
        {
            var str = Clipboard.GetText();
            int ind = str.IndexOf('\r');
            if (ind > 0)
                str = str.Substring(0, ind);
            return str.Trim();
        }
    }
}