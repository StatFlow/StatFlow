﻿using NbOrm.Xml;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataWalker.Data
{
    public class LocalQueries : ICustomSqlProviderList
    {
        public IEnumerable<Tuple<string, CustomSqlProvider>> Items() => Enumerable.Empty<Tuple<string, CustomSqlProvider>>();

        public IEnumerable<Tuple<string, CustomCollectionProvider>> CollectionProviders() => Enumerable.Empty<Tuple<string, CustomCollectionProvider>>();
        /*{
            yield return Tuple.Create<string, CustomCollectionProvider>(nameof(HtmlExperiment), HtmlExperiment);
        }

        private DfDynamicCollection HtmlExperiment(Uri uri, model model, object environment)
        {
            DfDynamicCollection coll = new DfDynamicCollection(nameof(HtmlExperiment));
            var xdoc = SgmlReader.NbLoadFile(@"C:\Temp\Korsun.htm");

            coll.LoadFromXml(WebLib.NbFindRecursive(xdoc.Element("html"), "a", "class", "toc-item"));
            return coll;
        }*/

    }
}