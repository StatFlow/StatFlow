﻿using LinkManager.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Drawing;

namespace LinkManagerTest
{
    [TestClass]
    public class DfRepositoryTest
    {
        [TestMethod]
        public void LinkManager_CreateRepository()
        {
#pragma warning disable IDE0059 // Unnecessary assignment of a value
            DfRepository rep = new DfRepository();
#pragma warning restore IDE0059 // Unnecessary assignment of a value
            //rep.Load(@"C:\Temp\2", _ => { });

        }

        [TestMethod]
        public void LinkManager_ExtractIcon()
        {
            var filePath = @"C:\Program Files (x86)\Git\LICENSE.txt";
            var theIcon = IconFromFilePath(filePath);

            if (theIcon != null)
            {
                // Save it to disk, or do whatever you want with it.
                using (var stream = new System.IO.FileStream(@"c:\temp\myfile.ico", System.IO.FileMode.Create))
                {
                    theIcon.Save(stream);
                }
            }
        }

        public static Icon IconFromFilePath(string filePath)
        {
            var result = (Icon)null;

            try
            {
                result = Icon.ExtractAssociatedIcon(filePath);
            }
            catch (System.Exception)
            {
                // swallow and return nothing. You could supply a default Icon here as well
            }

            return result;
        }

    }
}
