﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;

namespace NbTools
{
    public static partial class NbExt
    {
        public const string yyyyMMdd = "yyyyMMdd";
        public const string yyyy_MM_dd = "yyyy-MM-dd";
        public const string ddMMMyyyy = "dd-MMM-yyyy";
        public const string ddMMMyy = "dd-MMM-yy";
        public const string ddMMMyyyyHHmmss = "dd-MMM-yyyy HH:mm:ss";
        public const string ddMMMyyHHmmss = "dd-MMM-yy HH:mm:ss";
        public const string dd_MM_yyyyHHmmss = "dd/MM/yyyy HH:mm";
        public const string yyyyMMddHHmmss = "yyyy-MM-dd HH:mm:ss";
        public const string yyyyMMdd_HHmmss = "yyyyMMdd-HHmmss";
        public const string ebayDate = "dd MMM, yyyy HH:mm:ss";


        public static string[] DateFormats = new string[] { yyyyMMdd, yyyy_MM_dd, ddMMMyyyy, ddMMMyy, ddMMMyyyyHHmmss, ddMMMyyHHmmss, yyyyMMddHHmmss, dd_MM_yyyyHHmmss, ebayDate };

        public static DateTime ParseDate(this string dtStt)
        {
            if (!TryParseDate(dtStt, out DateTime ret))
                throw new Exception($"Can't parse a date out of '{dtStt}'");
            else
                return ret;
        }
        public static bool TryParseDate(this string dtStt, out DateTime date)
        {
            foreach (var dFormat in DateFormats)
            {
                if (DateTime.TryParseExact(dtStt, dFormat, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out date))
                    return true;
            }
            date = default;
            return false;
        }

        public static byte[] Gzip(this string str)
        {
            var bytes = Encoding.UTF8.GetBytes(str);

            using var msi = new MemoryStream(bytes);
            using var mso = new MemoryStream();
            using (var gs = new GZipStream(mso, CompressionMode.Compress))
                msi.CopyTo(gs);

            return mso.ToArray();
        }

        public static string Unzip(this byte[] bytes)
        {
            using var msi = new MemoryStream(bytes);
            using var mso = new MemoryStream();
            using (var gs = new GZipStream(msi, CompressionMode.Decompress))
                gs.CopyTo(mso);

            return Encoding.UTF8.GetString(mso.ToArray());
        }


        public static string ToNykLdn(this DateTime? dt)
        {
            if (!dt.HasValue || dt.Value == DateTime.MinValue)
                return String.Empty;
            var utc = dt.Value.ToUniversalTime();
            string easternZoneId = "Eastern Standard Time";
            try
            {
                TimeZoneInfo easternZone = TimeZoneInfo.FindSystemTimeZoneById(easternZoneId);
                var est = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(utc, "Eastern Standard Time");
                return "";
            }
            catch (TimeZoneNotFoundException)
            {
                return dt.Value.ToLongDateString();
            }
        }
        public static string ToString(this DateTime? dt, string format) => (!dt.HasValue || dt.Value == DateTime.MinValue) ? String.Empty : dt.Value.ToString(format);

        public static DateTime FromFileTime(int aHigh, int aLow) => DateTime.FromFileTime((long)aHigh << 32 | (long)aLow);

        public static string FileInOneLine(string fileName)
        {
            StringBuilder bld = new StringBuilder();
            foreach (var line in File.ReadLines(fileName))
            {
                bld.Append(line);
            }
            return bld.ToString();
        }

        //Helpers for ? operator
        public static void Do<T>(this T obj, Action<T> act) { if (obj != null && act != null) act(obj); }
        public static void AddTo<T>(this T obj, ICollection<T> coll) => coll.Add(obj);
        public static void AddTo<K, T>(this T obj, IDictionary<K, T> dict, K key) => dict.Add(key, obj);
        public static void AddTo<K, T>(this T obj, NbDictionary<K, T> dict, K key) => dict.Add(key, obj); //NbDictionari uses new and the call on the interface uses the base component's method

        public static void Call<T>(this T obj, Action<T> action) => action(obj);

        public static bool ContainsIC(this string source, string toCheck) => source.IndexOf(toCheck, StringComparison.OrdinalIgnoreCase) >= 0;
        public static bool EqIC(this string source, string other) => String.Equals(source, other, StringComparison.OrdinalIgnoreCase);

        public static string Truncate(this string value, int maxLength)
        {
            if (!string.IsNullOrEmpty(value) && value.Length > maxLength)
                return value.Substring(0, maxLength);
            else
                return value;
        }

        public static void AssertNotNull(object obj, string objname, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string membName = "")
        {
            if (obj == null)
                throw new NullReferenceException($"{filePath}({lineNum}): parameter '{objname}' is null in '{membName}'");
        }

        public static string ToCsvString(string str) //TODO: Speedup?
        {
            if (!String.IsNullOrEmpty(str))
            {
                str = str.Replace("\"", "\"\""); //Double quotes
                if (str.Contains(",") || str.Contains("\""))
                    return "\"" + str + "\"";
            }
            return str;
        }

        public static void CopyFileSafe(string srcFile, string dstFileName, bool deleteSource = false)
        {
            if (!File.Exists(srcFile)) throw new Exception($"Source file '{srcFile}' doesn't exist");
            var fl = new FileInfo(dstFileName);
            DirCreateRecursive(fl.Directory);
            var dstDir = fl.Directory.FullName;

            int cnt = 1;
            var dstFile = Path.Combine(dstDir, fl.Name);
            while (File.Exists(dstFile)) //Ensure we are not overwriting the file
            {
                dstFile = Path.Combine(dstDir, Path.GetFileNameWithoutExtension(fl.Name) + $" ({cnt})" + fl.Extension);
                cnt++;
                if (cnt++ > 6000)
                    throw new Exception($"There are over 6000 files named '{fl.Name}' in the directory '{dstDir}'");
            }
            File.Copy(srcFile, dstFile);

            if (deleteSource)
                File.Delete(srcFile);
        }

        /// <summary>
        /// Deletes existing old file and moves the current dstFile if it exist to .old file.
        /// </summary>
        /// <param name="dstFile">Full file name to be moved to old file</param>
        /// <returns>The old file name (useful for comparison with current verion in beyond compare)</returns>
        public static string MoveToOldFile(string dstFile)
        {
            var oldName = dstFile + ".old";
            File.Delete(oldName);
            if (File.Exists(dstFile))
                File.Move(dstFile, oldName);
            return oldName;
        }

        public static bool DirCreateRecursive(string dirName) => DirCreateRecursive(new DirectoryInfo(dirName));
        public static bool DirCreateRecursive(this DirectoryInfo di) //Recursive
        {
            if (!di.Exists)
            {
                if (di.Root.FullName == di.FullName) //We are in the root and it doens't exist
                    throw new NbException($"The root dir '{di.Root.FullName}' doens't exist");

                DirCreateRecursive(di.Parent);
                Directory.CreateDirectory(di.FullName);
                return true;
            }
            else
                return false;
        }

        public static readonly string[] DirsToIgnore = { "$RECYCLE.BIN", "RECYCLER", "Recycled", "System Volume Information" };
        public static readonly string[] FilesToIgnoreSystem = { "Thumbs.db" };

        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T">The type representing the Dir in the client code, it is passed from Dir creation to the FileCreation and the Subdir creation actions</typeparam>
        /// <param name="di">DirectoryInfo of the directory to visit first</param>
        /// <param name="parentDir">User object representing root dir, could be set to null in the root call</param>
        /// <param name="dirAction">Action called on directory visit. Takes the directoryInfo, the parent user directory object and retruns new directory user object</param>
        /// <param name="fileAction">Action called on file fisit. Takes the FileInfo and the current User directory object</param>
        public static void TraverseDirs<T>(DirectoryInfo di, T parentDir, Func<DirectoryInfo, T, T> dirAction, Action<FileInfo, T> fileAction)
        {
            var currDir = dirAction(di, parentDir);

            try
            {
                foreach (var fl in di.GetFiles())
                {
                    if (FilesToIgnoreSystem.Contains(fl.Name))
                        continue;

                    fileAction(fl, currDir);
                }

                foreach (var subDi in di.GetDirectories())
                {
                    if (DirsToIgnore.Contains(subDi.Name))
                        continue;

                    TraverseDirs(subDi, currDir, dirAction, fileAction);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(NbException.Exception2String(ex));
            }
        }

        private static void MoveDirSelectively(string dirFrom, string dirTo, HashSet<string> extensions)
        {
            NbExt.TraverseDirs(new DirectoryInfo(dirFrom),
                parentDir: new DirectoryInfo(dirTo),
                dirAction: (di, dstDir) =>
                {
                    if (di.Parent == null) //If the dst dir is the root (D:) do not add this nae
                        return dstDir;
                    else
                        return new DirectoryInfo(Path.Combine(dstDir.FullName, di.Name));
                },
                fileAction: (fl, dstDir) =>
                {
                    if (!extensions.Contains(fl.Extension))
                        return;

                    var dstFl = Path.Combine(dstDir.FullName, fl.Name);
                    NbExt.DirCreateRecursive(dstDir);
                    File.Move(fl.FullName, dstFl);
                    Console.WriteLine(fl.FullName);
                });
        }

        public static void DeleteByRegex(this DirectoryInfo di, string regex, string exceptForN = null)
        {
            var reg = new Regex(regex);
            foreach (var dir in di.GetDirectories().Where(d => reg.IsMatch(d.Name)))
            {
                if (!String.IsNullOrEmpty(exceptForN) && dir.Name.EqIC(exceptForN))
                    continue;
                try { dir.Delete(recursive: true); }
                catch (Exception ex) { Console.WriteLine($"Can't delete old snapshot folder: '{dir.FullName}'. {NbException.Exception2String(ex)}"); }
            }
        }
        public static string EnvVariable(string aVarName)
        {
            var env = Environment.GetEnvironmentVariables();
            if (!env.Contains(aVarName))
                throw new NbException($"Can't find {aVarName} environment variable");
            else
                return (string)env[aVarName];
        }

        public static string EnvFileInPath(string aFileName)
        {
            foreach (var path in NbExt.EnvVariable("Path").Split(Path.PathSeparator).Select(s => Environment.ExpandEnvironmentVariables(s)))
            {
                var fi = new FileInfo(Path.Combine(path, aFileName));
                //NbMessageBox.Show(fi.FullName);
                if (fi.Exists && fi.Length > 0) //Get rid of symlinks
                {
                    //NbMessageBox.Show("Found: " + fi.FullName);
                    return fi.FullName;
                }
                //NbMessageBox.Show("Not Found: " + fi.FullName);
            }
            throw new NbException($"Can't find file '{aFileName}' in PATH");
        }

        [Obsolete]
        public static IEnumerable<TResult> SelectNotNull<TSource, TResult>(this IEnumerable<TSource> source, Func<TSource, TResult> selector)
        {
            if (source != null)
                return source.Select(selector).Where(r => r != null);
            else
                return Enumerable.Empty<TResult>();
        }

        //private static readonly Regex fParameterRegex = new Regex(@"(@\w[\w\d_]*)");

        [Obsolete]
        public static string IfNull(this string aStr1, string aStr2)
        {
            if (!String.IsNullOrEmpty(aStr1))
                return aStr1;
            else if (!String.IsNullOrEmpty(aStr2))
                return aStr2;
            else
                throw new NbException("Both strings are null or empty in IfNull");
        }

        public static string Limit(this string aStr, int aLength)
        {
            if (String.IsNullOrEmpty(aStr) || aStr.Length <= aLength)
                return aStr;
            else if (aLength > 3)
                return aStr.Substring(0, aLength - 3) + "...";
            else
                return aStr.Substring(0, aLength);
        }

        public static bool StartsWith(this string aStr, char chr) => !String.IsNullOrEmpty(aStr) && aStr.Length > 0 && aStr[0] == chr;

        public static T GetItemOrCreateNew<T>(ref T[] arr, Predicate<T> aSearchPredicate)
            where T : new()
        {
            if (arr == null)
                arr = new T[0];

            foreach (T el in arr)
            {
                if (aSearchPredicate(el))
                    return el;
            }

            T col = new T();
            T[] newArr = new T[arr.Length + 1];
            arr.CopyTo(newArr, 0);
            newArr[newArr.GetUpperBound(0)] = col;
            arr = newArr;
            return col;
        }

        public static T GetItemOrCreateNew<A, T>(ref A[] arr, Predicate<T> aSearchPredicate)
            where A : class
            where T : class, A, new()
        {
            if (arr == null)
                arr = new A[0];

            foreach (A el in arr)
            {
                if (el is T && aSearchPredicate(el as T))
                    return el as T;
            }

            T col = new T();
            A[] newArr = new A[arr.Length + 1];
            arr.CopyTo(newArr, 0);
            newArr[newArr.GetUpperBound(0)] = col as A;
            arr = newArr;
            return col;
        }

        public static string LegalizeForFilename(this string aStr, int limit) => aStr.Replace("?", String.Empty).Replace(':', '-').Replace('/', '-').Replace('\\', '-').Replace("\"", "''")
            .Replace('*', '-').Replace('?', '-').Replace('|', '-').Limit(limit);

        public static string NameWithoutExtension(this FileInfo fi) => fi.Name.Substring(0, fi.Name.Length - fi.Extension.Length);

        public static string ExtensionWithoutDot(this FileInfo fi) => fi.Extension.Length > 0 ? fi.Extension.Substring(1) : String.Empty;

        public static bool IsContinuous(this IEnumerable<int> aSequence)
        {
            int prevKey = -1;
            bool first = true;
            foreach (int key in aSequence.OrderBy(i => i))
            {
                if (first)
                {
                    prevKey = key;
                    first = false;
                    continue;
                }

                if (key != prevKey + 1)
                    return false;

                prevKey = key;
            }
            return true;
        }

        public static IEnumerable<int> Duplicates(this IEnumerable<int> aSequence) => aSequence.GroupBy(el => el).Where(g => g.Count() > 1).Select(g => g.Key);

        public static T OneOf<T>(this Random aRnd, List<T> aList)
        {
            if (aList.Count == 0)
                throw new NbException("Empty list in OneOf");

            return aList[aRnd.Next(aList.Count)];
        }

        public static bool TryGetValue<T>(this IEnumerable<T> aCollection, Func<T, bool> aPredicate, out T aValue)
        {
            foreach (T item in aCollection)
            {
                if (aPredicate(item))
                {
                    aValue = item;
                    return true;
                }
            }
            aValue = default;
            return false;
        }

        private const int ticksCompar = 10000000;
        public static int CompareToSec(this DateTime dt, DateTime other) => (dt.Ticks / ticksCompar).CompareTo(other.Ticks / ticksCompar);

        public static bool EqualsToSec(this DateTime dt, DateTime other) => (dt.Ticks / ticksCompar).Equals(other.Ticks / ticksCompar);

        public static void ForEachSafe<T>(this IEnumerable<T> aCollection, Action<T> aAction)
        {
            if (aCollection == null)
                return;
            foreach (T item in aCollection)
                aAction(item);
        }


        /// <summary>
        /// Adds an item to the collection only if it is not yet in there. Not smart, useful for small collections only.
        /// </summary>
        /// <returns>True if the item was added, False if this item already existed in the collection</returns>
        public static bool AddUnique<T>(this ICollection<T> coll, T item)
        {
            if (coll.Contains(item))
                return false;

            coll.Add(item);
            return true;
        }

        public static IEnumerable<T> NotIn<T, K>(this IEnumerable<T> thisCollection, ICollection<K> thatCollection, Func<T, K, bool> aNameComparator) =>
             thisCollection.Where(t1 => !thatCollection.Any(t2 => aNameComparator(t1, t2)));

        public static IEnumerable<T> NotIn<T>(this IEnumerable<T> thisCollection, ICollection<T> thatCollection) where T : IEquatable<T> =>
            thisCollection.Where(t1 => !thatCollection.Any(t2 => t1.Equals(t2)));

        public static IEnumerable<KeyValuePair<T, T>> BothIn<T>(this IEnumerable thisCollection, ICollection thatCollection, Func<T, T, bool> aNameComparator)
            where T : class
        {
            foreach (object ob in thisCollection)
            {
                if (!(ob is T obj))
                    continue;

                bool found = false;
                foreach (object oth in thatCollection)
                {
                    if (!(oth is T other))
                        continue;

                    if (aNameComparator(obj, other))
                    {
                        if (found == true)
                            throw new NbException($"Object '{obj}' is equal to two or more objects in the other collection in BothIn()");
                        else
                            yield return new KeyValuePair<T, T>(obj, other);
                    }
                }
            }
        }

        /// <summary>
        /// Calls Add and Remove methods for differenced in two collections. The new Collection (this) will be changed.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="newCollection">Collection with new elements - will be changed</param>
        /// <param name="oldColletion">Enumerable of old elements</param>
        /// <param name="addAction">Action to create new element</param>
        /// <param name="removeAction">Action to remove an element</param>
        /// <returns>The number of changes made (calls to add or remove)</returns>
        public static int SynchronizeCollections<T>(this IEnumerable<T> oldColletion, IEnumerable<T> newCollection, Action<T> addAction, Action<T> removeAction)
        {
            int numOfChanges = 0;
            var oldCopy = oldColletion.ToList();
            foreach (T v in newCollection)
            {
                int ind = oldCopy.IndexOf(v);
                if (ind == -1) //Didn't exist before, but in the new list => Add
                {
                    addAction(v);
                    numOfChanges++;
                }
                else //Exists in both lists - doen't do anything, remove from newCollection, so it is not used for addition
                    oldCopy.RemoveAt(ind);
            }

            foreach (T v in oldCopy) //Remaining entries are not found in the newList and should be deleted
            {
                removeAction(v);
                numOfChanges++;
            }
            return numOfChanges;
        }

        public static IEnumerable<T> RandomizeList<T>(this IList<T> thisCollection)
        {
            Random rand = new Random();
            for (int i = thisCollection.Count - 1; i >= 0; --i)
            {
                int ind = rand.Next(0, i);
                yield return thisCollection[ind];
                thisCollection.RemoveAt(ind);
            }
        }

        public static List<KeyValuePair<K, int>> Histogram<K, V>(this IEnumerable<V> files, Func<V, K> getKey) =>
            files.GroupBy(getKey).ToDictionary(g => g.Key, g => g.Count()).OrderByDescending(p => p.Value).ToList();

        public static Dictionary<K, List<V>> NonUnique<K, V>(this IEnumerable<V> files, Func<V, K> getKey) =>
            files.GroupBy(getKey).Where(g => g.Count() > 1).ToDictionary(g => g.Key, g => g.ToList());


        public static TSource SingleOrDefaultVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicateN = null, string who = "Sequence", string whats = "Element",
            [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")

        {
            if (source == null) throw new ArgumentException("source");
            TSource result = default;
            long count = 0;

            foreach (TSource element in source ?? throw new ArgumentException("source"))
            {
                if (predicateN?.Invoke(element) ?? true) //If predicate is not specified - apply to all
                {
                    result = element;
                    checked { count++; }
                }
            }

            return count switch
            {
                0 => default,
                1 => result,
                _ => throw new NbExceptionInfo($"{who} contained {count} {whats} when only 1 was expected", filePath, lineNum, name),
            };
        }

        public static TSource SingleOrDefaultVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicate, Func<long, string> multipleError)
        {
            if (source == null) throw new ArgumentException("source");
            if (predicate == null) throw new ArgumentException("predicate");
            TSource result = default;
            long count = 0;
            foreach (TSource element in source)
            {
                if (predicate(element))
                {
                    result = element;
                    checked { count++; }
                }
            }

            return count switch
            {
                0 => default,
                1 => result,
                _ => throw new Exception(multipleError?.Invoke(count) ?? "There are more than one element in the sequence"),
            };
        }

        public static TSource SingleEnsure<TSource>(this IEnumerable<TSource> source, string whats = "Elements", string id = "'N/A'", string where = "Sequence",
            [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        {
            TSource result = default;
            long count = 0;
            foreach (TSource element in source ?? throw new ArgumentException(nameof(source)))
            {
                result = element;
                checked { count++; }
            }
            return count switch
            {
                0 => throw new NbExceptionInfo($"{where} didn't contain any {whats} with Id {id} when 1 was expected", filePath, lineNum, name),
                1 => result,
                _ => throw new NbExceptionInfo($"{where} contained {count} {whats} with Id {id} when only 1 was expected", filePath, lineNum, name),
            };
        }

        public static TSource SingleVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicateN, Func<string> noMatchError, Func<long, string> multipleError)
        {
            TSource result = default;
            long count = 0;
            foreach (TSource element in source ?? throw new ArgumentException("source"))
            {
                if (predicateN?.Invoke(element) ?? true) //If predicate is not specified - apply to all
                {
                    result = element;
                    checked { count++; }
                }
            }
            return count switch
            {
                0 => throw new Exception(noMatchError() ?? "Element in the sequence was not found"),
                1 => result,
                _ => throw new Exception(multipleError(count) ?? "There are more than one element in the sequence"),
            };
        }

        public static TSource SingleVerbose<TSource>(this IEnumerable<TSource> source, Func<TSource, bool> predicateN = null, string who = "Sequence", string whats = "Element",
            [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        {
            TSource result = default;
            long count = 0;
            foreach (TSource element in source ?? throw new ArgumentException("source"))
            {
                if (predicateN?.Invoke(element) ?? true) //If predicate is not specified - apply to all
                {
                    result = element;
                    checked { count++; }
                }
            }
            return count switch
            {
                0 => throw new NbExceptionInfo($"{who} didn't contain any {whats} when 1 was expected", filePath, lineNum, name),
                1 => result,
                _ => throw new NbExceptionInfo($"{who} contained {count} {whats} when only 1 was expected", filePath, lineNum, name),
            };
        }


        [Obsolete("Use Enumerable.Empty<T>() instead")]
        public static IEnumerable<T> Nothing<T>() => Enumerable.Empty<T>();

        public static IEnumerable<T> Yield<T>(params T[] arg) => arg;
        public static IEnumerable<T> Yield<T>(T arg)
        {
            if (arg == null)
                yield break;
            else
                yield return arg;
        }

        public static IEnumerable<T> Defaults<T>()
        {
            while (true) { yield return default; }
        }

        public static IEnumerable<T> Safe<T>(this IEnumerable<T> enumer) => enumer ?? Enumerable.Empty<T>();
        public static IEnumerable<T> Safe<T>(this Lazy<List<T>> enumer) => (enumer != null && enumer.IsValueCreated) ? enumer.Value : Enumerable.Empty<T>();
        public static IEnumerable<T> SafeOfType<T>(this IList enumer) => (enumer == null) ? Enumerable.Empty<T>() : enumer.OfType<T>();

        public static NbDictionary<TKey, TValue> ToNbDictionary<TObj, TKey, TValue>(this IEnumerable<TObj> sequence, Func<TObj, TKey> keyGetter, Func<TObj, TValue> valueGetter,
            IEqualityComparer<TKey> comparer = null, int capacity = 0, [CallerMemberName] string description = "", Func<TKey, TValue> creator = null, [CallerMemberName] string caller = "")
        {
            if (sequence == null) throw new ArgumentNullException(nameof(sequence), caller);
            if (keyGetter == null) throw new ArgumentNullException(nameof(keyGetter), caller);
            if (valueGetter == null) throw new ArgumentNullException(nameof(valueGetter), caller);

            NbDictionary<TKey, TValue> dict = new NbDictionary<TKey, TValue>(capacity, comparer, description, creator);
            foreach (var obj in sequence)
                dict.Add(keyGetter(obj), valueGetter(obj));
            return dict;
        }

        public static SortedList<TKey, TValue> ToSortedList<TObj, TKey, TValue>(this IEnumerable<IGrouping<TKey, TObj>> sequence, Func<IGrouping<TKey, TObj>, TValue> valueGetter)
        {
            SortedList<TKey, TValue> dict = new SortedList<TKey, TValue>();
            foreach (var grp in sequence)
            {
                dict.Add(grp.Key, valueGetter(grp));
            }
            return dict;
        }
        public static T CastVerbose<T>(this object val, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
            where T : class
        {
            if (val == null)
                throw new Exception($"Null value passed to NotNull class in {filePath}({lineNum}) method: '{name}'");
            if (!(val is T t))
                throw new Exception($"Object of type '{val.GetType().Name}' can't be cast to type '{typeof(T).Name}' in {filePath}({lineNum}) method: '{name}'");
            return t;
        }


        public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty));
        public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num, string otherLine) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty)).Concat(Yield(otherLine));
        public static IEnumerable<string> EmptyLines(this IEnumerable<string> lines, int num, IEnumerable<string> otherLines) => lines.Concat(Enumerable.Range(0, num).Select(_ => String.Empty)).Concat(otherLines);

        public static T[] Merge<T>(this T[] arr, T[] otherN) where T : IMergeableByName<T>
        {
            Debug.Assert(arr != null, "Merge this must no be null");

            if (otherN == null)
                return arr;

            var dic = otherN.ToDictionary(t => t.MergeName, StringComparer.OrdinalIgnoreCase);
            var res = new List<T>(arr.Length + otherN.Length);

            foreach (var from in arr)
            {
                if (dic.TryGetValue(from.MergeName, out T to)) //Table already exists
                {
                    res.Add(from.MergeTo(to));
                    dic.Remove(from.MergeName); //Used for merging - remove from dictionary
                }
                else
                    res.Add(from);
            }

            res.AddRange(dic.Values); //Add entries not used for merging (new ones)
            return res.ToArray();
        }

        public static void Deconstruct<T1, T2>(this KeyValuePair<T1, T2> tuple, out T1 key, out T2 value)
        {
            key = tuple.Key;
            value = tuple.Value;
        }

        public static T RunWithMessage<T>(Func<T> action, string mess)
        {
            Console.Write(mess);
            Stopwatch sw = new Stopwatch();
            sw.Start();
            var res = action();
            Console.WriteLine($"done in {sw.ElapsedMilliseconds / 1000:f1} sec.");
            return res;
        }

        public static string GetEmbeddedResourceTextFile(string resourceName)
        {
            Assembly assem = typeof(NbExt).Assembly;
            try
            {
                using var reader = new StreamReader(assem.GetManifestResourceStream(resourceName));
                return reader.ReadToEnd();
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Available resources are {String.Join(", ", assem.GetManifestResourceNames())}");
            }
        }

        public static string UserFriendlyFileSize(long aSize, int aPrecision)
        {
            string[] units = new string[] { "B", "KB", "MB", "GB", "TB" };

            if (aSize == 0)
                return "0 B";

            aSize = Math.Max(aSize, 0);
            int powUnits = Convert.ToInt16(Math.Floor(((aSize != 0) ? Math.Log(aSize) : 0) / Math.Log(1024)));
            powUnits = Math.Min(powUnits, units.GetLength(0) - 1);

            double res = aSize / Math.Pow(1024, powUnits);

            int digitsAbovePoint = (int)Math.Ceiling(Math.Log10(res));
            var divider = Math.Pow(10, digitsAbovePoint); //(res / divider) will be the number between 0.1 and 1.0
            decimal res1 = (decimal)(Math.Round(res / divider, aPrecision) * divider);

            return res1.ToString() + ' ' + units[powUnits];
        }
    }

    public interface IMergeableByName<T>
    {
        T MergeTo(T other);
        string MergeName { get; }
    }

    public class NotNull<T>
    where T : class
    {
        public readonly T Value;

        public NotNull(T val)
        {
            Value = val ?? throw new Exception($"Null value passed to NotNull class");
        }

        public static NotNull<T> Verbose(T val, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        {
            if (val == null)
                throw new Exception($"Null value passed to NotNull class in {filePath}({lineNum}) method: '{name}'");
            return new NotNull<T>(val);
        }

        public static NotNull<T> Cast(object val, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
        {
            if (val == null)
                throw new Exception($"Null value passed to NotNull class in {filePath}({lineNum}) method: '{name}'");

            if (!(val is T t))
                throw new Exception($"Object of type '{val.GetType().Name}' can't be cast to type '{typeof(T).Name}' in {filePath}({lineNum}) method: '{name}'");
            return new NotNull<T>(t);
        }

        public static explicit operator T(NotNull<T> nn) => nn.Value;
    }


    public class NbException : Exception
    {
        public NbException(string aMessage)
            : base(aMessage)
        { }

        [Obsolete("Use string interpolation: $ ")]
        public NbException(string aFormat, params object[] args)
            : base(String.Format(aFormat, args))
        { }

        public NbException(Exception ex, string mess)
            : base(mess, ex)
        { }

        public static string Exception2String(Exception ex, Action<Exception, StringBuilder> extraHandler = null)
        {
            StringBuilder bld = new StringBuilder();
            ProcException(ex, bld, 0, extraHandler);
            return bld.ToString();
        }

        private static void ProcException(Exception ex, StringBuilder bld, int margin, Action<Exception, StringBuilder> extraHandler = null)
        {
            for (int i = margin; i > 0; --i) //Margin without new string allocations
                bld.Append("  ");

            bld.Append(ex.Message);
            bld.Append(" {");
            bld.Append(ex.GetType().Name);
            bld.AppendLine("}");

            extraHandler?.Invoke(ex, bld);

            if (ex is AggregateException)
            {
                foreach (Exception ex1 in (ex as AggregateException).InnerExceptions)
                    ProcException(ex1, bld, margin + 1);
            }
            else
            {
                if (ex.InnerException != null)
                    ProcException(ex.InnerException, bld, margin + 1);
            }
        }

        public override string ToString() => Exception2String(this);
    }


    /// <summary>
    /// Fastest way to send a single item as an enumerable according to this:
    /// https://stackoverflow.com/questions/1577822/passing-a-single-item-as-ienumerablet
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public struct SingleSequence<T> : IEnumerable<T>
    {
        public struct SingleEnumerator : IEnumerator<T>
        {
            private readonly SingleSequence<T> _parent;
            private bool _couldMove;
            public SingleEnumerator(ref SingleSequence<T> parent)
            {
                _parent = parent;
                _couldMove = true;
            }
            public T Current => _parent._value;
            object IEnumerator.Current => Current;
            public void Dispose() { }

            public bool MoveNext()
            {
                if (!_couldMove) return false;
                _couldMove = false;
                return true;
            }
            public void Reset() => _couldMove = true;
        }
        
        private readonly T _value;
        public SingleSequence(T value) => _value = value;

        public IEnumerator<T> GetEnumerator() => new SingleEnumerator(ref this);
        IEnumerator IEnumerable.GetEnumerator() => new SingleEnumerator(ref this);
    }

    public class NbExceptionUserCancelled : NbException
    {
        public NbExceptionUserCancelled() : base("User cancelled the operation") { }
    }

    public class NbExceptionCmdLine : NbException
    {
        public NbExceptionCmdLine(string mess) : base(mess) { }
    }


    public class NbExceptionBadType : NbException
    {
        public NbExceptionBadType(string agnName, string expectedType, object actObj, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
            : base($"{filePath}({lineNum}): Argumnent '{agnName}' of type '{expectedType}' was expected. " +
                  (actObj != null ? $"The type '{actObj.GetType().Name}' was received in {name}" : $"Null reference was received"))
        { }
    }

    public class NbExceptionInfo : NbException
    {
        public NbExceptionInfo(string mess, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
            : base($"{filePath}({lineNum}): {mess} in {name}")
        { }
    }

    public class NbExceptionEnum<T> : NbException
    {
        public NbExceptionEnum(String enumStr, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
            : base($"{filePath}({lineNum}): Unsupported {EnumName()} enum value: {enumStr} in {name}. Supported values are: {String.Join(", ", Enum.GetValues(typeof(T)).Cast<T>().Select(e => e.ToString()))}")
        { }

        private static string EnumName()
        {
            string res = typeof(T).Name;
            if (res.EndsWith("s"))
                return res.Substring(0, res.Length - 1); //Use singular form
            else
                return res;
        }

        public NbExceptionEnum(T enumVal, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
            : this(enumVal.ToString(), filePath, lineNum, name)
        { }
    }

    public class NbExceptionPatternMatching : NbException
    {
        public NbExceptionPatternMatching(object obj, string whatIsIt, [CallerFilePath] string filePath = "", [CallerLineNumber] int lineNum = 0, [CallerMemberName] string name = "")
            : base($"{filePath}({lineNum}): Unsupported type '{obj.GetType().Name}' of {whatIsIt} in {name}")
        { }
    }

    public class NbDictionary<TKey, TValue> : Dictionary<TKey, TValue>
    {
        private readonly string Description;
        private readonly Func<TKey, TValue> CreatorN;

        public NbDictionary(int capacity = 0, IEqualityComparer<TKey> comparer = null, [CallerMemberName] string description = "", Func<TKey, TValue> creator = null)
            : base(capacity, comparer)
        {
            Description = description;
            CreatorN = creator;
        }

        public new TValue this[TKey key]
        {
            get
            {
                if (TryGetValue(key, out TValue res))
                    return res;
                else if (CreatorN != null)
                {
                    res = CreatorN(key);
                    Add(key, res);
                    return res;
                }
                else
                {
                    TKey key1 = key;
                    throw new Exception($"Key '{key1}' is not found in the '{Description}' dictionary and creator function was not supplied");
                }
            }
            set { base[key] = value; }
        }

        public new void Add(TKey key, TValue value)
        {
            if (base.ContainsKey(key))
                throw new NbException($"Key '{key}' already exists in the '{Description}' dictionary");
            else
                base.Add(key, value);
        }

        public TValue GetOrNull(TKey key)
        {
            TryGetValue(key, out TValue existing);
            return existing;
        }

        public void AddRange(IEnumerable<TValue> values, Func<TValue, TKey> keyGetter)
        {
            foreach (var v in values)
                Add(keyGetter(v), v);
        }
    }
}
