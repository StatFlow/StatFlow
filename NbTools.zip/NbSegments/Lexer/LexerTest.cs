﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NbOrm.Nbq
{
    [TestClass]
    public class LexerTest
    {

        //var dic = new Dictionary<string, int>{ ["Bob"] = 32, ["Alice"] = 17 }; - Another style for dictionary initialization
        private static readonly Dictionary<string, string> nbq_test1 = new Dictionary<string, string>
        {
            {"COUNTRIES['FR','IT']", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE COUNTRY_ID = 'FR'  AND COUNTRY_ID = 'IT'" },
            {"DOMAIN.COUNTRIES[REGION_ID=12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB FROM DOMAIN.COUNTRIES  WHERE REGION_ID = 12" },
            {"JOB_HISTORY[^13-JAN-01^]", "SELECT EMPLOYEE_ID ,START_DATE ,END_DATE ,JOB_ID ,DEPARTMENT_ID FROM JOB_HISTORY  WHERE START_DATE = '13-Jan-2001'" },
            {"COUNTRIES['Côte d''Ivoire', 12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE COUNTRY_ID = 'Côte d'Ivoire'  AND COUNTRY_ID = 12" },
            {"COUNTRIES[REGION_ID=12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE REGION_ID = 12" },
            {"COUNTRIES[REGION_ID=12,COUNTRY_NAME='Belgium']", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE REGION_ID = 12  AND COUNTRY_NAME = 'Belgium'" },
            {"COUNTRIES[12]", "SELECT COUNTRY_ID ,COUNTRY_NAME ,REGION_ID ,SOME_BLOB ,NULL_COL FROM COUNTRIES  WHERE COUNTRY_ID = 12" },
        };

        [TestMethod]
        public void LexerTests()
        {
            foreach (var (str, _) in nbq_test1)
            {
                var a = NbqLexer.Parse(str).ToList();
                Assert.IsTrue(a.Count > 1);
            }
        }


        [TestMethod]
        public void ParseChords()
        {
            var str = "[ [ { A# | {C ] | {Dm ]";
            var a = NbqLexer.Parse(str).ToList();
            Assert.IsTrue(a.Count > 1);

        }

    }

    public static class Ext
    {
        public static void Deconstruct<T1, T2>(this KeyValuePair<T1, T2> tuple, out T1 key, out T2 value)
        {
            key = tuple.Key;
            value = tuple.Value;
        }
    }
}
