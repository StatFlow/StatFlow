﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NbTools;

namespace NbHtmlGen
{
    public class TilesFormatter
    {
        public static INbTag Generate<T>(INbTag root, NbCss css, IEnumerable<INbTagGenerator> items)
            where T : INbTagGenerator //TODO: support colour for columns??
        {
            foreach (var item in items)
            {
                item.Generate(root);
            }
            return root;
        }
    }
}
