﻿using System;
using System.Threading.Tasks;
using NbTools;

namespace NbHtmlGen
{
    class BlobHtmlFormatter
    {
        internal static async Task<string> Load(INbConn nbConn, string sqlByUri)
        {
            string res;
            using var rdr = nbConn.CreateReader(sqlByUri);
            if (!await rdr.ReadAsync())
                throw new NbExceptionInfo($"Blob request '{sqlByUri}' didn't return any lines");

            res = rdr.GetBlob(0);

            if (await rdr.ReadAsync())
                throw new NbExceptionInfo($"Blob request '{sqlByUri}' returned more than one line");

            return res;
        }
    }
}
