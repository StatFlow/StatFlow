﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NbTools;

namespace NbHtmlGen
{
    public interface IHtmlColumnFormatter<T>
    {
        public abstract string Name { get; }
        public abstract string CellText(T nd, NbCss css);
    }

    public class TableFormatter
    {
        public static INbTag TableHor<T>(INbTag root, NbCss css, ICollection<IHtmlColumnFormatter<T>> columns, IEnumerable<T> nodes) //TODO: support colour for columns??
        {
            return root.TT("table", t =>
            {
                t.TT("tr", tr =>
                {
                    foreach (string colName in columns.Select(c => c.Name))
                        tr.TAV("th", a => a["style"] = "font-weight: bold", colName);
                });

                foreach (T n in nodes)
                    t.TT("tr", tr =>
                    {
                        foreach (var col in columns)
                            tr.TV("td", col.CellText(n, css), encode: false);
                    });
            });
        }

    }
}
