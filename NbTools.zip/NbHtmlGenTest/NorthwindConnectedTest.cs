﻿using NbCollV1;
using NbHtmlGen;
using NbOrm.Nbq;
using NbOrm.Xml;
using NbTools;
using NbTools.Collections;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace NbHtmlGenTest
{
    public class NorthwindConnectedTest : IClassFixture<ConnectionGetter>
    {
        readonly ConnectionGetter ConnGetter;

        public NorthwindConnectedTest(ConnectionGetter connGetter)
        {
            ConnGetter = connGetter;
        }

        public INbConn GetConnection(string _, string __)
        {
            string connString = @"Server=(localdb)\mssqllocaldb;Database=Northwind;Integrated Security=True";
            return new NbOrm.Ms.NbMsConn(connString);
        }

        [Fact]
        public async Task TestMethod1()
        {
            const string modelXml = @"C:\Repo\NbTools\DataWalker\Data\Home*.xml";
            const string iconsDir = @"C:\Users\budan\.freemind\icons";


            //Schema would have to load from xml, because some databases will not allow to use the API to get the schema
            model Model = model.MergeXmls(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, modelXml));
            layout_info HtmlLayout = layout_info.LoadXml(Path.Combine(Path.GetDirectoryName(modelXml), "Layout.xml"));
            QueryManager QueryMgr = new QueryManager(Model, HtmlLayout);

            var uri = new Uri(@"nbquery://host/dbo.Territories");
            var qType = NbqParser.GetQueryType(uri);
            var query = uri.LocalPath.TrimStart('/');
            var qRes = await QueryMgr.LoadDataForUriAsync(qType, query, ConnGetter, ConnectionGetter.ConnName); //Always save to history

            var CurrentQueryFormat = new DfExportFormat //Think about simplifying
            {
                Format = DfExportFormat.Formats.Html,
                isMergeCells = true,
                isVertical = true,
                isRemoveNullColumns = true
            };
            var (html, css, isUrl)  = qRes.Format(CurrentQueryFormat, new DirectoryInfo(iconsDir));
        }
    }

    public class ConnectionGetter : INbConnGetter, IDisposable
    {
        private readonly INbConn Conn;
        public const string ConnName = "Test";

        public ConnectionGetter()
        {
            string connString = @"Server=(localdb)\mssqllocaldb;Database=Northwind;Integrated Security=True";
            Conn = new NbOrm.Ms.NbMsConn(connString);
        }

        public void Dispose()
        {
            Conn.Dispose();
        }

        public INbConn GetConnection(string envName, string connName) => Conn;
    }
}
