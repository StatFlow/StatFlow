﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

using Nb.WebLib; //For OutlookStorage

namespace NbTools.Command
{
    internal class Email
    {
        const int LengthLimit = 120;
        readonly static string[] ToRemove = new string[] { "[GENJIRA]" };
        

        internal static int Run(string[] args)
        {
            if (args.Length < 2)
                throw new NbExceptionCmdLine("Email mode expects the destination folder as parameter");

            var rootFolder = new DirectoryInfo(args[1]);
            if (!rootFolder.Exists)
                throw new NbExceptionCmdLine($"Destination folder '{rootFolder.FullName}' doesn't exist");

            //Fill in the topic directories - they may be saved under subdirectories
            var topicDirs = new NbDictionary<string, DirectoryInfo>(comparer: StringComparer.OrdinalIgnoreCase, description: "Email topic Directories");
            foreach (var subDir in rootFolder.GetDirectories("*", SearchOption.AllDirectories))
                topicDirs.Add(subDir.Name, subDir);

            //TODO: think about parallel processing here
            foreach (var srcFile in Directory.GetFiles(Directory.GetCurrentDirectory(), "*.msg", SearchOption.AllDirectories).OrderBy(s => s))
            {
                Console.WriteLine($"Processing {srcFile}");

                string newFileName, folderName;
                DateTime dt;
                using (var messageStream = File.Open(srcFile, FileMode.Open, FileAccess.Read))
                {
                    try
                    {
                        OutlookStorage.Message message = new OutlookStorage.Message(messageStream); //TODO: derive disposable properly
                        folderName = RemoveWords(message.Subject, ToRemove).LegalizeForFilename(LengthLimit);
                        dt = message.Sent;
                        newFileName = $"{dt:yyyyMMdd HHmmss} {message.From}".LegalizeForFilename(LengthLimit)+ ".msg";
                    }
                    finally { messageStream.Close(); }
                }

                if (!topicDirs.TryGetValue(folderName, out DirectoryInfo dstDir))
                {
                    dstDir = new DirectoryInfo(Path.Combine(rootFolder.FullName, folderName));
                    dstDir.Create();
                    topicDirs.Add(folderName, dstDir);

                    //Set the dates on the folder
                    dstDir.CreationTimeUtc = dt;
                    dstDir.LastWriteTime = dt;
                }

                var dstFile = NbDir.EnsureUniqueFileName(Path.Combine(dstDir.FullName, newFileName));
                File.Move(srcFile, dstFile.FullName);
                dstFile.LastWriteTime = dt;

                //Dates on the folder maintain the min and max of all messages inside
                if (dstDir.CreationTimeUtc > dt)
                    dstDir.CreationTimeUtc = dt;
                if (dstDir.LastWriteTime < dt)
                    dstDir.LastWriteTime = dt;
            }
            return 0;
        }

        public static string RemoveReFw(string src)
        {
            while (src.StartsWith("RE:", StringComparison.OrdinalIgnoreCase) || src.StartsWith("FW:", StringComparison.OrdinalIgnoreCase))
            {
                src = src.Substring(3).Trim();
            }
            return src;
        }

        private static readonly Regex[] lastWordRegex = new Regex[] { new Regex(@"\s([a-zA-Z0-9\-]+)\s*$"), new Regex(@"\s(\d{2}\s\w{3}\s\d{4})$") };
        private static readonly string[] dateFormats = new string[] { "yyyy-MM-dd-HH-mm-ss", "dd MMM yyyy" };

        public static string RemoveTrailingDate(string src)
        {
            foreach(var match in lastWordRegex.Select(rg => rg.Match(src)).Where(m => m.Success))           
            {
                var lastWord = match.Groups[1].Value;
                bool canBeParsed = NbExt.DateFormats.Concat(dateFormats).Any(f => DateTime.TryParseExact(lastWord, f, null, DateTimeStyles.AllowInnerWhite, out DateTime parsed));
                if (canBeParsed)
                    return src.Substring(0, match.Groups[1].Index);
            }
            return src;
        }

        public static string RemoveWords(string src, IEnumerable<string> toRemove)
        {
            src = RemoveTrailingDate(RemoveReFw(src));
            foreach(var str in toRemove)
            {
                src = src.Replace(str, String.Empty);
            }
            return src.Trim();
        }

        public const string Help = "Email mode help";
    }
}
