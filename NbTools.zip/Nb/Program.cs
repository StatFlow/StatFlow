﻿using NbTools;
using NbTools.Crypto;

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.Xml.Linq;

namespace NbTools.Command
{
    class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            try
            {
                //TODO: Print header with version
                var modes = new Tuple<string, string, Func<string[], int>>[]
                {
                    Tuple.Create<string, string, Func<string[], int>>("email", Email.Help, Email.Run),
                    Tuple.Create<string, string, Func<string[], int>>("favicon", "favicon help", arg => Graphics.FavIcon(args[1], args[2])),
                    Tuple.Create<string, string, Func<string[], int>>("icon2base64", "icon2base64 help", arg => Graphics.Icon2Base64(args[1])),
                    Tuple.Create<string, string, Func<string[], int>>("george", "george help", arg => George(args[1], args[2])),
                    Tuple.Create<string, string, Func<string[], int>>("sendkey", "send key help", arg => SendKey(args[1], null)),
                    Tuple.Create<string, string, Func<string[], int>>("path", "path help", arg => PathVar(arg[1])),
                    //Tuple.Create<string, string, Func<string[], int>>("firebook", "Firefox bookmarks", arg => Firebook(args[1])),
                    Tuple.Create<string, string, Func<string[], int>>("lookaround", "Look Around", arg => LookAround()),
                    Tuple.Create<string, string, Func<string[], int>>("copy", "Copy", arg => Copy(args[1], args[2])),
                    Tuple.Create<string, string, Func<string[], int>>("xcopy", "Xcopy", arg => Xcopy(args[1], args[2], new TripleDESStringEncryptor().DecryptBytes)),
                };

                if (args.Length == 0)
                    throw new NbExceptionCmdLine($"Nb utility expects at least one parameter: the mode. Supported modes are: {String.Join(", ", modes.Select(m => m.Item1))}.");

                var mode = modes.SingleOrDefault(m => m.Item1.Equals(args[0], StringComparison.OrdinalIgnoreCase));
                if (mode == null)
                    throw new NbExceptionCmdLine($"Unsupported mode is provided: '{args[0].ToLowerInvariant()}'. Supported modes are: {String.Join(", ", modes.Select(m => m.Item1))}.");

                if (args.Length >= 2 && args[1].Equals("help", StringComparison.OrdinalIgnoreCase))
                    throw new NbExceptionCmdLine(mode.Item2);

                return mode.Item3(args);
            }
            catch (NbExceptionCmdLine ex)
            {
                Console.WriteLine(ex.Message);
                Thread.Sleep(5000);
                return 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Fatal exception: {NbException.Exception2String(ex)}");
                Thread.Sleep(5000);
                return 1;
            }
        }

        private static int Copy(string src, string dst)
        {
            if (!File.Exists(src))
                throw new NbExceptionCmdLine($"File '{src}' doesn't exist");
            if (Path.IsPathRooted(dst))
                NbExt.DirCreateRecursive(Path.GetDirectoryName(dst));

            var enc = new TripleDESStringEncryptor();
            File.WriteAllText(dst, Convert.ToBase64String(enc.EncryptBytes(File.ReadAllText(src).Gzip())));
            return 0;
        }

        private static int Xcopy(string src, string dst, Func<byte[], byte[]> func)
        {
            if (!File.Exists(src))
                throw new NbExceptionCmdLine($"File '{src}' doesn't exist");
            if (Path.IsPathRooted(dst))
                NbExt.DirCreateRecursive(Path.GetDirectoryName(dst));

            var enc = new TripleDESStringEncryptor();
            File.WriteAllText(dst, enc.DecryptBytes(Convert.FromBase64String(File.ReadAllText(src))).Unzip());
            return 0;
        }

        private static int LookAround()
        {
            string logName = @"C:\Temp\" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".txt";
            using (StreamWriter wrtr = new StreamWriter(logName))
            {
                wrtr.WriteLine($"User: {Environment.UserName}");
                wrtr.WriteLine($"UserDomainName: {Environment.UserDomainName}");
                wrtr.WriteLine($"CommandLine: {Environment.CommandLine}");
                wrtr.WriteLine($"MachineName: {Environment.MachineName}");
                wrtr.WriteLine($"CurrentDirectory: {Environment.CurrentDirectory}");
                wrtr.WriteLine($"GetCommandLineArgs: {String.Join(", ", Environment.GetCommandLineArgs())}");
            }
            return 1;
        }

        /*private static int Firebook(string file)
        {
            var root = LinqToHtml.LoadFile(file).Root.NbElement("DL");
            var bookHeader = root.Elements().SingleVerbose(n => n.Value == "Bookmarks Toolbar", () => "Can't find Bookmarks Toolbar tag", i => $"{i} Bookmarks Toolbar tags found");
            var dd = bookHeader.NextNode.NextNode as XElement ?? throw new Exception("Can't find DL after the Bookmarks Toolbar");
            var rootOfToolBar = dd.NbElement("DL");
            FireDlRecursive(rootOfToolBar, "Root");
            return 0;
        }


        private static void FireDlRecursive(XElement dl, string menuName)
        {
            using (var wtrt = new StreamWriter(NbDir.LegalizeFullPath(@"C:\temp\1\" + menuName + ".txt")))
            {
                string subMenuName = null;

                foreach (var node in dl.Elements())
                {
                    switch (node.Name.LocalName.ToUpperInvariant())
                    {
                        case "DT":
                            if (node.Elements().Count() == 0)
                                break;

                            var link = node.NbElement("a");
                            wtrt.WriteLine(link.NbAttribSafe("href"));
                            break;

                        case "H3":
                            subMenuName = node.Value;
                            break;

                        case "DL":
                            FireDlRecursive(node, subMenuName ?? throw new Exception("H3 name was not set before DL node"));
                            subMenuName = null;
                            break;
                    }
                }
            }
        }*/

        private static int PathVar(string srcFile)
        {
            const char PathSeparator = ';';
            if (!File.Exists(srcFile))
            {
                File.WriteAllLines(srcFile, Environment.GetEnvironmentVariable("PATH").Split(PathSeparator));
                Console.WriteLine($"Source file '{srcFile}' was not found. It will be populated from the environment variable PATH");
            }

            var dstFile = Path.Combine(Path.GetDirectoryName(srcFile), Path.GetFileNameWithoutExtension(srcFile) + ".oneline.txt");
            File.WriteAllText(dstFile, String.Join(PathSeparator.ToString(),
                File.ReadAllLines(srcFile).Select(l => l.Trim().TrimEnd(PathSeparator)).Distinct().Where(l => !String.IsNullOrWhiteSpace(l) && !l.StartsWith("#"))
                ));

            return 0;
        }


        // Get a handle to an application window.
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        public static extern IntPtr FindWindow(string lpClassName,
            string lpWindowName);

        // Activate an application window.
        [DllImport("USER32.DLL")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        private static int SendKey(string procName, string fileWith)
        {
            // Get a handle to the Calculator application. The window class
            // and window name were obtained using the Spy++ tool.
            //SunAwtCanvas  SunAwtComponent SunAwtFrame
            /*IntPtr calculatorHandle = FindWindow("SunAwtFrame", null);

            // Verify that Calculator is a running process.
            if (calculatorHandle == IntPtr.Zero)
            {
                Console.WriteLine("Calculator is not running.");
                return -1;
            }*/

            //IntPtr calculatorHandle = FindWindow("WindowsForms10.Window.8.app.0.2b89eaa_r16_ad1", "LDNDWM473437 - Desktop Viewer");

            /*Process[] processes = Process.GetProcessesByName(procName);
            foreach (Process proc in processes)
            {
                var res = SetForegroundWindow(proc.MainWindowHandle);  //proc.MainWindowHandle
                for (int i = 0; i < 5; ++i)
                {
                    SendKeys.SendWait("1");
                    Thread.Sleep(500);
                    SendKeys.SendWait("{BACKSPACE}");


                    Thread.Sleep(3000);
                }
        
            return 0;*/


            Process[] processes = Process.GetProcessesByName("CDViewer");
            foreach (Process proc in processes)
            {
                for (int i = 0; i < 5; ++i)
                {
                    SetForegroundWindow(proc.MainWindowHandle);  //proc.MainWindowHandle
                    SendKeys.SendWait(".");

                    Thread.Sleep(3 * 60 * 1000);
                }
            }
            return 0;
        }



        private static int George(string srcFile, string dstFile)
        {
            //Capital letters
            foreach (var pair in mapRus.Select(p => Tuple.Create((char)(p.Key - 0x20), p.Value)).ToList())
                mapRus.Add(pair.Item1, pair.Item2);

            using (StreamReader rdr = new StreamReader(srcFile))
            using (StreamWriter wrtr = new StreamWriter(dstFile))
            {
                while (!rdr.EndOfStream)
                {
                    char c = (char)rdr.Read();
                    if (mapRus.TryGetValue(c, out char newC))
                        wrtr.Write(newC);
                    else
                        wrtr.Write(c);
                }
            }
            return 0;
        }

        /*private static readonly Dictionary<char, char> mapEng = new Dictionary<char, char> {
{ 'a', 'ფ' },
{ 'b', 'მ' },
{ 'c', 'ყ' },
{ 'd', 'ვ' },
{ 'e', 'უ' },
{ 'f', 'თ' },
{ 'g', 'ა' },
{ 'h', 'პ' },
{ 'i', 'შ' },
{ 'j', 'რ' },
{ 'k', 'ო' },
{ 'l', 'ლ' },
{ 'm', 'ტ' },
{ 'n', 'ი' },
{ 'o', 'წ' },
{ 'p', 'ზ' },
{ 'q', 'ღ' },
{ 'r', 'კ' },
{ 's', 'ძ' },
{ 't', 'ე' },
{ 'u', 'გ' },
{ 'v', 'ს' },
{ 'w', 'ჯ' },
{ 'x', 'ჩ' },
{ 'y', 'ნ' },
{ 'z', 'ჭ' }, };*/

        private static readonly Dictionary<char, char> mapRus = new Dictionary<char, char> {
{ 'й', 'ღ' },
{ 'ц', 'ჯ' },
{ 'у', 'უ' },
{ 'к', 'კ' },
{ 'е', 'ე' },
{ 'н', 'ნ' },
{ 'г', 'გ' },
{ 'ш', 'შ' },
{ 'щ', 'წ' },
{ 'з', 'ზ' },
{ 'х', 'ხ' },
{ 'ъ', 'ც' },

{ 'ф', 'ფ' },
{ 'ы', 'ძ' },
{ 'в', 'ვ' },
{ 'а', 'თ' },
{ 'п', 'ა' },
{ 'р', 'პ' },
{ 'о', 'რ' },
{ 'л', 'ო' },
{ 'д', 'ლ' },
{ 'ж', 'დ' },
{ 'э', 'ჟ' },

{ 'я', 'ჭ' },
{ 'ч', 'ჩ' },
{ 'с', 'ყ' },
{ 'м', 'ს' },
{ 'и', 'მ' },
{ 'т', 'ი' },
{ 'ь', 'ტ' },
{ 'б', 'ქ' },
{ 'ю', 'ბ' }};
    }
}
