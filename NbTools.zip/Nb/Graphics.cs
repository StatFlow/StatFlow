﻿using NbTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media.Imaging;

namespace NbTools.Command
{
    internal static class Graphics
    {
        internal static int FavIcon(string url, string dstFile) 
        {
            //url = "www.bbc.co.uk";

            if (!url.StartsWith("http://") && !url.StartsWith("https://"))
                url = "http://" + url;

            string page;
            Uri uri = new Uri(url);
            Uri baseUri = new Uri(uri.Scheme + "://" + uri.Host);
            Uri favIcoUri = new Uri(baseUri, "favicon.ico");

            using (WebClient wc = new WebClient())
            {
                page = wc.DownloadString(url);


                /*Console.Write($"Downloading {favIcoUri}...");
                wc.DownloadFile(favIcoUri.ToString(), dstFile);
                Console.WriteLine("done!");*/
            }

            //page = wc.DownloadString(url);*/
            page = File.ReadAllText(@"C:\Temp\1.html");


            return 0;
        }

        internal static int Icon2Base64(string file, string iconSizeStr = "16")
        {
            if (Path.IsPathRooted(file))
                file = Path.Combine(NbDir.Startup.DirInfo.FullName, file);
            if (!File.Exists(file))
                throw new NbExceptionCmdLine($"File '{file}' doesn't exist");
            int IconSize = Int32.Parse(iconSizeStr);

            BitmapDecoder decoder = BitmapDecoder.Create(new Uri(file, UriKind.Absolute), BitmapCreateOptions.None, BitmapCacheOption.OnDemand);
            /* Create separate file for each frame
            int cnt = 1;
            foreach (var f in decoder.Frames)
            {
                Console.WriteLine($"Frame: {f.Width}x{f.Height}");
                File.WriteAllBytes($"{file}_{cnt++}_{f.Width}x{f.Height}_{f.Format.ToString()}.png", FrameToArray(f));
            }*/

            var img = decoder.Frames.FirstOrDefault(f => f.Width == IconSize) ?? decoder.Frames.OrderBy(f => f.Width).First(); //Returns bitmap frame
            var arr = FrameToArray(img);

            var base64str = Convert.ToBase64String(arr);
            Console.WriteLine("Will also be inserted into clipboard");
            Console.WriteLine(base64str);
            System.Windows.Clipboard.SetText(base64str);
            Console.ReadKey();

            return 0;
        }

        private static byte[] FrameToArray(BitmapFrame frm)
        {
            BitmapEncoder bme = new PngBitmapEncoder();
            bme.Frames.Add(BitmapFrame.Create(frm));
            using (var wrtr = new MemoryStream())
            {
                bme.Save(wrtr);
                wrtr.Flush();
                return wrtr.ToArray();
            }
        }


    }
}
