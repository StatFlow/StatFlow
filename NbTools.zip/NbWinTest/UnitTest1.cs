﻿using NbWin;
using System;
using System.Linq;
using Xunit;

namespace NbWinTest
{
    public class UnitTest1
    {
        [StaFact]
        public void LinkResolvinTest()
        {
            var res = LnkResolver.GetLnkTarget(@"C:\Users\budan\Desktop\MP4Splitter.lnk");
            Assert.Equal(@"C:\Program Files (x86)\MP4Tools\bin\MP4Splitter.exe", res);

            //var res = LnkResolver.GetLnkTarget(@"C:\Users\budan\Desktop\Skype.lnk");
            //Assert.Equal(@"C:\Program Files (x86)\Microsoft\Skype for Desktop\Skype.exe", res);
        }
    }
}
