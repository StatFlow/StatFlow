﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NbWpfLib
{
    public class WinFormsHelpers
    {

        public static ListViewItem ListViewItemByXyN(ListView listView, int x, int y)
        {
            var targetNodeN = listView.GetItemAt(x, y); // Retrieve the node at the drop location.
            if (targetNodeN == null)
                return null;

            listView.SelectedItems.Clear();
            targetNodeN.Selected = true;
            return targetNodeN;
        }


        public static ListViewItem ListViewItemByXyDragDrop(ListView listView, int x, int y)
        {
            Point targetPoint = listView.PointToClient(new Point(x, y)); // Retrieve the client coordinates of the drop location.
            var targetNodeN = listView.GetItemAt(targetPoint.X, targetPoint.Y); // Retrieve the node at the drop location.
            if (targetNodeN == null)
                return null;

            listView.SelectedItems.Clear();
            targetNodeN.Selected = true;
            return targetNodeN;
        }
    }
}
