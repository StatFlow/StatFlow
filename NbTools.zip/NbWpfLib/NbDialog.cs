﻿using System;
using System.Windows;
using NbTools;

namespace NbWpfLib
{
    public static class NbDialog
    {
        private static Window fMainWindow;
        public static Window MainWindow
        {
            get
            {
                if (fMainWindow == null)
                    throw new NbExceptionInfo("MainWindow property was not set in NbDialog");
                else
                    return fMainWindow;
            }
            set { fMainWindow = value; }
        }

        public static string Title { get; set; }

        public static bool YesNo(string question)
        {
            bool ret = false;
            UniversalDialog dlg = new UniversalDialog(MainWindow, question, null, null)
            {
                Title = Title
            };
            dlg.AddButton("Yes", ButtonType.Default, () => ret = true);
            dlg.AddButton("No", ButtonType.Cancel);
            dlg.ShowDialog();
            return ret;
        }

        public static void Error(Exception exp)
        {
            string mess = NbException.Exception2String(exp);

            Application.Current.Dispatcher.Invoke(() =>
            {
                UniversalDialog dlg = new UniversalDialog(MainWindow, mess, null, null)
                {
                    Title = "Error has occured"
                };
                dlg.AddButton("OK", ButtonType.Default);
                dlg.ShowDialog();
            });
        }

        public static void OK(string mess, string title = null)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                UniversalDialog dlg = new UniversalDialog(MainWindow, mess, null, null)
                {
                    Title = title ?? "OK"
                };
                dlg.AddButton("OK", ButtonType.Default);
                dlg.ShowDialog();
            });
        }
    }
}
