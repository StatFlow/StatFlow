﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace NbWpfLib
{
    /// <summary>
    /// Interaction logic for UniversalDialog.xaml
    /// </summary>
    public partial class UniversalDialog : Window
    {
        public UniversalDialog()
        {
            InitializeComponent();
        }

        public UniversalDialog(Window aOwner, string aTextBefore = null, string aUserInput = null, string aTextAfter = null)
        {
            InitializeComponent();

            Owner = aOwner;

            if (aTextBefore != null)
                lbTextBefore.Text = aTextBefore;
            else
                lbTextBefore.Visibility = Visibility.Collapsed;

            if (aUserInput != null)
            {
                tbUserInput.Text = aUserInput;
                tbUserInput.Focus();
                tbUserInput.SelectAll();
            }
            else
                tbUserInput.Visibility = Visibility.Collapsed;

            if (aTextAfter != null)
                lbTextAfter.Text = aTextAfter;
            else
                lbTextAfter.Visibility = Visibility.Collapsed;

            pnButtons.Children.Clear();


            /*, params Tuple<string, RoutedEventHandler>[] aButtons
            foreach(var pair in aButtons.Safe())
            {
                Button btn = new Button { Content = pair.Item1 };
                btn.Click += pair.Item2;
                pnButtons.Children.Add(btn);
            } */
        }

        public void AddButton(string aText, ButtonType aType = ButtonType.NotSpecified, Action aAction = null)
        {
            Button btn = new Button { Content = aText };
            btn.Click += (sender, __) =>
            {
                if (sender is Button && (sender as Button).IsDefault)
                    DialogResult = true;

                Close();
                aAction?.Invoke();
            };

            btn.IsDefault = (aType & ButtonType.Default) != 0;
            btn.IsCancel = (aType & ButtonType.Cancel) != 0;
            pnButtons.Children.Add(btn);
        }

        public bool ShowOkCancel()
        {
            this.AddButton(aText: "OK", aType: ButtonType.Default);
            this.AddButton(aText: "Cancel", aType: ButtonType.Cancel);
            var res = ShowDialog();

            return res.HasValue && res.Value;
        }

        public static string GetUserString(Window aOwner, string aTextBefore = null, string aUserInput = null, string aTextAfter = null)
        {
            UniversalDialog dlg = new UniversalDialog(aOwner, aTextBefore, aUserInput, aTextAfter);
            if (dlg.ShowOkCancel() && !String.IsNullOrEmpty(dlg.tbUserInput.Text))
                return dlg.tbUserInput.Text;
            else
                return null;
        }

        public static bool ActionOrCancel(Window aOwner, string aTextBefore, string aActonButtonName)
        {
            UniversalDialog dlg = new UniversalDialog(aOwner, aTextBefore);
            dlg.AddButton(aText: aActonButtonName, aType: ButtonType.Default);
            dlg.AddButton(aText: "Cancel", aType: ButtonType.Cancel);
            var res = dlg.ShowDialog();
            return res.HasValue && res.Value;
        }

        //TODO: Disable OK button is input is empty or validate by the regex

        /*internal static void ShowErrors(Window aOwner, IEnumerable<DataModel.LogEntry> fLoglist)
        {
            string message = String.Join(Environment.NewLine, fLoglist);
            UniversalDialog dlg = new UniversalDialog(aOwner, message);
            dlg.AddButton(aText: "Damn!", aType: ButtonType.Default);
            var res = dlg.ShowDialog();
        }*/
    }

    [Flags]
    public enum ButtonType { None = 0, Default = 1, Cancel = 2, NotSpecified = 4 };

}
