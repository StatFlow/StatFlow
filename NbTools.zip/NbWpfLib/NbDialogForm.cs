﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NbWpfLib
{
    public partial class NbDialogForm : Form
    {
        internal bool Result = false;   

        public NbDialogForm()
        {
            InitializeComponent();
        }

        private NbDialogForm(string title, string label, string defaultTxt = null)
            :base()
        {
            InitializeComponent();
            Text = title;
            label1.Text = label;
            if (defaultTxt != null)
            {
                textBox1.Text = defaultTxt;
                textBox1.SelectAll();
            }
            textBox1.Focus();
        }

        public static (bool, string) Show(string title, string label, string defaultTxt = null)
        {
            var dlg = new NbDialogForm(title, label, defaultTxt);
            dlg.ShowDialog();
            return (dlg.Result, dlg.textBox1.Text);
        }

        private void BtOK_Click(object sender, EventArgs e)
        {
            Result = true;
            Close();
        }

        private void BtCancel_Click(object sender, EventArgs e)
        {
            Result = false;
            Close();
        }
    }
}
