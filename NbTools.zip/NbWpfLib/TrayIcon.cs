﻿using System;
using System.Windows.Forms;

namespace NbWpfLib
{
    public class TrayIcon : IDisposable
    {
        private bool disposed = false;
        public readonly NotifyIcon Icon;

        public TrayIcon(System.Drawing.Icon icon)
        {
            Icon = new NotifyIcon()
            {
                Icon = icon,
                Visible = true
            };
        }

        protected void Dispose(bool disposing)
        {
            if (disposed) return;

            if (disposing)
            {
                //Managed resources
            }

            //Unmanaged resources
            Icon.Icon = null;
            Icon.Visible = false;
            Icon.Dispose();

            disposed = true;
        }

        ~TrayIcon() => Dispose(false);
        public void Dispose() => Dispose(true);
    }
}
