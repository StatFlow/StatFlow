﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Speech.Synthesis;
using System.Text;
using System.Threading.Tasks;

namespace NbWpfLib
{
    public class NbSpeech : IDisposable
    {
        private readonly SpeechSynthesizer Voice;

        public NbSpeech()
        {

            Voice = new System.Speech.Synthesis.SpeechSynthesizer();
            var a = Voice.GetInstalledVoices();

            var br = Voice.GetInstalledVoices().FirstOrDefault(v => v.VoiceInfo.Name.Contains("Bridget"));
            if (br != null)
                Voice.SelectVoice(br.VoiceInfo.Name);

            Voice.SetOutputToDefaultAudioDevice();
        }

        public Task Say(string text)
        {
            var taskCompSource = new TaskCompletionSource<bool>();
            Voice.SpeakAsync(text);

            EventHandler<SpeakCompletedEventArgs> evt1 = null;
            evt1 = new EventHandler<SpeakCompletedEventArgs>((src, arg) =>
            {
                Voice.SpeakCompleted -= evt1;
                taskCompSource.SetResult(true);
            });

            Voice.SpeakCompleted += evt1;

            return taskCompSource.Task;
        }

        public Task SayToFile(string text, string fileName)
        {
            var taskCompSource = new TaskCompletionSource<bool>();
            Voice.SetOutputToWaveFile(fileName);
            Voice.SpeakAsync(text);

            EventHandler<SpeakCompletedEventArgs> evt1 = null;
            evt1 = new EventHandler<SpeakCompletedEventArgs>((src, arg) =>
            {
                Voice.SpeakCompleted -= evt1;
                Voice.SetOutputToDefaultAudioDevice();
                taskCompSource.SetResult(true);
            });

            Voice.SpeakCompleted += evt1;

            return taskCompSource.Task;
        }

        public void Dispose()
        {
            Voice?.Dispose();
        }
    }
}
