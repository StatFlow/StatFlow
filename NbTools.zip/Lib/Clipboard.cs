using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace NbTools
{
    /// <summary>
    /// FxCop requires all Marshalled functions to be in a class called NativeMethods.
    /// </summary>
    public static class ClipboardTools
    {
        //Text-related
        public const string CL_Text = "Text";
        public const string CL_UnicodeText = "UnicodeText";
        public const string CL_SystemString = "System.String";

        //File-related
        public const string CL_FileGroupDescriptorW = "FileGroupDescriptorW";
        public const string CL_FileGroupDescriptor = "FileGroupDescriptor";
        public const string CL_FileDrop = "FileDrop";
        public const string CL_FileNameW = "FileNameW";
        public const string CL_FileName = "FileName";

        public static bool TryGetText(this IDataObject dataObj, out string text)
        {
            if (Clipboard.ContainsText())
            {
                text = Clipboard.GetText();
                return true;
            }
            else
            {
                text = null;
                return false;
            }
        }


        public static bool TryGetFileDescriptors(this IDataObject dataObj, out List<NativeMethods.FILEDESCRIPTORW> fileList)
        {
            if (dataObj.GetDataPresent(CL_FileGroupDescriptorW))
            {
                fileList = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORW>((MemoryStream)dataObj.GetData(CL_FileGroupDescriptorW)).ToList();
                return true;
            }
            else if (dataObj.GetDataPresent(CL_FileGroupDescriptor))
            {
                var a = NativeMethods.MarshalCntAndArrayOfStructures<NativeMethods.FILEDESCRIPTORA>((MemoryStream)dataObj.GetData(CL_FileGroupDescriptor)).ToList();
                throw new Exception($"FileGroupDescriptorW is not available while FileGroupDescriptor is available = non-Unicone Windows?");
            }
            else
            {
                fileList = null;
                return false;
            }
        }

        public static bool TryGetFileNames(this IDataObject dataObj, out string[] fileList)
        {
            if (dataObj.GetDataPresent(CL_FileDrop))
            {
                fileList = dataObj.GetData(CL_FileDrop) as string[] ?? throw new Exception($"{CL_FileDrop} output is not string[]");
                return true;
            }
            else if (dataObj.GetDataPresent(CL_FileNameW))
            {
                fileList = dataObj.GetData(CL_FileNameW) as string[] ?? throw new Exception($"{CL_FileNameW} output is not string[]");
                return true;
            }
            else if (dataObj.GetDataPresent(CL_FileName))
            {
                fileList = dataObj.GetData(CL_FileName) as string[] ?? throw new Exception($"{CL_FileName} output is not string[]");
                return true;
            }
            fileList = null;
            return false;
        }
    }
}

//Filedrop sample
/*byte[] moveEffect = { 2, 0, 0, 0 };
MemoryStream dropEffect = new MemoryStream();
dropEffect.Write(moveEffect, 0, moveEffect.Length);

StringCollection filestToCut = new StringCollection {"D:\\test.txt"};
DataObject data = new DataObject("Preferred DropEffect", dropEffect);
data.SetFileDropList(filestToCut);

//or execute default constructor and uncomment line below:
//data.SetData("Preferred DropEffect", dropEffect);

Clipboard.Clear();
Clipboard.SetDataObject(data, true);
*/
