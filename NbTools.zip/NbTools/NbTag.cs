﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace NbTools
{
    public interface INbTagGenerator
    {
        INbTag Generate(INbTag root);
    }

    /// <summary>
    /// Example:  a["id", "MusicStruct"]["LastAttrib"] = "lastValue"
    /// </summary>
    public interface INbAtrrib
    {
        string this[string attrName] { set; }
        INbAtrrib this[string attrName, string attValue] { get; }
        INbAtrrib Attrib(string attName, string attValue);
    }

    //TODO: endcode values for tags and attributes with (&gt;) and check if the tag, attribute names are valid
    public interface INbTag
    {
        INbTag Tag(string tagName);
        string this[string tagName] { set; }
        INbTag this[string tagName, string attValue] { get; }

        INbTag TT(string tagName, Action<INbTag> SubTags);
        INbTag TA(string tagName, Action<INbAtrrib> Attribs); //Used to be Tag


        /// <summary>
        /// Creates many tags with the same name
        /// </summary>
        /// <param name="tagName">The name of the multiple tags</param>
        /// <param name="attValues">The IEnumerable of value strings to put into these tags</param>
        /// <returns></returns>
        INbTag TTs(string tagName, IEnumerable<string> attValues);
        INbTag TAV(string tagName, Action<INbAtrrib> Attribs, string val, bool encode = true);

        /// <summary>
        /// Creates tag with action for attributes and action for subtags
        /// </summary>
        /// <param name="tagName">Tag name</param>
        /// <param name="Attribs">Action to create one or many attributes</param>
        /// <param name="SubTags">Action to create one or many subtags</param>
        /// <returns></returns>
        INbTag TAT(string tagName, Action<INbAtrrib> Attribs, Action<INbTag> SubTags);
        INbTag TV(string tagName, string val, bool encode = true);

        INbTag Value(string val, bool encode = true);
    }

    public class NbTag : INbTag, INbAtrrib
    {
        //private const char IndentMaj = '\t';
        private static string IndentMin;
        public int Level = 0;
        private readonly TextWriter Wr;
        private readonly string NameSpace;

        public static INbTag Create(TextWriter wr, string indent = "  ", string nameSpace = null) //, string tagName, Action<INbAtrrib> Attribs = null, Action<INbTag> SubTags = null)
        {
            return new NbTag(wr, indent, nameSpace);
        }

        public NbTag(TextWriter aWr, string indent, string nameSpace)
        {
            Wr = aWr;
            IndentMin = indent;
            NameSpace = nameSpace;
        }

        private void CreateTag(int aLevel, string tagName, Action<INbAtrrib> Attribs, Action<INbTag> SubTags, string val, bool encode = true)
        {
            if (tagName.Contains('<') || tagName.Contains('>'))
                throw new ArgumentException("Illegal tagName " + tagName);

            Level = aLevel;
            Indentation(Wr, Level);

            Wr.Write('<');
            if (!String.IsNullOrEmpty(NameSpace))
            {
                Wr.Write(NameSpace);
                Wr.Write(':');
            }
            Wr.Write(tagName);
            Attribs?.Invoke(this);

            if (SubTags != null)
            {   //Opening a closing tags
                Wr.WriteLine('>');

                if (!String.IsNullOrEmpty(val))
                    throw new ArgumentException("Both subTags and the value provided for tag '{tagName}'");

                Level++;
                SubTags(this);  //TODO: this can't return parameters because return parameter is used for chaining
                Level--;        //New lines could be made a responsibility of the code in SubTags
                Indentation(Wr, Level);
                ClosingTag(tagName);
            }
            else if (val != null) //Empty string should create opening and closing tags
            {
                Wr.Write('>');
                Wr.Write(encode ? System.Net.WebUtility.HtmlEncode(val) : val);
                ClosingTag(tagName);
            }
            else
            { //Single tag
                Wr.WriteLine("/>");
            }
        }

        private void ClosingTag(string tagName)
        {
            Wr.Write("</");
            if (!String.IsNullOrEmpty(NameSpace))
            {
                Wr.Write(NameSpace);
                Wr.Write(':');
            }
            Wr.Write(tagName);
            Wr.WriteLine('>');
        }

        private static void Indentation(TextWriter wr, int level)
        {
            //for (int i = level >> 2; i > 0; --i)
            //    wr.Write(IndentMaj);    //Tabs instead of four spaces

            for (int i = level; i > 0; --i) //level % 4
                wr.Write(IndentMin);
        }

        public INbAtrrib Attrib(string attName, string attValue)
        {
            Wr.Write(' ');
            Wr.Write(attName);
            Wr.Write("=\"");
            Wr.Write(attValue);
            Wr.Write('\"');
            return this;
        }

        INbAtrrib INbAtrrib.this[string attrName, string attValue]
        {
            get { Attrib(attrName, attValue); return this; }
        }

        string INbAtrrib.this[string attrName]
        {
            set { Attrib(attrName, value); }
        }

        INbTag INbTag.TA(string tagName, Action<INbAtrrib> Attribs)
        {
            CreateTag(this.Level, tagName, Attribs, null, null);
            return this;
        }

        INbTag INbTag.TT(string tagName, Action<INbTag> SubTags)
        {
            CreateTag(this.Level, tagName, null, SubTags, null);
            return this;
        }

        INbTag INbTag.Tag(string tagName)
        {
            CreateTag(this.Level, tagName, null, null, null);
            return this;
        }

        INbTag INbTag.Value(string val, bool encode)
        {
            string encoded = encode ? System.Net.WebUtility.HtmlEncode(val) : val;
            Wr.Write(encoded);
            return this;
        }

        public INbTag TTs(string tagName, IEnumerable<string> attValues)
        {
            if (attValues != null)
                foreach (var item in attValues)
                {
                    CreateTag(Level, tagName, null, null, item);
                }
            return this;
        }

        public INbTag TAT(string tagName, Action<INbAtrrib> Attribs, Action<INbTag> SubTags)
        {
            CreateTag(this.Level, tagName, Attribs, SubTags, null);
            return this;
        }

        public INbTag TAV(string tagName, Action<INbAtrrib> attribs, string val, bool encode = true)
        {
            CreateTag(this.Level, tagName, attribs, null, val, encode);
            return this;
        }

        public INbTag TV(string tagName, string val, bool encode = true)
        {
            CreateTag(this.Level, tagName, null, null, val, encode);
            return this;
        }

        string INbTag.this[string tagName]
        {
            set { CreateTag(this.Level, tagName, null, null, value); }
        }

        INbTag INbTag.this[string tagName, string attValue]
        {
            get { CreateTag(this.Level, tagName, null, null, attValue); return this; }
        }
    }

    public class HtmlTag : NbTag
    {
        public HtmlTag(TextWriter aWr)
            : base(aWr, " ", null)
        { }

        public static void CreateHtmlPage(string htmlFileName, string title, Action<INbTag> createContent)
        {
            if (createContent == null)
                throw new Exception("CreateContent actoin was not provided");

            using StreamWriter wrtr = new StreamWriter(htmlFileName);
            wrtr.WriteLine("<!doctype html>");
            var myT = NbTag.Create(wrtr).TT("html", t => t
                .TT("head", t1 => t1
                     ["title", title]
                     .TA("meta", a => a["charset"] = "utf-8")
                    //.TV("style", NbExt.FileInOneLine(DfExportHtml.Css), encode: false)
                    //.TAV("script", a1 => a1["type", "text/javascript"]["language"] = "javascript", FileInOneLine(@"Data\JavaScript.js"), encode: false)
                    )
                .TT("body", t2 => t2.TAT("div", a2 => a2["id"] = "content", t3 => createContent(t3))
                ));
        }


        private static string GetEmbeddedResourceTextFile(string resourceName)
        {
            Assembly assem = typeof(NbExt).Assembly;
            try
            {
                using var reader = new StreamReader(assem.GetManifestResourceStream(resourceName));
                return reader.ReadToEnd();
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Available resources are {String.Join(", ", assem.GetManifestResourceNames())}");
            }
        }
    }
}