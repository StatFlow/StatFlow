﻿using System;

namespace NbTools.NbNullable
{
    public static class NbNull
    {
        public const byte Byte_ = byte.MaxValue;
        public const char Char_ = char.MinValue;
        public const Int16 Int16_ = short.MinValue;
        public const Int32 Int32_ = int.MinValue;
        public const Int64 Int64_ = long.MinValue;
        public const Decimal Decimal_ = decimal.MinValue;
        public const double Double_ = double.MinValue;
        public static readonly DateTime DateTime_ = DateTime.MinValue;

        public static bool IsNbNull(this byte v) => v == Byte_;
        public static bool IsNbNull(this char v) => v == Char_;
        public static bool IsNbNull(this Int16 v) => v == Int16_;
        public static bool IsNbNull(this Int32 v) => v == Int32_;
        public static bool IsNbNull(this Int64 v) => v == Int64_;
        public static bool IsNbNull(this decimal v) => v == Decimal_;
        public static bool IsNbNull(this double v) => v == Double_;
        public static bool IsNbNull(this DateTime v) => v == DateTime_;

        public static bool IsNbNull<T>(this T v)
        {
            return v switch
            {
                String str => String.IsNullOrEmpty(str),
                byte b => IsNbNull(b),
                char b => IsNbNull(b),
                Int16 b => IsNbNull(b),
                Int32 b => IsNbNull(b),
                Int64 b => IsNbNull(b),
                decimal b => IsNbNull(b),
                double b => IsNbNull(b),
                DateTime b => IsNbNull(b),
                _ => v as object == null,
            };
        }

        public static byte ToNbNullByte(this string str)
        {
            byte res;
            if (String.IsNullOrEmpty(str))
                return Byte_;
            else if (!Byte.TryParse(str, out res))
                throw new Exception($"Can't parse byte out of '{str}'");
            return res;
        }
        public static string NullableToString(this byte bt, string format = null) => IsNbNull(bt) ? String.Empty : bt.ToString(format);
        public static string NullableToString(this decimal bt, string format = null) => IsNbNull(bt) ? String.Empty : bt.ToString(format);
        public static string NullableToString(this int bt, string format = null) => IsNbNull(bt) ? String.Empty : bt.ToString(format);

        public static char ToNbNullChar(this string str)
        {
            Char res;
            if (String.IsNullOrEmpty(str))
                return Char_;
            else if (!Char.TryParse(str, out res))
                throw new Exception($"Can't parse char out of '{str}'");
            return res;
        }

        public static Int16 ToNbNullInt16(this string str)
        {
            Int16 res;
            if (String.IsNullOrEmpty(str))
                return Int16_;
            else if (!Int16.TryParse(str, out res))
                throw new Exception($"Can't parse Int16 out of '{str}'");
            return res;
        }

        public static Int32 ToNbNullInt32(this string str)
        {
            Int32 res;
            if (String.IsNullOrEmpty(str))
                return Int32_;
            else if (!Int32.TryParse(str, out res))
                throw new Exception($"Can't parse Int32 out of '{str}'");
            return res;
        }

        public static Int64 ToNbNullInt64(this string str)
        {
            Int64 res;
            if (String.IsNullOrEmpty(str))
                return Int64_;
            else if (!Int64.TryParse(str, out res))
                throw new Exception($"Can't parse Int64 out of '{str}'");
            return res;
        }

        public static Decimal ToNbNullDecimal(this string str)
        {
            Decimal res;
            if (String.IsNullOrEmpty(str))
                return Decimal_;
            else if (!Decimal.TryParse(str, out res))
                throw new Exception($"Can't parse Decimal out of '{str}'");
            return res;
        }

        public static DateTime ToNbNullDateTime(this string str)
        {
            DateTime res;
            if (String.IsNullOrEmpty(str))
                return DateTime_;
            else if (!DateTime.TryParse(str, out res))
                throw new Exception($"Can't parse DateTime out of '{str}'");
            return res;
        }

        public static string ToString(Int64 i) => NbNull.IsNbNull(i) ? String.Empty : i.ToString();
        public static string ToString(Int32 i) => NbNull.IsNbNull(i) ? String.Empty : i.ToString();
    }
}
