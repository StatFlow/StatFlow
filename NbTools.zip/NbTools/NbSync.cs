﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbTools.Sync
{
    /// <summary>
    /// Change type used in creating event about the changes in the model
    /// </summary>
    public enum ChangeType
    {
        /// <summary>
        /// The Node was not changed
        /// </summary>
        None,
        /// <summary>
        /// The node was added
        /// </summary>
        Add,
        /// <summary>
        /// The node was removed
        /// </summary>
        Remove,
        /// <summary>
        /// Some properties of the node have changed
        /// </summary>
        Update,
        /// <summary>
        /// The property is set to a bad value
        /// </summary>
        ValidationWarning,
        /// <summary>
        /// The property is set to a bad value
        /// </summary>
        ValidationError,
        /// <summary>
        /// Use the given node as a parent for all event that will follow
        /// </summary>
        Push,
        /// <summary>
        /// Do not use the latest pushed event as a parent, revert to previous one on the stack
        /// </summary>
        Pop
    }

    public interface ISync<T>
    {
        /// <summary>
        /// The key which will be used to compare the Nodes to each other (such as file of directory name)
        /// </summary>
        string Key { get; }


        IEnumerable<PropertyChange<T>> Compare(T other);
    }


    /// <summary>
    /// Interface for a Node which can contain other nodes (composition pattern)
    /// </summary>
    /// <typeparam name="N">The type of the node</typeparam>
    public interface INodeColl<N> : ISync<N>
        where N : class, ISync<N>
    {
        /// <summary>
        /// The collection of all Node's children
        /// </summary>
        /// <returns>Enumerable of children nodes</returns>
        IEnumerable<N> GetChildren();
    }

    public class BaseChange<T>
    {
        /// <summary>
        /// The type of the change in this event
        /// </summary>
        public readonly ChangeType ChangeType;
        public readonly T NodeSrc;

        protected BaseChange(ChangeType changeType, T nodeSrc)
        {
            ChangeType = changeType;
            NodeSrc = nodeSrc;
        }
    }


    public class PropertyChange<T> : BaseChange<T>
    {


        public PropertyChange(T node, string prop, ChangeType changeType, object oldVal, object newVal, string commment)
            : this(node, prop, changeType, oldVal.ToString(), newVal.ToString(), commment)
        { }

        public PropertyChange(T node, string prop, ChangeType changeType, string oldVal, string newVal, string commment)
            :base(changeType, node)
        {
            PropertyName = prop;
            OldValue = oldVal;
            NewValue = newVal;
            Comment = commment;
        }

        public string PropertyName;
        public string OldValue;
        public string NewValue;
        public string Comment;
    }


    /// <summary>
    /// Represents a change of the Node of type T, can also be a message about pushing/popping a node into/from the parents stack
    /// </summary>
    /// <typeparam name="T">The type of the node</typeparam>
    public class NodeChange<T> : BaseChange<T>
    {
        /// <summary>
        /// Node from the old model (Removed will be shown only here)
        /// </summary>
        //public readonly T A;
        /// <summary>
        /// Node from the new mode (Added will be shown only here)
        /// </summary>
        public readonly T NodeDst;

        /// <summary>
        /// Constructor for a change message
        /// </summary>
        /// <param name="changeType">Change type</param>
        /// <param name="nodeSrc">Node from the old model (optional)</param>
        /// <param name="nodeDst">Node from the new model (optional)</param>
        public NodeChange(ChangeType changeType, T nodeSrc, T nodeDst)
            : base(changeType, nodeSrc)
        {
            NodeDst = nodeDst;
        }

        /// <summary>
        /// String representation of the change event
        /// </summary>
        /// <returns></returns>
        public override string ToString() => ChangeType switch
        {
            ChangeType.None => $"No Change: {NodeSrc} => {NodeDst}",
            ChangeType.Add => $"Added: {NodeDst}",
            ChangeType.Remove => $"Removed: {NodeSrc}",
            ChangeType.Update => $"Updated: {NodeSrc} => {NodeDst}",
            ChangeType.Push => $"Push directory: {NodeSrc}, {NodeDst}",
            ChangeType.Pop => $"Push directory: {NodeSrc}, {NodeDst}",
            _ => $"Unsupported change type: {ChangeType}"
        };
    }

    public static class SyncTools
    {
        public static IEnumerable<BaseChange<T>> SyncR<T>(INodeColl<T> parentA, INodeColl<T> parentB)
            where T : class, ISync<T>
        {
            var A = parentA.GetChildren().ToList();
            var B = parentB.GetChildren().ToList();

            //Processing nodes
            foreach (var ndA in A)
            {
                var nbB = B.SingleOrDefault(n => n.Key.Equals(ndA.Key));
                if (nbB is null) //a => null
                    yield return new NodeChange<T>(ChangeType.Remove, ndA, null);
                else //a => b - Node changed or equal?
                {
                    var propChanges = ndA.Compare(nbB).ToList(); //TODO: try to avoid ToList()
                    if (propChanges.Count > 0)
                    {
                        yield return new NodeChange<T>(ChangeType.Update, ndA, nbB);
                        foreach (var propChange in propChanges)
                            yield return propChange;
                    }
                    else
                        yield return new NodeChange<T>(ChangeType.None, ndA, nbB);

                    if (ndA is INodeColl<T> collA && ndA is INodeColl<T> collB)
                    {
                        yield return new NodeChange<T>(ChangeType.Push, ndA, nbB);
                        foreach (var res in SyncR(collA, collB))
                            yield return res;
                        yield return new NodeChange<T>(ChangeType.Pop, ndA, nbB);
                    }

                    B.Remove(nbB);
                }
            }

            foreach (var bBranch in B) //Only new remaining
            {
                yield return new NodeChange<T>(ChangeType.Add, null, bBranch);
            }
        }
    }
}
