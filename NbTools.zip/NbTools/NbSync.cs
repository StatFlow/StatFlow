﻿using System.Collections.Generic;
using System.Linq;

namespace NbTools.Sync
{
    /// <summary>
    /// Change type used in creating event about the changes in the model
    /// </summary>
    public enum ChangeType
    {
        /// <summary>
        /// The Node was not changed
        /// </summary>
        None,
        /// <summary>
        /// The node was added
        /// </summary>
        Add,
        /// <summary>
        /// The node was removed
        /// </summary>
        Remove,
        /// <summary>
        /// Some properties of the node have changed
        /// </summary>
        Update,
        /// <summary>
        /// The property is set to a bad value
        /// </summary>
        ValidationWarning,
        /// <summary>
        /// The property is set to a bad value
        /// </summary>
        ValidationError,
        /// <summary>
        /// Use the given node as a parent for all event that will follow
        /// </summary>
        //Push,
        /// <summary>
        /// Do not use the latest pushed event as a parent, revert to previous one on the stack
        /// </summary>
        //Pop
    }

    public interface ISync<T>
    {
        /// <summary>
        /// The key which will be used to compare the Nodes to each other (such as file of directory name)
        /// </summary>
        string Key { get; }


        IEnumerable<PropertyChange> GetChanges(T other);
    }


    /// <summary>
    /// Interface for a Node which can contain other nodes (composition pattern)
    /// </summary>
    /// <typeparam name="N">The type of the node</typeparam>
    public interface INodeColl<N> : ISync<N>
        where N : class, ISync<N>
    {
        /// <summary>
        /// The collection of all Node's children
        /// </summary>
        /// <returns>Enumerable of children nodes</returns>
        IEnumerable<N> GetChildren(string refTypeName);

        bool HasChildren(string refTypeName);
    }


    /// <summary>
    /// Represents a change of the Node of type T, can also be a message about pushing/popping a node into/from the parents stack
    /// </summary>
    /// <typeparam name="S">The type of the node</typeparam>
    public class NodeChange<S, D>
    {
        /// <summary>
        /// The type of the change in this event
        /// </summary>
        public readonly ChangeType ChangeType;

        /// <summary>
        /// Node from the source model (could be a file System)
        /// </summary>
        public readonly S NodeSrc;

        /// <summary>
        /// Node from the destination model (could be a file System)
        /// </summary>
        public readonly D NodeDst;

        /// <summary>
        /// Optional array of property changes
        /// </summary>
        public readonly PropertyChange[] PropChangesN;

        /// <summary>
        /// Constructor for a change message
        /// </summary>
        /// <param name="changeType">Change type</param>
        /// <param name="nodeSrc">Node from the source model (optional)</param>
        /// <param name="nodeDst">Node from the destination model (optional)</param>
        public NodeChange(ChangeType changeType, S nodeSrc, D nodeDst, IEnumerable<PropertyChange> propChanges = null)
        {
            ChangeType = changeType;
            NodeSrc = nodeSrc;
            NodeDst = nodeDst;

            if (propChanges != null)
                PropChangesN = propChanges.ToArray();
        }

        /// <summary>
        /// String representation of the change event
        /// </summary>
        /// <returns></returns>
        public override string ToString() => ChangeType switch
        {
            ChangeType.None => $"No Change: {NodeSrc} => {NodeDst}",
            ChangeType.Add => $"Added: {NodeSrc} => {NodeDst}",
            ChangeType.Remove => $"Removed: {NodeSrc} => {NodeDst}",
            ChangeType.Update => $"Updated: {NodeSrc} => {NodeDst}",
            //ChangeType.Push => $"Push directory: {NodeSrc}, {NodeDst}",
            //ChangeType.Pop => $"Pop directory: {NodeSrc}, {NodeDst}",
            _ => $"Unsupported change type: {ChangeType}"
        };
    }

    public class PropertyChange
    {
        public PropertyChange(ChangeType changeType, string prop, object oldVal, object newVal, string commment = null)
            : this(changeType, prop, oldVal.ToString(), newVal.ToString(), commment)
        { }

        public PropertyChange(ChangeType changeType, string prop, string oldVal, string newVal, string commment = null)
        {
            ChangeType = changeType;
            PropertyName = prop;
            OldValue = oldVal;
            NewValue = newVal;
            Comment = commment;
        }

        public readonly ChangeType ChangeType;
        public readonly string PropertyName;
        public readonly string OldValue;
        public readonly string NewValue;
        public readonly string Comment;

        /// <summary>
        /// String representation of the change event
        /// </summary>
        /// <returns></returns>
        public override string ToString() => ChangeType switch
        {
            ChangeType.Add => $"Property '{PropertyName}' added: '{OldValue}' => '{NewValue}' {Comment}",
            ChangeType.Remove => $"Property '{PropertyName}' removed: '{OldValue}' => '{NewValue}'  {Comment}",
            ChangeType.Update => $"Property '{PropertyName}' updated: '{OldValue}' => '{NewValue}'  {Comment}",
            //ChangeType.Push => $"Push directory: {NodeSrc}, {NodeDst}",
            //ChangeType.Pop => $"Pop directory: {NodeSrc}, {NodeDst}",
            _ => $"Unsupported change type: '{ChangeType}'"
        };
    }


    public static class SyncTools
    {
        public static IEnumerable<NodeChange<S, S>> SyncR<S>(INodeColl<S> parentAN, INodeColl<S> parentB, string refTypeName)
            where S : class, ISync<S>
        {
            var A = parentAN?.GetChildren(refTypeName)?.ToList();
            var B = parentB.GetChildren(refTypeName).ToList();

            //Processing nodes
            foreach (var ndA in A.Safe())
            {
                var ndB = B.SingleOrDefault(n => n.Key.Equals(ndA.Key));
                if (ndB is null) //a => null
                    yield return new NodeChange<S, S>(ChangeType.Remove, ndA, default);
                else //a => b - Node changed or equal?
                {
                    var propChanges = ndA.GetChanges(ndB);
                    if (propChanges.Any())
                        yield return new NodeChange<S, S>(ChangeType.Update, ndA, ndB, propChanges);
                    else
                        yield return new NodeChange<S, S>(ChangeType.None, ndA, ndB);

                    if (ndA is INodeColl<S> collA && ndB is INodeColl<S> collB && (collA.HasChildren(refTypeName) || collB.HasChildren(refTypeName))) //If both nodes are collections and one of them has children
                    {   //Push into subCollections and call the method recursively
                        //yield return new NodeChange<T>(ChangeType.Push, ndA, ndB);
                        foreach (var res in SyncR(collA, collB, refTypeName))
                            yield return res;
                        //yield return new NodeChange<T>(ChangeType.Pop, ndA, ndB);
                    }

                    B.Remove(ndB);
                }
            }

            foreach (var ndB in B) //Only new remaining
            {
                yield return new NodeChange<S, S>(ChangeType.Add, null, ndB);

                if (ndB is INodeColl<S> collB && collB.HasChildren(refTypeName)) //node is collection and has children
                {   //Push into subCollections and call the method recursively
                    //yield return new NodeChange<T>(ChangeType.Push, null, ndB);
                    foreach (var res in SyncR(null, collB, refTypeName)) //WARNING: This is good enough, because we need to attach these new nodes to the newly created collection A nodes
                        yield return res;
                    //yield return new NodeChange<T>(ChangeType.Pop, null, ndB);
                }
            }
        }
    }
}
