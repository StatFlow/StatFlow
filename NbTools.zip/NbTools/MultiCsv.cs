﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace NbTools
{
    public class MultiCsv
    {
        private readonly DirectoryInfo _di;
        private readonly CsvParameters _csvParam;
        private readonly Dictionary<Type, Dictionary<string, IdHolder>> holders = new Dictionary<Type, Dictionary<string, IdHolder>>();

        public MultiCsv(DirectoryInfo di, CsvParameters csvParam = null)
        {
            _di = di;
            _csvParam = csvParam;
        }

        public MultiCsv FromCsv<T>()
            where T : IdHolder, new()
        {
            if (holders.ContainsKey(typeof(T)))
                throw new CsvException("Type '{0}' objects are already loaded", typeof(T).Name);
            Dictionary<string, IdHolder> dict = NbExt.FromCsv<T>(_di, _csvParam).ToDictionary(h => h.Id, h => h as IdHolder);
            holders.Add(typeof(T), dict);
            return this;
        }

        public Dictionary<string, IdHolder> DictionaryOf<T>()
        {
            if (!holders.TryGetValue(typeof(T), out Dictionary<string, IdHolder> dict))
                throw new CsvException("Type '{0}' was not loaded", typeof(T).Name);
            return dict;
        }

        public bool TryGetValue<T>(string id, out T res)
            where T : IdHolder
        {
            var dict = DictionaryOf<T>();
            if (!dict.TryGetValue(id, out IdHolder hld))
            {
                res = null;
                return false;
            }
            else
            {
                res = (T)hld;
                return true;
            }
        }

        public T GetById<T>(string id)
            where T : IdHolder
        {
            if (!TryGetValue<T>(id, out T res))
                throw new CsvException("Object of type '{0}' with id = {1} doesn't exist", typeof(T).Name, id);
            return res;
        }

        public IEnumerable<T> EnumerableOf<T>()
            where T : IdHolder
        {
            return DictionaryOf<T>().Values.Cast<T>();
        }
    }
}
