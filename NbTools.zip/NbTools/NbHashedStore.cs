﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NbTools
{
    public class NbHashedStore
    {
        public readonly string RootDir;
        public readonly string Name;

        public NbHashedStore(string rootDir, string name)
        {
            Name = name;
            RootDir = rootDir;
            if (!Directory.Exists(rootDir)) throw new Exception($"Root directory '{rootDir}' of the hashed store '{Name}' was not found");
        }

        public string FullFileNameByHash(string hash, bool throwIfNotFound = true)
        {
            if (hash.Length <= 2) throw new Exception($"Hash value '{hash}' is too short");
            var fullPath = Path.Combine(RootDir, hash.Substring(0, 2), hash);
            if (throwIfNotFound && !File.Exists(fullPath))
                throw new Exception($"File with hash '{hash}' is not found in the '{Name}' hashed store");
            return fullPath;
        }

        public void SaveFileToStore(string srcFileName, string hash) => throw new NotImplementedException("SaveFileToStore");

        public void MoveFileOutOfStore(string hash, string dstFileName)
        {
            var srcFile = FullFileNameByHash(hash);

            FileInfo fi = new FileInfo(dstFileName);
            if (fi.Exists) throw new Exception($"Destination file '{dstFileName}' already exists, can't move a file out of the '{Name}' {nameof(NbHashedStore)}");
           
            NbExt.DirCreateRecursive(fi.Directory);
            File.Move(srcFile, dstFileName);
        }
    }
}
