﻿using System.Linq;
using System.IO;
using System.Text.RegularExpressions;
using System;

namespace NbTools.Media
{
    public static class NbMedia
    {
        public enum FileMediaTypes { Video, Photo, Audio, Other }

        public static string[] VideoExtensions = { ".mpg", ".mpeg", ".avi", ".asf", ".wmv", ".m2v", ".mp4", ".mkv", ".avi", ".ts", ".flv", ".mov" };
        public static string[] PhotoExtensions = { ".jpg", ".jpeg", ".png", ".webp", ".gif", ".jfif", ".svg", ".ico" };
        public static string[] AudioExtensions = { ".mp3", ".m4a", ".wav", ".ogg", ".mid", ".flac", ".ape" };
        public static string[] DocumentExtensions = { ".pdf", ".docx" };
        public static string[] LinkExtensions = { ".url" };

        public static FileMediaTypes GetFileMediaType(string extension)
        {
            if (VideoExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return FileMediaTypes.Video;
            else if (PhotoExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return FileMediaTypes.Photo;
            else if (AudioExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
                return FileMediaTypes.Audio;
            else
                return FileMediaTypes.Other;
        }



        public static (string url, string name) ProcessUrlLinkFile(FileInfo fi)
        {
            if (!fi.Extension.EqIC(".url"))
                throw new NbExceptionInfo("File provided for URl parsing doesn't have .url extension: " + fi.FullName);

            var lines = File.ReadAllLines(fi.FullName);
            try
            {   //Simplified Parse Ini
                if (lines.Length == 0) throw new Exception("No lines in URL file");
                if (lines[0].Trim() != "[InternetShortcut]") throw new Exception("URL file doesn't start with [InternetShortcut]");
                var dict = new NbDictionary<string, string>(lines.Length - 1, StringComparer.InvariantCultureIgnoreCase, $"Lines of {fi.Name} file");
                foreach (var line in lines.Skip(1))
                {
                    int eqInd = line.IndexOf("=");

                    if (eqInd == -1) throw new Exception($"Line '{line}' doesn't contain '='");
                    var key = line.Substring(0, eqInd);
                    var val = line.Substring(eqInd + 1);
                    dict.Add(key, val);
                }

                return (dict["url"], fi.NameWithoutExtension());
            }
            catch (Exception ex) { throw new Exception($"Error processing URL file '{fi.FullName}'\r\n{String.Join(Environment.NewLine, lines)}", ex); }
        }


        public static string GetNewFileInSequenceN(string aMediaDir)
        {
            string ext = null;
            foreach (var fi in new DirectoryInfo(aMediaDir).GetFiles().Where(f => !f.Name.Equals("Thumbs.db") && !f.Name.Equals("desktop.ini")).OrderBy(fi => fi.Name))
            {
                if (ext == null && VideoExtensions.Any(ex => ex.Equals(fi.Extension, StringComparison.OrdinalIgnoreCase))) //If the first file in the list with video extension
                {
                    ext = fi.Extension;
                    fi.MoveTo(fi.FullName.Substring(0, fi.FullName.Length - fi.Extension.Length)); // Remove extension from the current file
                }
                else if (ext != null)
                {
                    string newName = fi.FullName + ext;
                    fi.MoveTo(newName);
                    return newName;
                }
            }
            return null;
        }

        /*private static Regex DateTakenRegex
        {
            get
            {
                if (fDateTakenRegex == null)
                    fDateTakenRegex = new Regex(":");
                return fDateTakenRegex;
            }
        }
        private static Regex fDateTakenRegex;

        public static DateTime GetDateTakenFromImage(FileInfo fi)
        {
            try
            {
                using (FileStream fs = new FileStream(fi.FullName, FileMode.Open, FileAccess.Read))
                using (Image myImage = Image.FromStream(fs, false, false))
                {
                    PropertyItem propItem = myImage.GetPropertyItem(36867);
                    string dateTaken = DateTakenRegex.Replace(Encoding.UTF8.GetString(propItem.Value), "-", 2);
                    return DateTime.Parse(dateTaken);
                }
            }
            catch (ArgumentException)
            {
                return fi.LastWriteTime;
            }
        }*/
    }
}
