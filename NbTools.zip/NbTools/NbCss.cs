﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NbTools
{
    public class NbCss
    {
        private readonly List<NbCssElement> Vals = new List<NbCssElement>(50);
        private readonly Dictionary<string, NbCssIcon> Icons = new Dictionary<string, NbCssIcon>();
        private readonly string preloadTextN;
        private readonly DirectoryInfo graphicsDir;

        public NbCss(DirectoryInfo graphDir, string preloadText = null)
        {
            graphicsDir = graphDir;
            preloadTextN = preloadText;
        }

        public void Add(NbCssRule rule)
        {
            if (Vals.Exists(r => r.Name.EqIC(rule.Name)))
                throw new Exception($"Css rule {rule.Name} already exists in the collection");
            else
                Vals.Add(rule);
        }

        public string AddIcon(string fileName)
        {
            var nameNoExt = Path.GetFileNameWithoutExtension(fileName);
            if (!Icons.TryGetValue(nameNoExt, out var icon))
            {
                var fi = new FileInfo(Path.Combine(graphicsDir.FullName, fileName));
                if (!fi.Exists)
                    throw new Exception($"Icon '{fi.FullName}' doesn't exist!");

                icon = new NbCssIcon(fi);
                Icons.Add(nameNoExt, icon);
            }
            return icon.Name;
        }

        public void WriteMultiline(TextWriter wrtr)
        {
            if (!String.IsNullOrEmpty(preloadTextN))
                wrtr.WriteLine(preloadTextN);

            Vals.ForEachSafe(r => r.WriteMultiline(wrtr));
            Icons.Values.ForEachSafe(r => r.WriteMultiline(wrtr));
        }
    }

    public abstract class NbCssElement : IEquatable<NbCssElement>
    {
        public string Name { get; protected set; }
        public bool Equals(NbCssElement other) => Name.Equals(other.Name);

        public void WriteMultiline(TextWriter wrtr)
        {
            wrtr.Write('.');
            wrtr.Write(Name);
            wrtr.WriteLine(" {");
            foreach (var pair in GetRules())
            {
                wrtr.Write(pair.Key);
                wrtr.Write(": ");
                wrtr.Write(pair.Value);
                wrtr.WriteLine(";");
            }
            wrtr.WriteLine('}');
        }

        protected abstract IEnumerable<KeyValuePair<string, string>> GetRules();
    }

    public class NbCssIcon : NbCssElement
    {
        private readonly FileInfo FileInfo;

        public NbCssIcon(FileInfo fi)
        {
            FileInfo = fi;
            if (!FileInfo.Exists)
                throw new Exception($"File '{FileInfo.FullName}' doesn't exist");
            Name = "i_" + Path.GetFileNameWithoutExtension(FileInfo.Name);
        }

        protected override IEnumerable<KeyValuePair<string, string>> GetRules()
        {
            //url(data:image/png;base64,XXX )
            StringBuilder bld = new StringBuilder("url(data:image/");
            bld.Append(FileInfo.ExtensionWithoutDot().ToLowerInvariant());
            bld.Append(";base64,");
            bld.Append(Convert.ToBase64String(File.ReadAllBytes(FileInfo.FullName)));
            bld.Append(')');

            return NbExt.Yield(new KeyValuePair<string, string>("background-image", bld.ToString()));
        }
    }

    public class NbCssRule : NbCssElement
    {
        private readonly NbDictionary<string, string> fDecl;
        protected override IEnumerable<KeyValuePair<string, string>> GetRules() => fDecl;

        public NbCssRule(string name, IEnumerable<Tuple<string, string>> tagsN = null)
        {
            Name = name;
            fDecl = new NbDictionary<string, string>(5);
            tagsN.ForEachSafe(t => fDecl.Add(t.Item1, t.Item2));
        }

        public NbCssRule(string name, params Tuple<string, string>[] tags)
        {
            Name = name;
            fDecl = new NbDictionary<string, string>(5);
            tags.ForEachSafe(t => fDecl.Add(t.Item1, t.Item2));
        }

        public NbCssRule this[string attrName, string attValue] { get { fDecl.Add(attrName, attValue); return this; } }
        public string this[string attrName] { set { fDecl.Add(attrName, value); } }
    }
}
