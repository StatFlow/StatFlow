﻿using NbCollV1;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace NbTools.Collections
{
    [Flags]
    public enum SyncMode
    {
        None = 0, Append = 1, Update = 2, Remove = 4,
        All = Append | Update | Remove,
        AppendUpdate = Append | Update,
    };
    public enum CbCollChangedEventType { Reset, RowAppended, RowDeleted };

    public interface ICbChangeListener
    {
        void CbCollChanged(CbCollection collection, CbCollChangedEventType eventType, int rowNum);
        void CbCollValueChanged(CbCollection collection, ICbCollectionColumn column, int ind);
    }

    public delegate void CbCollChanged(CbCollection collection, CbCollChangedEventType eventType, int rowNum);
    public delegate void CbCollValueChanged(CbCollection collection, ICbCollectionColumn column, int ind);

    public class CbCollection
    {
        protected internal readonly NbDictionary<string, ICbCollectionColumn> fColumns;
        public IReadOnlyDictionary<string, ICbCollectionColumn> Columns => fColumns;
        public ICbCollectionColumn this[string name] => fColumns[name];
        public int Count => fCount - fDeleted.Count;
        private int fCount = 0; //This is useful for tracking internal and external dependencies

        private readonly HashSet<int> fDeleted = new HashSet<int>(); //TODO: think about bitmap collection here

        public bool IsDeleted(int index) => fDeleted.Contains(index);

        public readonly string Name;
        internal readonly int Capacity;
        private readonly DfTable TableDefN; //TODO: Think about generating it, if it is not available

        public CbCollection(string name, int capacity = 0)
        {
            Name = name;
            Capacity = capacity;

            fColumns = new NbDictionary<string, ICbCollectionColumn>(32, StringComparer.OrdinalIgnoreCase,
                $"{name} columns dictionary");
        }

        public CbCollection(DfTable tableDef, int capacity = 0)
        {
            Name = tableDef.name;
            TableDefN = tableDef;
            Capacity = capacity;

            fColumns = new NbDictionary<string, ICbCollectionColumn>(32, StringComparer.OrdinalIgnoreCase,
                $"{Name} columns dictionary");
        }

        public virtual IEnumerable<int> All
        {
            get
            {
                for (int i = 0; i < fCount; ++i)
                {
                    if (!fDeleted.Contains(i))
                        yield return i;
                }
            }
        }

        public ICbCollectionColumn GetOrCreateColumn(string colName)
        {
            if (fColumns.TryGetValue(colName, out var col))
                return col;

            //TODO: event new column created
            col = new CbString(this, colName);
            fColumns.Add(colName, col);
            return col;
        }

        public ICbCollectionColumn CreateColumn<T>(string colName) where T : ICbCollectionColumn
        {
            if (fColumns.TryGetValue(colName, out var col))
                return col;

            col = typeof(T).Name switch
            {
                nameof(CbString) => new CbString(this, colName),
                nameof(CbBoolean) => new CbBoolean(this, colName),
                nameof(CbInt32) => new CbInt32(this, colName),
                nameof(CbInt64) => new CbInt64(this, colName),
                _ => throw new NbException($"Type {typeof(T).Name} is not supported in GetOrCreateColumn"),
            };
            //TODO: event new column created
            fColumns.Add(colName, col);
            return col;
        }

        /// <summary>
        /// Replaces columns with strings with the columns with references, if link type fields are found
        /// </summary>
        /// <param name="allTables"></param>
        internal void Resolve(NbDictionary<string, CbCollection> allTables)
        {
            foreach (var fldDef in TableDefN?.fields?.Items?.Safe())
            {
                switch (fldDef?.link?.Length ?? 0)
                {
                    case 0: break; //No links - nothing to resolve
                    case 1:
                        var lnk = fldDef.link[0];

                        if (!fColumns.TryGetValue(fldDef.name, out var srcColumn))
                            throw new NbException($"Can't find field '{Name}.{fldDef.name}'");

                        if (!allTables.TryGetValue(lnk.ref_table ?? Name, out var dstColl))
                            throw new NbException($"Field '{TableDefN.name}.{fldDef.name}' refers to table '{lnk.ref_table}' which can't be found in xml");

                        var reffKeyCollection = dstColl as CbKeyedCollection ?? throw new NbException($"Reffered table '{dstColl.Name}' is not a Keyed Collection");

                        if (!reffKeyCollection.Columns.TryGetValue(lnk.ref_field, out var dstColumn))
                            throw new NbException($"Field '{TableDefN.name}.{fldDef.name}' refers to field '{lnk.ref_table}.{lnk.ref_field}' which can't be found in this table");

                        if (dstColumn != reffKeyCollection.KeyN)
                            throw new NbException($"Field '{TableDefN.name}.{fldDef.name}' refers to non-primary field '{lnk.ref_table}.{lnk.ref_field}'. Such reference is not yet supported");

                        switch (srcColumn)
                        {
                            case CbCollectionColumn<string> srcStringCol: TypedRefColumnCreation(srcStringCol, dstColumn, fldDef.name); break;
                            case CbCollectionColumn<int> srcInt32Col: TypedRefColumnCreation(srcInt32Col, dstColumn, fldDef.name); break;

                            default:
                                throw new NbExceptionInfo($"Unsupported type of column '{srcColumn.GetType().Name}' CbReferenceColumn creation");
                        }
                        break;
                    default:
                        throw new NbException($"Field '{TableDefN.name}.{fldDef.name}' has more than one link subnode, the resolution is not supported");
                }
            }
        }

        private void TypedRefColumnCreation<T>(CbCollectionColumn<T> srcCol, ICbCollectionColumn dstCol, string colName)
        {
            if (!(dstCol is CbCollectionKeyColumn<T> dstTyped))
                throw new NbExceptionInfo($"In reference source and destination columns must have the same type. {srcCol.FullName} has type {srcCol.GetType().Name}  and references {dstCol.FullName} of type {dstCol.GetType().Name}.");

            CbReferenceColumn<T> refCol = new CbReferenceColumn<T>(this, srcCol, dstTyped);
            fColumns[colName] = refCol; //Replacing the text column with the reference column
        }

        private void IndexCheck(int ind)
        {
            if (ind < 0 || ind >= fCount)
                throw new Exception($"Index '{ind}' is out of bounds for collection '{Name}'");
        }
        //TODO: block the collection while a row is selected
        public void Select(int ind) //TODO: Reset and Select could return transaction object with Update on them
        {
            IndexCheck(ind);
            fColumns.Values.ForEachSafe(f => f.SelectBuffer(ind));
        }

        public void Reset() => fColumns.Values.ForEachSafe(f => f.ResetBuffer()); //TODO: Reset and Select could return transaction object with Update on them
        public void Append()
        {
            fCount++;
            foreach (var fld in fColumns.Values)
            {
                fld.AppendBuffer();
                Debug.Assert(fld.Count == fCount);
            }
            if (EventSuppressorN == null)
                OnChanged?.Invoke(this, CbCollChangedEventType.RowAppended, fCount - 1);
        }

        public string GetLineText(int rowNum)
        {
            return (fDeleted.Contains(rowNum) ? "Deleted: " : String.Empty) +
             String.Join(", ", fColumns.Values.Select(f => $"{f.Name}: '{f.GetText(rowNum)}'"));
        }

        internal void UpdateAt(int index)
        {
            fColumns.Values.ForEachSafe(f => f.UpdateFromBufferAt(index));

            if (OnValueChanged != null && EventSuppressorN == null)
            {
                fColumns.Values.Safe().Where(f => f.ValueChanged).ForEachSafe(f => OnValueChanged(this, f, index));
            }
        }

        internal void DeleteAt(int index)
        {
            if (fDeleted.Contains(index))
                return;

            fDeleted.Add(index);
            if (EventSuppressorN == null)
                OnChanged?.Invoke(this, CbCollChangedEventType.RowDeleted, index);
        }

        public CbCollection DeleteColumn(string colName)
        { fColumns.Remove(colName); return this; } //TODO: Reset event

        public CbCollection RenameColumn(string oldName, string newName)
        {
            if (fColumns.ContainsKey(newName))
                throw new Exception($"Colection {Name} already contains a column {newName}");

            var col = fColumns[oldName];
            fColumns.Remove(oldName);
            col.Rename(newName);
            fColumns.Add(col.Name, col); //Adding with new name
            return this;
        }

        public string LineToCsv(int index, char sep = ',')
        {
            IndexCheck(index);
            return String.Join(sep.ToString(), fColumns.Values.Select(f => f.GetText(index)));
        }

        #region Events

        public class EventSuppressor : IDisposable
        {
            private readonly CbCollection fColl;
            internal EventSuppressor(CbCollection coll) { fColl = coll; }

            public void Dispose()
            {
                fColl.RestoreEvents(this);
            }
        }

        private EventSuppressor EventSuppressorN;
        public EventSuppressor SuppressEvents()
        {
            if (EventSuppressorN != null)
                throw new Exception("Events are already suppressed");
            return EventSuppressorN = new EventSuppressor(this);
        }

        private void RestoreEvents(EventSuppressor supp)
        {
            if (EventSuppressorN != supp)
                throw new Exception("Wrong event suppressor");
            EventSuppressorN = null;
        }

        public event CbCollChanged OnChanged;
        public event CbCollValueChanged OnValueChanged;
        #endregion Events
    }
}

