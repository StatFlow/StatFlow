﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

using NbCollV1;

namespace NbTools.Collections
{
    public class DfDynamicCollection : DfCollection
    {
        private const string DefaultCsvFieldType = "VARCHAR2_200";

        protected readonly List<Tuple<IDfColumnBase, DfField>> fCols;
        protected readonly List<DfColumnBackReference> fBackReferenceFields = new List<DfColumnBackReference>(10);

        public DfDynamicCollection(string name) : base(name)
        {
            fCols = new List<Tuple<IDfColumnBase, DfField>>();
        }

        public override string ToString() => $"{CollectionName}: {fCols.Count} cols, {Count} rows";

        public void Synchronize(DfDynamicCollection other)
        {
            var thisKey = PrimaryKeyColumn ?? throw new Exception("this collection doesn't have a key column in Synchronize method");
            var otherKey = other.PrimaryKeyColumn ?? throw new Exception("other collection doesn't have a key column in Synchronize method");
            if (thisKey.GetType() != otherKey.GetType()) throw new Exception($"this and other collection key column have different type: this = {thisKey.GetType().Name}, other = {otherKey.GetType()}");



        }

        public IEnumerable<Tuple<IDfColumnBase, DfField>> ColumnsOrdererByLayout()
            => fCols.Where(p => p.Item2.col_position >= 0).OrderBy(p => p.Item2.col_position)
                .Concat(fCols.Where(p => p.Item2.col_position < 0)); //Ordered are followed by unordered and hidden

        /*public List<dynamic> GetDynamics()
{
   var list = new List<dynamic>(Count);
   for(int i = 0; i < Count; ++i)
   {
       dynamic line = new System.Dynamic.ExpandoObject();
       var dict = (IDictionary<String, Object>)line;
       fCols.ForEach(c => dict.Add(c.Item1.Name, c.Item1.GetObject(i)));
       list.Add(line);
   }
   return list;
}*/

        public List<string> GetKVStrings
        {
            get
            {
                StringBuilder bld = new StringBuilder();
                var list = new List<string>(Count);
                for (int i = 0; i < Count; ++i)
                {
                    bld.Clear();
                    bool first = true;
                    foreach(var c in fCols)
                    {
                        if (!first)
                            bld.Append(',');

                        bld.Append(c.Item1.Name).Append('=').Append(c.Item1.GetText(i));
                        first = false;
                    }
                    list.Add(bld.ToString());
                }
                return list;
            }
        }


        public override IDfColumnBase PrimaryKeyColumn => fCols.FirstOrDefault(p => p.Item2.IsPrimary)?.Item1;
        public IDfColumnBase ParentKeyColumnN => fCols.FirstOrDefault(c => c.Item2.key == DfKey.parent_id).Item1;

        public override IEnumerable<int> SavingOrder => Enumerable.Range(0, Count); //No particular order implemented yet

        public bool TryGetColumn(string name, out IDfColumnBase col)
        {
            col = fCols.FirstOrDefault(c => c.Item1.Name.Equals(name)).Item1;
            return col != null;
        }

        public void AddColumn(IDfColumnBase column, DfField dfField)
        {
            if (fCols.Any(c => c.Item1.Name.EqIC(column.Name)))
                throw new Exception($"Column {column.Name} already exist");

            fCols.Add(Tuple.Create(column, dfField));
        }
        
        public void InsertColumnAfter(string afterColumnName, IDfColumnBase column, DfField dfFieldN = null)
        {
            int ind = fCols.FindIndex(c => c.Item1.Name.EqIC(afterColumnName));
            if (ind < 0)
                throw new Exception($"Can't find column '{afterColumnName}'");

            InsertColumnAfter(ind + 1, column, dfFieldN);
        }

        public void InsertColumnAfter(int index, IDfColumnBase column, DfField dfFieldN = null)
        {
            if (index < 0 || index > fCols.Count)
                throw new ArgumentException($"Index {index} to insert to is out of range. There are {fCols.Count} columns");

            if (fCols.Any(c => c.Item1.Name.EqIC(column.Name)))
                throw new Exception($"Column {column.Name} already exist");

            if (dfFieldN == null)
                dfFieldN = new DfField { name = column.Name, @null = false };

            if (index == fCols.Count)
                fCols.Add(Tuple.Create(column, dfFieldN));
            else
                fCols.Insert(index, Tuple.Create(column, dfFieldN));
        }

        public IDfColumnBase GetColumn(string name) => GetColumn<IDfColumnBase>(name);

        public T GetColumn<T>(string name)
            where T : class, IDfColumnBase
        {
            var col = fCols.SingleVerbose(cl => cl.Item1.Name == name,
                () => $"Column '{name}' is not found in the table '{CollectionName}'",
                i => $"{i} Columns '{name}' were found in the table '{CollectionName}'").Item1;

            return col switch
            {
                T ret => ret,
                _ => throw new Exception($"Column '{name}' of the table '{CollectionName}' is '{col.GetType().Name}' and can't be cast to '{typeof(T).Name}'"),
            };
        }

        public void ReplaceColumn(IDfColumnBase dfColRef)
        {
            int ind = fCols.FindIndex(p => p.Item1.Name.Equals(dfColRef.Name));
            if (ind < 0)
                throw new Exception($"Can't replace column '{dfColRef.Name}', the original column is not found in the table '{CollectionName}'");

            var toInsert = Tuple.Create(dfColRef, fCols[ind].Item2); //Get the value from ind before deleting it on the next line
            fCols.RemoveAt(ind);
            fCols.Insert(ind, toInsert);//Keep the same field xml description
        }

        public override IEnumerable<IDfColumnBase> GetColumns() => fCols.Select(p => p.Item1);
        public IReadOnlyList<Tuple<IDfColumnBase, DfField>> GetColumnsAndDesc() => fCols.Select(p => Tuple.Create(p.Item1, p.Item2)).ToList();

        public void AddBackreferenceField(DfColumnBackReference backRefField) => fBackReferenceFields.Add(backRefField);

        override protected void ProcessCsvHeaders(IEnumerable<string> headers, DfTable recSetN)
        {
            //For csv loading
            foreach (string fldName in headers)
            {
                if (recSetN != null && recSetN.TryGetField(fldName, out var fldDesc)) //Field description is found in the xml
                { }
                else //Field description is not found, assume string
                {
                    fldDesc = new DfField { name = fldName, type = DfType.@string, @null = true }; //Wihtout any info string nullable is the safest type
                }

                var col = DfColumnBase<int>.CreateColumn(this, fldDesc);
                fCols.Add(Tuple.Create(col, fldDesc));
            }
        }

        /// <summary>
        /// Takes a sequence of xml elements, each of them will be represented as a string
        /// </summary>
        /// <param name="elements"></param>
        public void LoadFromXml(IEnumerable<XElement> elements, DfTable recSet)
        {
            bool first = true;
            foreach (var baseElem in elements)
            {
                if (first)
                {
                    ProcessCsvHeaders(baseElem.FlattenXElementAndAttributesSkipRoot().Select(e1 => e1.Item1), recSet);
                    first = false;
                }

                AddLine();
                foreach (var triple in baseElem.FlattenXElementAndAttributesSkipRoot())
                {
                    var (dfColumn, Item2) = fCols.FirstOrDefault(c => c.Item1.Name.EqIC(triple.Item1));
                    if (dfColumn == null)
                    {
                        //TODO: create column dynamically here
                        throw new NbExceptionInfo("Dynamic creation of columns is not supported for XML parsing");
                    }

                    dfColumn.SetText(triple.Item2?.Value ?? triple.Item3?.Value);
                }
                ReleaseLine();

                /*Count++;
                foreach (var (dfColumn, Item2) in fCols.Where(c => c.Item1.Count < Count)) //Filing in the rest of columns with null
                {
                    dfColumn.CreateText(null);
                }
                if (!fCols.Any(c => c.Item1.Count != Count))
                {
                    var badCols = String.Join(", ", fCols.Where(c => c.Item1.Count != Count).Select(c => $"{c.Item1.Name}({c.Item1.Count})"));
                    throw new Exception($"Main counter {Count}, these columns don't match: {badCols}");
                }*/

                Debug.Assert(!fCols.Any(c => c.Item1.Count != Count), "Column length and variable length don't match");
            }
        }

        public void CreateNew(DfTable layout)
        {
            foreach (DfField fldDesc in layout.fields.Items)
            {
                var col = DfColumnBase<int>.CreateColumn(this, fldDesc);
                fCols.Add(Tuple.Create(col, fldDesc));
            }
        }

        public override bool LoadFromCsv(string fileName, DfTable recSetN, CsvParameters csvParamN = null)
        {
            try
            {
                if (!File.Exists(fileName))
                    return false; //empty file

                Encoding enc = csvParamN?.EncodingN ?? defaultEnconding;
                using Stream strm = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                using StreamReader rdr = new StreamReader(strm, enc);
                return LoadFromCsv(rdr, recSetN, csvParamN);
            }
            catch(Exception ex) { throw new NbException(ex, $"Failure reading csv file '{fileName}'"); }
        }



        public override bool LoadFromCsv(TextReader rdr, DfTable recSetN, CsvParameters csvParamN = null)
        {
            StringBuilder bld = new StringBuilder();
            List<string> columnNames = GetColumnsFromHeaderOrParameters(rdr, csvParamN, bld, out char sep);
            ProcessCsvHeaders(columnNames, recSetN); //Can create columns out of headers here

            var Columns = GetColumns().ToList(); //Columns can be created at the previous step
            int[] colIndArr = new int[columnNames.Count];
            for (int i = 0; i < columnNames.Count; ++i)
            {
                var ind = Columns.FindIndex(c => c.Name.Equals(columnNames[i], StringComparison.OrdinalIgnoreCase));
                colIndArr[i] = ind;
                if (ind < 0)
                    csvParamN?.Warning($"Column '{columnNames[i]}' is present in csv is not found in the DfCollection");
            }

            foreach (var col in Columns)
            {
                var ind = columnNames.FindIndex(cn => cn.Equals(col.Name, StringComparison.OrdinalIgnoreCase));
                if (ind < 0)
                    csvParamN?.Warning($"Column '{col.Name}' is present in DfCollection but not found in csv. Nullable fields will be set to null");
            }

            int lineCounter = 1; //The header is already read
            while (rdr.Peek() != -1) //Same as EOF
            {
                lineCounter++;
                Debug.Assert(!Columns.Any(c => c.Count != Count), "Column length and variable length don't match");
                int colNum = 0;
                AddLine();
                foreach (var str in NbExt.DeCsvLine2(rdr, bld, sep, csvParamN?.Trim ?? false))
                {
                    if (colNum >= colIndArr.Length)
                        break;
                    int ind = colIndArr[colNum];
                    if (ind >= 0) //There is a corresponding column in collection
                        Columns[ind].SetText(str);
                    colNum++;
                }
                ReleaseLine();
                //Count++;
                Debug.Assert(!Columns.Any(c => c.Count != Count), "Column length and variable length don't match");
            }
            //Changed?.Invoke(DfCollChangedEventType.Reset); TODO:
            return true;
        }

        public List<string> GetColumnsFromHeaderOrParameters(TextReader rdr, CsvParameters csvParamN, StringBuilder bld, out char sep)
        {
            List<string> columnNames;
            if (csvParamN?.QuoatedFields ?? false)
            {
                sep = csvParamN?.FieldDelimiterN ?? ','; //Default separator
                if (!String.IsNullOrEmpty(csvParamN?.HeadersN))
                {   //Headers provided in parameters 
                    columnNames = csvParamN.HeadersN.Split(sep).ToList();

                    if (csvParamN?.HeadersAreInTheFile ?? true) //Read the headers line, but ignore it (provided headers take precedence)
                        NbExt.DeCsvLine2(rdr, bld, sep, trim: false).ToList();
                }
                else
                {   //Headers were not provided in parameters
                    if (!(csvParamN?.HeadersAreInTheFile ?? true))
                        throw new Exception("No headers in the file and no header string provided in the paramenters");

                    columnNames = NbExt.DeCsvLine2(rdr, bld, sep, trim: true) //always trim headers
                        .Select(h1 => (h1.StartsWith("[") && h1.EndsWith("]")) ? h1.Substring(1, h1.Length - 1) : h1) //Handle fields like [ID]
                        .ToList(); //Header
                }
            }
            else
            {
                string headerLine = null;
                if (csvParamN?.HeadersAreInTheFile ?? true)
                    headerLine = rdr.ReadLine();
                if (!String.IsNullOrEmpty(csvParamN?.HeadersN)) //Headerline provided in the parameters takes precedence
                    headerLine = csvParamN.HeadersN;
                if (String.IsNullOrEmpty(headerLine))
                    throw new Exception("No headers in the file and no header string provided in the paramenters");

                sep = csvParamN?.FieldDelimiterN ?? supportedSeparators.Select(sp => Tuple.Create(sp, headerLine.Split(sp).Length))
                    .OrderByDescending(pair => pair.Item2).FirstOrDefault().Item1;
                columnNames = NbExt.DeCsvLine(headerLine, bld, sep, trim: true) //always trim headers
                    .Select(h1 => (h1.StartsWith("[") && h1.EndsWith("]")) ? h1.Substring(1, h1.Length - 1) : h1) //Handle fields like [ID]
                    .ToList(); //Header
            }

            if ((columnNames?.Count ?? 0) == 0)
                throw new Exception($"Can't read header while loading {CollectionName} collection from csv");
            return columnNames;
        }

        public IDfColumnBase AddField(DfType cType, string fldName)
        {
            var fldDesc = new DfField { name = fldName, type = cType, @null = true }; //By default allow nulls
            switch (cType)
            {
                /*case CType.byte:  break;
                case CType.sbyte: break;
                case CType.char:  break;
                case CType.double: break;
                case CType.float: break;
                case CType.blob: break;*/

                case DfType.@bool:
                case DfType.@char:
                case DfType.@short:
                    fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnInt16(fldName, this, fldDesc.@null), fldDesc)); break;

                //case CType.@ushort: fCols.Add(new DfColumnInt<ushort?>(fldName, this)); break;
                case DfType.@int: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnInt32(fldName, this, fldDesc.@null), fldDesc)); break;
                //case CType.@uint: fCols.Add(new DfColumnInt<uint?>(fldName, this)); break;
                case DfType.@long: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnInt64(fldName, this, fldDesc.@null), fldDesc)); break;
                //case CType.@ulong: fCols.Add(new DfColumnInt<ulong?>(fldName, this)); break;

                case DfType.@decimal: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnDecimal(fldName, this, fldDesc.@null), fldDesc)); break;

                case DfType.@string: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnString(fldName, this, fldDesc.@null), fldDesc)); break;
                case DfType.DateTime: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnDateTime(fldName, this, fldDesc.@null), fldDesc)); break;

                default:
                    throw new NbExceptionInfo($"Unsupported CType {cType} when adding a field");
            }
            return fCols[fCols.Count].Item1;
        }

        public async Task LoadFromDbAsync(INbConn conn, string sql, DfTable layoutTableN, int maxRowCount)
        {
            using var rdr = conn.CreateReader(sql);
            int colCount = await rdr.FieldCount();
            int primColInd = -1; //Not found

            for (int ci = 0; ci < colCount; ci++) //For each field in the first row
            {
                string fldName = rdr.GetName(ci);

                DfType cType;
                if (layoutTableN != null && layoutTableN.TryGetField(fldName, out DfField fldDesc)) //Field description is found in the xml
                {
                    cType = fldDesc.type;
                    if (fldDesc.IsPrimary)
                        primColInd = ci; //Save primary field index for blob fields - they will need to read from it, not from the blob itself

                    if (fldDesc.IsFieldRef && fldDesc.link[0].ref_type == RefTypes.blob) //Force blob cType - may be implemented differently, 
                        cType = DfType.blob;
                }
                else //Field description is not found, determine type
                {
                    var tName = rdr.GetFieldType(ci).Name;
                    cType = tName switch
                    {
                        nameof(String) => DfType.@string,
                        nameof(Decimal) => DfType.@decimal,
                        nameof(Int64) => DfType.@long,
                        nameof(Int32) => DfType.@int,
                        nameof(Int16) => DfType.@short,
                        nameof(DateTime) => DfType.DateTime,
                        nameof(Boolean) => DfType.@bool,
                        "Byte[]" => DfType.blob,
                        _ => throw new Exception($"Can't convert '{tName}' to DfType"),
                    };
                    fldDesc = new DfField { name = fldName, type = cType, @null = true }; //By default allow nulls
                }

                switch (cType)
                {
                    /*case CType.byte:  break;
                    case CType.sbyte: break;
                    case CType.char:  break;
                    case CType.double: break;
                    case CType.float: break;
                    case CType.blob: break;*/

                    case DfType.@bool:
                    case DfType.@char:
                    case DfType.@short:
                        fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnInt16(fldName, this, fldDesc.@null), fldDesc)); break;

                    //case CType.@ushort: fCols.Add(new DfColumnInt<ushort?>(fldName, this)); break;
                    case DfType.@int: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnInt32(fldName, this, fldDesc.@null), fldDesc)); break;
                    //case CType.@uint: fCols.Add(new DfColumnInt<uint?>(fldName, this)); break;
                    case DfType.@long: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnInt64(fldName, this, fldDesc.@null), fldDesc)); break;
                    //case CType.@ulong: fCols.Add(new DfColumnInt<ulong?>(fldName, this)); break;

                    case DfType.@decimal: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnDecimal(fldName, this, fldDesc.@null), fldDesc)); break;

                    case DfType.@string: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnString(fldName, this, fldDesc.@null), fldDesc)); break;
                    case DfType.DateTime: fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnDateTime(fldName, this, fldDesc.@null), fldDesc)); break;

                    case DfType.blob:
                        {
                            if (fldDesc.link != null && fldDesc.link.Length > 0) //Referring to the blob in this table
                            {
                                if (layoutTableN.PrimaryKeyN == null)
                                    throw new Exception($"Primary field must be defined for the BLOB field '{fldName}' in the recordset '{layoutTableN.name}'");

                                if (layoutTableN.PrimaryKeyN.IsNumeric) //The primary key will be stored in the Blob Column, so its type drives the type of Blob column
                                    fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnBlobInt64(fldName, this, fldDesc.@null, layoutTableN.name, layoutTableN.PrimaryKeyN.name, isSameTable: true), fldDesc));
                                else
                                    fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnBlobString(fldName, this, fldDesc.@null, layoutTableN.name, layoutTableN.PrimaryKeyN.name, isSameTable: true), fldDesc));
                            }
                            else //Referring the the BLOB in another table
                            {
                                break;
                                //var fldRef = fldDesc.link[0]; //TODO: revisit and support multiple refs
                                //fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnBlobString(fldName, this, fldDesc.@null, layoutTableN.name, layoutTableN.PrimaryKeyN.name, isSameTable: true), fldDesc));
                                //break;

                                /* var fldRef = fldDesc.link[0]; //TODO: revisit and support multiple refs
                                 if (fldRef == null)
                                     throw new Exception($"field_ref description in the recordset must be provided for the BLOB field '{fldName}' in the recordset '{layoutTableN.name}'");

                                 string key_fld = fldRef.uri_key_field; //Use the explicit reference to the fields where the key value for the blob is located
                                 if (String.IsNullOrEmpty(key_fld))
                                 {
                                     if (fldRef.ref_table == null)
                                         throw new Exception($"ref_table is not set in the  field_ref description  in the recordset for the BLOB field '{fldName}'  in the recordset '{layoutTableN.name}'");

                                     //Fix later
                                     var primColN = fldRef.Recordset.PrimaryKeyN;
                                     if (primColN == null)
                                         throw new Exception($"BLOB field '{fldName}'  in the recordset '{recSet.name}' refers to the table '{fldRef.Recordset.name}', which doesn't have primary key and ref_field tag is not specified");

                                     //key_fld = primColN.name;
                                 }

                                 //TODO: fix later
                                 /*if (String.IsNullOrWhiteSpace(key_fld))
                                     throw new Exception($"Can't create BLOB link, the uri_key_field for '{fldRef.name}' is not specified and the recordset '{fldRef.Recordset.name}' doesn't have primary keys");

                                 if (model.IsNumeric(fldRef.ReferencedField.GetCType())) //This field returns the data for blob - so the type of this fields determines the type of blob
                                     fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnBlobInt64(fldName, this, fldDescNew.IsNullable, fldRef.Recordset.name, key_fld, isSameTable: false), fldDescNew));
                                 else
                                     fCols.Add(Tuple.Create((IDfColumnBase)new DfColumnBlobString(fldName, this, fldDescNew.IsNullable, fldRef.Recordset.name, key_fld, isSameTable: false), fldDescNew));*/

                            }
                            break;
                        }

                    default:
                        throw new NbExceptionInfo($"Unsupported CType {cType} in recordset {layoutTableN.name}");
                }

                /*string val = String.Empty;
                values.TryGetValue(col, out val);
                col.CreateText(val);*/
            }

            //Resolving uri_key_field into its index
            foreach (var col in fCols.Select(p => p.Item1).OfType<DfColumnBlobInt64>())
                col.Resolve(fCols.Select(c => c.Item1));
            foreach (var col in fCols.Select(p => p.Item1).OfType<DfColumnBlobString>())
                col.Resolve(fCols.Select(c => c.Item1));


            int i = -1;
            int row = 0;
            try
            {
                while (await rdr.ReadAsync())
                {
                    row++;
                    for (i = 0; i < colCount; i++) //For each field in the first row
                    {
                        var col = fCols[i].Item1;
                        col.CreateText(rdr, i);
                    }
                    Count++;
                    Debug.Assert(!fCols.Any(c => c.Item1.Count != Count), "Column length and variable length don't match");

                    if (Count >= maxRowCount)
                        break;
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error reading column {fCols[i]}, SqlType: '{rdr.GetFieldType(i)}' row #{row} in tsql '{sql}' in DfDynamicCollection.Load", ex);
            }

        }
    }
}
