﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using NbOrm.Xml;
using NbTools;
using NbTools.Collections;

#pragma warning disable IDE1006

namespace NbCollV1
{
    public partial class layout_info
    {
        [XmlAttributeAttribute("schemaLocation", Namespace = "http://www.w3.org/2001/XMLSchema-instance")]
        public string xsiSchemaLocation = @"NbCollV1 C:\!Work\Repo\NbTools\NbTools\Collections\NbColl.xsd";

        [XmlIgnore]
        private string FileName; //For saving

        private readonly NbDictionary<string, DfTable> fTables = new NbDictionary<string, DfTable>(50, StringComparer.OrdinalIgnoreCase, "NbColl table descriptions");
        public IReadOnlyCollection<DfTable> Tables => fTables.Values;

        public bool TryGetValue(string tableName, out DfTable table) => fTables.TryGetValue(tableName, out table);
        public DfTable this[string tableName]
        {
            get
            {
                if (!TryGetValue(tableName, out var table))
                    throw new Exception($"Can't find table '{table}' in the layout '{FileName}'");
                return table;
            }
        }

        private readonly static NbDictionary<string, NbDictionary<string, string>> enum_types =
            new NbDictionary<string, NbDictionary<string, string>>(50, StringComparer.OrdinalIgnoreCase, "Static enum types collections",
            s => new NbDictionary<string, string>(50, StringComparer.OrdinalIgnoreCase, $"{s} enum values")); //Generator of empty daughter dictionaries

        public static Lazy<XmlSerializer> modelXmlSerializer = new Lazy<XmlSerializer>(() => new XmlSerializer(typeof(layout_info)), false);
        public static layout_info LoadXml(string xmlFileName)
        {
            try
            {
                layout_info res;
                var fl = new FileInfo(xmlFileName);
                if (!fl.Exists)
                    throw new Exception($"Layout file does not exist: '{fl.FullName}'");

                using (FileStream str = new FileStream(fl.FullName, FileMode.Open))
                using (StreamReader rdr = new StreamReader(str))
                {
                    res = (layout_info)modelXmlSerializer.Value.Deserialize(rdr);
                    res.FileName = fl.FullName;
                }
                foreach (var enumFile in res.enum_file.Safe())
                {
                    var flName = Path.IsPathRooted(enumFile.path) ? enumFile.path : Path.Combine(fl.Directory.FullName, enumFile.path);
                    res.LoadEnumFromCsv(flName);
                }

                foreach (var t in res.table.Safe())
                {
                    t.Resolve(enum_types);
                    res.fTables.Add(t.name, t);
                }
                return res;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deserializing '{xmlFileName}'", ex);
            }
        }

        public void SaveXml()
        {
            try
            {
                string old = FileName + ".old";
                if (File.Exists(old))
                    File.Delete(old);
                File.Move(FileName, old);
            }
            catch { } //Ignore errors renaming old file

            using FileStream str = new FileStream(FileName, FileMode.Create);
            using StreamWriter wtrt = new StreamWriter(str);
            modelXmlSerializer.Value.Serialize(wtrt, this);
        }

        private void LoadEnumFromCsv(string path)
        {
            var par = new CsvParameters { FieldDelimiterN = '\t' };
            foreach (var line in NbExt.FromCsv<EnumTypeLine>(path, par))
                enum_types[line.TypeName].Add(line.Key, line.Value); //[] throws prober exception
        }

        public DfTable GetOrCreate(string name, recordset recSet)
        {
            if (TryGetValue(recSet.name, out DfTable layoutTableN))
                return layoutTableN;

            layoutTableN = new DfTable { name = name };
            layoutTableN.PopulateByRecordset(recSet.Fields);
            if (table == null)
                table = new DfTable[0];

            table = table.Concat(NbExt.Yield(layoutTableN)).ToArray(); //Adding to the collection
            return layoutTableN;
        }

        public class EnumTypeLine
        {
#pragma warning disable CS0649
            public string TypeName;
            public string Key;
            public string Value;
#pragma warning restore CS0649
        }
    }

    public partial class DfTable
    {
        public bool TryGetField(string fldName, out DfField field)
        {
            field = fields.Items.Safe().SingleOrDefaultVerbose(f => f.name.EqIC(fldName), i => $"There are {i} fields with the name {fldName} in the table {name}");
            return field != null;
        }

        internal void Resolve(NbDictionary<string, NbDictionary<string, string>> enum_types)
        {
            foreach (var fld in fields?.Items.Safe().Where(f => !String.IsNullOrWhiteSpace(f.enum_name)))
                if (fields?.Items is null)
                    return;

            foreach (var fld in fields?.Items.Safe().Where(f => !String.IsNullOrWhiteSpace(f.enum_name)))
            {
                if (!enum_types.TryGetValue(fld.enum_name, out var values))
                    throw new Exception($"Field '{name}[{fld.name}]' refers to enum_name '{fld.enum_name}', which can't be found in the collections of enums");
                else
                    fld.EnumValuesN = values;
            }
        }

        /// <summary>
        /// Tops up the collection of DfFields, by creating new ones calling IDfColumnBase.DefaultLayout
        /// </summary>
        /// <param name="cols"></param>
        internal void PopulateByRecordset(IEnumerable<IDfColumnBase> cols)
        {
            var dict = fields.Items.Safe().ToDictionary(i => i.name, StringComparer.OrdinalIgnoreCase);
            foreach (var col in cols)
            {
                if (dict.ContainsKey(col.Name))
                    continue;

                var newRec = col.DefaultLayout;
                dict.Add(newRec.name, newRec);
            }

            if (dict.Count != fields?.Items?.Length)
                fields.Items = dict.Values.ToArray();
        }

        internal void PopulateByRecordset(IEnumerable<field_base> cols)
        {
            if (fields == null)
                fields = new DfFields();

            var dict = fields.Items.Safe().ToDictionary(i => i.name, StringComparer.OrdinalIgnoreCase);
            foreach (var col in cols)
            {
                if (dict.ContainsKey(col.name))
                    continue;

                string tName = col.GetCType().ToString();
                if (!Enum.TryParse(tName, out DfType dType))
                    throw new NbException($"Can't convert cType {tName} into DfType");

                var newRec = new DfField { name = col.name, type = dType, @null = col.@null };
                dict.Add(newRec.name, newRec);
            }

            if (dict.Count != fields?.Items?.Length)
                fields.Items = dict.Values.ToArray();
        }

        public DfField PrimaryKeyN => fields.Items.Safe().SingleOrDefaultVerbose(f => f.IsPrimary, i => $"There are '{i}' primary keys in the table '{name}'");
    }

    public partial class DfField
    {
        public const int HiddenPos = -2;

        [XmlIgnore]
        internal NbDictionary<string, string> EnumValuesN;

        public bool IsPrimary => key == DfKey.primary || key == DfKey.identity;
        public bool IsFieldRef => link != null && link.Length > 0;
        public bool IsHidden => col_position == HiddenPos;

        public bool IsNumeric
        {
            get
            {
                switch (type)
                {
                    case DfType.@byte:
                    case DfType.@sbyte:
                    case DfType.@char:
                    case DfType.@decimal:
                    case DfType.@double:
                    case DfType.@float:
                    case DfType.@int:
                    case DfType.@uint:
                    case DfType.@long:
                    case DfType.@ulong:
                    case DfType.@short:
                    case DfType.@ushort:
                        return true;
                    default:
                        return false;
                }
            }
        }

        public override string ToString() => name;
    }

    public partial class DfLink
    {
        public override string ToString() => $"{ref_table}[{ref_field}]";
    }
}

#pragma warning restore