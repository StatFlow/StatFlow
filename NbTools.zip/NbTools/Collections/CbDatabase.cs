﻿using NbCollV1;
using System;
using System.IO;

namespace NbTools.Collections
{
    public class CbDatabase : IDisposable
    {
        private readonly string LayoutName;
        private readonly layout_info Layout;
        private readonly NbDictionary<string, CbCollection> fTables;
        private readonly string FileExt = ".csv";

        private string DirectoryName;
        private readonly CsvParameters CsvPar = new CsvParameters();

        public CbDatabase(string laoytFileName)
        {
            LayoutName = laoytFileName;
            Layout = layout_info.LoadXml(laoytFileName);
            fTables = new NbDictionary<string, CbCollection>(Layout.Tables.Count, StringComparer.OrdinalIgnoreCase, $"{LayoutName} CbDatabase tables");
        }

        public CbCollection this[string name] => fTables[name];
        public CbKeyedCollection GetKeyed(string name)
        {
            var keyed = fTables[name] as CbKeyedCollection ?? throw new NbException($"Collection '{name}' is not keyed collection");
            if (keyed.KeyN == null)
                throw new NbException($"KeyedCollection '{name}' doens't have key column set");
            return keyed;
        }

        public void LoadAndResolveTables(string directoryN = null)
        {
            DirectoryName = directoryN ?? Path.GetDirectoryName(LayoutName);

            foreach (var tblDef in Layout.Tables)
                LoadTable(tblDef);

            foreach (var coll in fTables.Values)
                coll.Resolve(fTables);
        }

        public void SaveTables(string directoryN = null)
        {
            var dstDirName = directoryN ?? DirectoryName;
            NbExt.DirCreateRecursive(dstDirName);

            foreach (var coll in fTables.Values)
            {
                CbLoaderSaverCsv saver = new CbLoaderSaverCsv(coll);
                saver.SaveToFile(Path.Combine(dstDirName, coll.Name + FileExt));
            }
        }

        private void LoadTable(DfTable tbl)
        {
            var fileName = Path.Combine(DirectoryName, tbl.name + FileExt);
            try
            {
                if (!File.Exists(fileName))
                    throw new NbException($"'{fileName}' was not found");

                var key = tbl.PrimaryKeyN;
                if (key != null) //Has Key
                {
                    CbKeyedCollection coll = new CbKeyedCollection(tbl);
                    CbLoaderSaverCsv ldr = new CbLoaderSaverCsv(coll);
                    ldr.AppendFile(fileName, CsvPar);

                    coll.SetKeyColumn(key.name);

                    fTables.Add(coll.Name, coll);
                }
                else
                {
                    CbCollection coll = new CbCollection(tbl);
                    CbLoaderSaverCsv ldr = new CbLoaderSaverCsv(coll);
                    ldr.AppendFile(fileName, CsvPar);
                    fTables.Add(coll.Name, coll);
                }
            }
            catch (Exception ex)
            {
                throw new NbException(ex, $"Error loading '{fileName}' file for CbDatabase");
            }
        }

        public void Dispose()
        { }
    }
}
