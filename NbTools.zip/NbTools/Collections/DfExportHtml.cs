﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using NbCollV1;

namespace NbTools.Collections
{
    public class DfExportFormat
    {
        public enum Formats { Html, Csv };

        public Formats Format;
        public bool isVertical;
        public bool isMergeCells;
        public bool isRemoveNullColumns;
        public bool isTableOnly;
        public int maxRows = 100;

        public override string ToString() => $"{Format};{(isVertical ? "Vert" : "Hor")};{(isMergeCells ? "Merg" : "NotMerg")};{(isRemoveNullColumns ? "RemNull" : "KeepNull")}";

        public static IEnumerable<DfExportFormat> Permutations()
        {
            DfExportFormat f = new DfExportFormat { isRemoveNullColumns = false };
            {
                f.isMergeCells = false;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }
                f.isMergeCells = true;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }
            }

            f.isRemoveNullColumns = true;
            {
                f.isMergeCells = false;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }

                f.isMergeCells = true;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }
            }
        }
    }

    public class DfExportHtml
    {
        private readonly IDfCollection fColl;

        private readonly NbDictionary<string, DfField> fLayouts;
        private readonly IDfCellFormatter fCellFormattter;
        private readonly DirectoryInfo fIconDir;

        private IEnumerable<IDfColumnBase> ColsFiltered(DfExportFormat format)
            => fColl.GetColumns().Where(p => !(format.isRemoveNullColumns && p.IsAllNull));

        public DfExportHtml(IDfCollection aColl, DfTable aLayout, DirectoryInfo iconDir)
        {
            fColl = aColl;
            fCellFormattter = new DfCellHtmlFormatter();
            fIconDir = iconDir;
            aLayout.PopulateByRecordset(aColl.GetColumns()); //TODO: call somewhere at resolution time

            fLayouts = aLayout.fields.Items.Safe().ToNbDictionary(p => p.name, p => p, StringComparer.OrdinalIgnoreCase,
                description: "DfExportHtml class Field Layouts collection");
        }

        public string ExportHtml(DfExportFormat format, string title, string header)
        {
            var cssPreload = File.ReadAllText("Css.css");
            NbCss css = new NbCss(fIconDir, cssPreload);

            //NbCss css = new NbCss(fIconDir, NbExt.GetEmbeddedResourceTextFile("NbTools.Css.css"));
            //css.AddPng("tree.png");
            //css.AddPng("journal.png");

            using StringWriter wrtr = new StringWriter();
            var tg = NbTag.Create(wrtr);
            tg.TT("body", t2 => Body(t2.TV("p", header), css, format));
            var body = wrtr.ToString();

            wrtr.GetStringBuilder().Clear(); //Highly experimental!
            css.WriteMultiline(wrtr);
            var cssText = wrtr.ToString();

            wrtr.GetStringBuilder().Clear(); //Highly experimental!
            var myT = NbTag.Create(wrtr).TT("html", t => t
            .TT("head", t1 => t1
                 ["title", title]
                 .Tag("meta", a => a["charset"] = "utf-8")
                 .TV("style", cssText, encode: false)
                //.TAV("script", a1 => a1["type", "text/javascript"]["language"] = "javascript", FileInOneLine(@"Data\JavaScript.js"), encode: false)
                )
            .TV("body", body, encode: false)
            );

            return wrtr.ToString();
        }

        public (string html, string css) ExportTableOnly (DfExportFormat format)
        {
            var cssPreload = File.ReadAllText("Css.css");
            NbCss css = new NbCss(fIconDir, cssPreload);

            using StringWriter wrtr = new StringWriter();
            var tg = NbTag.Create(wrtr);
            Body(tg, css, format);
            var body = wrtr.ToString();

            wrtr.GetStringBuilder().Clear(); //Highly experimental!
            css.WriteMultiline(wrtr);
            var cssText = wrtr.ToString();
            return (body, cssText);
        }

        public INbTag Body(INbTag root, NbCss css, DfExportFormat format) => format.isVertical ? TableVer(root, css, format) : TableHor(root, css, format);

        private INbTag TableHor(INbTag root, NbCss css, DfExportFormat format) //TODO: support colour for columns??
        {
            return root.TT("table", t =>
            {
                t.TT("tr", tr =>
                {
                    foreach (string colName in ColsFiltered(format).Select(cd => cd.Name))
                        tr.TAV("th", a => a["style"] = "font-weight: bold", colName);
                });

                foreach (int r in fColl.All)
                    t.TT("tr", tr =>
                    {
                        foreach (var col in ColsFiltered(format))
                            tr.TV("td", col.Format(r, fCellFormattter, fLayouts[col.Name], css), encode: false);
                    });
            });
        }

        private INbTag TableVer(INbTag root, NbCss css, DfExportFormat format)
        {
            return root.TT("table", t =>
            {
                foreach (var col in ColsFiltered(format))
                {
                    DfField fldLayout = fLayouts[col.Name];

                    t.TAT("tr", a =>
                    {
                        if (!String.IsNullOrEmpty(fldLayout.color))
                            a["class"] = fldLayout.color;
                    },
                        tr =>
                        {
                            //tr.TAT("td", a => a["class"] = "IconSuccessEncoded", null);
                            tr.TAV("td", a => a["style"] = "font-weight: bold", col.Name);
                            //tr["td"] = colAndDesc.Item1.Name;

                            if (format.isMergeCells)
                            {
                                string prevStr = null;
                                int spanCount = 0;
                                foreach (int r in fColl.All)
                                //for (int r = 0; r < fColl.Count; ++r)
                                {
                                    if (r == 0) //very first one
                                    {
                                        prevStr = col.Format(r, fCellFormattter, fldLayout, css);
                                        spanCount = 1;
                                        continue;
                                    }

                                    string newStr = col.Format(r, fCellFormattter, fldLayout, css);
                                    if (prevStr == newStr)
                                        spanCount++;
                                    else
                                    {
                                        CreateCell(tr, spanCount, prevStr);
                                        prevStr = newStr; //Save new as prev
                                        spanCount = 1;
                                    }
                                }

                                CreateCell(tr, spanCount, prevStr);  //Push the last one
                            }
                            else
                            {
                                foreach (int r in fColl.All)
                                    CreateCell(tr, 1, col.Format(r, fCellFormattter, fldLayout, css));
                            }
                        });
                }
            });
        }

        public void CreateCell(INbTag tr, int spanCount, string str)
        {
            if (spanCount == 1)
                tr.TV("td", str, encode: false);
            else
                tr.TAV("td", a => a["colspan"] = spanCount.ToString(), str, encode: false);
        }
    }
}
