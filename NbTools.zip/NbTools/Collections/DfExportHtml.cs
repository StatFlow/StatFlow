﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using NbCollV1;

namespace NbTools.Collections
{
    public class DfExportFormat
    {
        public enum Formats { Html, Csv };

        public Formats Format;
        public bool isVertical;
        public bool isMergeCells;
        public bool isRemoveNullColumns;
        public bool isTableOnly;
        public int maxRows = 100;

        public override string ToString() => $"{Format};{(isVertical ? "Vert" : "Hor")};{(isMergeCells ? "Merg" : "NotMerg")};{(isRemoveNullColumns ? "RemNull" : "KeepNull")}";

        public static IEnumerable<DfExportFormat> Permutations()
        {
            DfExportFormat f = new DfExportFormat { isRemoveNullColumns = false };
            {
                f.isMergeCells = false;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }
                f.isMergeCells = true;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }
            }

            f.isRemoveNullColumns = true;
            {
                f.isMergeCells = false;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }

                f.isMergeCells = true;
                {
                    f.isVertical = false;
                    yield return f;
                    f.isVertical = true;
                    yield return f;
                }
            }
        }
    }

    public class DfExportHtml
    {
        private readonly IDfCollection fColl;

        private readonly NbDictionary<string, DfField> fLayouts;
        private readonly IDfCellFormatter fCellFormattter;
        private readonly DirectoryInfo fIconDir;

        private IEnumerable<IDfColumnBase> ColsFiltered(DfExportFormat format)
            => fColl.GetColumns().Where(p => !(format.isRemoveNullColumns && p.IsAllNull));

        public DfExportHtml(IDfCollection aColl, DfTable aLayout, DirectoryInfo iconDir)
        {
            fColl = aColl;
            fCellFormattter = new DfCellHtmlFormatter();
            fIconDir = iconDir;
            aLayout.PopulateByRecordset(aColl.GetColumns()); //TODO: call somewhere at resolution time

            fLayouts = aLayout.fields.Items.Safe().ToNbDictionary(p => p.name, p => p, StringComparer.OrdinalIgnoreCase,
                description: "DfExportHtml class Field Layouts collection");
        }

        public string ExportHtml(DfExportFormat format, string title, string header)
        {
            NbCss css = new NbCss(fIconDir, DfExportHtml.Css);

            //NbCss css = new NbCss(fIconDir, NbExt.GetEmbeddedResourceTextFile("NbTools.Css.css"));
            //css.AddPng("tree.png");
            //css.AddPng("journal.png");

            using StringWriter wrtr = new StringWriter();
            var tg = NbTag.Create(wrtr);
            tg.TT("body", t2 => Body(t2.TV("p", header), css, format));
            var body = wrtr.ToString();

            wrtr.GetStringBuilder().Clear(); //Highly experimental!
            css.WriteMultiline(wrtr);
            var cssText = wrtr.ToString();

            wrtr.GetStringBuilder().Clear(); //Highly experimental!
            var myT = NbTag.Create(wrtr).TT("html", t => t
            .TT("head", t1 => t1
                 ["title", title]
                 .TA("meta", a => a["charset"] = "utf-8")
                 .TV("style", cssText, encode: false)
                //.TAV("script", a1 => a1["type", "text/javascript"]["language"] = "javascript", FileInOneLine(@"Data\JavaScript.js"), encode: false)
                )
            .TV("body", body, encode: false)
            );

            return wrtr.ToString();
        }

        public (string html, string css) ExportTableOnly (DfExportFormat format)
        {
            NbCss css = new NbCss(fIconDir, DfExportHtml.Css);

            using StringWriter wrtr = new StringWriter();
            var tg = NbTag.Create(wrtr);
            Body(tg, css, format);
            var body = wrtr.ToString();

            wrtr.GetStringBuilder().Clear(); //Highly experimental!
            css.WriteMultiline(wrtr);
            var cssText = wrtr.ToString();
            return (body, cssText);
        }

        public INbTag Body(INbTag root, NbCss css, DfExportFormat format) => format.isVertical ? TableVer(root, css, format) : TableHor(root, css, format);

        private INbTag TableHor(INbTag root, NbCss css, DfExportFormat format) //TODO: support colour for columns??
        {
            return root.TT("table", t =>
            {
                t.TT("tr", tr =>
                {
                    foreach (string colName in ColsFiltered(format).Select(cd => cd.Name))
                        tr.TAV("th", a => a["style"] = "font-weight: bold", colName);
                });

                foreach (int r in fColl.All)
                    t.TT("tr", tr =>
                    {
                        foreach (var col in ColsFiltered(format))
                            tr.TV("td", col.Format(r, fCellFormattter, fLayouts[col.Name], css), encode: false);
                    });
            });
        }

        private INbTag TableVer(INbTag root, NbCss css, DfExportFormat format)
        {
            return root.TT("table", t =>
            {
                foreach (var col in ColsFiltered(format))
                {
                    DfField fldLayout = fLayouts[col.Name];

                    t.TAT("tr", a =>
                    {
                        if (!String.IsNullOrEmpty(fldLayout.color))
                            a["class"] = fldLayout.color;
                    },
                        tr =>
                        {
                            //tr.TAT("td", a => a["class"] = "IconSuccessEncoded", null);
                            tr.TAV("td", a => a["style"] = "font-weight: bold", col.Name);
                            //tr["td"] = colAndDesc.Item1.Name;

                            if (format.isMergeCells)
                            {
                                string prevStr = null;
                                int spanCount = 0;
                                foreach (int r in fColl.All)
                                //for (int r = 0; r < fColl.Count; ++r)
                                {
                                    if (r == 0) //very first one
                                    {
                                        prevStr = col.Format(r, fCellFormattter, fldLayout, css);
                                        spanCount = 1;
                                        continue;
                                    }

                                    string newStr = col.Format(r, fCellFormattter, fldLayout, css);
                                    if (prevStr == newStr)
                                        spanCount++;
                                    else
                                    {
                                        CreateCell(tr, spanCount, prevStr);
                                        prevStr = newStr; //Save new as prev
                                        spanCount = 1;
                                    }
                                }

                                CreateCell(tr, spanCount, prevStr);  //Push the last one
                            }
                            else
                            {
                                foreach (int r in fColl.All)
                                    CreateCell(tr, 1, col.Format(r, fCellFormattter, fldLayout, css));
                            }
                        });
                }
            });
        }

        public void CreateCell(INbTag tr, int spanCount, string str)
        {
            if (spanCount == 1)
                tr.TV("td", str, encode: false);
            else
                tr.TAV("td", a => a["colspan"] = spanCount.ToString(), str, encode: false);
        }

        public const string Css = @"body {
    background: #9EBDE6;
    color: #000000;
    font-family: ""Segoe UI"", Tahoma, Geneva, Verdana, sans-serif;
    padding: 0 0 0 8px;
    margin: 0;
}

    h1 {
    padding: 10px 0 10px 10px;
    font-size: 21pt;
    background-color: #E2E2E2;
    border-bottom: 1px #C1C1C2 solid;
    margin: 0;
    font-weight: normal;
}

h2 {
    font-size: 18pt;
    font-weight: normal;
    padding: 15px 0 5px 0;
    margin: 0;
}

h3 {
    font-weight: normal;
    font-size: 15pt;
    margin: 0;
    padding: 15px 0 5px 0;
}

a {
    color: #1382CE;
    outline: none;
}

    a img
{
    outline: none;
    margin: -1px 0 -3px 0;
    width: 16px;
    height: 16px;
}

img {
    border: 0;
}

table {
    background: #E7E7E8;
    border-spacing: 0 0;
    border-collapse: collapse;
    font-size: 9pt;
}

    table th
{
    background: #E7E7E8;
        text-align: left;
    text-decoration: none;
    font-weight: normal;
    padding: 2px 3px 2px 3px;
}

table td
{
    vertical-align: top;
    padding: 2px 3px 2px 3px;
    margin: 0;
    border: 1px solid #C7C7C8;
        color: #000000;
    }

.C1 {
    background: #F7D7D6;
}

.C2 {
    background: #A5D7F7;
}
.C3 {
    background: #F7D7D6;
}
.C4 {
    background: #C6EFFF;
}
.C5 {
    background: #FFE7D6;
}
.C6 {
    background: #FFF7E7;
}

.D1 {
    background: #ECB7A0;
}

.D2 {
    background: #4A9EEF;
}

.D3 {
    background: #E7B6B5;
}

.D4 {
    background: #94DFFF;
}

.D5 {
    background: #F7CFB5;
}

.D6 {
    background: #FFEFCE;
}";
    }
}
