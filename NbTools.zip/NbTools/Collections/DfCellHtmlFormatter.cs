﻿using NbCollV1;
using NbTools.NbNullable;
using System;
using System.Text;
using System.Text.RegularExpressions;

namespace NbTools.Collections
{
    public class DfCellHtmlFormatter : IDfCellFormatter
    {
        private static string DoFormat(string keyStr, string keyInApostr, DfField fldDesc, NbCss nbCss)
        {
            string userVisible = keyStr;

            if (fldDesc.link != null && fldDesc.link.Length > 0)   //If references exist
                return ProcessFieldRef(fldDesc, keyStr, keyInApostr, nbCss);
            else //Simple field, no references
            {
                userVisible = Enrich(fldDesc, keyStr); //TODO: support self-table blob references - support them in the else statement?
                //if (fldDesc. == CType.blob) //Same-table blob reference
                //   userVisible = $"<a href=\"nbblob://host/{fld.Recordset.name}[{keyInApostr}]\">{userVisible}</a>";
                return userVisible;
            }
        }

        /// <summary>
        /// Processes one reference within a field, field can contain multiple references (one label and two icons for instance)
        /// Also supports blob references
        /// </summary>
        /// <param name="fld"></param>
        /// <param name="keyStr"></param>
        /// <param name="keyInApostr"></param>
        /// <returns></returns>
        private static string ProcessFieldRef(DfField fld, string keyStr, string keyInApostr, NbCss nbCss)
        {
            //string userVisible = fld_rf.ref_icon != null ? $@"<img src=""file://{fld_rf.ref_icon}"">" : Enrich(fld_rf.SolidField()?.BaseType, fld_rf, keyStr);
            //TODO: implement add the base64 icons to css
            StringBuilder bld = new StringBuilder(); //TODO: return IEnum of generated text
            foreach (var fld_rf in fld.link.Safe())
            {
                string text = (fld_rf.layout != LinkLayout.IconOnly) ? Enrich(fld, keyStr) : null;
                string icon = null;
                if (fld_rf.layout != LinkLayout.TextOnly && fld_rf.ref_icon != null)
                {
                    var icoName = nbCss.AddIcon(fld_rf.ref_icon);
                    icon = $@"<img class=""{icoName}"">";
                }

                var userVisible = fld_rf.layout switch
                {
                    LinkLayout.TextOnly => text,
                    LinkLayout.IconOnly => icon,
                    LinkLayout.TextAndIcon => text + icon,
                    LinkLayout.IconAndText => icon + text,
                    _ => throw new NbExceptionEnum<LinkLayout>(fld_rf.layout),
                };
                string title = String.IsNullOrWhiteSpace(fld_rf.ref_comment) ? String.Empty : $" title=\"{fld_rf.ref_comment}\"";

                if (fld_rf.ref_type == RefTypes.blob)
                {
                    if (String.IsNullOrEmpty(fld_rf.ref_table))
                        throw new Exception($"ref_table field must be configured for blob field '{fld}'");

                    bld.AppendLine($"<a href=\"nbblob://host/{fld_rf.ref_table}[{keyInApostr}]\" {title}>{userVisible}</a>");
                }
                else
                {
                    var uriFldReference = String.IsNullOrEmpty(fld_rf.ref_field) ? null : fld_rf.ref_field + "=";
                    bld.AppendLine($"<a href=\"nbquery://host/{fld_rf.ref_table}[{uriFldReference}{keyInApostr}]\" {title}>{userVisible}</a>");
                }
            }
            return bld.ToString();
        }

        /// <summary>
        /// Enriches the simple value in the field with more info: static enum desctiptions, replacements and split_by logic
        /// </summary>
        /// <param name="fldDesc">Field descriptor from NbColl xml</param>
        /// <param name="fldVal">Value of the field to be enriched</param>
        /// <returns></returns>
        private static string Enrich(DfField fldDesc, string fldVal)
        {
            foreach (var repl in fldDesc.replace.Safe())
            {
                if (!String.IsNullOrEmpty(repl.from))
                    fldVal = fldVal.Replace(repl.from, repl.to);
                else if (!String.IsNullOrEmpty(repl.from_regex))
                    fldVal = Regex.Replace(fldVal, repl.from_regex, repl.to);
            }
            if (!String.IsNullOrEmpty(fldDesc.split_by))
                fldVal = fldVal.Replace(fldDesc.split_by, "<br/>");

            if (fldDesc.EnumValuesN != null)
            {
                if (!fldDesc.EnumValuesN.TryGetValue(fldVal, out string descN))
                    descN = "\u047E";

                return $"{fldVal} - {descN}";
            }
            else
                return fldVal;
        }

        public string Format(DfColumnString col, int index, DfField fldDesc, NbCss nbCss)
        {
            var str = col[index];
            if (String.IsNullOrWhiteSpace(str))
                return str;
            else
                return DoFormat(str, "'" + str + "'", fldDesc, nbCss);
        }


        public string Format(DfColumnDateTime col, int index, DfField fldDesc, NbCss nbCss)
        {
            var val = col[index];
            if (val.IsNbNull())
                return null;

            string str = col.GetText(index);
            return DoFormat(str, "^" + str + "^", fldDesc, nbCss);
        }

        public string Format(DfColumnInt16 col, int index, DfField fldDesc, NbCss nbCss)
        {
            var val = col[index];
            if (val.IsNbNull())
                return null;

            string str = col.GetText(index);
            return DoFormat(str, str, fldDesc, nbCss);
        }

        public string Format(DfColumnInt32 col, int index, DfField fldDesc, NbCss nbCss)
        {
            var val = col[index];
            if (val.IsNbNull())
                return null;

            string str = col.GetText(index);
            return DoFormat(str, str, fldDesc, nbCss);
        }

        public string Format(DfColumnInt64 col, int index, DfField fldDesc, NbCss nbCss)
        {
            var val = col[index];
            if (val.IsNbNull())
                return null;

            string str = col.GetText(index);
            return DoFormat(str, str, fldDesc, nbCss);
        }

        public string Format(DfColumnStringIndex col, int index, DfField fldDesc, NbCss nbCss)
        {
            var str = col[index];
            if (String.IsNullOrWhiteSpace(str))
                return str;
            else
                return DoFormat(str, str, fldDesc, nbCss);
        }

        public string Format(DfColumnDecimal col, int index, DfField fldDesc, NbCss nbCss)
        {
            var val = col[index];
            if (val.IsNbNull())
                return null;

            string str = col.GetText(index);
            return DoFormat(str, str, fldDesc, nbCss);
        }
    }
}
