﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace NbTools
{
    public class NbObservableListFilter<TItem> : INbObservableList<TItem>
        where TItem : class, INotifyPropertyChanged
    {
        private readonly INbObservableList<TItem> fUnderLying;
        private List<TItem> fFilteredListN = null;

        public NbObservableListFilter(INbObservableList<TItem> underLying)
        {
            fUnderLying = underLying;
            underLying.Changed += UnderLying_Changed;
        }

        private void UnderLying_Changed(TItem item, NotifyCollectionChangedAction action, int undIndex = -1, int newCount = -1)
        {
            if (fFilter == null) //if no filter - propagate up
            {
                Changed?.Invoke(item, action, undIndex, newCount);
                return;
            }

            switch (action)
            {
                case NotifyCollectionChangedAction.Add:
                    {
                        if (fFilter(item))
                        {
                            if (fFilteredListN == null)
                                throw new NbExceptionInfo("_filter != null, but fFilteredListN == null");

                            fFilteredListN.Add(item);
                            Changed?.Invoke(item, action, fFilteredListN.Count - 1, fFilteredListN.Count);
                        }
                    }
                    break;

                case NotifyCollectionChangedAction.Remove:
                    if (fFilteredListN != null && fFilteredListN.Count > 0) //The removed item can possibly be in the filter
                    {
                        int ind = fFilteredListN.FindIndex(i => ReferenceEquals(i, item));
                        if (ind >= 0) //removed item is found in the filter
                        { //Propagate event
                            fFilteredListN.RemoveAt(ind);
                            Changed?.Invoke(item, action, ind, fFilteredListN.Count);
                        }
                    }
                    break;
                case NotifyCollectionChangedAction.Reset:
                    SetFilter(fFilter, fDependantFields); //replay the filter logic, includes Reset
                    break;

                /*case NotifyCollectionChangedAction.Replace:
                    break;
                case NotifyCollectionChangedAction.Move:
                    break;*/
                default:
                    throw new NbExceptionInfo($"Unsupported Action: {action}");
            }
        }


        private void Item_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (fFilteredListN == null) //Filter is not on, change of property shouldn't affect anything
                return;

            if (!(sender is TItem item))
                throw new NbExceptionInfo($"Item send in PropertyChanged is not {typeof(TItem).Name}");

            if (!fDependantFields?.Any(f => f.Equals(e.PropertyName, StringComparison.OrdinalIgnoreCase)) ?? false) //If property doesn't affect the filtering
                return;

            bool newStateIncluded = fFilter(item);

            int ind = fFilteredListN.IndexOf(item);
            if (ind >= 0) //If changed object is included in filtered list
            {
                if (!newStateIncluded) //Was included now should be removed
                {
                    item.PropertyChanged -= Item_PropertyChanged;
                    fFilteredListN.RemoveAt(ind);
                    Changed?.Invoke(item, NotifyCollectionChangedAction.Remove, ind, fFilteredListN.Count);
                }
                else
                    return; //Was included and stays included
            }
            else //Changed object was not included in the filter
            {
                if (newStateIncluded) //Was not included, but now should be included
                {
                    item.PropertyChanged += Item_PropertyChanged;
                    fFilteredListN.Add(item);
                    Changed?.Invoke(item, NotifyCollectionChangedAction.Add, fFilteredListN.Count - 1, fFilteredListN.Count);
                }
                else
                    return;
            }
        }

        public void SetFilter(Func<TItem, bool> filterFunc, params string[] dependantFields)
        {
            fFilter = filterFunc;
            if (fFilter == null)
            {
                fFilteredListN = null;
                fDependantFields = null;
            }
            else
            {
                fDependantFields = dependantFields;

                if (fFilteredListN == null)
                    fFilteredListN = new List<TItem>();
                else
                {
                    foreach (var f in fFilteredListN) //Remove registration to avoid memory leaks (TODO: use disposable lists)
                        f.PropertyChanged -= Item_PropertyChanged;
                    fFilteredListN.Clear();
                }

                for (int i = 0; i < fUnderLying.Count; ++i)
                {
                    var und = fUnderLying[i];
                    if (fFilter(und))
                    {
                        fFilteredListN.Add(und);
                        und.PropertyChanged += Item_PropertyChanged;
                    }
                }
            }

            Changed?.Invoke(default, NotifyCollectionChangedAction.Reset);
        }


        private Func<TItem, bool> fFilter = null;
        private string[] fDependantFields = null;
        public Func<TItem, bool> Filter => fFilter;

        public TItem this[int index]
        {
            get
            {
                if (fFilteredListN == null) //Filter is not set
                    return fUnderLying[index];

                if (index < 0 || index >= fFilteredListN.Count)
                    throw new NbExceptionInfo("Requested index is outside of range");
                return fFilteredListN[index]; //Filtered list keeps indexes in underlying
            }
        }

        public int Count => fFilteredListN != null ? fFilteredListN.Count : fUnderLying.Count;

        public event NbObservableListHandler<TItem> Changed;
    }
}
