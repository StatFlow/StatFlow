﻿using System;
using System.Collections.Generic;

namespace NbTools.Collections
{

    public class CbCollectionKeyColumn<T> : ICbCollectionKeyColumn
    {
        private readonly CbCollectionColumn<T> BaseColumn;
        private readonly List<int> fIndex;
        private readonly List<T> fValues;

        public CbCollectionKeyColumn(CbCollectionColumn<T> baseColumn)
        {
            BaseColumn = baseColumn;

            fIndex = new List<int>(BaseColumn.Count + BaseColumn.Count / 8);
            fValues = BaseColumn.fValues; //Using the same array for values
            for (int i = 0; i < BaseColumn.Count; ++i)
                fIndex.Add(i);

            fIndex.Sort(BaseColumn); //Base column's IComparer<int> interface is used here
            //If IComparer thrown exception on equal fields, we could have sorting and checking for uniqueness in one go

            //Make sure unique
            for (int i = 1; i < BaseColumn.Count; ++i)
            {
                if (BaseColumn.Compare(fIndex[i - 1], fIndex[i]) >= 0)
                    throw new Exception($"Index for '{this.FullName}' is not unique. Value is '{fValues[fIndex[i - 1]]}' and '{fValues[fIndex[i]]}'");
            }
        }

        public string Name => BaseColumn.Name;
        public string FullName => BaseColumn.FullName;
        public int Count => BaseColumn.Count;
        public bool ValueChanged => BaseColumn.ValueChanged;

        public void AppendBuffer() => BaseColumn.AppendBuffer();
        public string GetText(int index) => BaseColumn.GetText(index);

        public string GetTextFromBuffer() => BaseColumn.GetTextFromBuffer();

        public int BinarySearch(T val) => fValues.IndexOf(val); //TODO: use proper binary search
        public int IndexOf(string str) => BinarySearch(BaseColumn.FromText(str));

        public void Rename(string newName) => BaseColumn.Rename(newName);
        public void ReplaceFromBuffer(int index) => BaseColumn.ReplaceFromBuffer(index);
        public void ResetBuffer() => BaseColumn.ResetBuffer();

        public void SelectBuffer(int ind) => BaseColumn.SelectBuffer(ind);
        public bool SetTextToBuffer(string str) => BaseColumn.SetTextToBuffer(str);

        public void UpdateFromBufferAt(int ind) => BaseColumn.UpdateFromBufferAt(ind);

        //internal int BinarySearch(T val) => BaseColumn.BinarySearch(val);
    }

    /// <summary>
    /// Почему не нужно наследовать KeyColumn от Column. The main variability is by the type of the field (string, int, e.t.c)
    /// All solicd classes must have the solid behavior for string, int, e.t.c. If we derive like this, we create another
    /// branch, which will have to have its onw solid classes with the same set of types. The set of field types is much more basis
    /// and has more variability than base / key column behavior, so the key column must aggregate the column, not derive from it.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /*public class CbCollectionKeyColumn<T> : CbCollectionColumn<T>
    {
        private readonly List<int> fIndex;
        private readonly IComparer<int> IndexComparer;

        public CbCollectionKeyColumn(CbCollectionColumn<T> baseCol)
            : base(baseCol.ParentCollection, baseCol.Name, baseCol.NullTreatment)
        {
            fIndex = new List<int>(baseCol.Count + baseCol.Count / 8);
            fValues = baseCol.fValues; //Using the same array for values
            for (int i = 0; i < baseCol.Count; ++i)
                fIndex.Add(i);

            switch (typeof(T).Name)
            {
                case nameof(String):
                    IndexComparer = new CompStringIcUnique(fValues as List<string>, baseCol.FullName);
                    break;

                default:
                    throw new Exception($"Index comparer for type '{fValues.GetType().Name}' is not supported");

            }

            fIndex.Sort(IndexComparer);

            //Make sure unique
            for (int i = 1; i < baseCol.Count; ++i)
            {
                if (IndexComparer.Compare(fIndex[i - 1], fIndex[i]) >= 0)
                    throw new Exception($"Index for '{this.FullName}' is not unique. Value is '{fValues[fIndex[i - 1]]}' and '{fValues[fIndex[i]]}'");
            }

        }


        //TODO: think about moving this behaviour out
        protected override bool TryFromText(string str, out T val)
        {
            val = (T)Convert.ChangeType(str, typeof(T)); //TODO: come up with something better
            return true;
        }





        private class CompStringIC : IComparer<int>
        {
            private readonly IReadOnlyList<string> Vals;
            internal CompStringIC(IReadOnlyList<string> vals) { Vals = vals; }
            public int Compare(int x, int y) => String.Compare(Vals[x], Vals[y], ignoreCase: true);
        }

        //TODO: more informative exception
        private class CompStringIcUnique : IComparer<int>
        {
            private readonly IReadOnlyList<string> Vals;
            private readonly string ColumnName;
            internal CompStringIcUnique(IReadOnlyList<string> vals, string columnName)
            {
                Vals = vals;
                ColumnName = columnName;
            }
            public int Compare(int x, int y)
            {
                var res = String.Compare(Vals[x], Vals[y], ignoreCase: true);
                if (res == 0)
                    throw new NbException($"Index column '{ColumnName}' is not unique, value '{Vals[x]}' is found more than once. Line numbers: {x} and {y}");
                return res;

            }
        }
    }*/

}
