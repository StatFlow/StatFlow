﻿using NbCollV1;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NbTools.Collections
{
    public class CbKeyedCollection : CbCollection
    {
        public ICbCollectionKeyColumn KeyN;

        public CbKeyedCollection(string name, int capacity = 0) : base(name, capacity) { }
        public CbKeyedCollection(DfTable tableDef, int capacity = 0) : base(tableDef, capacity) { }

        public void SetKeyColumn(string name)
        {
            var strCol = fColumns[name] as CbCollectionColumn<string> ?? throw new Exception("Only string column are supported as base for keyed columns");

            KeyN = strCol.GenerateKeycolumn();
            fColumns[name] = KeyN; //Also updating the collection of columns
        }

        public override IEnumerable<int> All
        {
            get
            {
                if (KeyN == null)
                    return base.All; //No order
                else 
                    return base.All.OrderBy(i => KeyN.GetText(i));
            }
        }

        public void SyncWith(CbKeyedCollection other, Func<int, bool> predicateN = null, SyncMode syncMode = SyncMode.All)
        {
            if (this.KeyN == null)
                throw new Exception("Key column is not set");
            var otherKeyCol = other.KeyN ?? throw new Exception("Other collection key column is not set");

            var missing = fColumns.Keys.Where(k => !other.Columns.ContainsKey(k));
            if (missing.Any())
                throw new Exception($"The following columns are missing from the other collection: {String.Join(", ", missing)}");


            HashSet<int> visitedInOther = new HashSet<int>();

            foreach (int rowNum in All) //Cycle on our collection
            {
                string key = KeyN.GetText(rowNum);
                int otherRow = otherKeyCol.IndexOf(key);
                if (otherRow >= 0) //Found
                { //Update
                    visitedInOther.Add(otherRow);

                    if ((syncMode & SyncMode.Update) != 0)
                    {
                        Select(rowNum);
                        foreach (var fld in fColumns.Values)
                        {
                            string otherVal = other.Columns[fld.Name].GetText(otherRow);
                            fld.SetTextToBuffer(otherVal); //Updates the buffer
                        }
                        UpdateAt(rowNum);
                    }
                }
                else if ((syncMode & SyncMode.Remove) != 0)
                {   //Not found in other and deletes are allowed
                    DeleteAt(rowNum);
                }
            }

            foreach (int otherRowNum in other.All) //Cycle on other collecion
            {
                if (predicateN?.Invoke(otherRowNum) ?? true)
                {
                    if (visitedInOther.Contains(otherRowNum)) //Skip visited
                        continue;

                    string otherKey = otherKeyCol.GetText(otherRowNum);
                    if (String.IsNullOrEmpty(otherKey) || otherKey == "00:00:00:00:00:00")
                        continue; //Ignore empty keys

                    Reset();
                    foreach (var fld in fColumns.Values)
                    {
                        string otherVal = other.Columns[fld.Name].GetText(otherRowNum);
                        fld.SetTextToBuffer(otherVal); //Updates the buffer
                    }
                    Append();
                }
            }
        }

    }
}