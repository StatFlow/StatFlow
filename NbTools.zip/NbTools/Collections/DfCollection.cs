﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Diagnostics;

using NbCollV1;

namespace NbTools.Collections
{
    public delegate void DfCollChanged(DfCollChangedEventType eventType);
    public delegate void DfCollValueChanged(IDfColumnBase col, int ind);
    public enum DfCollChangedEventType { Reset };

    public interface IDfValueChangeListener
    {
        void OnValueChanged(IDfColumnBase col, int ind);
    }

    public interface IDfCellFormatter
    {
        string Format(DfColumnInt16 dfColumnString, int index, DfField fldDesc, NbCss nbCss);
        string Format(DfColumnInt32 dfColumnString, int index, DfField fldDesc, NbCss nbCss);
        string Format(DfColumnInt64 dfColumnString, int index, DfField fldDesc, NbCss nbCss);
        string Format(DfColumnDecimal dfColumnString, int index, DfField fldDesc, NbCss nbCss);

        string Format(DfColumnDateTime dfColumnString, int index, DfField fldDesc, NbCss nbCss);
        string Format(DfColumnString dfColumnString, int index, DfField fldDesc, NbCss nbCss);
        string Format(DfColumnStringIndex dfColumnString, int index, DfField fldDesc, NbCss nbCss);
    }

    public interface IDfColumnBase : IComparer<int>
    {
        string Name { get; set; } //Allow to rename columns during merge
        int Count { get; }

        int CreateText(INbReader val, int index);
        string GetText(int index);
        object GetObject(int index);

        IEnumerable<string> Rows { get; }

        void SetText(string val);
        string ValidateTextN(string val);

        int Find(string parent);

        bool IsAllNull { get; }
        string Format(int index, IDfCellFormatter frm, DfField fldDesc, NbCss nbCss);
        void AddDefault();
        DfField DefaultLayout { get; }
    }

    public interface IDfReferenceColumn : IDfColumnBase
    {
        DfColumnBackReference ResolveAndCreateBackeferenceColumn(string backReferenceColumnName, DfColumnString loaderColumn);
        void RemoveReference(int ind, int refInd, bool suppressNotification);
    }

    public interface IDfCollection
    {
        IEnumerable<int> All { get; }
        IEnumerable<IDfColumnBase> GetColumns();
        event DfCollChanged Changed;
        event DfCollValueChanged ValueChanged;
    }

    //TODO: support collection of filtering functions
    public class DfFilter : IDfCollection
    {
        public class FilterFunction
        {
            public string Name;
            public int Complexity;
            public Func<int, bool> Function;

            internal class NameComparer : IEqualityComparer<FilterFunction>
            {
                public bool Equals(FilterFunction x, FilterFunction y) => x.Name.Equals(y.Name);
                public int GetHashCode(FilterFunction obj) => obj.Name.GetHashCode();
            }

            internal class ComplComparer : IComparer<FilterFunction>
            { public int Compare(FilterFunction x, FilterFunction y) => x.Complexity.CompareTo(y.Complexity); }
        }
        private static readonly FilterFunction.NameComparer fNameCompar = new FilterFunction.NameComparer();
        private static readonly FilterFunction.ComplComparer fComplexCompar = new FilterFunction.ComplComparer();


        private readonly IDfCollection fUnder;
        private readonly List<FilterFunction> fFunctions;

        public DfFilter(IDfCollection underlying)
        {
            fUnder = underlying;
            fFunctions = new List<FilterFunction>(10);
            underlying.Changed += Underlying_Changed;
            underlying.ValueChanged += Underlying_ValueChanged;
        }

        private void Underlying_ValueChanged(IDfColumnBase col, int ind)
        {
            //DfTODO: notify only about values passing filter 
            ValueChanged?.Invoke(col, ind);
        }

        private void Underlying_Changed(DfCollChangedEventType eventType) => Changed?.Invoke(eventType);


        /// <summary>
        /// Inserts the filtering function structure into the list and sort by complexity on the insertion. Allows to set the same name multiple times
        /// </summary>
        /// <param name="func">Filtering function structure</param>
        public void AddFunction(FilterFunction func)
        {
            int ind = fFunctions.FindIndex(a => fNameCompar.Equals(a, func));
            if (ind != -1)
            {
                fFunctions.RemoveAt(ind);
            }

            int insLocation = fFunctions.BinarySearch(func, fComplexCompar);
            if (insLocation < 0)
                insLocation = ~insLocation;

            fFunctions.Insert(insLocation, func);
            Changed?.Invoke(DfCollChangedEventType.Reset);
        }

        public void RemoveFunction(FilterFunction func)
        {
            int ind = fFunctions.FindIndex(a => fNameCompar.Equals(a, func));
            if (ind != -1)
            {
                fFunctions.RemoveAt(ind);
                Changed?.Invoke(DfCollChangedEventType.Reset);
            }
        }

        public IEnumerable<IDfColumnBase> GetColumns() => fUnder.GetColumns();

        public IEnumerable<int> All
        {
            get
            {
                if (fFunctions.Count == 0)
                    return fUnder.All;
                else
                    return fUnder.All.Where(i => fFunctions.All(f => f.Function(i)));
            }
        }

        public event DfCollChanged Changed;
        public event DfCollValueChanged ValueChanged;
    }

    public class DfOrder : IDfCollection//, IComparer<int>
    {
        private readonly IDfCollection fUnder;

        public DfOrder(IDfCollection underlying)
        {
            fUnder = underlying;
            underlying.Changed += Underlying_Changed;
            underlying.ValueChanged += Underlying_ValueChanged;
        }

        private void Underlying_ValueChanged(IDfColumnBase col, int ind)
        {
            if (ReferenceEquals(col, fOrderColN)) //Field determining the order chaged - reset 
                Changed?.Invoke(DfCollChangedEventType.Reset); //TODO: issue order change event
            else
                ValueChanged?.Invoke(col, ind); //Pass through
        }

        private void Underlying_Changed(DfCollChangedEventType eventType) => Changed?.Invoke(eventType);

        //Order by function - use later
        /*public Func<int, int, int> Order
        {
            get { return fFunc; }
            set { fFunc = value; Changed?.Invoke(DfCollChangedEventType.Reset); }
        }
        private Func<int, int, int> fFunc;
        public int Compare(int x, int y) => fFunc(x, y);

        public IEnumerable<int> All => fFunc == null ? fUnder.All : fUnder.All.OrderBy(i => i, this);*/

        public void ByColumn(IDfColumnBase colN, bool desc = false)
        {
            fOrderColN = colN;
            fDesc = desc;
        }

        public IEnumerable<IDfColumnBase> GetColumns() => fUnder.GetColumns();

        private IDfColumnBase fOrderColN;
        private bool fDesc = false;

        public IEnumerable<int> All
        {
            get
            {
                if (fOrderColN == null)
                    return fUnder.All;
                else
                    return fDesc ? fUnder.All.OrderByDescending(i => i, fOrderColN) : fUnder.All.OrderBy(i => i, fOrderColN);
            }
        }

        public event DfCollChanged Changed;
        public event DfCollValueChanged ValueChanged;
    }

    public abstract class DfCollection : IDfCollection
    {
        public readonly string CollectionName;
        protected static Encoding defaultEnconding = Encoding.UTF8;
        protected char[] supportedSeparators = new char[] { ',', '\t', '|' };

        private readonly HashSet<int> fDeleted;

        public event DfCollChanged Changed;
        public event DfCollValueChanged ValueChanged;
        internal void OnValueChanged(IDfColumnBase col, int ind) => ValueChanged?.Invoke(col, ind);

        public DfCollection(string name)
        {
            CollectionName = name;
            fDeleted = new HashSet<int>();
        }

        public int Count { get; protected set; } = 0;
        public int CurrentLine { get; protected set; } = -1;

        public int GetLineForEditing() => (CurrentLine != -1) ? CurrentLine : throw new Exception("AddLine() or EditLine() line should be called before the changing the fields");
        
        public void AddLine()
        {
            if (CurrentLine >= 0)
                throw new Exception("Current Line was not released");
            else
                CurrentLine = Count;
        }

        public void EditLine(int lineNum)
        {
            if (CurrentLine >= 0)
                throw new Exception("Current Line was not released");
            else if (lineNum >= Count || lineNum < 0)
                throw new Exception($"Line #{lineNum} does not exist, Count = {Count}");
            else
                CurrentLine = lineNum;
        }

        public void ReleaseLine()
        {
            if (CurrentLine < 0)
                throw new Exception("Release line call without Add or Edit Line call");

            int commonCount = -1;
            foreach (var col in GetColumns())
            {
                int currCount = col.Count;

                if (CurrentLine == currCount) //If there was addition of a new line
                {
                    col.AddDefault();
                    currCount++; //Avoid calling count second time
                }
                else if (CurrentLine > currCount) //if there is something wrong
                    throw new Exception($"CurrentLine is greater than Count on the column: {CurrentLine}>{currCount}. More than one line is missing.");

                if (commonCount < 0)
                    commonCount = currCount;
                else if (commonCount != currCount)
                    throw new Exception($"Column {col} have column count {currCount} different from the rest of the columns count {commonCount}");
            }

            Count = commonCount;
            CurrentLine = -1;
        }



        public virtual bool LoadFromCsv(string fileName, DfTable recSetN, CsvParameters csvParamN = null)
        {
            if (!File.Exists(fileName))
                return false; //empty file

            StringBuilder bld = new StringBuilder();
            Encoding enc = csvParamN?.EncodingN ?? defaultEnconding;

            Exception exp = null;
            for (int i = 0; i < 2; i++)
            {
                try
                {
                    using Stream strm = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                    using StreamReader rdr = new StreamReader(strm, enc);
                    return LoadFromCsv(rdr, recSetN, csvParamN);
                }
                catch (Exception ex) { exp = ex; }
            }
            throw exp;
        }

        public virtual bool LoadFromCsv(TextReader rdr, DfTable recSetN, CsvParameters csvParamN = null)
        {
            StringBuilder bld = new StringBuilder();

            string headerLine = rdr.ReadLine(); //Detecting the best separator to use automatically
            if (String.IsNullOrEmpty(headerLine))
                return false;

            char sep = csvParamN?.FieldDelimiterN ?? supportedSeparators.Select(sp => Tuple.Create(sp, headerLine.Split(sp).Length))
                .OrderByDescending(pair => pair.Item2).FirstOrDefault().Item1;

            var columnNames = NbExt.DeCsvLine(headerLine, bld, sep, trim: true) //always trim headers
                .Select(h1 => (h1.StartsWith("[") && h1.EndsWith("]")) ? h1.Substring(1, h1.Length - 1) : h1) //Handle fields like [ID]
                .ToList(); //Header

            ProcessCsvHeaders(columnNames, recSetN); //Can create columns out of headers here

            var Columns = GetColumns().ToList(); //Columns can be created at the previous step
            int[] colIndArr = new int[columnNames.Count];
            for (int i = 0; i < columnNames.Count; ++i)
            {
                var ind = Columns.FindIndex(c => c.Name.Equals(columnNames[i], StringComparison.OrdinalIgnoreCase));
                colIndArr[i] = ind;
                if (ind < 0)
                    csvParamN?.Warning($"Column '{columnNames[i]}' is present in csv is not found in the DfCollection");
            }

            foreach (var col in Columns)
            {
                var ind = columnNames.FindIndex(cn => cn.Equals(col.Name, StringComparison.OrdinalIgnoreCase));
                if (ind < 0)
                    csvParamN?.Warning($"Column '{col.Name}' is present in DfCollection but not found in csv. Nullable fields will be set to null");
            }

            int lineCounter = 1; //The header is already read
            while (true)
            {
                lineCounter++;
                string line = rdr.ReadLine();
                if (line == null)
                    break;
                else if (String.IsNullOrWhiteSpace(line)) //Skip empty lines
                    continue;

                Debug.Assert(!Columns.Any(c => c.Count != Count), "Column length and variable length don't match");
                int colNum = 0;
                AddLine();
                foreach (var str in NbExt.DeCsvLine(line, bld, sep, csvParamN?.Trim ?? false))
                {
                    if (colNum >= colIndArr.Length)
                        break;
                    int ind = colIndArr[colNum];
                    if (ind >= 0) //There is a corresponding column in collection
                        Columns[ind].SetText(str);
                    colNum++;
                }
                ReleaseLine();

                //Count++;
                Debug.Assert(!Columns.Any(c => c.Count != Count), "Column length and variable length don't match");
            }

            Changed?.Invoke(DfCollChangedEventType.Reset);
            return true;
        }

        protected abstract void ProcessCsvHeaders(IEnumerable<string> headers, DfTable recSetN);

        public void Save(string dir, CsvParameters csvParamN) => SaveToFile(Path.Combine(dir, CollectionName + ".csv"), csvParamN);

        public void SaveToFile(string fileName, CsvParameters csvParamN)
        {
            lock (this)
            {
                var Columns = GetColumns().ToList();
                Debug.Assert(!Columns.Any(c => c.Count != Count), "Column length and variable length don't match");

                if (File.Exists(fileName))
                {
                    switch (csvParamN?.CopyOnSave ?? CsvParameters.SaveMode.None)
                    {
                        case CsvParameters.SaveMode.Timestamped:
                            File.Move(fileName, fileName + "." + DateTime.Now.ToString("yyyyMMdd_HHmmss"));
                            break;

                        case CsvParameters.SaveMode.Single:
                            var oldFilename = fileName + ".old";
                            if (File.Exists(oldFilename))
                                File.Delete(oldFilename);
                            File.Move(fileName, oldFilename);
                            break;
                        case CsvParameters.SaveMode.None: break;
                        default:
                            throw new NbExceptionEnum<CsvParameters.SaveMode>(csvParamN.CopyOnSave);
                    }
                }

                Encoding enc = csvParamN?.EncodingN ?? defaultEnconding;
                string separator = (csvParamN?.FieldDelimiterN ?? ',').ToString();

                using Stream strm = new FileStream(fileName, FileMode.Create, FileAccess.Write, FileShare.Write);
                using StreamWriter wrtr = new StreamWriter(strm, enc);
                var h = String.Join(separator, Columns.Select(c => c.Name));
                wrtr.WriteLine(h);
                foreach (int i in SavingOrder.Where(i => !fDeleted.Contains(i))) //Ordered by index, excluding marked as deleted
                {
                    var l = String.Join(separator, Columns.Select(c =>
                    {   //Making the string CSV - friendly
                            var s = (c.GetText(i) ?? String.Empty).Replace(singleQuote, doubleQuotes);
                        if (s.Contains(separator) || s.Contains(singleQuote))
                            return $"{singleQuote}{s}{singleQuote}";
                        else
                            return s;
                    }));
                    wrtr.WriteLine(l);
                }
            }
        }

        private const string singleQuote = "\"";
        private const string doubleQuotes = "\"\"";

        abstract public IEnumerable<IDfColumnBase> GetColumns();
        abstract public IDfColumnBase PrimaryKeyColumn { get; }
        abstract public IEnumerable<int> SavingOrder { get; }

        public IEnumerable<int> All => Enumerable.Range(0, Count).Where(i => !fDeleted.Contains(i));
        public virtual void Delete(int ind)
        {
            fDeleted.Add(ind);
            Changed?.Invoke(DfCollChangedEventType.Reset); //TODO: specific event for the entry
        }

        public int Add(Dictionary<IDfColumnBase, string> values)
        {
            Debug.Assert(!GetColumns().Any(c => c.Count != Count), "Column length and variable length don't match");
            int newInd = Count;

            AddLine();
            foreach (var col in GetColumns())
            {
                //TODO: Validation and key auto supply
                string val = String.Empty;
                values.TryGetValue(col, out val);
                col.SetText(val);
            }
            ReleaseLine();
            Debug.Assert(!GetColumns().Any(c => c.Count != Count), "Column length and variable length don't match");
            /*var badColumn = GetColumns().FirstOrDefault(c => c.Count != Count);
            if (badColumn != null)
                throw new NbExceptionInfo($"Column {badColumn.Name} counter = {badColumn.Count} and the newId is {Count}");*/

            Changed?.Invoke(DfCollChangedEventType.Reset); //TODO: specific event for the entry
            return newInd;
        }

        public string GetDescr(int ind) => String.Join("\r\n", GetColumns().Select(c => $"{c.Name}: '{c.GetText(ind)}'"));

        /*public dynamic GetDynamic(int ind)
        {
            dynamic res = new ExpandoObject();
            foreach (var col in GetColumns())
                ((IDictionary<String, Object>)res).Add(col.Name, col.GetText(ind));
            return res;
        }*/
    }

    /// <summary>
    /// Contains 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public abstract class DfColumnBase<T> : IDfColumnBase
    {
        protected const string ErrNullString = "The field is non-nullable, but empty string was provided";

        public List<T> Vals; //TODO: Make protected
        public virtual int Count => Vals.Count;

        public T this[int ind]
        {
            get { return Vals[ind]; }
            private set { Vals[ind] = value; } //TODO: make internal, raise event here, call this from SetText
        }

        public string Name { get; set; }

        protected bool fAllNull = true;
        public bool IsAllNull => fAllNull;

        public readonly bool IsNullable;
        public override string ToString() => $"{Name} ({GetType().Name.Substring(8)})";

        public readonly DfCollection fColl; //TODO: think about hiding

        public static IDfColumnBase CreateColumn(DfCollection coll, DfField fldDesc)
        {
            switch(fldDesc.type)
            {
                case DfType.@decimal: return new DfColumnDecimal(fldDesc.name, coll, fldDesc.@null);
                case DfType.@char: return new DfColumnInt16(fldDesc.name, coll, fldDesc.@null);
                case DfType.@short: return new DfColumnInt16(fldDesc.name, coll, fldDesc.@null);
                case DfType.@int: return new DfColumnInt32(fldDesc.name, coll, fldDesc.@null);
                case DfType.@long: return new DfColumnInt64(fldDesc.name, coll, fldDesc.@null);

                case DfType.@string:
                    if (fldDesc.IsPrimary)
                        return new DfColumnStringIndex(fldDesc.name, coll, fldDesc.@null);
                    else
                        return new DfColumnString(fldDesc.name, coll, fldDesc.@null);

                case DfType.@DateTime: return new DfColumnDateTime(fldDesc.name, coll, fldDesc.@null);

                default: throw new NbExceptionEnum<DfType>(fldDesc.type);
            }
        }

        public DfColumnBase(string name, DfCollection coll, bool isNullable)
        {
            Name = name;
            fColl = coll;
            IsNullable = isNullable;
            Vals = new List<T>();
        }

        //Saving fucntionality
        public abstract void AddDefault();
        public abstract int CreateText(INbReader val, int colIndex);
        public abstract string Format(int index, IDfCellFormatter frm, DfField fldDesc, NbCss nbCss);

        public int CreateValue(T val)
        {
            int index = Vals.Count;
            Vals.Add(val);
            //fColl.OnValueChanged(this, index); //Do not trigger event on create for individual fields, raise one for the whole object
            return index;
        }

        public string ValidateTextN(string str) => TryGetValueFromString(str, out T _, out string err) ? null : err;

        public virtual string GetText(int index) => Val2Str(Vals[index]); //For extra logic in DfColumnReference

        public virtual void SetText(string str)
        {
            if (TryGetValueFromString(str, out T val, out string err))
                SetValue(val);
            else
                throw new Exception(err + " " + Name);
        }

        public T GetValue(int ind) => Vals[ind];
        public object GetObject(int ind) => Vals[ind];

        public void SetValue(T val)
        {
            int index = fColl.GetLineForEditing();
            if (index == Vals.Count)
                Vals.Add(val);
            else
            {
                T oldValue = Vals[index];
                Vals[index] = val;
                if (!IsEqual(oldValue, val))
                    fColl.OnValueChanged(this, index); //Only raise event if the values are different
            }
        }

        //public abstract T Str2Val(string str);
        public abstract bool TryGetValueFromString(string str, out T val, out string errorMessage);
        public abstract bool IsEqual(T x, T y);



        //Reading functionality
        public virtual string Val2Str(T val) => val?.ToString() ?? String.Empty;
        public IEnumerable<string> Rows => Enumerable.Range(0, Count).Select(i => GetText(i));

        public abstract DfField DefaultLayout { get; }

        //Comparing functionality
        public int Compare(int x, int y) => ValCompare(Vals[x], Vals[y]);
        public abstract int ValCompare(T x, T y);

        public IEnumerable<int> Where(T val, IEnumerable<int> inds) => inds.Where(i => Vals[i].Equals(val));
        public IEnumerable<int> Where(Predicate<T> pred, IEnumerable<int> inds) => inds.Where(i => pred(Vals[i]));

        //public virtual string ValidateTextN(string val) => null; //No validation by default

        public int Find(string parent)
        {
            for (int r = 0; r < Count; r++)
            {
                if (parent.EqIC(GetText(r)))
                    return r;
            }
            return -1;
        }
    }

    public static class DfExtensions
    {
        public static IEnumerable<int> Wher(this IEnumerable<int> ind, DfColumnString strField, Predicate<string> pred) => ind.Where(i => pred(strField.Vals[i])); //TODO: Do we need it? Vals shouldn't be public

        public static IEnumerable<int> Wher<TEnum>(this IEnumerable<int> ind, DfColumnEnum<TEnum> strField, Predicate<TEnum> pred)
            where TEnum : struct, IConvertible, IComparable => ind.Where(i => pred(strField.Vals[i]));
    }
}
