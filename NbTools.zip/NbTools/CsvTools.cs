﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace NbTools
{
    public class CsvParameters
    {
        public enum SaveMode { None, Single, Timestamped }

#pragma warning disable CA1051 // Do not declare visible instance fields
        public DirectoryInfo RepositoryDirN;
        public Action<string> LoggerN;
        public IEnumerable<Func<string, IdHolder>> ResolversN;
        public IEnumerable<string> IgnoreSourceFieldN;
        public char? FieldDelimiterN;
        public char? RowDelimiterN;

        public Encoding EncodingN;

        /// <summary>
        /// Defines whether the file is expected to have quotes around the values (causes symbol by symbol reading). 
        /// Also determines wether the output should have quotes if the string has quotes or delimiters inside it.
        /// </summary>
        public bool QuoatedFields;
        public bool HeadersAreInTheFile = true;
        /// <summary>
        /// Headers: override headers from the file or provide headers if they are not found in the file
        /// </summary>
        public string HeadersN;

        /// <summary>
        /// Date format used unless specified on the field level
        /// </summary>
        public string DefaultDateFormat;
        public string DefaultDateTimeFormat;

        public SaveMode CopyOnSave = SaveMode.None;
        public bool Trim = false;

#pragma warning restore CA1051 // Do not declare visible instance fields

        public void Error(string mess)
        {
            //If you don't want exception - provide the logger
            if (LoggerN != null)
                LoggerN("CsvError: " + mess);
            else
                throw new NbException("CsvError: " + mess);
        }

        public void Warning(string format, params object[] parameters)
        {
            //If you don't want exception - provide the logger
            if (LoggerN != null)
                LoggerN("CsvWarning: " + String.Format(format, parameters));
            else
                throw new NbException("CsvWarning: " + String.Format(format, parameters));
        }
    }

    public sealed class CsvWriter<T> : IDisposable
    {
        private StreamWriter wrtr;
        private readonly string FileName;
        private readonly CsvParameters csvParam;
        private readonly char sep;
        private readonly List<CsvObjectToText> fieldList;

        public CsvWriter(string fileName, CsvParameters csvParamN = null)
        {
            FileName = fileName;
            csvParam = csvParamN ?? new CsvParameters { FieldDelimiterN = ',' };

            sep = csvParamN?.FieldDelimiterN ?? NbExt.defaultSeparator;
            fieldList = CsvObjectToText.Create(typeof(T), csvParamN?.LoggerN, sep);
        }

        public void Write(T obj, string tail = null)
        {
            if (wrtr == null)
            {
                wrtr = new StreamWriter(FileName);
                var headers = String.Join(sep.ToString(), fieldList.Select(h => h.Name));
                wrtr.WriteLine(headers);
            }

            int fldCount = 0;
            foreach (var fldProp in fieldList)
            {
                if (fldCount > 0)
                    wrtr.Write(sep);

                string res = fldProp.GetText(obj, csvParam);
                wrtr.Write(res);
                fldCount++;
            }

            if (!String.IsNullOrEmpty(tail))
            {
                wrtr.Write(sep);
                wrtr.Write(tail);
            }

            wrtr.WriteLine();
        }


        public void Write(IEnumerable<T> objs, string tail = null)
        {
            foreach (var obj in objs)
                Write(obj, tail);
        }

        public void Dispose()
        {
            wrtr?.Flush();
            wrtr?.Dispose();
        }
    }

    public static partial class NbExt
    {
        internal static char defaultSeparator = ',';
        private static readonly Encoding defaultEnconding = Encoding.UTF8;
        private const char quote = '"';

        private enum States { SeparatorRead, ReadingField, ReadingQuotedField };

        public static string ToCsvString(this string str, char sep = ',') //TODO: Speedup?
        {
            str = str.Replace("\"", "\"\""); //Double quotes
            if (str.Contains(sep) || str.Contains("\""))
                return "\"" + str + "\"";
            else
                return str;
        }

        /// <summary>
        /// Reads the key-value pairs from a csv file. The header is expected (first line will be skipped), but the column names are not important. The first column in for keys the second for values. 
        /// If the configName parameter is specified, the function expects a csv with three columns: Key, Value, Config. Lines where config is not specified or matches the sent value will be loaded.
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="configName"></param>
        /// <param name="csvParamN"></param>
        /// <returns></returns>
        public static NbDictionary<string, string> CsvToDict(string fileName, string configName = null, CsvParameters csvParamN = null)
        {
            var dict = new NbDictionary<string, string>(description: fileName);
            Encoding enc = csvParamN?.EncodingN ?? defaultEnconding;
            char sep = csvParamN?.FieldDelimiterN ?? defaultSeparator;

            int lineCnt = 0;

            using Stream strm = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
            using StreamReader rdr = new StreamReader(strm, enc);
            if (rdr.EndOfStream)
                return null; //No lines, no header

            var bld = new StringBuilder();
            while (!rdr.EndOfStream)
            {
                lineCnt++;
                string line = rdr.ReadLine();
                if (String.IsNullOrWhiteSpace(line))
                    continue;

                if ((csvParamN?.HeadersAreInTheFile ?? true) && lineCnt == 1)
                    continue; //Skip headers

                var cols = DeCsvLine(line, bld, sep, trim: true).ToList();

                if (String.IsNullOrEmpty(configName))
                    switch (cols.Count) //Only two columns
                    {
                        case 0: continue;
                        case 1: dict.Add(cols[0], null); break;
                        default: dict.Add(cols[0], cols[1]); break;
                    }
                else //Key, Config, Value
                    switch (cols.Count)
                    {
                        case 0: continue;
                        case 1: dict.Add(cols[0], null); break; //Only key specified - value is null
                        case 2: dict.Add(cols[0], cols[1]); break; //Key and value specified - save both
                        default:
                            if (!String.IsNullOrWhiteSpace(cols[2]) && cols[2].EqIC(configName)) //If config column is ot empty and config doesn't match - skip
                                dict.Add(cols[0], cols[1]);
                            break;
                    }
            }
            return dict;
        }

        public static void ToCsv<T>(this IEnumerable<T> objList, string fileName, CsvParameters csvParamN = null)
            where T : class
        {
            Encoding enc = csvParamN?.EncodingN ?? defaultEnconding;

            using (StreamWriter wrtr = new StreamWriter(fileName + ".new", false, enc))
                ToCsv(objList, wrtr, csvParamN);

            //If saving was successful
            File.Delete(fileName);
            File.Move(fileName + ".new", fileName);
        }

        public static void ToCsv<T>(this IEnumerable<T> objList, TextWriter wrtr, CsvParameters csvParamN = null)
            where T : class
        {
            char sep = csvParamN?.FieldDelimiterN ?? defaultSeparator;
            var fieldList = CsvObjectToText.Create(typeof(T), csvParamN?.LoggerN, sep);
            var headers = String.Join(sep.ToString(), fieldList.Select(h => h.Name));
            wrtr.WriteLine(headers);
            foreach (var obj in objList)
            {
                int fldCount = 0;
                foreach (var fldProp in fieldList)
                {
                    if (fldCount > 0)
                        wrtr.Write(sep);

                    string res = fldProp.GetText(obj, csvParamN);
                    wrtr.Write(res);
                    fldCount++;
                }
                wrtr.WriteLine();
            }
        }

        public static IEnumerable<string> ToCsvLines<T>(this IEnumerable<T> objList, CsvParameters csvParamN = null)
            where T : class
        {
            using MemoryStream ms = new MemoryStream();
            using StreamWriter wrtr = new StreamWriter(ms);
            ToCsv(objList, wrtr, csvParamN);
            wrtr.Flush();
            ms.Position = 0;
            using StreamReader rdr = new StreamReader(ms);
            while (!rdr.EndOfStream)
                yield return rdr.ReadLine();
        }

        public static void ToCsv<T>(this IEnumerable<T> objList, DirectoryInfo repoDir, CsvParameters csvParamN = null) where T : class =>
            ToCsv(objList, GetFilename<T>(repoDir), csvParamN);

        private static string GetFilename<T>(DirectoryInfo di) => Path.Combine(di.FullName, typeof(T).Name + ".csv");

        public static Obj BuildObject<Obj, Inf>(Inf infoHolder, CsvObjectSetter<Inf>[] fldArray, Action<string> log)
            where Obj : class, new()
        {
            Obj obj = new Obj();
            FillObject(obj, infoHolder, fldArray, log);
            return obj;
        }

        public static void FillObject<Obj, Inf>(Obj obj, Inf infoHolder, CsvObjectSetter<Inf>[] fldArray, Action<string> _)
        {
            //TODO: Use info holder as a numerable of strings and ZIP it with fldArray
            //This way we can Enumerate only the fields refered by fldEnum, and avoid reading each line to the end
            foreach (var setter in fldArray)
                setter?.SetField(obj, infoHolder);
        }

        public static IEnumerable<T> FromCsv<T>(string fileName, CsvParameters csvParamN = null)
            where T : new()
        {
            if (!File.Exists(fileName))
                return Enumerable.Empty<T>();

            //Stream will be closed by the reader in the below function
            Stream strm = null;
            Exception ex = null;
            for (int i = 2; i > 0; i--) //Allow a couple of retries
            {
                try
                {
                    strm = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                    break;
                }
                catch(Exception x)
                {
                    ex = x;
                }
            }
            if (ex != null)
                throw ex;

            return FromCsv<T>(strm, csvParamN, fileName);
        }

        public static IEnumerable<T> FromCsv<T>(Stream strm, CsvParameters csvParamN = null, string fileName = null)
            where T : new()
        {
            StringBuilder bld = new StringBuilder();
            Encoding enc = csvParamN?.EncodingN ?? defaultEnconding;

            using StreamReader rdr = new StreamReader(strm, enc);
            if (rdr.EndOfStream)
                yield break; //No lines, no header

            char sep = csvParamN?.FieldDelimiterN ?? defaultSeparator;
            List<string> headers = DeCsvLine(rdr.ReadLine(), bld, sep, trim: true) //always trim headers
                .Select(h1 => (h1.StartsWith("[") && h1.EndsWith("]")) ? h1.Substring(1, h1.Length - 1) : h1) //Handle fields like [ID]
                .Where(h2 => !String.IsNullOrWhiteSpace(h2)).ToList(); //Header
            CsvTextToObject[] fieldsAndProps = CsvTextToObject.Create(typeof(T), headers, csvParamN); //Just take the string, ignoring the index

            //Process custom attribute for file line num or file name
            Action<object, object> fileLineNumSetter = null, fileNameSetter = null, lineContentSetter = null;
            foreach (var fld in typeof(T).GetFields().Where(f => !f.IsStatic))
            {
                fld.ProcessCustomAttributes(fld.SetValue, ref fileLineNumSetter, ref fileNameSetter, ref lineContentSetter);
            }
            foreach (var prp in typeof(T).GetProperties())
            {
                prp.ProcessCustomAttributes(prp.SetValue, ref fileLineNumSetter, ref fileNameSetter, ref lineContentSetter);
            }

            int counter = 1; //The header is already read
            while (!rdr.EndOfStream)
            {
                counter++;
                string line = rdr.ReadLine();
                if (String.IsNullOrWhiteSpace(line))
                    continue;

                T obj = BuildObject<T>(DeCsvLine(line, bld, sep, csvParamN?.Trim ?? false), fieldsAndProps, csvParamN?.LoggerN);

                fileLineNumSetter?.Invoke(obj, counter);
                fileNameSetter?.Invoke(obj, fileName);
                lineContentSetter?.Invoke(obj, line);
                yield return obj;
            }
        }

        public static IEnumerable<T> FromCsv<T>(DirectoryInfo repoDir, CsvParameters csvParamN = null) where T : new() => FromCsv<T>(GetFilename<T>(repoDir), csvParamN);

        private static void ProcessCustomAttributes(this MemberInfo fldProb, Action<object, object> setter,
            ref Action<object, object> fileLineNumSetter, ref Action<object, object> fileNameSetter, ref Action<object, object> lineContentSetter)
        {
            foreach (var custAtt in fldProb.GetCustomAttributes().Select(ca => ca.GetType().Name))
            {
                switch (custAtt)
                {
                    case nameof(CsvFileLineNum):
                        if (fileLineNumSetter != null)
                            throw new NbExceptionInfo($"There are two or more fields with {nameof(CsvFileLineNum)} attribute");

                        fileLineNumSetter = setter;
                        break;
                    case nameof(CsvFileName):
                        if (fileNameSetter != null)
                            throw new NbExceptionInfo($"There are two or more fields with {nameof(CsvFileName)} attribute");

                        fileNameSetter = setter;
                        break;

                    case nameof(CsvFileLineContent):
                        if (lineContentSetter != null)
                            throw new NbExceptionInfo($"There are two or more fields with {nameof(CsvFileLineContent)} attribute");

                        lineContentSetter = setter;
                        break;
                }
            }
        }


        public static IEnumerable<T> FromCsv<T>(IEnumerable<string> lines, CsvParameters csvParamN = null)
            where T : new()
        {
            char sep = csvParamN?.FieldDelimiterN ?? defaultSeparator;

            StringBuilder bld = new StringBuilder();
            CsvTextToObject[] fieldsAndProps = null;
            foreach (string line in lines)
            {
                if (fieldsAndProps == null)
                {
                    List<string> headers = DeCsvLine(line, bld, sep, trim: true) //Always trim headers
                        .Select(h1 => (h1.StartsWith("[") && h1.EndsWith("]")) ? h1.Substring(1, h1.Length - 1) : h1) //Handle fields like [ID]
                        .ToList(); //Header
                    fieldsAndProps = CsvTextToObject.Create(typeof(T), headers, csvParamN); //Just take the string, ignoring the index
                    continue;
                }

                if (String.IsNullOrWhiteSpace(line))
                    continue;

                yield return BuildObject<T>(DeCsvLine(line, bld, sep, csvParamN?.Trim ?? false), fieldsAndProps, csvParamN?.LoggerN);
            }

            if (fieldsAndProps == null)
                csvParamN?.Warning("CSV didn't contain the header");
        }

        public static Obj BuildObject<Obj>(IEnumerable<string> infoEnum, CsvTextToObject[] fldArray, Action<string> log)
        where Obj : new()
        {
            Obj obj = new Obj();
            FillObject<Obj>(obj, infoEnum, fldArray, log);
            return obj;
        }

        public static void FillObject<Obj>(Obj obj, IEnumerable<string> infoEnum, CsvTextToObject[] fldArray, Action<string> _)
        {
            int arrInd = 0;
            while (fldArray[arrInd].SpecFunc != CsvFieldInfo.SpecialFunction.None) //Skip all special fields - they will be filled in elsewhere
                arrInd++;

            int colNum = 0;
            foreach (string str in infoEnum)
            {
                if (arrInd >= fldArray.Length) //We've reached the end of fields to fill
                    break;

                if (colNum == fldArray[arrInd].Index) //curent column and the next field to fill index match
                {
                    fldArray[arrInd].SetField(obj, str);
                    arrInd++; //Go to the next field to fill
                }
                else //Current text column is not required in the object
                {
                    // Debug.Assert(colNum < arrInd); 
                }
                colNum++;
            }
        }

        /// <summary>
        /// DeCsv algorithm runs on the string already read from the file - to be deprecated, run DeCsvLine of the TextReader where possible
        /// </summary>
        /// <param name="str"></param>
        /// <param name="bld">The string builder allocated outside the cycle to reduce the number of allocations</param>
        /// <param name="separator"></param>
        /// <param name="trim"></param>
        /// <returns></returns>
        public static IEnumerable<string> DeCsvLine(string str, StringBuilder bld, char separator, bool trim)
        {
            using var rdr = new StringReader(str);
            States state = States.SeparatorRead;

            bld.Clear();
            int curr;
            while ((curr = rdr.Read()) != -1)
            {
                char ch = (char)curr;

                switch (state)
                {
                    case States.SeparatorRead:
                        if (ch.Equals(quote))
                            state = States.ReadingQuotedField;
                        else if (ch.Equals(separator)) //Separators next to each other - empty string
                            yield return String.Empty;
                        else
                        {
                            state = States.ReadingField;
                            bld.Append(ch);
                        }
                        break;
                    case States.ReadingField:
                        if (ch.Equals(separator))
                        {
                            yield return trim ? bld.ToString().Trim() : bld.ToString(); //The string is ready
                            bld.Clear();
                            state = States.SeparatorRead;
                        }
                        else
                            bld.Append(ch); //Simply next symbol 
                        break;
                    case States.ReadingQuotedField:
                        //Don't check for separator inside quotes
                        if (ch.Equals(quote)) //Could be end of the string or embedded quotes
                        {
                            int peek = rdr.Peek();
                            if (peek == -1) //End of line
                                break; //It was the last field in the line and it ends with separator, stop and return the last line
                            else if (((char)peek).Equals(quote))
                            { //Two quotes together
                                rdr.Read(); //Consume the next separator
                                bld.Append(quote); //Keep only one of them
                            }
                            else if (((char)peek).Equals(separator))
                                state = States.ReadingField; //The quote is closed, treat as normal field
                            else
                            { //Not a double quote and not followed by the separator, give a warning.
                              //TODO: give a warning
                                bld.Append(ch); //Append it just in case 
                            }
                        }
                        else
                            bld.Append(ch);
                        break;
                }
            }
            yield return trim ? bld.ToString().Trim() : bld.ToString(); //return the last string
        }

        public static IEnumerable<string> DeCsvLine2(TextReader rdr, StringBuilder bld, char separator, bool trim)
        {
            States state = States.SeparatorRead;

            bld.Clear();
            int curr;
            while ((curr = rdr.Read()) != -1)
            {
                char ch = (char)curr;

                switch (state)
                {
                    case States.SeparatorRead:
                        if (ch == '\r')
                            continue;
                        else if (ch == '\n')
                            goto last;
                        else if (ch.Equals(quote))
                            state = States.ReadingQuotedField;
                        else if (ch.Equals(separator)) //Separators next to each other - empty string
                            yield return String.Empty;
                        else
                        {
                            state = States.ReadingField;
                            bld.Append(ch);
                        }
                        break;
                    case States.ReadingField:
                        if (ch == '\r')
                            continue;
                        else if (ch == '\n')
                            goto last;
                        else if (ch.Equals(separator))
                        {
                            yield return trim ? bld.ToString().Trim() : bld.ToString(); //The string is ready
                            bld.Clear();
                            state = States.SeparatorRead;
                        }
                        else
                            bld.Append(ch); //Simply next symbol 
                        break;
                    case States.ReadingQuotedField:
                        //Don't check for separator inside quotes
                        if (ch.Equals(quote)) //Could be end of the string or embedded quotes
                        {
                            int peek = rdr.Peek();
                            if (peek == -1) //End of file
                                goto last; //It was the last field in the line and it ends with separator, stop and return the last line
                            else if (((char)peek).Equals(quote))
                            { //Two quotes together
                                rdr.Read(); //Consume the next separator
                                bld.Append(quote); //Keep only one of them
                            }
                            else
                                state = States.ReadingField; //The quote is closed, treat as normal field
                        }
                        else
                            bld.Append(ch);
                        break;
                }
            }
        last:
            yield return trim ? bld.ToString().Trim() : bld.ToString(); //return the last string
        }


        [Obsolete("Method ToDebugList should only be used temporary")]
        public static List<T> ToDebugList<T>(this IEnumerable<T> en)
        {
            return en.ToList();
        }

        public class MaxMin
        {
            public MaxMin(string name)
            {
                Name = name;
                Min = Int32.MaxValue;
                Max = Int32.MinValue;
                IsNumber = true;
                IsDate = true;
            }

            public readonly string Name;
            public int Min;
            public int Max;
            public bool IsNumber;
            public bool IsDate;

            public override string ToString()
            {
                return String.Format("{0}: ({1},{2}){3}{4}", Name, Min, Max,
                    IsNumber ? " Number" : String.Empty,
                    IsDate ? " Date" : String.Empty);
            }
        }

        public static List<MaxMin> MaxMinLengths(string fileName, char separator)
        {
            bool header = true;
            List<MaxMin> stats = null;
            StringBuilder bld = new StringBuilder();
            foreach (var line in File.ReadAllLines(fileName))
            {
                if (header)
                {
                    stats = line.Split(',').Select(l => new MaxMin(l)).ToList();
                    header = false;
                }
                else
                {
                    int cnt = 0;
                    foreach (string fld in DeCsvLine(line, bld, separator, trim: false))
                    {
                        MaxMin mm = stats[cnt];
                        int len = fld.Length;
                        mm.Max = Math.Max(mm.Max, fld.Length);
                        mm.Min = Math.Min(mm.Min, fld.Length);

                        if (mm.IsDate && fld.Length > 0 && !DateTime.TryParse(fld, out DateTime dt))
                        {
                            mm.IsDate = false;
                        }
                        if (mm.IsNumber && fld.Length > 0 && Int32.TryParse(fld, out int num))
                        {
                            mm.IsNumber = false;
                        }

                        cnt++;
                    }
                }
            }
            return stats;
        }
    }

    public abstract class IdHolder
    {
        protected abstract int MaxId { get; set; }

        public IdHolder()
        {
            Id = (++MaxId).ToString();
        }

        public string Id
        {
            get { return _id; }
            set
            {
                _id = value;
                if (Int32.TryParse(value.ToString(), out int intId) && intId > MaxId)
                    MaxId = intId;
            }
        }
        [CsvIgnore]
        private string _id;
    }


    public class NbStringReader
    {
        private int pos;
        private readonly string _str;
        public NbStringReader(string str)
        {
            _str = str;
            pos = 0;
        }

        public bool IsReadToTheEnd
        {
            get { return pos == _str.Length; }
        }
        public string GetString(int length, string aFieldName)
        {
            if (pos + length > _str.Length)
                throw new Exception("Unexpected end of string while reading the field " + aFieldName);
            string res = _str.Substring(pos, length).Trim();
            pos += length;
            return res;
        }
        public NbStringReader Str(string fieldName, out string field, int length)
        {
            if (pos + length > _str.Length)
                throw new Exception("Unexpected end of string while reading the field " + fieldName);
            field = _str.Substring(pos, length).Trim();
            pos += length;
            return this;
        }
        public NbStringReader DecimalNotNull(string fieldName, out decimal field, int length, decimal nullValue = 0M)
        {
            Str(fieldName, out string str, length);
            if (String.IsNullOrWhiteSpace(str)) //Empty string - use nullValue provided
                field = nullValue;
            else if (!decimal.TryParse(str, out field))
                throw new CsvException("Can't parse a decimal out of '{0}' for the field '{1}'", str, fieldName);
            return this;
        }
        public NbStringReader IntNotNull(string fieldName, out int field, int length, int nullValue = -1)
        {
            Str(fieldName, out string str, length);
            if (String.IsNullOrWhiteSpace(str)) //Empty string - use nullValue provided
                field = nullValue;
            else if (!Int32.TryParse(str, out field))
                throw new CsvException("Can't parse an interger out of '{0}* for the field '{1}'", str, fieldName);
            return this;
        }
    }


    public sealed class CsvIgnore : Attribute { }
    public sealed class CsvFileName : Attribute { }
    public sealed class CsvFileLineNum : Attribute { }
    public sealed class CsvFileLineContent : Attribute { }

    public sealed class CsvNameInSource : Attribute
    {
        public readonly string SourceColumn;
        public CsvNameInSource(string sourceColumnName) { SourceColumn = sourceColumnName; }
    }

    public sealed class CsvFormat : Attribute
    {
        public readonly string Format;
        public CsvFormat(string format) { Format = format; }
    }

    public class CsvException : Exception
    {
        public CsvException(string aMessage)
            : base(aMessage)
        { }

        public CsvException(string aFormat, params object[] args)
            : base(String.Format(aFormat, args))
        { }

        public CsvException(Exception ex, string aFormat, params object[] args)
            : base(String.Format(aFormat, args), ex)
        { }
    }

    public class LinesCollector : IDisposable
    {
        private class FileDesc
        {
            internal FileDesc(string fullPath)
            {
                FullPath = fullPath;
                lines = new List<string>(500);
            }

            internal readonly string FullPath;
            internal readonly List<string> lines;
        }

        public readonly string Dir;
        private readonly Dictionary<string, FileDesc> fFiles;
        private readonly Dictionary<string, string> HeadersN;
        private readonly string DefaultHeaderN;
        private readonly string DefaultFooterN;
        public readonly string ReportPrefix;

        public LinesCollector(string dir, string reportPrefix, Dictionary<string, string> headersN, string defaultHeaderN, string defaultFooterN = null)
        {
            Dir = dir;
            //NbDir.CreateDirRecursive(dirName);

            fFiles = new Dictionary<string, FileDesc>(10);
            HeadersN = headersN;
            DefaultHeaderN = defaultHeaderN;
            DefaultFooterN = defaultFooterN;
            ReportPrefix = reportPrefix;
        }

        public void Write(string subSystem, string line, string fileName = null)
        {
            if (!fFiles.TryGetValue(subSystem, out FileDesc fd))
            {
                fd = new FileDesc(Path.Combine(Dir, fileName ?? (subSystem + ".csv")));
                fFiles.Add(subSystem, fd);
            }
            fd.lines.Add(line);
        }

        public void Dispose()
        {
            foreach (var pair in fFiles)
            {
                var list = pair.Value.lines;
                if (list.Count == 0)
                    continue;

                try
                {
                    list.Sort();
                    string hdr = null;
                    if (HeadersN?.TryGetValue(pair.Key, out hdr) ?? false)
                        list.Insert(0, hdr);
                    else if (!String.IsNullOrEmpty(DefaultHeaderN))
                        list.Insert(0, DefaultHeaderN);

                    if (!String.IsNullOrEmpty(DefaultFooterN))
                        list.Add(DefaultFooterN);

                    File.WriteAllLines(pair.Value.FullPath, list);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error while saving file {pair.Value.FullPath}:\r\n" + NbException.Exception2String(ex));
                }
            }
        }
    }
}


