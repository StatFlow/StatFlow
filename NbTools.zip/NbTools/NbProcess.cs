﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NbTools
{
    public class NbProcess
    {
        public static Task<(int exitCode, string stdOut, string errOut)> RunAsync(string exeName, IEnumerable<string> argumentsN = null, string workDirN = null)
        {
            var tsc = new TaskCompletionSource<(int exitCode, string stdOut, string errOut)>();

            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = PutInQuotes(exeName),
                Arguments = argumentsN != null ? String.Join(" ", argumentsN.Select(a => PutInQuotes(a))) : null,
                WorkingDirectory = workDirN,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };

            string stdOut, stdErr;
            Process pc = Process.Start(psi);
            pc.EnableRaisingEvents = true;

            stdOut = pc.StandardOutput.ReadToEnd();
            stdErr = pc.StandardError.ReadToEnd();
            int exitCode = pc.ExitCode;

            pc.Exited += (s, e) =>
            {
                tsc.SetResult((exitCode, stdOut, stdErr));
                pc.Dispose();
            };

            return tsc.Task;
        }

        public static string PutInQuotes(string str)
        {
            if (!str.Contains(" "))
                return str;
            else if (str.StartsWith('\"') && str.EndsWith("\""))
                return str;
            else
                return '\"' + str + '\"';
        }


        public static (string stdOut, string errOut) RunSyncFail(string exeName, DirectoryInfo workDir = null, params string[] arguments)
        {
            var (exitCode, stdOut, errOut) = RunSync(exeName, workDir, arguments);
            if (exitCode != 0)
                throw new Exception($"Proces {exeName} returned {exitCode}{Environment.NewLine}{errOut}");

            return (stdOut, errOut);
        }

        public static (int exitCode, string stdOut, string errOut) RunSync(string exeName, DirectoryInfo workDir = null, params string[] arguments)
        {
            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = PutInQuotes(exeName),
                Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
                WorkingDirectory = workDir?.FullName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };

            string stdOut, stdErr;

            using Process pc = Process.Start(psi);
            stdOut = pc.StandardOutput.ReadToEnd();
            stdErr = pc.StandardError.ReadToEnd();
            int exitCode = pc.ExitCode;
            pc.WaitForExit();

            return (exitCode, stdOut, stdErr);
        }


        internal void SvnSubmit(string dir)
        {
            var submitComment = DateTime.Now.ToString("yyMMdd - HHmmss");

            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = "svn.exe",
                Arguments = $"commit -m \"{submitComment}\"",
                WorkingDirectory = dir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true
            };

            string stdOut, stdErr;
            using Process pc = Process.Start(psi);
            stdOut = pc.StandardOutput.ReadToEnd();
            stdErr = pc.StandardError.ReadToEnd();
            pc.WaitForExit();
            int exitCode = pc.ExitCode;
            if (exitCode != 0)
                throw new Exception($"Svn exited with code: {exitCode}");
        }
    }
}
