﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbTools
{
    /// <summary>
    /// Подумать о том, чтобы сделать Fluent API для вызова NbProcess
    /// https://visualstudiomagazine.com/articles/2013/12/01/best-practices-for-designing-a-fluent-api.aspx
    /// </summary>
    public class NbProcess
    {
        public static Task<(int exitCode, string stdOut, string errOut)> RunAsync(string exeName, DirectoryInfo workDir = null, params string[] arguments)
        {
            var tsc = new TaskCompletionSource<(int exitCode, string stdOut, string errOut)>();

            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = PutInQuotes(exeName),
                Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
                WorkingDirectory = workDir?.FullName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };

            StringBuilder outBld = new StringBuilder();
            StringBuilder errBld = new StringBuilder();

            Process pc = new Process
            {
                StartInfo = psi,
                EnableRaisingEvents = true
            };

            pc.OutputDataReceived += (s, e) =>
            {
                outBld.AppendLine(e.Data);
            };
            pc.ErrorDataReceived += (s, e) =>
            {
                errBld.AppendLine(e.Data);
            };

            pc.Exited += (s, e) =>
            {
                int exitCode = pc.ExitCode;
                tsc.SetResult((exitCode, outBld.ToString(), errBld.ToString()));
                pc.Dispose();
            };

            pc.Start();
            pc.BeginOutputReadLine();
            pc.BeginErrorReadLine();
            return tsc.Task;
        }

        public static string PutInQuotes(string str)
        {
            if (!str.Contains(" "))
                return str;
            else if (str.StartsWith('\"') && str.EndsWith("\""))
                return str;
            else
                return '\"' + str + '\"';
        }


        public static (string stdOut, string errOut) RunSyncFail(string exeName, DirectoryInfo workDir = null, params string[] arguments)
        {
            var (exitCode, stdOut, errOut) = RunSync(exeName, workDir, arguments);
            if (exitCode != 0)
                throw new Exception($"Proces {exeName} returned {exitCode}{Environment.NewLine}{errOut}");

            return (stdOut, errOut);
        }

        public static void FireAndForget(string exeName, DirectoryInfo workDir = null, params string[] arguments)
        {
            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = PutInQuotes(exeName),
                Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
                WorkingDirectory = workDir?.FullName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };
            Process.Start(psi);
        }


        public static (int exitCode, string stdOut, string errOut) RunSync(string exeName, DirectoryInfo workDir = null, params string[] arguments)
        {
            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = PutInQuotes(exeName),
                Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
                WorkingDirectory = workDir?.FullName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };

            string stdOut, stdErr;

            using Process pc = Process.Start(psi);
            stdOut = pc.StandardOutput.ReadToEnd();
            stdErr = pc.StandardError.ReadToEnd();
            int exitCode = pc.ExitCode;
            pc.WaitForExit();

            return (exitCode, stdOut, stdErr);
        }


        internal void SvnSubmit(string dir)
        {
            var submitComment = DateTime.Now.ToString("yyMMdd - HHmmss");

            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = "svn.exe",
                Arguments = $"commit -m \"{submitComment}\"",
                WorkingDirectory = dir,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true
            };

            string stdOut, stdErr;
            using Process pc = Process.Start(psi);
            stdOut = pc.StandardOutput.ReadToEnd();
            stdErr = pc.StandardError.ReadToEnd();
            pc.WaitForExit();
            int exitCode = pc.ExitCode;
            if (exitCode != 0)
                throw new Exception($"Svn exited with code: {exitCode}");
        }
    }
}
