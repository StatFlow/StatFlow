﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Serialization;

using NbTools;
using NbOrm.Nbq;
using NbCollV1;
using NbTools.Collections;


namespace NbOrm.Xml
{
    public partial class view
    {
        [XmlIgnore]
        public CustomSqlProvider fCustSql; //Custom function to build the sql by url, model and enviroment
        [XmlIgnore]
        public CustomCollectionProvider fCustColl; 
        [XmlIgnore]
        public SQL fXmlSql; //MixedContent sql object provided in XML

        [XmlIgnore]
        public List<table> RefTables;

        [XmlIgnore]
        public List<table> KeyValueTables;

        public override string SqlSelectStatement() => sql.ToString();

        public override DfDynamicCollection DfDynamicCollectionByUriN(NbqQueryType qType, string query, model mdl, DfTable layout, object env)
        {
            if (fCustColl != null)
                return fCustColl(qType, query, mdl, env);
            else
                return null;
        }

        public override string SqlSelectStatementByUri(NbqQueryType qType, string query, model mdl, object env)
        {
            if (fCustSql != null)
                return fCustSql(qType, query, mdl, env);
            else if (fXmlSql == null)
                throw new Exception("Either Xml Sql or Custom C# request function should exist");

            return SqlGenerator.GenerateViewSql(NbqParser.Parse(query, mdl), fXmlSql, name);
        }

        public override IEnumerable<field_base> Fields => fields.SafeOfType<field_base>();
        public IEnumerable<field_base> Parameters => sql?.Parameters ?? Enumerable.Empty<field_base>();

        public override IEnumerable<recordset> TableReferences => RefTables;

        public override field_base GetFieldForSearchTypeN(SearchTypes sType)
        {
            var res = Parameters.SingleOrDefaultVerbose(f => f.default_search == sType, i => $"There are {i} parameters with default_searchtype = {sType} in the view {name}");
            return res ?? base.GetFieldForSearchTypeN(sType); //If not such parameters - find in fields
        }


        public override void ResolveAndValidate(modelConfig config, NbDictionary<string, recordset> tablesDict, type_base[] types, XElement mixedContentN)
        {
            Cfg = config;
            RefTables = new List<table>(this.tables?.Length ?? 0);
            KeyValueTables = new List<table>(this.tables?.Length ?? 0);

            foreach (var r in this.tables.Safe())
            {
                if (String.IsNullOrWhiteSpace(r.name))
                    throw new Exception($"table_ref with empty name in '{name}' view");

                recordset rc = tablesDict[r.name];
                if (!(rc is table))
                    throw new Exception($"view '{name}' references {rc.GetType().Name} '{rc.name}', but only references to 'table' are supported");

                if (r.is_key_value)
                    KeyValueTables.Add(rc as table);
                else
                    RefTables.Add(rc as table);
            }

            //TODO: Put the table resolution into a single location
            foreach (var fbase in Fields.Safe().Concat(Parameters))
            {
                recordset rc = null;
                if (fbase is field_ref)
                {
                    var tblName = (fbase as field_ref)?.ref_table; //?? (fbase as ViewParam)?.ref_table;
                    if (String.IsNullOrWhiteSpace(tblName))
                        throw new Exception($"{fbase} doesn't have field_ref field populated in '{name}' view");

                    rc = rc = tablesDict[tblName];
                }
                if (rc != null)
                    fbase.ResolveReference(config, rc, this, tablesDict, types);

                if (fbase is field)
                {
                    fbase.ResolveReference(config, null, this, tablesDict, types);

                    var fld = fbase as field;
                    if (fld.BaseType.Ctype == CType.blob)
                        throw new Exception($"{name}.{fld} - fields with {nameof(CType.blob)} type can't be used in views, please use the {nameof(field_ref)} tag that references solid table with primary key containg the blob");
                }

                if (fbase is ViewParam)
                {
                    var par = fbase as ViewParam;
                }
            }

            //Routine to put text and objects from the mixedContext into the single array. Something that XmlSerializer should have done.
            //Text (even a single copy) always gets copied to the Items array.
            if (mixedContentN != null)
            {
                object[] orderedList = new object[(sql.Items?.Length ?? 0) + (sql.Text?.Length ?? 0)];
                int objCnt = 0, textCnt = 0, resCnt = 0;
                foreach (var node in mixedContentN.Nodes())
                {
                    if (node is XText)
                        orderedList[resCnt] = sql.Text[textCnt++];
                    else if (node is XElement)
                        orderedList[resCnt] = sql.Items[objCnt++];
                    else if (node is XComment) //Ignore comments
                    { }
                    else
                        throw new Exception($"Unsupported node type: {node.GetType().Name} in mixedContent ordering routine");
                    ++resCnt;
                }
                sql.Items = orderedList;
                sql.Text = null;
            }
        }

        internal override IEnumerable<string> CsClass(SqlCs csGenerator) { yield break; } //TODO: view generation is not implemented

        public override recordset MergeTo(recordset toTable)
        {
            if (GetType() != toTable.GetType())
                throw new NbExceptionInfo($"Attempt to merget {GetType().Name} {name} and {toTable.GetType().Name} {toTable.name} ");

            //view other = toTable as view;
            throw new NbExceptionInfo($"Merging for views is not yet supported");
        }
    }
}
