﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Serialization;
using NbTools.Collections;

using NbTools;
using NbCollV1;
using NbOrm.Nbq;

#pragma warning disable IDE1006 //These words must begin with upper case characters

namespace NbOrm.Xml
{
    public abstract partial class recordset : IMergeableByName<recordset>
    {
        [XmlIgnore]
        internal protected modelConfig Cfg;

        [XmlIgnore]
        public modelTables TableSet { get; internal set; }
        public string GetConnectionName() => TableSet.conn_name;

        public abstract IEnumerable<field_base> Fields { get; }
        public bool TryGetField(string name, out field_base field)
        {
            field = Fields.FirstOrDefault(f => f.name.EqIC(name));
            return field != null;
        }

        public field_base this[string fldName] => 
            TryGetField(fldName, out field_base res) ? res : throw new Exception($"Can't find the field {fldName} in xml recordset {name}");

        public abstract IEnumerable<recordset> TableReferences { get; }

        public virtual field_base GetFieldForSearchTypeN(SearchTypes sType)
        {
            var res = Fields.SingleOrDefaultVerbose(f => f.default_search == sType, i => $"There are {i} fields with default_searchtype = {sType} in the recordset {name}");
            if (res != null)
                return res;

            var pKey = PrimaryKeyN; //If primary key is compatible with requested search type
            if (pKey != null && model.CtypeToSearchType(pKey.GetCType()) == sType)
                return pKey;

            return null;
        }

        //TODO Support combined keys here
        public field_base PrimaryKeyN => Fields.FirstOrDefault(f => f.key == field_baseKey.primary || f.key == field_baseKey.identity);
        public abstract void ResolveAndValidate(modelConfig config, NbDictionary<string, recordset> tablesDict, type_base[] types, XElement mixedContentN);
        public override string ToString() => $"{GetType().Name} '{name}'";

        internal static recordset ResolveReferenceToTable(string ref_table, NbDictionary<string, recordset> tablesDict, string field_name)
        {
            if (!tablesDict.TryGetValue(ref_table, out recordset rs))
                throw new NbException($"Recordset or field {field_name} references non-exiting table {ref_table}. Other recordsets are not supported");
            return rs;
        }

        public string MergeName => name;
        public virtual recordset MergeTo(recordset other)
        { throw new NotImplementedException($"MergeTo is not implemented for {GetType().Name} {nameof(recordset)}"); }

        #region Code Generation

        internal static string sqlFieldSeparator = Environment.NewLine + ","; //+ Environment.NewLine

        public string CsName => name; //Name used to generate C# statemens will not be pluralised 
        public virtual string SqlName => name; //Name used to generate SQL statemens (can be pluralised)
        public string XmlName => name; //Name used for XML resolution purposes

        public abstract string SqlSelectStatement();
        public abstract string SqlSelectStatementByUri(NbqQueryType qType, string query, model mdl, object env); //object is an extra parameter to pass to custom function

        //object is an extra parameter to pass to custom function
        public virtual DfDynamicCollection DfDynamicCollectionByUriN(NbqQueryType qType, string query, model mdl, DfTable layout, object env) => null;

        internal abstract IEnumerable<string> CsClass(SqlCs csGenerator);

        protected IEnumerable<string> CsSelect()
        {
            return CsCode.BracedStatement($"internal static IEnumerable<{CsName}> Select(INbConn connection, string suffix = null)",
                NbExt.Yield($"string sql = @\"{SqlSelectStatement().Replace("\"", "\"\"")}\" + suffix;") //Replace single quotes with double for C#
                .EmptyLines(1, CsSelectCommand()));
        }

        protected IEnumerable<string> CsSelectCommand()
        {
            return CsCode.BracedStatement("using(var r = connection.CreateReader(sql))",
                 CsCode.BracedStatement("while (r.Read())",
                 CsReaderToObject()
                ));
        }

        protected IEnumerable<string> CsReaderToObject()
        {
            yield return String.Format("var x = new {0}();", CsName);
            foreach (var f in Fields.Select((f1, i) => Tuple.Create(f1, i)))
                yield return f.Item1.CsReaderToProperty(f.Item2);

            yield return "yield return x;";
        }
        #endregion
    }

    public delegate string CustomSqlProvider(NbqQueryType qType, string query, model model, object environment);
    public delegate DfDynamicCollection CustomCollectionProvider(NbqQueryType qType, string query, model model, object environment);

    /// <summary>
    /// This interface should be implemeted by the code, which provides its onw sql or ready collections to be used in DataWalker
    /// Datawalker will then dinamically search for such implementations in the code
    /// </summary>
    public interface ICustomSqlProviderList
    {
        /// <summary>
        /// Gets the collection of Sql Providers that take the Url, the reference to the model and the evironment and return generated sql
        /// </summary>
        /// <returns>Clollection of tuples with the unique name and the SqlProvider</returns>
        IEnumerable<Tuple<string, CustomSqlProvider>> Items();

        /// <summary>
        /// Get the collection of collection providers, i.e. the objects taking the Url, the references to the model and the evironment and returning already loaded DfDynamicCollection
        /// </summary>
        /// <returns>Clollection of tuples with the unique name and the Collection Provider</returns>
        IEnumerable<Tuple<string, CustomCollectionProvider>> CollectionProviders();
    }

    public partial class groupby_query : recordset
    {
        private recordset ReferencedTable;

        public override IEnumerable<field_base> Fields => Items;
        public override IEnumerable<recordset> TableReferences
        { get { yield return ReferencedTable; } }

        internal override IEnumerable<string> CsClass(SqlCs csGenerator)
        {
            return CsCode.BracedStatement("public partial class " + CsName,
                Items.Select(f => f.CsProperty())
                .EmptyLines(1, CsSelect()));
        }

        public override string SqlSelectStatement()
        {
            return String.Format("SELECT {0}\r\nFROM {1} GROUP BY {2} ",
                String.Join(recordset.sqlFieldSeparator, Items.Select(f => f.SelectLine)),
                ReferencedTable.SqlName,
                String.Join(recordset.sqlFieldSeparator, Items.OfType<field_groupby>().Select(f => f.ReferencedField.name)));
        }

        public override void ResolveAndValidate(modelConfig config, NbDictionary<string, recordset> tablesDict, type_base[] types, XElement mixedContentN)
        {
            Cfg = config;
            if (String.IsNullOrWhiteSpace(name))
                throw new NbException("Query with empty name found");
            if (Items == null || Items.Length == 0)
                throw new NbException($"Query '{name}' int model doesn't contain any fields");

            ReferencedTable = ResolveReferenceToTable(ref_table, tablesDict, name);

            foreach (var ffield in Items)
                ffield.ResolveReference(config, ReferencedTable, this, tablesDict, types);
        }

        public override string SqlSelectStatementByUri(NbqQueryType qType, string query, model mdl, object env)
        {
            throw new NotImplementedException();
        }
    }


    public partial class join_query : recordset
    {
        private recordset LeftTable;
        private recordset RightTable;

        public override IEnumerable<field_base> Fields => Items;
        public override IEnumerable<recordset> TableReferences
        {
            get
            {
                yield return LeftTable;
                yield return RightTable;
            }
        }

        internal override IEnumerable<string> CsClass(SqlCs csGenerator)
        {
            return CsCode.BracedStatement("public partial class " + CsName,
                Items.Select(f => f.CsProperty())
                .EmptyLines(1, CsSelect()));
        }

        public override void ResolveAndValidate(modelConfig config, NbDictionary<string, recordset> tablesDict, type_base[] types, XElement mixedContentN)
        {
            Cfg = config;
            if (String.IsNullOrWhiteSpace(name))
                throw new NbException("Query with empty name found");

            LeftTable = ResolveReferenceToTable(ref_table_left, tablesDict, name);
            RightTable = ResolveReferenceToTable(ref_table_right, tablesDict, name);

            if (Items == null || Items?.Length == 0)
            {
                Items = LeftTable.Fields.Select(f => (field_base)new field_left { name = $"{LeftTable.name}.{f.name}", ref_field = f.name, @null = f.@null })
                    .Concat(RightTable.Fields.Select(f => (field_base)new field_right { name = $"{RightTable.name}.{f.name}", ref_field = f.name, @null = f.@null })).ToArray();
            }

            foreach (var ffield in Items.OfType<field_left>())
                ffield.ResolveReference(config, LeftTable, this, tablesDict, types);
            foreach (var ffield in Items.OfType<field_right>())
                ffield.ResolveReference(config, RightTable, this, tablesDict, types);

        }

        public override string SqlSelectStatement()
        {
            var left2rightField = LeftTable.Fields.OfType<field_ref>().Where(f => f.References(RightTable)).SingleOrDefault();
            var right2leftField = RightTable.Fields.OfType<field_ref>().Where(f => f.References(LeftTable)).SingleOrDefault();
            if (left2rightField == null && right2leftField == null)
                throw new Exception("'{0}' join query tries to join tables without foreign key relationship");

            string fields = String.Join(recordset.sqlFieldSeparator, Items.Select(f => f.SelectLine));
            string joinStatement = (left2rightField != null) ? left2rightField.SqlJoinCondition("l", "r") : right2leftField.SqlJoinCondition("r", "l");

            return $@"SELECT {fields}
FROM {LeftTable.SqlName} l
    INNER JOIN {RightTable.SqlName} r ON {joinStatement} ";
        }

        public override string SqlSelectStatementByUri(NbqQueryType qType, string query, model mdl, object env)
        {
            throw new NotImplementedException();
        }
    }

}

#pragma warning restore