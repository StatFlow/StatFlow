﻿using NbTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using System.Xml.Linq;

#pragma warning disable IDE1006

namespace NbOrm.Xml
{
    public partial class model
    {
        public static SearchTypes CtypeToSearchType(CType cType)
        {
            switch (cType)
            {
                case CType.@char:
                case CType.@string:
                    return SearchTypes.@string;

                case CType.@decimal:
                case CType.@double:
                case CType.@float:
                case CType.@int:
                case CType.@uint:
                case CType.@long:
                case CType.@ulong:
                case CType.@short:
                case CType.@ushort:
                    return SearchTypes.@int;

                case CType.DateTime:
                    return SearchTypes.date;
                default:
                    return SearchTypes.none;
            }
        }

        public static bool IsNumeric(CType cType)
        {

            switch (cType)
            {
                case CType.@byte:
                case CType.@sbyte:
                case CType.@char:
                case CType.@decimal:
                case CType.@double:
                case CType.@float:
                case CType.@int:
                case CType.@uint:
                case CType.@long:
                case CType.@ulong:
                case CType.@short:
                case CType.@ushort:
                    return true;
                default:
                    return false;
            }
        }

        public recordset GetRecordset(string name) => tables.SelectMany(ts => ts.Items.Safe()).Single(t => t.name.Equals(name, StringComparison.OrdinalIgnoreCase));

        private static readonly XmlSerializer modelXmlSerializer = new XmlSerializer(typeof(model));

        internal void ResolveAndValidate(IDictionary<string, XElement> viewMixedContents)
        {
            int tablesEndingWithS = tables.SelectMany(ts => ts.Items.Safe()).OfType<table>().Count(t => t.XmlName.EndsWith("S") || t.XmlName.EndsWith("s"));

            modelConfig cnf = new modelConfig
            {
                pluralise = (tablesEndingWithS < tables.Length / 2) ? TriBool.@true : TriBool.@false
            };
            config = cnf.PushSettingsTo(config);

            if (tables == null || tables.Length == 0)
                throw new NbException("Data model doesn't contain any tables");

            var tableDict = tables.SelectMany(ts => ts.Items.Safe()).ToNbDictionary(t => t.name, t => t, description: "Full set of recordsets from XML");

            foreach (var tableSet in tables)
            {
                foreach (var recordset in tableSet.Items.Safe())
                {
                    try
                    {
                        viewMixedContents.TryGetValue(recordset.name, out XElement mixedContent);
                        recordset.TableSet = tableSet;
                        recordset.ResolveAndValidate(config, tableDict, types, mixedContent);
                    }
                    catch (Exception ex)
                    {
                        throw new Exception($"Error while resolving {recordset.GetType().Name} '{recordset.name}'", ex);
                    }
                }
            }
        }

        public static model LoadXml(string xmlFileName)
        {
            var viewMixedContexts = new NbDictionary<string, XElement>(20, description: "NbOrm mixed contents");
            try
            {
                model res;
                using (FileStream str = new FileStream(xmlFileName, FileMode.Open))
                using (StreamReader rdr = new StreamReader(str))
                {
                    res = (model)modelXmlSerializer.Deserialize(rdr);

                    str.Seek(0, SeekOrigin.Begin);
                    var doc = XDocument.Load(str);
                    var tbls = doc.Element(nameof(model)).Element("tables");
                    var views = tbls.Elements(nameof(view)).ToList();
                    foreach (var v in views)
                    {
                        v.Element("sql")?.AddTo(viewMixedContexts, v.Attrib("name").Value);
                    }
                }
                res.ResolveAndValidate(viewMixedContexts);
                return res;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deserializing '{xmlFileName}'", ex);
            }
        }

        //Reads multiple xmls with the same schema
        public static model MergeXmls(string xmlFileSearchPatternWithPath)
        {
            List<string> csvFiles = new List<string>();
            var viewMixedContexts = new NbDictionary<string, XElement>(20, description: "NbOrm mixed contents");
            model mod = null;
            var xmlsToLoad = NbDir.ListFiles(xmlFileSearchPatternWithPath).ToList();
            foreach (var fi in xmlsToLoad)
            {
                try
                {
                    using (FileStream str = new FileStream(fi.FullName, FileMode.Open))
                    using (StreamReader rdr = new StreamReader(str))
                    {
                        var res = (model)modelXmlSerializer.Deserialize(rdr);
                        if (mod == null)
                            mod = res;
                        else
                            res.MergeTo(mod);

                        str.Seek(0, SeekOrigin.Begin);
                        var doc = XDocument.Load(str);
                        var tbls = doc.Element(nameof(model)).Elements("tables");
                        var lst = tbls.Elements(nameof(view)).ToList();
                        foreach (var v in lst)
                        {
                            v.Element("sql")?.AddTo(viewMixedContexts, v.Attrib("name").Value);
                        }
                    }

                    string csvFileName = Path.Combine(fi.Directory.FullName, Path.GetFileNameWithoutExtension(fi.FullName) + ".csv");
                    if (File.Exists(csvFileName))
                        csvFiles.Add(csvFileName);
                }
                catch (Exception ex)
                { throw new Exception($"Error deserializing '{fi.FullName}'", ex); }
            }
            if (mod == null)
                throw new Exception($"No xml files with the pattern '{xmlFileSearchPatternWithPath}' were loaded");

            mod.ResolveAndValidate(viewMixedContexts);

            foreach (string csvFile in csvFiles)
                mod.ResolveCsv(csvFile);

            return mod;
        }

        private void ResolveCsv(string csvFile)
        {
            var enum_types = types.OfType<enum_static>().ToNbDictionary(t => t.name, t => t, StringComparer.OrdinalIgnoreCase, types.Length, "Xml model's enum_static types");
            var par = new CsvParameters { FieldDelimiterN = '\t' };

            foreach (var line in NbExt.FromCsv<EnumTypeLine>(csvFile, par))
            {
                enum_types[line.TypeName].AddValue(line.Key, line.Value); //[] throws prober exception
            }
        }

        public class EnumTypeLine
        {
#pragma warning disable CS0649
            public string TypeName;
            public string Key;
            public string Value;
#pragma warning restore CS0649
        }

        private void MergeTo(model mod)
        {
            //public modelConfig config; //Not yet supported for merging
            mod.tables = tables.Merge(mod.tables);
            mod.types = types.Merge(mod.types);
            name = MergeStr(name, mod.name);
        }

        public void WriteXml(string xmlFileName)
        {
            try
            {
                using StreamWriter wrtr = new StreamWriter(xmlFileName);
                modelXmlSerializer.Serialize(wrtr, this);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error serializing into '{xmlFileName}'", ex);
            }
        }

        public static string MergeStr(string oldVal, string newVal) => String.IsNullOrWhiteSpace(newVal) ? oldVal : newVal;
        public static T Merge<T>(T oldVal, T newVal) where T : class => newVal ?? oldVal;
    }

    public partial class modelConfig
    {
        internal modelConfig PushSettingsTo(modelConfig parCnf)
        {
            if (parCnf == null)
                return this;

            if (parCnf.pluralise == TriBool.not_specified)
                parCnf.pluralise = this.pluralise;

            return parCnf;
        }
    }
}
#pragma warning restore IDE1006