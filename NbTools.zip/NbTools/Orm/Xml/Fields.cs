﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NbTools;
using System.Xml.Serialization;
using NbTools.Collections;

#pragma warning disable IDE1006 //These words must begin with upper case characters

namespace NbOrm.Xml
{
    public abstract partial class field_base : IMergeableByName<field_base>
    {
        [XmlIgnore]
        internal protected modelConfig Cfg;
        [XmlIgnore]
        public field_base ReferencedField; //TODO: Move to the field_ref?
        [XmlIgnore]
        public type_base BaseType;

        [XmlIgnore]
        public recordset Recordset { get; protected set; }
        [XmlIgnore]
        public int OrderNum => order_asc >= 0 ? order_asc : order_desc;

        public CType GetCType()
        {
            var sf = SolidField();
            if (sf.BaseType == null)
                throw new Exception($"Field's {Recordset?.name}.{name} BaseType is null");

            return sf.BaseType.Ctype;
        }//SolidField().Ctype; //TODO: consider removing and using only Type

        public field SolidField() => (this is field) ? this as field : ReferencedField.SolidField();


        [XmlIgnore]
        public string SqlName => Cfg.field_prefix + name;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="refRecset">The recordset the fields refers to</param>
        /// <param name="containingRecset">The recordset the fields belongs to</param>
        /// <param name="tables"></param>
        /// <param name="types"></param>
        internal virtual void ResolveReference(modelConfig cfg,  recordset refRecset, recordset containingRecset, NbDictionary<string, recordset> tablesDict, type_base[] types)
        {
            Cfg = cfg;
            Recordset = containingRecset;

            IEnumerable<field_base> items = (refRecset as table)?.Fields ?? (refRecset as view)?.Fields;
            if (items == null)
                throw new NbExceptionInfo($"Can't use {refRecset.GetType().Name} '{refRecset.name}' as a referenced recordset");

            string refField = ref_field_tag;
            if (String.IsNullOrWhiteSpace(refField)) //refereced field name is not provided try to link to the primary key
            {
                ReferencedField = items.SingleVerbose(f => f.key == field_baseKey.primary || f.key == field_baseKey.identity,
                    () => $"Field {containingRecset}.{name} doesn't have ref_field tag populated and default resolving is impossible because the {refRecset.XmlName} doesn't have either identity or primary key fields",
                    i => $"{refRecset.XmlName} has {i} primary keys and identity fields, default referece is impossible");
            }
            else
            {
                ReferencedField = items.SingleOrDefaultVerbose(f => ref_field_tag.EqIC(f.name), i => $"{refRecset} has {i} fields with the name {ref_field_tag}");
                if (ReferencedField == null && refRecset is view) //Not found in fields - search in parameters
                {
                    ReferencedField = (refRecset as view).Parameters.SingleVerbose(f => ref_field_tag.EqIC(f.name), () => $"{refRecset} doesn't have neither a field nor a parameter '{ref_field_tag}'",
                        i => $"{refRecset} has {i} parameters with the name {ref_field_tag}");
                }
            }
        }

        protected abstract string ref_field_tag { get; }

        internal virtual string SqlOraTableFieldEnding(IReadOnlyCollection<recordset> tables)
        { throw new NbExceptionInfo($"SqlOraTableFieldEnding should not be called on '{GetType().Name}'"); }

        internal virtual string SqlMsTableFieldEnding(IReadOnlyCollection<recordset> tables)
        { throw new NbExceptionInfo($"SqlMsTableFieldEnding should not be called on '{GetType().Name}'"); }

        internal virtual string SqlOraContraint(string tableName) => String.Empty;

        internal string CsProperty() => $"public {GetNullableCType()} {name};";

        internal string CsReaderToProperty(int i)
        {
            CType refCType = GetCType();
            return String.Format("x.{0} = r.Get{1}{2}({3});", name,
                @null ? "Nullable" : String.Empty,
                CsCode.CType2CsType(refCType),
                i);
        }

        //Int32? DateTime? but string 
        protected string GetNullableCType()
        {
            var cType = GetCType();
            if (cType == CType.blob)
                return "string";

            if (cType != CType.@string && @null)
                return cType.ToString() + "?";
            else
                return cType.ToString();
        }

        internal virtual string SelectLine => ReferencedField.name.Equals(name) ? '[' + Cfg.field_prefix + name + ']' : $"[{ReferencedField.name}] as \"{name}\"";

        public string MergeName => name;
        public override string ToString() => $"{GetType().Name} '{name}'";

        internal string SqlMsContraint(string _) => String.Empty;

        public virtual field_base MergeTo(field_base other) { throw new NbExceptionInfo($"Can't merge {this} to  {other}"); }
    }

    public partial class field : field_base
    {
        internal override string SqlMsTableFieldEnding(IReadOnlyCollection<recordset> tablesDict)
        {
            var msTypeWithLen = SqlScriptMs.CType2MsType(BaseType);
            if (this.key == field_baseKey.identity)
                return $"{msTypeWithLen} IDENTITY(1, 1) PRIMARY KEY";
            else
                return $"{msTypeWithLen} {(@null ? String.Empty : "NOT ")}NULL";
        }

        //TODO: User Ora_type if provided
        internal override string SqlOraTableFieldEnding(IReadOnlyCollection<recordset> tables)
        {
            var oraType = SqlScriptOracle.CType2OraType(BaseType.Ctype);

            int assumedLength = BaseType.length;
            int assumedPrecision = BaseType.precision;
            if (assumedLength == 0)
            {
                switch (BaseType.Ctype)
                {
                    case CType.@bool: assumedLength = 1; break;
                    case CType.@byte: assumedLength = 3; assumedPrecision = 0; break;

                    /*
                    case CType.double: break;
                    case CType.float: break;
                    case CType.uint: break;
                    case CType.long: break;
                    case CType.ulong: break;
                    case CType.short: break;
                    case CType.ushort: break;*/


                    case CType.@int: assumedLength = 10; assumedPrecision = 0; break;
                    case CType.@decimal: assumedLength = 38; assumedPrecision = 19; break;
                    case CType.@string: assumedLength = 4000; break;
                    case CType.DateTime: break;
                    default: break;
                }

            }

            string lengthStr;
            if (oraType == SqlScriptOracle.Number)
                lengthStr = String.Format("({0},{1})", assumedLength, assumedPrecision);
            else if (oraType == SqlScriptOracle.Date)
                lengthStr = String.Empty;
            else
                lengthStr = String.Format("({0})", assumedLength);

            return String.Format("{0}{1} {2}NULL", oraType, lengthStr, @null ? String.Empty : "NOT ");
        }

        internal override string SqlOraContraint(string tableName)
        {
            if (key == field_baseKey.primary || key == field_baseKey.identity)
                return String.Format("CONSTRAINT {0} PRIMARY KEY", SqlScriptOracle.OraName(tableName, "PK"));
            else
                return null;
        }

        internal string SqlOraIdentityTrigger(table table)
        {
            return String.Format(@"CREATE OR REPLACE TRIGGER {0} 
        BEFORE INSERT ON {1} 
        FOR EACH ROW 
        BEGIN 
        SELECT {2}.NEXTVAL 
        INTO :new.{3} 
        FROM dual; 
        END; 
        /", SqlScriptOracle.OraName(table.SqlName, "PK_TRIG"), table.SqlName, table.SequenceName, name);
        }

        internal override void ResolveReference(modelConfig cfg, recordset referecedRecordset, recordset parentRecordset, NbDictionary<string, recordset> tablesDict, type_base[] types)
        {
            Cfg = cfg;
            Recordset = parentRecordset;
            ReferencedField = this;

            if (String.IsNullOrEmpty(type))
                throw new NbExceptionInfo($"Field {this} doesn't have a mandatory type attribute set");

            BaseType = types?.FirstOrDefault(t => t.name.Equals(type, StringComparison.OrdinalIgnoreCase));
            if (BaseType == null)
                throw new NbExceptionInfo($"Field {this} of the {referecedRecordset} refers to the type {type} which can't be found");
        }

        protected override string ref_field_tag { get { throw new NbException("field.RefField Should never be called"); } }

        public override field_base MergeTo(field_base other)
        {
            if (!(other is field oth))
                return base.MergeTo(other); //Throws exception
            else
            {
                type = model.MergeStr(type, oth.type); //Do we need to merge the source field?
                //BaseType = model.Merge(BaseType, oth.BaseType);

                if (key != field_baseKey.none)
                    oth.key = key;
                //TODO: merge fields
                return this;
            }

        }
    }

    public partial class field_ref : field_base
    {
        private recordset fRefTable;
        public recordset ReferencedTable => fRefTable;

        public bool References(recordset tbl) => tbl == fRefTable;
        internal string SqlJoinCondition(string thisPref, string refPref) => $"{thisPref}.{name} = {refPref}.{ReferencedField.name}";
        internal override string SelectLine => name; //referenced field is in another table

        protected override string ref_field_tag => ref_field;

        internal override void ResolveReference(modelConfig config, recordset referecedRecordset, recordset parentRecordset, NbDictionary<string, recordset> tablesDict, type_base[] types) //table is not used it is resolved here
        {
            Cfg = config;
            Recordset = parentRecordset;
            fRefTable = recordset.ResolveReferenceToTable(ref_table, tablesDict, name);
            ReferencedField = fRefTable.PrimaryKeyN; //If ref_field is not specified - use primary
            if (!String.IsNullOrEmpty(ref_field))
            {
                ReferencedField = fRefTable.Fields.SingleVerbose(f => f.name.EqIC(ref_field), () => $"Field '{parentRecordset.name}.{this.name}' references '{fRefTable.name}{ref_field}' which doesn't exist", i => $"There are {i} fields called '{ref_field}' in the table {fRefTable.name}");
            }

            if (ReferencedField == null)
                throw new NbException($"Field {name} references table {ref_table} which doesn't have either identity or primary key fields and the ref_field was not specified");
        }
    }

    public partial class field_groupby : field_base
    {
        protected override string ref_field_tag => ref_field;
    }

    public partial class field_aggregate : field_base
    {
        /// <summary>
        /// Returns string like  max(id) as MAX_ID
        /// </summary>
        internal override string SelectLine => $"{func}({ReferencedField.name}) as {name}";

        internal override void ResolveReference(modelConfig cfg, recordset referecedRecordset, recordset parentRecordset, NbDictionary<string, recordset> tablesDict, type_base[] types)
        {
            Cfg = cfg;
            if (func == Aggregate_functions.count)
            {
                type_base tp = types.SingleVerbose(t => t.name.EqIC("int"), () => "Type 'int' is required for field_aggregate tags", i => $"{i} types with the name 'int' found");

                Recordset = parentRecordset;
                ReferencedField = new field
                {
                    name = String.IsNullOrWhiteSpace(ref_field) ? "*" : ref_field,
                    BaseType = tp,
                    type = tp.name
                }; //counter is an int
            }

            else
                base.ResolveReference(cfg, referecedRecordset, parentRecordset, tablesDict, types);
        }

        protected override string ref_field_tag => ref_field;
    }

    public partial class field_left : field_base
    {
        internal override string SelectLine => "l." + base.SelectLine; //base will cater for AS statement
        protected override string ref_field_tag => ref_field;
    }

    public partial class field_right : field_base
    {
        internal override string SelectLine => "r." + base.SelectLine; //base will cater for AS statement
        protected override string ref_field_tag => ref_field;
    }

    public partial class modelTables : IMergeableByName<modelTables>
    {
        public string MergeName => group ?? conn_name;

        public modelTables MergeTo(modelTables other)
        {
            Items = Items.Merge(other.Items);
            return this;
        }

        public override string ToString() => $"{group ?? conn_name}[{Items?.Length ?? 0}]";
    }

    public abstract partial class type_base : IMergeableByName<type_base>
    {
        public string MergeName => name;

        public abstract type_base MergeTo(type_base other);
    }

    public partial class type_scalar : type_base
    {
        public override type_base MergeTo(type_base other)
        {
            if (!(other is type_scalar oth))
                throw new Exception($"Can't merge type_base with {other.GetType()}");
            return this;
        }

        public override string ToString() => $"{name}, [{Ctype}]";
    }

    public partial class enum_static
    {
        readonly Dictionary<string, string> dict = new Dictionary<string, string>();

        internal void AddValue(string key, string val) => dict.Add(key, val);

        public string this[string key]
        {
            get
            {
                if (String.IsNullOrEmpty(key))
                    return null;

                if (dict.TryGetValue(key, out string res))
                    return res;
                else
                    return null;
            }
        }

        public override type_base MergeTo(type_base other)
        {
            if (!(other is enum_static oth))
                throw new Exception($"Can't merge enum_static with {other.GetType()}");
            return this;
        }
    }
}

#pragma warning restore