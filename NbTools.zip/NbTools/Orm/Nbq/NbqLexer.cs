﻿using System;
using System.Collections.Generic;
using System.Text;
using NbTools;

namespace NbOrm.Nbq
{
    public class NbqLexer
    {
        public const char StringQualifier = '\'';
        public const string quoteStr = "\'";
        public const char DateQualifier = '^';

        private enum State { Start, ReadingIdentifier, ReadingNumber, ReadingString, ReadingDate }

        private static bool IsIdentifierLetter(char c) => Char.IsLetter(c) || c == '_';
        private static bool IsPunct(char c) => Char.IsPunctuation(c) || c == '=';



        public static IEnumerable<NbqLexem> Parse(string src)
        {
            StringBuilder bld = new StringBuilder();
            int from = 0;
            State st = State.Start;

            for (int i = 0; i < src.Length; ++i)
            {
                char ch = src[i];
                switch (st)
                {
                    case State.Start:
                        bld.Clear();
                        from = i;
                        if (IsIdentifierLetter(ch)) //First Letter of identifier
                        {
                            st = State.ReadingIdentifier;
                            bld.Append(ch);
                        }
                        else if (Char.IsDigit(ch)) //First digit of a number
                        {
                            st = State.ReadingNumber;
                            bld.Append(ch);
                        }
                        else if (Char.IsSeparator(ch)) //Ignore separators if we are not reading anything
                        { }
                        else if (ch == StringQualifier)
                        {
                            st = State.ReadingString; //Don't push the ' into the buffer
                            from++; //don't include ' into lexem
                        }
                        else if (ch == DateQualifier)
                        {
                            st = State.ReadingDate; //Don't push the ^ into the buffer
                            from++; //don't include ' into lexem
                        }
                        else if (IsPunct(ch))
                            yield return new NbqLexem(NbqLexem.Type.Punctuation, ch, i);
                        else
                            yield return new NbqLexem(NbqLexem.Type.Error, $"Unexpected symbol: '{ch}'", i, i);
                        break;

                    case State.ReadingIdentifier:
                        if (IsIdentifierLetter(ch)) //Continue reading 
                            bld.Append(ch);
                        else if (Char.IsDigit(ch)) //Digit within identifier - continue
                            bld.Append(ch);
                        else                       //Any other symbol should create post an identifier 
                        {
                            yield return new NbqLexem(NbqLexem.Type.Identifier, bld.ToString(), from, i);
                            st = State.Start;
                            goto case State.Start;
                        }
                        break;

                    case State.ReadingNumber:
                        if (Char.IsDigit(ch)) //Digit within identifier - continue
                            bld.Append(ch);
                        else if (IsIdentifierLetter(ch)) //Continue reading 
                        {
                            bld.Append(ch);
                            yield return new NbqLexem(NbqLexem.Type.Error, $"Letter within a digit '{bld}'", from, i);
                            yield break;
                        }
                        else                       //Any other symbol should create post a number 
                        {
                            yield return new NbqLexem(NbqLexem.Type.Number, bld.ToString(), from, i);
                            st = State.Start;
                            goto case State.Start;
                        }
                        break;

                    case State.ReadingString:
                        if (ch == StringQualifier)
                        {
                            if (i + 1 < src.Length && src[i + 1] == StringQualifier) //If next symbol exists and it is also the quote
                            {
                                bld.Append(StringQualifier); //Append single quote
                                ++i; //Jump over the next quote
                            }
                            else //Next symbol is not quote - finish with the string
                            {
                                yield return new NbqLexem(NbqLexem.Type.String, bld.ToString(), from, i - 1); //Do not include last quote
                                st = State.Start;
                            }
                        }
                        else
                            bld.Append(ch);

                        break;

                    case State.ReadingDate:
                        if (ch == DateQualifier)
                        {
                            if (!NbExt.TryParseDate(bld.ToString(), out DateTime dt))
                                yield return new NbqLexem(NbqLexem.Type.Error, $"Cant't parse a date out of '{bld}'", from, src.Length - 1);
                            else
                                yield return new NbqLexem(NbqLexem.Type.DateTime, dt, from, i - 1); //Do not include last roof
                            st = State.Start;
                        }
                        else
                            bld.Append(ch);

                        break;

                    default:
                        throw new Exception($"Unsupported state: {st}");
                }
            }
            //Return the last indentifier or digit
            switch (st)
            {
                case State.ReadingString:
                    yield return new NbqLexem(NbqLexem.Type.Error, $"Unexpected end of a string '{bld}'", from, src.Length - 1);
                    break;
                case State.ReadingIdentifier:
                    yield return new NbqLexem(NbqLexem.Type.Identifier, bld.ToString(), from, src.Length - 1);
                    break;
                case State.ReadingNumber:
                    yield return new NbqLexem(NbqLexem.Type.Number, bld.ToString(), from, src.Length - 1);
                    break;
            }
        }
    }

    public class NbqLexem //TODO: struct?
    {
        public enum Type { Error, Identifier, Number, String, DateTime, Punctuation }

        public Type type;
        public string ValN;
        public DateTime? DateN;
        public char CharN;
        public int From;
        public int To;

        public NbqLexem(Type aType, string str, int aFrom, int aTo)
        {
            type = aType;
            ValN = str;
            From = aFrom + 1;
            To = aTo + 1;
        }

        public NbqLexem(Type aType, char aChar, int at)
        {
            type = aType;
            CharN = aChar;
            From = at + 1;
            To = at + 1;
        }

        public NbqLexem(Type aType, DateTime aDate, int aFrom, int aTo)
        {
            type = aType;
            DateN = aDate;
            From = aFrom + 1;
            To = aTo + 1;
        }

        public string SqlValue()
        {
            switch (type)
            {
                case Type.Number: return ValN;
                case Type.String: return NbqLexer.StringQualifier + ValN + NbqLexer.StringQualifier;
                case Type.DateTime: return "'" + DateN.Value.ToString(NbExt.ddMMMyyyy) + "'"; //SQL - date qualifier is not used
                default:
                    throw new Exception($"Can't generate sql value for type: {type}");
            }
        }

        public override string ToString()
        {
            switch (type)
            {
                case Type.Error:
                case Type.Identifier:
                case Type.Number:
                case Type.String:
                    return $"{type}: '{ValN}'";
                case Type.DateTime:
                    return $"{type}: '{DateN.Value.ToString(NbExt.ddMMMyyyy)}'";


                case Type.Punctuation:
                    return $"{type}: '{CharN}'";
                default:
                    throw new NbExceptionEnum<Type>(type);
            }
        }

        public bool IsPunct(char symb) => type == Type.Punctuation && CharN == symb;
    }
}
