﻿using NbOrm.Xml;
using NbTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NbOrm.Nbq
{
    public enum NbqQueryType { nbquery, nbsql, nbblob, nbdgml, nbcsv };

    public class NbqUriBuilder
    {
        const string fHost = "host";

        [Obsolete("use BuildQuery")]
        public static string BuildStr(string table, string parameters, NbqQueryType type)
        {
            if (String.IsNullOrEmpty(table))
                throw new Exception("Table name was not provided when building URI");

            if (!String.IsNullOrEmpty(parameters))
            {
                parameters = parameters.Trim();
                if (!parameters.StartsWith("["))
                {
                    if (!parameters.StartsWith(NbqLexer.quoteStr) &&  //Doesn't already start with a "
                        !parameters.Contains("=") &&      //Doesn't contains field=value construct
                        !Int64.TryParse(parameters, out long _)) //Parameter ia not numeric
                    {
                        parameters = NbqLexer.StringQualifier + parameters + NbqLexer.StringQualifier;
                    }
                    parameters = "[" + parameters + "]";
                }
            }

            return $"{type}://{fHost}/{table}{parameters}";  //host must exist, because URI wouldn't parse 
        }

        public static string BuildQuery(string table, string parameters)
        {
            if (String.IsNullOrEmpty(table))
                throw new Exception("Table name was not provided when building nb query");

            if (!String.IsNullOrEmpty(parameters))
            {
                parameters = parameters.Trim();
                if (!parameters.StartsWith("["))
                {
                    if (!parameters.StartsWith(NbqLexer.quoteStr) &&  //Doesn't already start with a "
                        !parameters.Contains("=") &&      //Doesn't contains field=value construct
                        !Int64.TryParse(parameters, out long _)) //Parameter ia not numeric
                    {
                        parameters = NbqLexer.StringQualifier + parameters + NbqLexer.StringQualifier;
                    }
                    parameters = "[" + parameters + "]";
                }
            }

            return $"{table}{parameters}";
        }

        [Obsolete("use BuildQuery")]
        public static string BuildStr(string table, List<NbqInParameter> parameters, NbqQueryType type)
        {
            if (String.IsNullOrEmpty(table))
                throw new Exception("Table name was not provided when building URI");

            StringBuilder bld = new StringBuilder();
            bld.Append(type.ToString()).Append("://")
                .Append(fHost).Append('/').Append(table);

            if ((parameters?.Count ?? 0) > 0)
            {
                bld.Append(NbqParser.Bracket(BracketType.Params, true));

                bool first = true;
                foreach(var pr in parameters)
                {
                    if (!first)
                        bld.Append(NbqParser.ParamSeparator);
                    else
                        first = false;

                    bld.Append(pr.Name).Append('=');
                    switch (pr.searchType)
                    {
                        case SearchTypes.@int:
                            bld.Append(pr.Value);
                            break;
                        case SearchTypes.@string:
                            bld.Append(NbqParser.Bracket(BracketType.String, true));
                            bld.Append(pr.Value);
                            bld.Append(NbqParser.Bracket(BracketType.String, false));
                            break;
                        case SearchTypes.date:
                            bld.Append(NbqParser.Bracket(BracketType.Date, true));
                            bld.Append(pr.Value);
                            bld.Append(NbqParser.Bracket(BracketType.Date, false));
                            break;
                        default:
                            throw new NbExceptionEnum<SearchTypes>(pr.searchType);
                    }
                }
                bld.Append(NbqParser.Bracket(BracketType.Params, false));
            }

            return bld.ToString();
        }


        public static string BuildQuery(string table, List<NbqInParameter> parameters)
        {
            if (String.IsNullOrEmpty(table))
                throw new Exception("Table name was not provided when building URI");

            StringBuilder bld = new StringBuilder();
            bld.Append(table);

            if ((parameters?.Count ?? 0) > 0)
            {
                bld.Append(NbqParser.Bracket(BracketType.Params, true));

                bool first = true;
                foreach (var pr in parameters)
                {
                    if (!first)
                        bld.Append(NbqParser.ParamSeparator);
                    else
                        first = false;

                    bld.Append(pr.Name).Append('=');
                    switch (pr.searchType)
                    {
                        case SearchTypes.@int:
                            bld.Append(pr.Value);
                            break;
                        case SearchTypes.@string:
                            bld.Append(NbqParser.Bracket(BracketType.String, true));
                            bld.Append(pr.Value);
                            bld.Append(NbqParser.Bracket(BracketType.String, false));
                            break;
                        case SearchTypes.date:
                            bld.Append(NbqParser.Bracket(BracketType.Date, true));
                            bld.Append(pr.Value);
                            bld.Append(NbqParser.Bracket(BracketType.Date, false));
                            break;
                        default:
                            throw new NbExceptionEnum<SearchTypes>(pr.searchType);
                    }
                }
                bld.Append(NbqParser.Bracket(BracketType.Params, false));
            }

            return bld.ToString();
        }


        //public static Uri Build(string table, string parameters, NbqQueryType type) => new Uri(BuildStr(table, parameters, type));

        //public static Uri Build(string table, List<NbqInParameter> parameters, NbqQueryType type) => new Uri(BuildStr(table, parameters, type));


        public static string BuildHtml(field_base fld, string key, bool isNumeric, NbqQueryType type)
        {
            //TODO: Get solid field can be called many times in the cycle - improve performance

            string userOut;
            if (fld?.SolidField()?.BaseType is enum_static tp)
            {
                var desc = tp[key] ?? "\u047E";
                userOut = $"{key} - {desc}";
            }
            else
                userOut = key;

            if (!isNumeric)
                key = "'" + key + "'";

            var foreign = (fld as field_ref);
            if (foreign != null)
            {
                userOut = $"<a href=\"nbquery://{fHost}/{foreign.ref_table}[{key}]\">{userOut}</a>";  //host must exist, because URI wouldn't parse 
            }

            var fieldRef = (fld as field_ref);
            if (fieldRef != null)
            {
                if (fieldRef.ref_field != null) //If referenced field was specified
                    key = $"{fieldRef.ReferencedField.name}={key}";

                userOut = $"<a href=\"nbquery://{fHost}/{fieldRef.ref_table}[{key}]\">{userOut}</a>";  //host must exist, because URI wouldn't parse 
            }
            return userOut;
        }

        public static string BuildBlobHtml(string blobTableName, string blobKeyValue, string userOut)
        {
            return $"<a href=\"nbblob://{fHost}/{blobTableName}[{blobKeyValue}]\">{userOut}</a>";
        }
    }

    public class NbqInParameter
    {
        public string Name;
        public string Value;
        public SearchTypes searchType;

        public Regex Regex;
        public int OrderOrder; //-1 - not in order, starts with 0
        public bool IsDescending;
    }

    public enum BracketType { Fields, Params, String, Date }

    public static class NbqParser
    {
        public static char ParamSeparator = ',';

        public static char Bracket(BracketType type, bool isOpening)
        {
            return type switch
            {
                BracketType.Fields => isOpening ? '(' : ')',
                BracketType.Params => isOpening ? '[' : ']',
                BracketType.String => '\'',
                BracketType.Date => '^',
                _ => throw new NbExceptionEnum<BracketType>(type),
            };
        }

        //Always moveNext before calling the underlying function, this allows to test the next symbol in the current function to make sure its job is done
        [Obsolete("Parse(string str, model mdl) instead  ")]
        public static NbqRecordset Parse(Uri uri, model mdl) => Parse(uri.LocalPath.TrimStart('/'), mdl);
        public static NbqRecordset Parse(string str, model mdl)
        {
            var lexList = NbqLexer.Parse(str).ToList();
            NbDictionary<string, recordset> tables = mdl.tables.SelectMany(ts => ts.Items.Safe()).ToNbDictionary(t => t.name, t => t, StringComparer.OrdinalIgnoreCase, mdl.tables.Length, "NbOrm tables");
            var lex = lexList.GetEnumerator();
            if (!lex.MoveNext())
                return null;

            return NbqRecordset.Try(lex, tables);
        }

        [Obsolete("Do not use request type based on the protocol type")]
        public static NbqQueryType GetQueryType(Uri uri)
        {
            if (uri == null)
                throw new Exception("Empty Uri provided");

            if (!Enum.TryParse(uri.Scheme, out NbqQueryType res))
                throw new Exception($"Unsupported query type in uri: {uri}. Supported types are: {String.Join(", ", Enum.GetValues(typeof(NbqQueryType)).Cast<NbqQueryType>().Select(t => t.ToString())) }");
            else
                return res;
        }

       //private static NbqQueryType qt;
        public static bool IsSupportedQueryType(Uri uri) => Enum.TryParse(uri.Scheme, out NbqQueryType _);
    }

    public class NbqException : Exception
    {
        public readonly NbqLexem Lexem;

        public NbqException(string mess, NbqLexem lex)
            : base(mess)
        {
            Lexem = lex;
        }

        public override string ToString() => $"{Message}: {Lexem}";
    }
}
