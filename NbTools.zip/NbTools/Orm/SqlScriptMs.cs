﻿using System;
using System.Collections.Generic;
using System.Linq;
using NbTools;

namespace NbOrm.Xml
{
    public class SqlScriptMs : SqlScript
    {
        public override IEnumerable<string> DropScript(model aModel)
        {
            return DropTables(aModel);
        }

        private IEnumerable<string> DropTables(model aModel)
        {
            var res = aModel.tables.SelectMany(ts => ts.Items.Safe()).OfType<table>().Where(t => t.owner == TableOwnership.xml)
                .Reverse().Select(t => String.Format("DROP TABLE {0};", t.SqlName)).ToList();
            return res;
        }

        protected override IEnumerable<string> CreateScriptContents(IEnumerable<table> ownedTables, model aModel)
        {
            return ownedTables.SelectMany(t => BracketedStatement("CREATE TABLE  " + t.SqlName, TableFields(t, aModel).JoinCommas()));
        }

        protected IEnumerable<string> TableFields(table tab, model model)
        {
            int maxNameLength = tab.Items.Max(f => f.name.Length) + 1;
            string mask = "{0,-" + maxNameLength.ToString() + "}";
            // ID NUMBER(8)  NOT NULL, 
            foreach (var f in tab.Items)
            {
                string fldDef = String.Format(mask, f.name) + f.SqlMsTableFieldEnding(model.tables.SelectMany(ts => ts.Items.Safe()).ToList());
                string constr = f.SqlMsContraint(tab.SqlName);
                yield return String.IsNullOrEmpty(constr) ? fldDef
                    : fldDef + Environment.NewLine + new String(' ', maxNameLength) + constr; //two lines in case of contraints 
            }
        }

        internal static string CType2MsType(type_base tp)
        {
            switch (tp.Ctype)
            {

                case CType.@bool: return "bit";
                //case CType. byte: 
                //break; 
                //case CType. sbyte: 
                //break; 
                //case CType.char: 
                //break;
                case CType.@decimal:
                    return String.Format("decimal({0},{1})",
                    tp.length != 0 ? tp.length : 38,
                    tp.precision != 0 ? tp.length : 19);
                case CType.@double: return "double";
                case CType.@float: return "float";
                case CType.@int:
                case CType.@uint: return "int";
                case CType.@long:
                case CType.@ulong: return "bigint";
                case CType.@short:
                case CType.@ushort: return "smallint";
                case CType.@string: return String.Format("nvarchar({0})", tp.length != 0 ? tp.length.ToString() : "max");
                case CType.DateTime: return "datetime";
                default: throw new Exception($"Unsupported CType: {tp.Ctype} for Ms-Sql conversion");
            }
        }
    }

    public class SqlCsMs : SqlCs
    {
        protected override IEnumerable<string> SqlInsertStringDef(recordset recset, field identityN)
        {
            const string separator = ", "; //+ Environment.NewLine
            string insertStatement = String.Format("INSERT INTO {0} ({1})\r\nVALUES ({2}){3}", recset.SqlName,
                String.Join(separator, recset.Fields.Where(f => f != identityN).Select(f => "[" + f.name + "]")),
                String.Join(separator, recset.Fields.Where(f => f != identityN).Select(f => ParamName(f))),
                identityN != null ? "\r\nSELECT CAST(scope_identity() AS int)" : String.Empty);

            yield return String.Format("string sql = @\"{0}\";", insertStatement);
        }

        protected override IEnumerable<string> SqlUpdateStringDef(recordset recset, field_base primary_key)
        {
            const string separator = ", "; //+ Environment.NewLine            //"INSERT INTO {0} ({1})\r\nVALUES ({2}){3}"
            string insertStatement = String.Format("UPDATE {0} SET\r\n{1}\r\nWHERE {2}", recset.SqlName,
                String.Join(separator, recset.Fields.Where(f => f != primary_key).Select(f => UpdateLine(f))),
                UpdateLine(primary_key));

            yield return String.Format("string sql = @\"{0}\";", insertStatement);
        }




        protected override string ParamName(field_base fld)
        { return "@" + fld.name; }

        protected override string UpdateLine(field_base fld)
        { return String.Format("[{0}] = {1}", fld.name, ParamName(fld)); }
    }
}
