﻿using NbTools;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doer.Logic
{
    public class Os : IDisposable
    {
        private Process Prc;
        private readonly List<string> ErrOutput;
        private readonly List<string> StdOutput;
        private readonly string Prompt; //Line to ingnore in the process output
        private readonly string Exec;
        private int LinesReceived;

        private TaskCompletionSource<string[]> Tcs;

        public Os(string execFile, string prompt = null)
        {
            Prompt = prompt;
            Exec = execFile;
            ErrOutput = new List<string>();
            StdOutput = new List<string>();
            LinesReceived = 0;
        }

        public Task<string[]> Start(string args)
        {
            if (Tcs != null && !Tcs.Task.IsCompleted && !Tcs.Task.IsFaulted && !Tcs.Task.IsCanceled)
                throw new InvalidOperationException("Async task is already running");

            Tcs = new TaskCompletionSource<string[]>();
            LinesReceived = 0;

            var psi = new ProcessStartInfo
            {
                FileName = Exec,
                Arguments = args,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };

            Prc = new Process { StartInfo = psi, EnableRaisingEvents = true };
            Prc.OutputDataReceived += Prc_OutputDataReceived;
            Prc.ErrorDataReceived += (_, e) =>
            {
                lock (ErrOutput) { ErrOutput.Add(e.Data); }
            };
            Prc.Exited += Prc_Exited;

            Prc.Start();
            Prc.BeginOutputReadLine(); //After start
            Prc.BeginErrorReadLine();  //After start

            Debug.WriteLine("Command: Start");
            Prc.StandardInput.WriteLine(); //This causes the prompt to appear in the output. Empty string and single space do not work
            return Tcs.Task;
        }

        /// <summary>
        /// Sending commands to the cmd line tool and getting the output back
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public Task<string[]> Command(string cmd)
        {
            if (Prc == null)
                throw new InvalidOperationException("Attempt to run command when the process was not started");

            if (Tcs != null && !Tcs.Task.IsCompleted && !Tcs.Task.IsFaulted && !Tcs.Task.IsCanceled)
                throw new InvalidOperationException("Async task is already running");

            Tcs = new TaskCompletionSource<string[]>();
            ErrOutput.Clear();
            StdOutput.Clear();
            LinesReceived = 0;

            Debug.WriteLine("Command: " + cmd);
            Prc.StandardInput.WriteLine(cmd + Environment.NewLine);
            return Tcs.Task;
        }

        private void Prc_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            if (e?.Data == null)
                return;

            LinesReceived++;
            Debug.WriteLine("Data: " + e.Data);

            lock (StdOutput)
            {
                if (!String.IsNullOrEmpty(Prompt) && e.Data.StartsWith(Prompt))
                {
                    if (LinesReceived != 1) //Ignore prompts appearing as a fist line (before output)
                        Tcs.SetResult(StdOutput.ToArray()); //Copy so that the list can be reset for the next operation
                }
                else
                    StdOutput.Add(e.Data);
            }
        }

        private void Prc_Exited(object sender, EventArgs e)
        {
            Tcs.SetResult(StdOutput.ToArray());
        }

        public void Dispose()
        {
            Prc?.Dispose();
        }


        //Detect the need for input: parse output for prompt
        // foreach(ProcessThread thread in process.Threads)
        // if (thread.ThreadState == ThreadState.Wait
        // && thread.WaitReason == ThreadWaitReason.UserRequest)
        //    process.Kill();
        // or ThreadWaitReason.LpcReply

    }

    /// <summary>
    /// Class working with windows diskpart.exe utility in order to mount and unmount drives.
    /// Needs permission escalation to work properly
    /// </summary>
    public class OsDiskPart : Os
    {
        public OsDiskPart()
            : base("diskpart.exe", "DISKPART>")
        { }

        public class DiskDetails
        {
            public enum Statuses { Online, Offline };

            public string DiskId;
            public string Type;
            public Statuses Status;

            public bool SetProperty(string prop)
            {
                if (!prop.Contains(':'))
                    return false; //Line is not property

                var parts = prop.Split(':');
                var val = parts[1].Trim();

                switch (parts[0].Trim())
                {
                    case "Disk ID": DiskId = val; break;
                    case "Type": Type = val; break;

                    case "Status":
                        if (val.StartsWith("Online"))
                            Status = Statuses.Online;
                        else if (val.StartsWith("Offline"))
                            Status = Statuses.Offline;
                        else
                            throw new NbExceptionEnum<Statuses>(val);
                        break;
                }
                return true;
            }
        }


        public async Task<DiskDetails> GetDiskDetails(int diskInd)
        {
            await Command("select disk " + diskInd.ToString());
            var lines = await Command("detail disk");

            var res = new DiskDetails();
            foreach (var line in lines.Where(l => !String.IsNullOrWhiteSpace(l)))
            {
                res.SetProperty(line); //TODO: process other non-property lines
            }
            return res;
        }
    }
}
