﻿using All2All;
using NbFilterV1.Xml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace NbTools
{
	public class NbSqlBuilder
	{
		private readonly string Table;
		private readonly data_request Req;
		private readonly List<Field> Fields;

		public NbSqlBuilder(string table, data_request req)
		{
			Table = table;
			Req = req;
			string[] cols = req.columns ?? throw new NbException("data_request didn't define any columns");

			Fields = new List<Field>(cols.Select(c => new Field() { SqlName = c }));
		}

		public int FieldCount => Fields.Count;

		/*private static readonly (string, DisplayStyle)[] Cols = new (string, DisplayStyle)[] {
			("Name", DisplayStyle.String),
			("Extension", DisplayStyle.String),
			("Size", DisplayStyle.FileSize),
			("Hash", DisplayStyle.String),
		};*/

		private static readonly Dictionary<string, SubTreeInfo> SubTreeInfos = new Dictionary<string, SubTreeInfo>
		{
			{ "Dirs", new SubTreeInfo{ TableName = "Dirs", ParentFieldName = "ParentDirId" } },
			{ "Tags", new SubTreeInfo{ TableName = "Tags", ParentFieldName = "ParentTagId", ManyToManyTable = "FileTags", ManyToManyLeftField = "FileId", ManyToManyRightField = "TagId" } } 
		};

		public IEnumerable<(string fieldName, DisplayStyle displayStyle)> ColumnNamesAndStyles()
		{
			foreach(Field fld in Fields)
			{
				if (fld.SqlName == "Size")
					yield return (fld.SqlName, DisplayStyle.FileSize); //TODO: store the styles on the UI side
				else
					yield return (fld.SqlName, DisplayStyle.String);
			}
		}

		public void AddField(string sqlName, string outName = null, string where = null, bool groupBy = false, int orderBy = 0)
			=> Fields.Add(new Field { SqlName = sqlName, OutName = outName, Where = where, GroupBy = groupBy, OrderBy = orderBy });

		public string GetMsSqlString()
		{
			StringBuilder bld = new StringBuilder();
			StringBuilder preSelects = new StringBuilder(); //Selects that will be inserted before the current one which then will be used in where in  statements

			CommaList(bld, "select top 1000\r\n", Fields.Select(f => f.MsSqlFieldStatement).Concat(NbExt.Yield("Id")), separator: ", ");
			bld.Append($" from {Table}\r\n");

			var wheresAndPreselects = Req.filter?.and?.Safe().Select((f, cntr) => CreateWhereExpr(f, cntr)).ToList();

			CommaList(preSelects, "with", wheresAndPreselects.Select(ws => ws.preselect), separator: ",\r\n");

			CommaList(bld, "where\r\n", wheresAndPreselects.Select(ws => ws.where), separator: "\r\n  and ");
			string sql = preSelects.ToString() + Environment.NewLine + bld.ToString();
			return sql;
		}

		private (string where, string preselect) CreateWhereExpr(flt_base f, int cntr)
		{
			string preselName = "presel" + cntr;

			switch (f)
			{
				case in_node inNode: return ($"{inNode.field} = {inNode.node_id}", null);
				case in_subtree inSubtree:
					if (!SubTreeInfos.TryGetValue(inSubtree.field, out var sti))
						throw new Exception($"Can't find subtree info for the '{inSubtree.field}' inSubtree filter criteria");

					string preselect = TreeTraversal(inSubtree.node_id, sti, preselName);

					if (!String.IsNullOrEmpty(sti.ManyToManyTable))
						return ($"Id in (select {sti.ManyToManyLeftField} from {sti.ManyToManyTable} inner join {preselName} on {preselName}.Id = {sti.ManyToManyTable}.{sti.ManyToManyRightField})", preselect);
					else
						return ($"{sti.ParentFieldName} in (select Id from {preselName})", preselect);

				case contain cnt: return ($"{cnt.field} like '%{cnt.val}%'", null);
				case equal eq: return ($"{eq.field} = {eq.val}", null);//TODO: be aware of the type - do not use quotes for int and process dates properly
				default: throw new Exception($"Filter type '{f.GetType().Name}' is not yet supported");
			}
		}

		private string TreeTraversal(string id, SubTreeInfo sti, string resultTableName)
		{
			//TODO: assign the name of the temp table from the list preSel01 - preSel99
			string preselect = $@" {resultTableName}(Id,{sti.ParentFieldName}) as (
		select Id,{sti.ParentFieldName} from {sti.TableName} where Id = {id}
			union all
		select e.Id, e.{sti.ParentFieldName}
		from {sti.TableName} e inner join {resultTableName} on e.{sti.ParentFieldName} = {resultTableName}.Id)";
			return preselect;
		}

		/*private string TreeTraversal2(string dirId)
		{
			//TODO: accign the name of the temp table from the list preSel01 - preSel99
			string preselect = $@" with t(level,path,Id,ParentDirId,Name) as (
		select 0,Name,Id,ParentDirId,Name from Dirs where Id = {dirId}
	union all
		select
			level + 1,
			e.name + '\' + path,
			e.Id,
			e.ParentDirId,
			e.Name 
		from 
			Dirs e
			inner join t on e.ParentDirId = t.Id
)";
			return preselect;
		}*/


		public string GetOracleString()
		{
			//Checks if filed is unique
			if (Fields.Count == 0)
				throw new Exception("No fields in the request");
			//NbDictionary<string, int> fieldNames = 

			bool isGroupBy = false;
			foreach(var fl in Fields)
			{
				if (fl.GroupBy)
					isGroupBy = true;
			}

			StringBuilder bld = new StringBuilder();
			if (isGroupBy)
			{
				//Only allow groupby fields in group by select
				var fldList = isGroupBy ? Fields.Where(f => f.GroupBy).Select(f => f.OracleFieldStatement)
					: Fields.Where(f => f.GroupBy).Select(f => f.OracleFieldStatement);

				CommaList(bld, "select\r\n", fldList, separator: ",\r\n");
				CommaList(bld, "from", NbExt.Yield(Table));
				CommaList(bld, "where", Fields.Select(f => f.WhereStatement), separator: " and ");
				CommaList(bld, "group by", Fields.Where(f => f.GroupBy && !f.SqlName.EqIC("NULL")).Select(f=> f.SqlName));
				//TODO: support descending
				CommaList(bld, "order by", Fields.Where(f => f.OrderBy != 0).OrderBy(f => Math.Abs(f.OrderBy)).Select(f => f.SqlName));
			}
			else
				throw new NotImplementedException("NbSqlBuilder fo non-group bys");

			return bld.ToString().TrimStart('\r', '\n');
		}

		private void CommaList(StringBuilder bld, string prefix, IEnumerable<string> entries, string separator = null)
		{
			bool first = true;
			foreach (var entry in entries.Where(e => !String.IsNullOrWhiteSpace(e)))
			{
				if (first)
				{
					first = false; 
					bld.AppendLine(); //Start prefix from a new line
					bld.Append(prefix).Append(' ');
				}
				else
					bld.Append(separator ?? ", ");

				bld.Append(entry);
			}
			//bld.AppendLine();
		}
		class Field
		{
			internal string SqlName;
			internal string OutName;
			internal string Where;
			internal bool GroupBy;
			internal int OrderBy;

			internal string OracleFieldStatement => String.IsNullOrEmpty(OutName) ? SqlName : $"{SqlName} as \"{OutName}\"";
			internal string MsSqlFieldStatement => String.IsNullOrEmpty(OutName) ? SqlName : $"{SqlName} as {OutName}";
			internal string WhereStatement => String.IsNullOrEmpty(Where) ? "": $"{SqlName} {Where}";

		}

		/// <summary>
		/// Keeps info about building the preselect for tree traversal for in_subtree 
		/// </summary>
		internal class SubTreeInfo
		{
			public string TableName;
			public string ParentFieldName;
			public string ManyToManyTable;
			public string ManyToManyLeftField;
			public string ManyToManyRightField;
		}
	}
}
