﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NbTools.SqlGen.Xml;
using A2aTypes.Xml;

namespace NbTools
{
    public class NbSqlBuilder
    {
        private readonly NbSqlXml SqlXml;

        public NbSqlBuilder(NbSqlXml sqlXml)
        {
            SqlXml = sqlXml;
            if (SqlXml.table == null || SqlXml.table.Length == 0) throw new ArgumentException("Tables were not provided with SqlXml");
        }

        public int FieldCount => SqlXml.table.Sum(t => t.field?.Length ?? 0);

        //TODO: this should be come part of server-side XML with knowledge about the tables. The client should not now how to do in-subtree sql
        private static readonly Dictionary<string, SubTreeInfo> SubTreeInfos = new Dictionary<string, SubTreeInfo> 
        {
            { "Dirs", new SubTreeInfo{ TableName = "Dirs", PrimaryKeyName = "Id", ParentFieldName = "ParentDirId" } },
            { "Tags", new SubTreeInfo{ TableName = "Tags", PrimaryKeyName = "Id", ParentFieldName = "ParentTagId", ManyToManyTable = "FileTags", ManyToManyLeftField = "FileId", ManyToManyRightField = "TagId" } }
        };

        [Obsolete("store the styles on the UI sid")]
        public IEnumerable<(string fieldName, DisplayStyles displayStyle)> ColumnNamesAndStyles()
        {
            foreach (NbSqlField fld in SqlXml.table.SelectMany(t => t.field))
            {
                if (fld.name == "Size")
                    yield return (fld.name, DisplayStyles.FileSize);
                else
                    yield return (fld.name, DisplayStyles.String);
            }
        }

        /*public void AddField(string sqlName, string outName = null, string where = null, bool groupBy = false, int orderBy = 0)
            => Fields.Add(new Field { SqlName = sqlName, OutName = outName, Where = where, GroupBy = groupBy, OrderBy = orderBy });*/

        public string GetMsSqlString()
        {
            StringBuilder bld = new StringBuilder();
            StringBuilder preSelects = new StringBuilder(); //Selects that will be inserted before the current one which then will be used in where in  statements

            //SELECT
            string fromStatement = CreateFromStatement(SqlXml.table);

            CommaList(bld, $"select top {SqlXml.top} ", CreateSelectList(SqlXml.table), separator: ", ");
            bld.Append($" from {fromStatement}\r\n");

            //WHERE
            var wheresAndPreselectsN = SqlXml.filter.Safe().Select((f, cntr) => CreateWhereExpr(f, cntr)).ToList();
            if (wheresAndPreselectsN != null)
            {
                CommaList(preSelects, "with", wheresAndPreselectsN.Select(ws => ws.preselect), separator: ",\r\n");
                CommaList(bld, "where\r\n", wheresAndPreselectsN.Select(ws => ws.where), separator: "\r\n  and ");
            }

            //ORDER BY
            var orderFields = SqlXml.table.SelectMany(t => t.field).Where(f => f.order_ind >= 0).OrderBy(f => f.order_ind).ToList();
            if (orderFields.Count > 0)
                CommaList(bld, "order by ", orderFields.Select(s => s.OrderBySql), separator: ", ");

            string sql = preSelects.ToString() + Environment.NewLine + bld.ToString();
            return sql;
        }

        internal IEnumerable<string> CreateSelectList(NbSqlTable[] table)
        {
            foreach (NbSqlTable tbl in table)
            {
                foreach (NbSqlField fld in tbl.field)
                {
                    yield return $"{tbl.alias}.{fld.name}";
                }
            }
        }


        internal string CreateFromStatement(NbSqlTable[] table)
        {
            StringBuilder bld = new StringBuilder($"{table[0].name} {table[0].alias}\r\n");

            for (int i = 1; i < table.Length; i++)
            {
                NbSqlTable tb = table[i];
                NbSqlTable joinTb = table.FirstOrDefault(t => t.name == tb.join.to_table) ?? throw new Exception($"Table {tb.name} is joined to table {tb.join.to_table}, which can't be found");
                NbSqlField joinFld = joinTb.field.FirstOrDefault(f => f.name == tb.join.to_field) ?? throw new Exception($"Table {tb.name} is joined to table's '{tb.join.to_table}' field '{tb.join.to_field}', which can't be found");


                NbSqlJoin join = tb.join;

                bld.Append($"\tleft join {tb.name} {tb.alias} on {joinTb.alias}.{joinFld.name} = {tb.alias}.Id"); //TODO: ask for field to join or primary key
            }

            return bld.ToString();
        }


        private (string where, string preselect) CreateWhereExpr(FilterBase f, int cntr)
        {
            string preselName = "presel" + cntr;

            switch (f)
            {
                case InNode inNode: return ($"{inNode.field} = {inNode.node_id}", null);
                case InSubtree inSubtree:
                    if (!SubTreeInfos.TryGetValue(inSubtree.tree_table, out var sti))
                        throw new Exception($"Can't find subtree info for the '{inSubtree.field}' inSubtree filter criteria");

                    string preselect = TreeTraversal(inSubtree.root_node_id, sti, preselName);

                    if (!String.IsNullOrEmpty(sti.ManyToManyTable))
                        return ($"{inSubtree.TableResolved.alias}.Id in (select {sti.ManyToManyLeftField} from {sti.ManyToManyTable} inner join {preselName} on {preselName}.Id = {sti.ManyToManyTable}.{sti.ManyToManyRightField})", preselect);
                    else
                        return ($"{inSubtree.TableResolved.alias}.{inSubtree.field} in (select {sti.PrimaryKeyName} from {preselName})", preselect);

                case FltContain cnt: return ($"{cnt.field} like '%{cnt.val}%'", null);
                case FltEqual eq: return ($"{eq.field} = {eq.val}", null);//TODO: be aware of the type - do not use quotes for int and process dates properly
                default: throw new Exception($"Filter type '{f.GetType().Name}' is not yet supported");
            }
        }


        /// <summary>
        /// Creates tree-traversing sql sub-request that will be used in   "in ()" statement in the main select
        /// </summary>
        /// <param name="rootNodeId">The Id of the node that acts a root of the subtree</param>
        /// <param name="sti"></param>
        /// <param name="resultTableName"></param>
        /// <returns></returns>
        private string TreeTraversal(string rootNodeId, SubTreeInfo sti, string resultTableName)
        {
            //TODO: assign the name of the temp table from the list preSel01 - preSel99
            string preselect = $@" {resultTableName}({sti.PrimaryKeyName},{sti.ParentFieldName}) as (
		select Id,{sti.ParentFieldName} from {sti.TableName} where {sti.PrimaryKeyName} = {rootNodeId}
			union all
		select e.{sti.PrimaryKeyName}, e.{sti.ParentFieldName}
		from {sti.TableName} e inner join {resultTableName} on e.{sti.ParentFieldName} = {resultTableName}.{sti.PrimaryKeyName})";
            return preselect;
        }

        /*private string TreeTraversal2(string dirId)
		{
			//TODO: accign the name of the temp table from the list preSel01 - preSel99
			string preselect = $@" with t(level,path,Id,ParentDirId,Name) as (
		select 0,Name,Id,ParentDirId,Name from Dirs where Id = {dirId}
	union all
		select
			level + 1,
			e.name + '\' + path,
			e.Id,
			e.ParentDirId,
			e.Name 
		from 
			Dirs e
			inner join t on e.ParentDirId = t.Id
)";
			return preselect;
		}*/


        /*public string GetOracleString()
        {
            //Checks if filed is unique
            if (Fields.Count == 0)
                throw new Exception("No fields in the request");
            //NbDictionary<string, int> fieldNames = 

            bool isGroupBy = false;
            foreach (var fl in Fields)
            {
                if (fl.GroupBy)
                    isGroupBy = true;
            }

            StringBuilder bld = new StringBuilder();
            if (isGroupBy)
            {
                //Only allow groupby fields in group by select
                var fldList = isGroupBy ? Fields.Where(f => f.GroupBy).Select(f => f.OracleFieldStatement)
                    : Fields.Where(f => f.GroupBy).Select(f => f.OracleFieldStatement);

                CommaList(bld, "select\r\n", fldList, separator: ",\r\n");
                CommaList(bld, "from", Tables.Select(t => t.Name));
                CommaList(bld, "where", Fields.Select(f => f.WhereStatement), separator: " and ");
                CommaList(bld, "group by", Fields.Where(f => f.GroupBy && !f.SqlName.EqIC("NULL")).Select(f => f.SqlName));
                //TODO: support descending
                CommaList(bld, "order by", Fields.Where(f => f.OrderBy != 0).OrderBy(f => Math.Abs(f.OrderBy)).Select(f => f.SqlName));
            }
            else
                throw new NotImplementedException("NbSqlBuilder fo non-group bys");

            return bld.ToString().TrimStart('\r', '\n');
        }*/

        private void CommaList(StringBuilder bld, string prefix, IEnumerable<string> entries, string separator = null)
        {
            bool first = true;
            foreach (var entry in entries.Where(e => !String.IsNullOrWhiteSpace(e)))
            {
                if (first)
                {
                    first = false;
                    bld.AppendLine(); //Start prefix from a new line
                    bld.Append(prefix).Append(' ');
                }
                else
                    bld.Append(separator ?? ", ");

                bld.Append(entry);
            }
            //bld.AppendLine();
        }
        class Field
        {
            internal string SqlName;
            internal string OutName;
            internal string Where;
            internal bool GroupBy;
            internal int OrderBy;

            internal string OracleFieldStatement => String.IsNullOrEmpty(OutName) ? SqlName : $"{SqlName} as \"{OutName}\"";
            internal string MsSqlFieldStatement => String.IsNullOrEmpty(OutName) ? SqlName : $"{SqlName} as {OutName}";
            internal string WhereStatement => String.IsNullOrEmpty(Where) ? "" : $"{SqlName} {Where}";

        }

        /// <summary>
        /// Keeps info about building the preselect for tree traversal for in_subtree 
        /// </summary>
        internal class SubTreeInfo
        {
            public string TableName;
            public string PrimaryKeyName; //Primary key in the table containing the tree, the ParentFieldName refers to it.
            public string ParentFieldName; //The name of the field in the table keeping tree structrure that refers to the parent Id .
            public string ManyToManyTable;
            public string ManyToManyLeftField;
            public string ManyToManyRightField;
        }
    }
}
