﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;

namespace NbTools
{
    public static partial class NbExt
    {
        public static string ElementNull(this XElement el, XName name)
        {
            if (el == null)
                return String.Empty;
            var res = el.Element(name);
            return res != null ? res.Value : String.Empty;
        }

        public static string XPathVal(this XElement el, string xPathName)
        {
            if (el == null)
                return String.Empty;
            var res = el.XPathSelectElement(xPathName);
            return res != null ? res.Value : String.Empty;
        }

        public static IEnumerable<Tuple<string, XElement>> FlattenXElement(this XElement element, string parentName = null)
        {
            string thisName = (String.IsNullOrEmpty(parentName) ? "" : parentName + ".") + element.Name.LocalName;
            if (!element.HasElements)
                return NbExt.Yield(Tuple.Create(thisName, element));
            else
                return element.Elements().SelectMany(subEl => FlattenXElement(subEl, thisName));
        }

        public static IEnumerable<Tuple<string, XElement, XAttribute>> FlattenXElementAndAttributesSkipRoot(this XElement element)
        {
            return element.Attributes().Select(a => Tuple.Create<string, XElement, XAttribute>(a.Name.LocalName, null, a))
                .Concat(element.Elements().SelectMany(e => e.FlattenXElementAndAttributes()));
        }

        public static IEnumerable<Tuple<string, XElement, XAttribute>> FlattenXElementAndAttributes(this XElement element, string parentName = null)
        {
            string thisName = (String.IsNullOrEmpty(parentName) ? "" : parentName + ".") + element.Name.LocalName;
            var attr = element.Attributes().Select(a => Tuple.Create<string, XElement, XAttribute>(thisName + "." + a.Name.LocalName, null, a));

            if (!element.HasElements)
                return attr.Concat(NbExt.Yield(Tuple.Create<string, XElement, XAttribute>(thisName, element, null)));
            else
                return attr.Concat(element.Elements().SelectMany(subEl => FlattenXElementAndAttributes(subEl, thisName)));
        }

        public static string NbAttribSafe(this XElement elem, string aName)
        {
            elem.NbTryGetAttribute(aName, out string ret);
            return ret;
        }


        public static bool NbTryGetAttribute(this XElement elem, string aName, out string aAttribValue)
        {
            var att = elem.Attribute(aName);  //elem.Name.Namespace + - not used?
            aAttribValue = att?.Value;
            return !(att == null);
        }

        public static IEnumerable<XElement> NbFindRecursive(this XElement elem, string name, string attribute = null, string attributeValue = null)
        {
            if (attribute == null && attributeValue != null)
                throw new ArgumentException("attribute must be specified if attributeValue is provided");

            return elem.Descendants(elem.Name.Namespace + name) //Using namespace of the parent
                .Where(i =>
                {
                    if (attribute == null)
                        return true; //Attribute is not provided - any element is good

                    XAttribute att = i.Attribute(attribute);
                    if (att == null)
                        return false;
                    else if (attributeValue == null)
                        return true; //Fits no matter what the attribute value is 
                    else
                        return att.Value.Equals(attributeValue, StringComparison.OrdinalIgnoreCase);
                });
        }

        public static XElement NbFindSingleRecursive(this XElement elem, string name, string attribute = null, string attributeValue = null) =>
            elem.NbFindRecursive(name, attribute, attributeValue).SingleVerbose(_ => true,
            () => $"Element {ElDescriptor(name, attribute, attributeValue)} is not found",
            i => $"{i} Elements {ElDescriptor(name, attribute, attributeValue)} were found");

        private static string ElDescriptor(string name, string attribute, string attributeValue) => $"'{name}'"
            + ((attribute != null) ? $" attribute '{attribute}'" : String.Empty)
            + ((attributeValue != null) ? $" = '{attributeValue}'" : String.Empty);

        //Linq to Sql extensions
        public static XElement TagN(this XElement node, string name)
        {
            var ns = node.GetDefaultNamespace().NamespaceName;
            return node.Element(XName.Get(name, ns));
        }

        public static XElement Tag(this XElement node, string name)
        {
            var el = TagN(node, name);
            if (el == null)
                throw new NbException($"Element '{node.Name}' doesn't contain element '{name}'");
            return el;
        }

        public static IEnumerable<XElement> Tags(this XElement node, string name)
        {
            var ns = node.GetDefaultNamespace().NamespaceName;
            return node.Elements(XName.Get(name, ns));
        }

        public static XAttribute AttribN(this XElement node, string name)
        {
            var ns = node.GetDefaultNamespace().NamespaceName;
            return node.Attribute(XName.Get(name, ns));
        }

        public static XAttribute Attrib(this XElement node, string name)
        {
            var ns = node.GetDefaultNamespace().NamespaceName;
            var at = node.Attribute(XName.Get(name, ns));
            if (at == null)
                throw new NbException($"Element '{node.Name}' doesn't contain attibute '{name}'");
            return at;
        }

        public static IEnumerable<XAttribute> Attribs(this XElement node, string name)
        {
            var ns = node.GetDefaultNamespace().NamespaceName;
            return node.Attributes(XName.Get(name, ns));
        }
    }
}
