﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbTools
{
    public class NbLog : IDisposable
    {
        const char separator = ',';
        private readonly string LogFileName;
        private readonly DateTime StartTime;

        private StreamWriter wrtr = null;
        private int Index = 0;

        public enum LogType { Info, Warning, Error, Exception, Verbose, Data, Begin, End }

        public NbLog(string logFile = null)
        {
            if (String.IsNullOrEmpty(logFile))
                logFile = NbDir.Legalize(AppDomain.CurrentDomain.FriendlyName) + "_log.csv";

            if (!Path.IsPathRooted(logFile))
                logFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, logFile);

            logFile = NbDir.ExpandDateVariables(logFile);

            FileInfo fi = new FileInfo(logFile);
            fi.Directory.DirCreateRecursive();

            int cnt = 1;
            if (fi.Exists)
            {
                string newName;
                do
                {
                    newName = Path.Combine(Path.GetDirectoryName(logFile),
                        Path.GetFileNameWithoutExtension(logFile) + $" ({cnt++})" + Path.GetExtension(logFile));

                    if (cnt > 1000)
                        throw new Exception($"Too many log files collected: {LogFileName}");
                } while (File.Exists(newName));
                File.Move(logFile, newName);
            }

            LogFileName = logFile;
            StartTime = DateTime.Now;
            Info($"Start Logging at {StartTime:yyyyMMdd-HHmmss}");
        }

        public void Info(string mess) => Write(LogType.Info, mess);

        public void Warning(string mess) => Write(LogType.Warning, mess);

        public void Error(string mess) => Write(LogType.Error, mess);

        public void Exception(string mess, Exception ex)
        {
            Write(LogType.Error, mess);
            Write(LogType.Exception, NbException.Exception2String(ex));
        }

        private void Write(LogType tp, string mess)
        {
            bool quotes = false;
            if (mess.Contains('"'))
            {
                mess.Replace("\"", "\"\"");
                quotes = true;
            }
            else if (mess.Contains('\n'))
                quotes = true;

            if (wrtr == null) //Lazy init
            {
                wrtr = new StreamWriter(LogFileName) { AutoFlush = true };
                wrtr.WriteLine("Ind,TimeStamp,Type,Message"); //Header
            }
            lock (wrtr)
            {
                wrtr.Write(Index++);
                wrtr.Write(separator);
                wrtr.Write((DateTime.UtcNow - StartTime).ToString("g"));
                wrtr.Write(separator);
                switch (tp)
                {
                    case LogType.Info: wrtr.Write("[Info]"); break;
                    case LogType.Warning: wrtr.Write("[Warning]"); break;
                    case LogType.Error: wrtr.Write("[Error]"); break;
                    case LogType.Exception: wrtr.Write("[Exception]"); break;
                    case LogType.Verbose: wrtr.Write("[Verbose]"); break;
                    case LogType.Data: wrtr.Write("[Data]"); break;
                    case LogType.Begin: wrtr.Write("[Begin]"); break;
                    case LogType.End: wrtr.Write("[End]"); break;
                    default:
                        wrtr.Write("[Error]");
                        mess = $"Unsupported logging entry type: '{tp}'";
                        break;
                }

                wrtr.Write(separator);
                if (quotes)
                    wrtr.Write('"');
                wrtr.Write(mess);
                if (quotes)
                    wrtr.Write('"');
                wrtr.WriteLine();
            }
        }


        public void Dispose()
        {
            if (wrtr != null)
            {
                Info($"Stop Logging at {DateTime.Now:yyyyMMdd-HHmmss}");
                wrtr.Close();
            }
        }
    }
}
