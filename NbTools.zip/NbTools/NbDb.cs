﻿using System;
using System.Collections.Generic;
using System.Data;

namespace NbTools
{
    //Has to be in NbTool for DfCollections to use the interface, Ora and MsSql implementations are in NbOrm

    public enum ConnectionType { None, Oracle, MsSql }

    /// <summary>
    /// Gets connection from connection manager by its name - useful when queries specify which connection to use, or run on multiple connections (comparison between DBs)
    /// </summary>
    public interface INbConnGetter
    {
        INbConn GetConnection(string envName, string connName);
    }

    public interface INbConn : IDisposable
    {
        INbCommand CreateCommand(string sql);
        INbReader CreateReader(string sql);
        INbTrans BeginTransaction();

        ConnectionType ConnType { get; }

        T ReadSingle<T>(string sql);
        List<T> ReadList<T>(string sql);
    }

    public interface INbTrans
    {
        void Commit();
    }

    public interface INbReader : IDisposable
    {
        bool Read();
        DataTable FillDataTable();

        Type GetFieldType(int ordinal);
        bool IsDBNull(int ordinal);
        T GetValue<T>(int index);
        int FieldCount { get; }

        string GetBlob(int index);
        byte[] GetBytes(int index);
        string GetString(int index);
        string GetNullableString(int index);

        char GetChar(int index);
        char? GetNullableChar(int index);

        Int16 GetInt16(int index);
        Int16? GetNullableInt16(int index);
        int GetInt32(int index);
        int? GetNullableInt32(int index);
        string GetName(int index);
        long GetInt64(int index);
        long? GetNullableInt64(int index);

        decimal GetDecimal(int index);
        decimal? GetNullableDecimal(int index);

        double GetDouble(int index);
        double? GetNullableDouble(int index);

        DateTime GetDateTime(int index);
        DateTime? GetNullableDateTime(int index);

        bool GetBoolean(int index);
        bool? GetNullableBoolean(int index);
    }

    public interface INbCommand : IDisposable
    {
        void AddParam(string name, object value);
        void AddParam(string name, bool value);
        void AddParam(string name, bool? value);
        void AddBlob(string name, byte[] value);
        void Run();
        int RunGetInt32();
        T ReadSingle<T>();
        Tuple<T, U> ReadSingle<T, U>();
        Tuple<T, U, V> ReadSingle<T, U, V>();
    }
}
