﻿using System;
using System.Collections.Generic;
using System.IO;

namespace NbTools
{
    public class MultiLogger : IDisposable
    {
        private class FileDesc : IDisposable
        {
            internal FileDesc(string fullPath)
            {
                FullPath = fullPath;
                Wrtr = new StreamWriter(fullPath);
            }

            internal readonly string FullPath;
            internal readonly StreamWriter Wrtr;

            public void Dispose() => Wrtr.Dispose();
        }

        public readonly string Dir;
        private readonly Dictionary<string, FileDesc> fFiles;
        private readonly Dictionary<string, string> HeadersN;
        private readonly string DefaultHeaderN;
        private readonly string DefaultFooterN; //This could be a function call to include the accumulator
        public readonly string FileNameMask;

        public MultiLogger(string dir, string fileNameMask, Dictionary<string, string> headersN, string defaultHeaderN, string defaultFooterN = null)
        {
            Dir = dir;
            NbExt.DirCreateRecursive(new DirectoryInfo(dir));

            fFiles = new Dictionary<string, FileDesc>(10);
            HeadersN = headersN;
            DefaultHeaderN = defaultHeaderN;
            DefaultFooterN = defaultFooterN;
            FileNameMask = fileNameMask;
        }

        public void Write(string subSystem, string line)
        {
            if (!fFiles.TryGetValue(subSystem, out FileDesc fd))
            {
                fd = new FileDesc(Path.Combine(Dir, String.Format(FileNameMask, subSystem)));
                fFiles.Add(subSystem, fd);

                string header = DefaultHeaderN;
                HeadersN?.TryGetValue(subSystem, out header); //Specific header overrides generic
                
                if (!string.IsNullOrEmpty(header)) //If header exists - write it
                    fd.Wrtr.WriteLine(header);
            }
            fd.Wrtr.WriteLine(line);
        }

        public void FlushAll()
        {
            fFiles.Values.ForEachSafe(fDesc => fDesc.Wrtr?.Flush());
        }

        public void Dispose()
        {
            foreach (var flDesc in fFiles.Values)
            {
                try {
                    if (!String.IsNullOrEmpty(DefaultFooterN))
                        flDesc.Wrtr.WriteLine(DefaultFooterN);

                    flDesc.Dispose(); 
                }
                catch { } //Ignore error while closing files - nothing we can do here
            }
        }
    }
}
