﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using A2aCommands.Xml;
using A2aTypes.Xml;
using NbTools.SqlGen.Xml;

namespace All2All
{
    public enum UpdateType { Add, Update, Remove }
    //public enum DisplayStyles { String, Number, TimeMinSec, FileSize }

    public interface IUserInterface //All fields for displaing in the datagrid
    {
        /// <summary>
        /// Asks UI to add the top-level description (no detail) of a node, usually on the tree. 
        /// </summary>
        /// <param name="updType">Type of update: Add, Update, Remove</param>
        /// <param name="nodeId">Unique id of the node as a string</param>
        /// <param name="nodeId">Node type as a string</param>
        /// <param name="parentId">Id of the parent node is should be attached to in the hierarchy</param>
        /// <param name="Label">The short description of the node</param>
        /// <param name="hasChildren">yes if children are expected or known to exist</param>
        /// <param name="requestId">Unique RequestId, which will allow the UI to identify the data coming back</param>
        void AddSimple(UpdateType updType, string nodeId, string nodeType, string parentId, string Label, bool hasChildren, int requestId);


        /// <summary>
        /// Set Columns is a long-term solution and is preferred to Types set to List view at contruction for the following reasons:
        /// * It might not be possible to know all columns for pivot-type queries, where columns will be created based on data
        /// * Some models such as All-to-all XMl might have user-defined columns that will not be known  in the model
        /// </summary>
        /// <param name="columns"></param>
        /// <param name="requestId"></param>
        void SetColumns(IEnumerable<(string fieldName, DisplayStyles displayStyle)> columns, int requestId);

        void AddAllFields(UpdateType updType, string nodeId, string nodeType,  string[] columns, int requestId);

        void AddWebPage(string html, int requestId);

        void SetStatus(string message);
        Task<string> ShowDialog(string message);

        //TODO: must return the properties separately, because this interface will work across the network or other languages
        Task<bool> EditForm(A2aFormParameters formParams); //returns - save (true) of cancel (false)
    }

    public interface IDataProvider : IDisposable
    {
        string ModelName { get; }

        A2aTypes.Xml.A2aT GetTypes(); 

        /// <summary>
        /// Asks datalayer to provide data for the treeview. Expected callbacks: AddSimple()
        /// </summary>
        /// <param name="parentIdN">Id of the node to get children for, if null - request for the parent node. There can only be a single parent</param>
        /// <param name="typesN"></param>
        /// <param name="canToken"></param>
        /// <param name="requestId"></param>
        /// <returns></returns>
        Task GetChildren(string parentIdN, string parentTypeN, IEnumerable<string> typesN, CancellationToken canToken, int requestId);

        /// <summary>
        /// Asks data layer to send children of a given type and a given parent node in full details.
        /// This method is parameterized by the parent to make this call to the database in one go. Asking details for each node would be inefficient
        /// Expected result: SetColumns() and AddAllFields() callbacks
        /// </summary>
        /// <param name="parentId"></param>
        /// <param name="typesN"></param>
        /// <param name="canToken"></param>
        /// <param name="requestId"></param>
        /// <returns></returns>
        //Task GetDetails(string parentId, string parentType, IEnumerable<string> typesN, CancellationToken canToken, int requestId); new version is GetList

        Task GetList(NbSqlXml request, CancellationToken canToken, int previousRequestId, int requestId);

        /// <summary>
        /// Commands for a single selected element
        /// </summary>
        /// <param name="nodeId"></param>
        /// <param name="nodeType"></param>
        /// <returns></returns>
        IEnumerable<A2aCommandDesc> GetCommandsSingle(string nodeId, string nodeType);

        /// <summary>
        /// Commands for a pair of elemements
        /// </summary>
        /// <param name="srcNodeId">Id of the other (first selected) element </param>
        /// <param name="scrNodeType"></param>
        /// <param name="srcNodeName"></param>
        /// <param name="dstNodeId">Id of the last selected (focused) element in the pair</param>
        /// <returns></returns>
        IEnumerable<A2aCommandDesc> GetCommandsDouble(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId);


        IEnumerable<A2aCommandDesc> GetDragCommands(string srcNodeId, string scrNodeType, string srcNodeName, string dstNodeId); //TODO: Think if double is the same as drag

        /// <summary>
        /// Commands for a set of 
        /// </summary>
        /// <param name="selNodeId"></param>
        /// <param name="selNodeType"></param>
        /// <param name="selNodeName"></param>
        /// <param name="nodeId"></param>
        /// <returns></returns>
        IEnumerable<A2aCommandDesc> GetCommandsMultiple (string selNodeId, string selNodeType, string selNodeName, IEnumerable<string> nodeId);

        /// <summary>
        /// The model can't give a command object to the UI to execute becuase this protocol will potentially work over the net
        /// </summary>
        /// <param name="cmdName"></param>
        /// <param name="scrNodeId"></param>
        /// <param name="scrNodeType"></param>
        /// <param name="scrNodeName"></param>
        /// <param name="dstNodeIdN"></param>
        /// <returns></returns>
        Task ExecuteCommand(string cmdName, string scrNodeId, string scrNodeType, string scrNodeName, string dstNodeIdN);
    }

    public class FormDesc
    {
        public List<A2aFormProperty> Properties;
    }

    [DebuggerDisplay("{FormTitle}({Properties.Count})")]
    public class A2aFormParameters
    {
        public string FormTitle;
        public List<A2aFormProperty> Properties;
        //TODO: Buttons
    }



        /// <summary>
        /// Desciptor of a field used in the Editor Window. Includes the Value, Type, Label and Tooltip
        /// </summary>
        [DebuggerDisplay("{Id}({Type}): {Value}")]
    public class A2aFormProperty
    {
        //
        public string Id;
        public string Type;
        public string Value;
        public string Label;
        public string Tooltip;

        public Func<string, string> ValidationMessage;
        public bool IsReadonly = false;
    }
}
