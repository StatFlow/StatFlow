﻿using NbTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NbFilterV1.Xml
{
    public partial class data_requestFilter
    {
        public static data_requestFilter MergeAll(IEnumerable<data_requestFilter> other)
        {
            data_requestFilter result = new data_requestFilter
            {
                and = other.Where(i => i.and != null).SelectMany(oth => oth.and.Safe()).ToArray()
            };
            return result;
        }


        /// <summary>
        /// Concatenates the and collections of two filter criterias. Shallow copy.
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public data_requestFilter MergeWith(data_requestFilter other)
        {
            data_requestFilter result = new data_requestFilter
            {
                and = this.and.Safe().Concat(other.and.Safe()).ToArray()
            };
            return result;
        }
    }
}

