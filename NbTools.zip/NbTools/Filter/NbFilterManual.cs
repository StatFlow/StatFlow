﻿using NbTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace NbFilterV1.Xml
{
    public partial class data_request
    {
        private static Lazy<XmlSerializer> Ser = new Lazy<XmlSerializer>(() => new XmlSerializer(typeof(data_request)), isThreadSafe: true);

        public string Serialize()
        {
            using MemoryStream ms = new MemoryStream();
            Ser.Value.Serialize(ms, this);
            ms.Position = 0;

            using var rdr = new StreamReader(ms);
            return rdr.ReadToEnd();
        }
    }

    public partial class data_requestFilter
    {
        public static data_requestFilter MergeAll(IEnumerable<data_requestFilter> other)
        {
            //var ot = other.ToDebugList();
            data_requestFilter result = new data_requestFilter
            {
                and = other.Where(i => i?.and != null).SelectMany(oth => oth.and.Safe()).ToArray()
            };
            return result;
        }


        /// <summary>
        /// Concatenates the and collections of two filter criterias. Shallow copy.
        /// </summary>
        /// <param name="other"></param>
        /// <returns></returns>
        public data_requestFilter MergeWith(data_requestFilter other)
        {
            data_requestFilter result = new data_requestFilter
            {
                and = this.and.Safe().Concat(other.and.Safe()).ToArray()
            };
            return result;
        }
    }
}

