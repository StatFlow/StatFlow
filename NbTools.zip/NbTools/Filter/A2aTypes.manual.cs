﻿using NbTools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace A2aTypes.Xml
{
    public partial class A2aT
    {
        internal void Resolve()
        {
            var typesDict = types.ToNbDictionary(t => t.name, t => t, null, types.Length, "A2A Types");
            tree_views.ForEachSafe(t => t.Resolve(typesDict));
        }

        public override string ToString() => $"Types: {String.Join(", ", types.Safe().Select(t => t.name))}; TreeViews: {String.Join(", ", tree_views.Safe().Select(t => t.name))}; ListViews: {String.Join(", ", list_views.Safe().Select(t => t.name))};";
    }


    public partial class A2aType
    {
        public override string ToString() => $"Type '{name}' ({String.Join(", ", column.Safe().Select(t => t.name))})";
    }


    public partial class ListView
    {
        public override string ToString() => $"ListView '{name}' ({type})";
    }


    public partial class TreeView
    {
        [XmlIgnore]
        public A2aType[] TypesResoved;

        internal void Resolve(NbDictionary<string, A2aType> types)
        {
            TypesResoved = type.Select(t => types[t]).ToArray();
        }

        public override string ToString() => $"TreeView '{name}' ({String.Join(", ", type.Safe())})";
    }
}