using System;
using System.Linq;

namespace NbTools.SqlGen.Xml
{

    public partial class NbSqlXml
    {
        public override string ToString()
        {
            string tblList = String.Join(", ", table.Select(t => $"{t.name} {t.alias}"));
            string fltList = String.Join(", ", filter.Select(t => filter.ToString()));
            return $"tables:{tblList} filters:{fltList}";
        }
    }

    /*public partial class NbSqlTable { }

    public partial class NbSqlJoin { }*/

    public partial class NbSqlField
    {
        public string OrderBySql => $"{name} {(order_desc ? " desc" : "")}";
    }

    /*public partial class FilterBase { }

    public partial class InSubtree { }*/

    public partial class InNode
    {
        public override string ToString() => $"node_id:{node_id} node_type:{node_type} field:{field}";
    }

    /*public partial class FltContain { }
    public partial class FltEqual { }
    public partial class NbSqlXml { }*/
}
