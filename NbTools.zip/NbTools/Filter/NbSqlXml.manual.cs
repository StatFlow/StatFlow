using System;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace NbTools.SqlGen.Xml
{
    public partial class NbSqlXml
    {
        [XmlIgnore]
        public bool IsResolved { get; private set; }

        public void Resolve()
        {
            table.ForEachSafe(t => t.Resolve());
            filter.ForEachSafe(t => t.Resolve(table));
            IsResolved = true;
        }

        public override string ToString()
        {
            string tblList = String.Join(", ", table.Select(t => $"{t.name} {t.alias}"));
            string fltList = String.Join(", ", filter.Select(t => filter.ToString()));
            return $"tables:{tblList} filters:{fltList}";
        }

        public string ToXmlString()
        {
            using StringWriter wrtr = new StringWriter();
            Ser.Serialize(wrtr, this);
            return wrtr.ToString();
        }
    }

    //public partial class NbSqlJoin { }

    public partial class NbSqlTable
    {
        internal void Resolve()
        {
            field.ForEachSafe(t => t.Resolve(this));
        }

        public override string ToString()
        {
            var flds = String.Join(",", field.Safe().Select(fld => fld.ToString()));
            return $"{name} ({flds})";
        }
    }

    public partial class NbSqlField
    {
        public NbSqlField(string name) : this()
        {
            this.name = name;
        }

        [XmlIgnore]
        private NbSqlTable Parent;

        internal void Resolve(NbSqlTable tbl)
        {
            Parent = tbl;
        }

        public string OrderBySql => $"{Parent.alias}.{name} {(order_desc ? " desc" : "")}";

        public override string ToString() => $"{name}";
    }

    public partial class InNode
    {
        public override string ToString() => $"node_id:{node_id} node_type:{node_type} field:{field}";
    }


    public partial class FilterBase
    {
        [XmlIgnore]
        public NbSqlTable TableResolved;

        internal void Resolve(NbSqlTable[] tables)
        {
            if (String.IsNullOrEmpty(table))
                throw new NbExceptionInfo($"Table parameter was not set for the Filter Tag for field {field}");
            TableResolved = tables.SingleVerbose(t => t.name.EqIC(table), () => $"Filter refers to the table '{table}' which was not found", i => $"Filter refers to the table '{table}'. {i} tables with this name was found");
        }
    }

    //public partial class InSubtree { }
    /*public partial class FltContain { }
    public partial class FltEqual { }
    public partial class NbSqlXml { }*/
}
