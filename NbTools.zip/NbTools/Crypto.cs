﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace NbTools.Crypto
{
    public interface IStringEncryptor
    {
        string EncryptString(string plainText);
        string DecryptString(string encryptedText);
    }

    public class TripleDESStringEncryptor : IStringEncryptor
    {
        private readonly byte[] _k;
        private readonly byte[] _iv;
        private readonly TripleDESCryptoServiceProvider _provider;

        public TripleDESStringEncryptor()
        {
            const int keyLength = 3;
            var seed = Math.PI;
            _iv = BitConverter.GetBytes(seed);
            _k = new byte[keyLength * sizeof(double)];
            for (int i = 0; i < keyLength; ++i)
            {
                seed *= Math.E;
                Array.Copy(BitConverter.GetBytes(seed), 0, _k, i * sizeof(double), sizeof(double));
            }
            _provider = new TripleDESCryptoServiceProvider();
        }

        public string EncryptString(string plainText) => Encoding.Default.GetString(Transform(Encoding.Default.GetBytes(plainText), _provider.CreateEncryptor(_k, _iv)));
        public string DecryptString(string encryptedText) => Encoding.Default.GetString(Transform(Encoding.Default.GetBytes(encryptedText), _provider.CreateDecryptor(_k, _iv)));

        public string EncryptBase64(string plainText) => Convert.ToBase64String(Transform(Encoding.Default.GetBytes(plainText), _provider.CreateEncryptor(_k, _iv)));
        public string DecryptBase64(string encryptedText) => Encoding.Default.GetString(Transform(Convert.FromBase64String(encryptedText), _provider.CreateDecryptor(_k, _iv)));

        public byte[] EncryptBytes(byte[] bytes) => Transform(bytes, _provider.CreateEncryptor(_k, _iv));
        public byte[] DecryptBytes(byte[] bytes) => Transform(bytes, _provider.CreateDecryptor(_k, _iv));

        private byte[] Transform(byte[] input, ICryptoTransform transform)
        {
            if (input == null || input.Length == 0)
                return null;

            using (MemoryStream stream = new MemoryStream())
            using (CryptoStream cryptoStream = new CryptoStream(stream, transform, CryptoStreamMode.Write))
            {
                cryptoStream.Write(input, 0, input.Length);
                cryptoStream.FlushFinalBlock();
                return stream.ToArray();
            }
        }
    }
}