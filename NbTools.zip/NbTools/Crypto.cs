﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace NbTools.Crypto
{
    public interface IStringEncryptor
    {
        string EncryptString(string plainText);
        string DecryptString(string encryptedText);
    }

    public class TripleDESStringEncryptor : IStringEncryptor
    {
        private readonly byte[] _k;
        private readonly byte[] _iv;
        private readonly TripleDESCryptoServiceProvider _provider;

        public TripleDESStringEncryptor()
        {
            const int keyLength = 3;
            var seed = Math.PI;
            _iv = BitConverter.GetBytes(seed);
            _k = new byte[keyLength * sizeof(double)];
            for (int i = 0; i < keyLength; ++i)
            {
                seed *= Math.E;
                Array.Copy(BitConverter.GetBytes(seed), 0, _k, i * sizeof(double), sizeof(double));
            }
            _provider = new TripleDESCryptoServiceProvider();
        }

        public string EncryptString(string plainText) => Encoding.Default.GetString(Transform(Encoding.Default.GetBytes(plainText), _provider.CreateEncryptor(_k, _iv)));
        public string DecryptString(string encryptedText) => Encoding.Default.GetString(Transform(Encoding.Default.GetBytes(encryptedText), _provider.CreateDecryptor(_k, _iv)));

        public string EncryptBase64(string plainText) => Convert.ToBase64String(Transform(Encoding.Default.GetBytes(plainText), _provider.CreateEncryptor(_k, _iv)));
        public string DecryptBase64(string encryptedText) => Encoding.Default.GetString(Transform(Convert.FromBase64String(encryptedText), _provider.CreateDecryptor(_k, _iv)));

        public byte[] EncryptBytes(byte[] bytes) => Transform(bytes, _provider.CreateEncryptor(_k, _iv));
        public byte[] DecryptBytes(byte[] bytes) => Transform(bytes, _provider.CreateDecryptor(_k, _iv));

        private byte[] Transform(byte[] input, ICryptoTransform transform)
        {
            if (input == null || input.Length == 0)
                return null;

            using MemoryStream stream = new MemoryStream();
            using CryptoStream cryptoStream = new CryptoStream(stream, transform, CryptoStreamMode.Write);
            cryptoStream.Write(input, 0, input.Length);
            cryptoStream.FlushFinalBlock();
            return stream.ToArray();
        }

        //Convert.FromHexString - use in > .Net 5 
        public static string ByteToHexBitFiddle(byte[] bytes)
        {
            char[] c = new char[bytes.Length * 2];
            int b;
            for (int i = 0; i < bytes.Length; i++)
            {
                b = bytes[i] >> 4;
                c[i * 2] = (char)(55 + b + (((b - 10) >> 31) & -7));
                b = bytes[i] & 0xF;
                c[i * 2 + 1] = (char)(55 + b + (((b - 10) >> 31) & -7));
            }
            return new string(c);
        }

        public static string Ldr
        {
            get
            {
                int num = 0x26b66a5; //40593061;
                var arr1 = num.ToString().ToArray();
                var str = new String(arr1.Append(arr1[0]).Select((b, i) => (char)(2 + b + b + (i % 5 == 0 ? 1 : 0))).ToArray());
                return char.ToUpper(str[0]) + str.Substring(1);
            }
        }
    }

    public class GeorgeConverter
    {
        private static Dictionary<char, char> MapAll;

        public GeorgeConverter()
        {
            MapAll = new Dictionary<char, char>();
            foreach (var triple in Letters)
            {
                MapAll[triple.Item1] = triple.Item2;
                MapAll[triple.Item2] = triple.Item1;
            }
        }

        public (string, int) Convert(string text)
        {
            StringBuilder bld = new StringBuilder(text.Length);

            int counter = 0;
            foreach (var ch in text.ToLowerInvariant())
            {
                if (MapAll.TryGetValue(ch, out char gr))
                {
                    counter++;
                    bld.Append(gr);
                }
                else
                    bld.Append(ch); //No converstion for english letters, digits and symbols
            }
            return (bld.ToString(), counter);
        }


        enum LetterType { None = 0, Glas, Soglas }
        static readonly (char, char, LetterType)[] Letters =
        {
            ('й', 'ღ', LetterType.None),
            ( 'ц', 'ჯ' , LetterType.Soglas),
            ( 'у', 'უ' , LetterType.Glas),
            ( 'к', 'კ' , LetterType.Soglas),
            ( 'е', 'ე' , LetterType.Glas),
            ( 'н', 'ნ' , LetterType.Soglas),
            ( 'г', 'გ' , LetterType.Soglas),
            ( 'ш', 'შ' , LetterType.Soglas),
            ( 'щ', 'წ' , LetterType.Soglas),
            ( 'з', 'ზ' , LetterType.Soglas),
            ( 'х', 'ხ' , LetterType.Soglas),
            ( 'ъ', 'ც' , LetterType.None),

            ( 'ф', 'ფ' , LetterType.Soglas),
            ( 'ы', 'ძ' , LetterType.Glas),
            ( 'в', 'ვ' , LetterType.Soglas),
            ( 'а', 'თ' , LetterType.Glas),
            ( 'п', 'ა' , LetterType.Soglas),
            ( 'р', 'პ' , LetterType.Soglas),
            ( 'о', 'რ' , LetterType.Glas),
            ( 'л', 'ო' , LetterType.Soglas),
            ( 'д', 'ლ' , LetterType.Soglas),
            ( 'ж', 'დ' , LetterType.Soglas),
            ( 'э', 'ჟ' , LetterType.Glas),

            ( 'я', 'ჭ' , LetterType.Glas),
            ( 'ч', 'ჩ' , LetterType.Soglas),
            ( 'с', 'ყ' , LetterType.Soglas),
            ( 'м', 'ს' , LetterType.Soglas),
            ( 'и', 'მ' , LetterType.Glas),
            ( 'т', 'ი' , LetterType.Soglas),
            ( 'ь', 'ტ' , LetterType.None),
            ( 'б', 'ქ' , LetterType.Soglas),
            ( 'ю', 'ბ' , LetterType.Glas)
        };
    }
}