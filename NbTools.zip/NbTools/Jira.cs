﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;

namespace NbTools
{
    public static partial class NbExt
    {

        public static IEnumerable<T> FromJiraRss<T>(string fileName, CsvParameters csvParamN = null)
            where T : new()
        {
            if (!File.Exists(fileName))
                yield break;

            Dictionary<string, int> headerDict = new Dictionary<string, int>(30, StringComparer.OrdinalIgnoreCase);

            XElement channel = XDocument.Load(fileName).Root.TagN("channel");
            foreach (var item in channel.Tags("item"))
            {
                foreach (var tag in item.Elements())
                {
                    if (!tag.Name.LocalName.Equals("customfields", StringComparison.OrdinalIgnoreCase))
                        headerDict[tag.Name.LocalName] = 1;
                    else
                    {
                        foreach (var cFls in tag.Tags("customfield"))
                            headerDict[cFls.TagN("customfieldname").Value] = 1;
                    }
                }
            }
            List<string> headers = headerDict.Keys.ToList();
            CsvTextToObject[] fieldsAndProps = CsvTextToObject.Create(typeof(T), headers, csvParamN); //Just take the string, ignoring the index


            List<string> line = new List<string>(headers.Count);
            foreach (var item in channel.Tags("item"))
            {
                line.Clear();
                var cfRoot = item.TagN("customfields");
                foreach (var hdr in headers) //TODO: pack as a enumerator
                {
                    if (!hdr.Contains(" ")) //Custom attributes can contain spaces
                    {
                        var tag = item.TagN(hdr);
                        if (tag != null)
                        {
                            line.Add(tag.Value);
                            continue;
                        }
                    }

                    if (cfRoot != null)
                    {
                        line.Add(GetCustomFieldValueN(cfRoot, hdr));
                        continue;
                    }

                    line.Add(null);
                }

                Action<string> act = csvParamN?.LoggerN;
                T obj = BuildObject<T>(line, fieldsAndProps, act);
                yield return obj;
            }
        }

        private static string GetCustomFieldValueN(XElement cfRoot, string name)
        {
            foreach (var cFls in cfRoot.Tags("customfield"))
            {
                if (cFls.Tag("customfieldname").Value.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return cFls.TagN("customfieldvalues")?.Tags("customfieldvalue")?.FirstOrDefault()?.Value;
            }
            return null;
        }
    }
}
