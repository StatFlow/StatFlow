﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace NbTools
{
    public class NbDir
    {
        public readonly DirectoryInfo DirInfo;
        private string fPreviousFilename;

        public NbDir(string aDi)
        { DirInfo = new DirectoryInfo(aDi); }

        public NbDir(DirectoryInfo aDi)
        { DirInfo = aDi; }

        public static NbDir Startup => new NbDir(AppDomain.CurrentDomain.BaseDirectory);
        public static string NameOnly(FileInfo fi) => fi.Name.Substring(0, fi.Name.Length - fi.Extension.Length);
        public override string ToString() => DirInfo.FullName;

        public static string ExpandAll(string resultFile)
        {
            DateTime timestamp = DateTime.Now; //Use single timestamp for the whole run
            string date = timestamp.ToString("yyyyMMdd");
            string time = timestamp.ToString("HHmmss");

            resultFile = ExpandDateVariables(Environment.ExpandEnvironmentVariables(resultFile), timestamp);
            resultFile = resultFile.Replace("{DATE}", date).Replace("{TIME}", time).Replace("{DATETIME}", date + "_" + time);
            FileInfo fi = EnsureUniqueFileName(resultFile, timestamp); //create  'Filename (1).ext' if such file already exists
            NbExt.DirCreateRecursive(fi.Directory); //Ensure directory exists
            return resultFile;
        }


        public static void CopyDir(string sourceDirectory, string targetDirectory)
        {
            DirectoryInfo diSource = new DirectoryInfo(sourceDirectory);
            DirectoryInfo diTarget = new DirectoryInfo(targetDirectory);

            diTarget.DirCreateRecursive();
            CopyDirAll(diSource, diTarget);
        }

        public static void CopyDirAll(DirectoryInfo source, DirectoryInfo target)
        {
            Directory.CreateDirectory(target.FullName);

            // Copy each file into the new directory.
            foreach (FileInfo fi in source.GetFiles())
            {
                Console.WriteLine(@"Copying {0}\{1}", target.FullName, fi.Name);
                fi.CopyTo(Path.Combine(target.FullName, fi.Name), true);
            }

            // Copy each subdirectory using recursion.
            foreach (DirectoryInfo diSourceSubDir in source.GetDirectories())
            {
                DirectoryInfo nextTargetSubDir =
                    target.CreateSubdirectory(diSourceSubDir.Name);
                CopyDirAll(diSourceSubDir, nextTargetSubDir);
            }
        }


        public static string ReplaceExtension(string fileName, string newExtension)
        {
            if (newExtension[0] != '.')
                newExtension = "." + newExtension;

            return Path.Combine(Path.GetDirectoryName(fileName), Path.GetFileNameWithoutExtension(fileName) + newExtension);
        }

        private static readonly char[] curlies = new char[] { '{', '}' };
        private static readonly Lazy<Regex> dateTimeRegex = new Lazy<Regex>(() => new Regex(@"{[y|m|d|h|s|-|_| ]+}", RegexOptions.IgnoreCase));
        public static string ExpandDateVariables(string str, DateTime? now = null)
        {
            if (!now.HasValue)
                now = DateTime.Now;

            return dateTimeRegex.Value.Replace(str, m =>
            {
                string format = m.ToString().Trim(curlies);
                try
                {
                    return now.Value.ToString(format);
                }
                catch (Exception ex)
                {
                    throw new ArgumentException(String.Format("Error while converting date using '{0}' format", format), ex);
                }
            });
        }

        public static int SyncTo(string srcPattern, string dstDir, Action<string> logN = null)
        {
            var srcDir = Path.GetDirectoryName(srcPattern);
            if (!Directory.Exists(srcDir))
                throw new NbExceptionInfo($"Sync source directory '{srcDir}' doesn't exist");

            var srcFilePattern = Path.GetFileName(srcPattern);
            NbExt.DirCreateRecursive(dstDir);

            var srcFiles = new DirectoryInfo(srcDir).GetFiles(srcFilePattern).OrderByDescending(f => f.CreationTimeUtc).ToList();
            var dstFiles = new DirectoryInfo(dstDir).GetFiles(srcFilePattern);

            int copyCounter = 0;
            foreach (var fn in srcFiles.NotIn(dstFiles, (s, d) => s.Name.Equals(d.Name, StringComparison.OrdinalIgnoreCase)))
            {
                try
                {
                    File.Copy(fn.FullName, dstDir);
                    copyCounter++;
                }
                catch (Exception ex)
                {
                    logN?.Invoke($"Can't copy '{fn.FullName}' into '{dstDir}': {ex.Message}");
                }
            }

            return copyCounter;
        }

        public static FileInfo EnsureUniqueFileName(string filename, DateTime? timestamp = null)
        {
            FileInfo fi = new FileInfo(filename);
            if (!fi.Exists)
                return fi;

            string extension = fi.Extension;
            string filenameNoExtension = fi.FullName.Substring(0, fi.FullName.Length - fi.Extension.Length);

            //If the timestamp is provided - put the timestamp at the end of the filename to ensure uniqueness
            if (timestamp.HasValue)
            {
                string newFileName = String.Format("{0}_{1}{2}", filenameNoExtension, timestamp.Value.ToString("HHmmss"), extension);
                fi = new FileInfo(newFileName);
                if (!fi.Exists)
                    return fi;
            }

            //The filename is not unique, interate and add a counter at the end of the file name
            int maxFileCopies = 1000;
            for (int i = 1; i < maxFileCopies; ++i)
            {
                string newFileName = String.Format("{0} ({1}){2}", filenameNoExtension, i, extension);
                fi = new FileInfo(newFileName);
                if (!fi.Exists)
                    return fi;
            }
            throw new InvalidOperationException(String.Format("There are over {0} copies of the file '{1}'. Can't create another one.", maxFileCopies, filename));
        }

        public string TimestampedFile(string aPrefix, string aExtension)
        {
            DateTime timestamp = DateTime.Now;
            string file = String.Format("{0}\\{1} {2}.{3}",
                DirInfo.FullName, aPrefix,
                TimeOfDay(timestamp),
                aExtension);

            if (file.Equals(fPreviousFilename))
            {
                Thread.Sleep(1);
                return TimestampedFile(aPrefix, aExtension);
            }
            else
            {
                fPreviousFilename = file;
                return file;
            }
        }

        public static string TimeStampTheFile(FileInfo fi, DateTime timestamp = default)
        {
            if (timestamp == default)
                timestamp = DateTime.Now;

            string file = String.Format("{0}{1} {2}{3}",
                fi.FullName.Substring(0, fi.FullName.Length - fi.Extension.Length),
                DayOfYear(timestamp),
                TimeOfDay(timestamp),
                fi.Extension);

            FileInfo fl = new FileInfo(file);
            if (!fl.Exists)
            {   //Create the directory to ensure that the file can be created
                NbExt.DirCreateRecursive(fl.Directory);
                return file;
            }
            Thread.Sleep(1);
            return TimeStampTheFile(fi);
        }

        public static string TimeOfDay(DateTime t) => String.Format("{0:d2}-{1:d2}-{2:d2}.{3:d3}", t.Hour, t.Minute, t.Second, t.Millisecond);
        public static string DayOfYear(DateTime t) => String.Format("{0:d4}-{1:d2}-{2:d2}", t.Year, t.Month, t.Day);

        public static NbDir CreateTimestampedDir(string aPathAndPrefix)
        {
            DateTime timestamp = DateTime.Now;
            string dir = String.Format("{0} {1:d2}.{2:d2} {3:d2}-{4:d2}-{5:d2}",
                aPathAndPrefix, timestamp.Month, timestamp.Day, timestamp.Hour, timestamp.Minute, timestamp.Second);

            DirectoryInfo di = new DirectoryInfo(dir);
            NbExt.DirCreateRecursive(di);
            return new NbDir(di);
        }

        public NbDir TimestampedDir(string aPrefix)
        {
            DateTime timestamp = DateTime.Now;
            string dir = String.Format("{0}\\{1} {2:d2}.{3:d2} {4:d2}-{5:d2}-{6:d2}",
                DirInfo.FullName, aPrefix,
                timestamp.Month, timestamp.Day, timestamp.Hour, timestamp.Minute, timestamp.Second);

            NbDir newDir = new NbDir(new DirectoryInfo(dir));
            NbExt.DirCreateRecursive(newDir.DirInfo);
            return newDir;
        }

        public static Exception MoveFile(string aSrc, string aDst)
        {
            FileInfo fi = new FileInfo(aDst);
            NbExt.DirCreateRecursive(fi.Directory);
            try
            {
                File.Move(aSrc, aDst);
                return null;
            }
            catch (Exception e)
            {
                return e;
            }
        }

        public static void EmptyDir(DirectoryInfo directory)
        {
            foreach (var file in directory.GetFiles()) file.Delete();
            foreach (var subDirectory in directory.GetDirectories()) subDirectory.Delete(true);
        }

        /// <summary>
        /// </summary>
        /// <returns>true - if directory was created, false if directory already existed</returns>
        [Obsolete("Use DirCreateRecursive from NbExt")]
        public bool CreateRecursive() => CreateDirRecursive(DirInfo);

        [Obsolete("Use DirCreateRecursive from NbExt")]
        public static bool CreateDirRecursive(string aDirName) => CreateDirRecursive(new DirectoryInfo(aDirName));

        /// <summary>
        /// </summary>
        /// <returns>true - if directory was created, false if directory already existed</returns>
        [Obsolete("Use DirCreateRecursive from NbExt")]
        public static bool CreateDirRecursive(DirectoryInfo di) //Recursive
        {
            if (!di.Exists)
            {
                if (di.Root.FullName == di.FullName) //We are in the root and it doens't exist
                    throw new NbException($"The root dir '{di.Root.FullName}' doens't exist");

                CreateDirRecursive(di.Parent);
                Directory.CreateDirectory(di.FullName);
                return true;
            }
            else
                return false;
        }

        //The list of files by the search pattern, including the directory
        public static IEnumerable<FileInfo> ListFiles(string aSearchWithPath) => new DirectoryInfo(Path.GetDirectoryName(aSearchWithPath)).GetFiles(Path.GetFileName(aSearchWithPath)).OrderBy(fi => fi.Name);

        public static IEnumerable<FileInfo> ListFilesRecursively(DirectoryInfo di, string aSearchPattern) => ListFilesRecursively(di, aSearchPattern.Split(Path.PathSeparator));
        public static IEnumerable<FileInfo> ListFilesRecursively(DirectoryInfo di, IEnumerable<string> aSearchPatterns)
        {
            return aSearchPatterns.SelectMany(ptrn => FlattenDir(di).SelectMany(d =>
            {
                try { return d.GetFiles(ptrn); }
                catch (UnauthorizedAccessException) { return Enumerable.Empty<FileInfo>(); }
            }));
        }

        public static IEnumerable<DirectoryInfo> FlattenDir(DirectoryInfo aDir)
        {
            if (aDir == null || !aDir.Exists)
                return Enumerable.Empty<DirectoryInfo>();

            try
            {
                return NbExt.Yield(aDir).Concat(aDir.GetDirectories().SelectMany(e => FlattenDir(e)));
            }
            catch (UnauthorizedAccessException) { return Enumerable.Empty<DirectoryInfo>(); }
        }

        public static string Legalize(string aFileName)
        {
            // / ? < > \ : * | ”
            aFileName = Regex.Replace(aFileName, "\"", "''");
            aFileName = Regex.Replace(aFileName, @"/|\?|<|>|\\|:|\*|\|", "_");
            return aFileName;
        }

        public static string LegalizeFullPath(string aFileName)
        {
            // / ? < > \ : * | ”
            aFileName = Regex.Replace(aFileName, "\"", "''");
            aFileName = Regex.Replace(aFileName, @"\?|<|>|\*|\|", "_");
            return aFileName;
        }

        public static void SaveBlobToFile(byte[] blob, string FileName)
        {
            FileStream fs = new FileStream(FileName, FileMode.Create, FileAccess.Write);
            int len = blob.Length;
            fs.Write(blob, 0, len);
            fs.Close();
        }

        public static byte[] ReadBlobFromFile(string FileName)
        {
            using FileStream fs = new FileStream(FileName, FileMode.Open, FileAccess.Read);
            int length = Convert.ToInt32(fs.Length);//we don't support extra large files (>4Gb)
            byte[] data = new byte[length];
            fs.Read(data, 0, length);
            return data;
        }

        private static readonly Lazy<Regex> fSizeRegex = new Lazy<Regex>(() => new Regex(@"([\d.,]+)\W*([KMGTКМЬГТ])i*[BБ]", RegexOptions.IgnoreCase));

        public static bool TryParseSize(string p, out long size)
        {
            size = -1;
            Match mt = fSizeRegex.Value.Match(p);
            if (!mt.Success)
                return false;

            string valStr = mt.Groups[1].Value.ToString().Replace(',', '.');

            if (!Double.TryParse(valStr, out double val))
                return false;

            switch (mt.Groups[2].Value.ToString().ToUpperInvariant())
            {
                case "K":
                case "К":
                    val *= 1024f; break;
                case "M":
                case "М":
                    val *= 1024f * 1024f; break;
                case "G":
                case "Г":
                    val *= 1024f * 1024f * 1024f; break;
                case "T":
                case "Т":
                    val *= 1024f * 1024f * 1024f * 1024f; break;
                default:
                    return false;
            }

            size = Convert.ToInt64(val);
            return true;
        }

        /// <summary>
        /// Keep big amount of files in directories by 10000 based on the integer Id
        /// </summary>
        /// <param name="aFileId">integer id for the file</param>
        /// <param name="aExtension">file extension without dot like "jpg"</param>
        /// <returns></returns>
        public static string ByTenThousandId(int aFileId, string aExtension)
        {
            if (!aExtension.StartsWith("."))
                aExtension = "." + aExtension;

            return String.Format(@"{0}\{1}{2}", aFileId / 10000, aFileId, aExtension);
        }

        //TODO: support file (2).ext here to be compatible with windows naming convention
        public FileInfo GrouppingNewFile(int aFieldId, string aExtension, ref List<long> aExistingFileLength)
        {
            string dstFileOnly = ByTenThousandId(aFieldId, aExtension);
            FileInfo dstFile = new FileInfo(DirInfo.FullName + Path.DirectorySeparatorChar + dstFileOnly);

            int cntr = 1;
            while (dstFile.Exists)
            {
                if (aExistingFileLength != null)
                    aExistingFileLength.Add(dstFile.Length);

                dstFileOnly = NbDir.ByTenThousandId(aFieldId, String.Format("{0}.{1}", cntr++, aExtension));
                dstFile = new FileInfo(DirInfo.FullName + Path.DirectorySeparatorChar + dstFileOnly);
            }
            return dstFile;
        }

        public List<FileInfo> GrouppingFileList(int parentId, string aExtension)
        {
            List<FileInfo> list = new List<FileInfo>(50);
            string dstFileOnly = ByTenThousandId(parentId, aExtension);
            FileInfo dstFile = new FileInfo(DirInfo.FullName + Path.DirectorySeparatorChar + dstFileOnly);

            int cntr = 1;
            while (dstFile.Exists)
            {
                list.Add(dstFile);

                dstFileOnly = NbDir.ByTenThousandId(parentId, String.Format("{0}.{1}", cntr++, aExtension));
                dstFile = new FileInfo(DirInfo.FullName + Path.DirectorySeparatorChar + dstFileOnly);
            }
            return list;
        }


        public static bool CompareDirs(string aLeftDirectory, string aRightDirectory, string aComparisonMask)
        {
            DirectoryInfo diRight = new DirectoryInfo(aRightDirectory);
            FileInfo[] rgFiles = diRight.GetFiles(aComparisonMask);
            foreach (FileInfo fi in rgFiles)
            {
                string leftFileName = aLeftDirectory + "\\" + fi.Name;
                if (!CompareTwoFiles(leftFileName, fi.FullName))
                {
                    //aSettings.Logger.Write(Verasis.Platform.LogView.Severity.Warning, null, @"Files: {0} and {1} are different.", leftFileName, fi.FullName);
                    return false;
                }
            }
            return true;
        }

        public static bool CompareTwoFiles(string aLeftFile, string aRightFile)
        {
            try
            {
                using StreamReader file1 = new StreamReader(new FileStream(aLeftFile, FileMode.Open, FileAccess.Read));
                using StreamReader file2 = new StreamReader(new FileStream(aRightFile, FileMode.Open, FileAccess.Read));
                while (file1.Peek() >= 0 || file2.Peek() >= 0)
                    if (file1.Read() != file2.Read())
                        return false;

                return true;

            }
            catch (Exception)
            { return false; }
        }

        const int BYTES_TO_READ = sizeof(Int64);

        public static bool CompareTwoFiles2(FileInfo first, FileInfo second)
        {
            if (first.Length != second.Length)
                return false;

            int iterations = (int)Math.Ceiling((double)first.Length / BYTES_TO_READ);

            using (FileStream fs1 = first.OpenRead())
            using (FileStream fs2 = second.OpenRead())
            {
                byte[] one = new byte[BYTES_TO_READ];
                byte[] two = new byte[BYTES_TO_READ];

                for (int i = 0; i < iterations; i++)
                {
                    fs1.Read(one, 0, BYTES_TO_READ);
                    fs2.Read(two, 0, BYTES_TO_READ);

                    if (BitConverter.ToInt64(one, 0) != BitConverter.ToInt64(two, 0))
                        return false;
                }
            }
            return true;
        }
    }

    public class TempFileName : IDisposable
    {
        private readonly string Filename;

        public TempFileName(string extension = "tmp")
        {
            Filename = "%TEMP%\\" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "." + extension;
            Filename = Environment.ExpandEnvironmentVariables(Filename);
        }

        public static implicit operator string(TempFileName tfn) => tfn.Filename;
        public override string ToString() => Filename;

        public void Dispose()
        {
            try
            {
                if (File.Exists(Filename))
                    File.Delete(Filename);
            }
            catch { } //Ignore the errors if temporary files can't be deleted
        }
    }
}
