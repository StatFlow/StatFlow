﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using System.Threading;

namespace Exec
{
    public static class Selenium
    {
        public static int Main() //string[] args
        {
            var pss = File.ReadAllText(@"C:\!Work\Conn\pss");

            //IWebDriver dr = new InternetExplorerDriver(@"D:\SETUP\Programming\Selenium");

            Console.Write("RSA: ");
            string key = Console.ReadLine();
            IWebDriver dr = new FirefoxDriver(@"C:\Temp\Selenium");

            //dr.Navigate().GoToUrl("https://myaccess.barclays.com/__extraweb__realmform?resource=%2F&alias=myaccess.barclays.com&r0=144&r1=145&r2=146&r3=147&r4=148");
            dr.Navigate().GoToUrl(@"https://myworkspace.barclays.com/vpn/index.html");
            File.WriteAllText(@"c:\temp\Selenium\Page.html", dr.PageSource);

            new SelectElement(dr.FindElement(By.ClassName("domain_select"))).SelectByText("INTRANET");
            dr.FindElement(By.Id("Enter user name")).SendKeys("budantsn");
            dr.FindElement(By.Id("passwd")).SendKeys(pss);
            dr.FindElement(By.Id("passwd1")).SendKeys(key);
            dr.FindElement(By.Id("Log_On")).Click();

            var wait1 = new WebDriverWait(dr, TimeSpan.FromSeconds(10));
            Thread.Sleep(3000);
            wait1.Until(d => d.FindElement(By.ClassName("storeapp-details-link")));
            //File.WriteAllText(@"c:\temp\Selenium\Page3.html", dr.PageSource);
            dr.FindElement(By.ClassName("storeapp-details-link")).Click();

            Console.Write("Done, press any key...");
            Console.ReadKey();
            return 0;
        }

    }
}
