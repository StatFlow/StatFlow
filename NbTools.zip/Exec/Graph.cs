﻿using NbTools;
using NbTools.Dgml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace NbGraph
{
    /*public class Node
    {
        public readonly string Name;
        public readonly NodeList NodeList;
        public List<Node> Links = new List<Node>(5);
        public static Lazy<XmlSerializer> modelXmlSerializer = new Lazy<XmlSerializer>(() => new XmlSerializer(typeof(DirectedGraph)), false);

        public static int NdCnt = 0;

        public Node(string aName = null, NodeList nodeList = null, params Node[] children)
        {
            Name = aName ?? $"Node-{NdCnt++}";
            foreach (var nd in children.Safe())
            {
                Links.Add(nd);
                //nd.AddLink(this);
                if (NodeList == null)
                    NodeList = nd.NodeList;
            }

            if (NodeList == null)
                NodeList = nodeList;
            if (NodeList == null)
                throw new Exception("NodeList was not provided");

            NodeList.Add(this);
        }

        public void AddLink(Node nd)
        {
            Links.Add(nd);
            //nd.Links.Add(this); //Adding reciprocal Nodes
        }

        public void AddLinks(params Node[] nds)
        {
            foreach (var nd in nds)
                AddLink(nd);
        }
    }


    public class NodeList
    {
        public readonly string Name;
        public List<Node> Nodes = new List<Node>(5);


        public NodeList(string Name = null)
        {
            if (Name == null)
                Name = $"NodeList";
        }

        public void Add(Node nd) => Nodes.Add(nd);

        public void SaveDgml(string fileName)
        {
            try
            {
                var dgNodes = Nodes.Select(n => new DirectedGraphNode { Id = n.Name, Label = n.Name }).ToArray();
                var dgLinks = Nodes.SelectMany(n => n.Links.Select(l => new DirectedGraphLink { Source = n.Name, Target = l.Name })).ToArray();

                DirectedGraph dg = new DirectedGraph
                {
                    Title = Name,
                    Nodes = dgNodes,
                    Links = dgLinks
                };

                using (StreamWriter wrtr = new StreamWriter(fileName))
                {
                    Node.modelXmlSerializer.Value.Serialize(wrtr, dg);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error serializing dgml into '{fileName}'", ex);
            }
        }
    }*/



}
