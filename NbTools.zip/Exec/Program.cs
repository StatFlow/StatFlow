﻿using System;
using System.IO;

using NbTools;
using LinkManager.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NbTools.Collections;
using System.Diagnostics;
using NbTools.Media;

namespace Exec
{
    class Program
    {
        //private const string testFile = "test1.csv";
        //private const string controlFile = "cmp.csv";
        //private static Random Rnd = new Random();
        //private const string resDir = @"C:\temp\Html\";

        //private const string modelFile = @"..\..\..\DataWalker\MsSql\HomeSql*.xml";
        //private const string tblName = "Contacts";


        //private const string modelFile = @"C:\!Work\Repo\Miscell\ELIG\ELIG*.xml";
        //private const string tblName = "LookupInfo.PayeeStatus";

        static void Main(string[] _)
        {
            var rnd = new Random();

            var matches = 15;
            bool userTurn = true;
            while (matches > 1)
            {
                Console.WriteLine($"There are {matches} matches on the table");

                int choice;
                if (userTurn)
                {
                    Console.WriteLine($"Enter the number or matches: 1- {Math.Min(matches, 3)}");
                    choice = Int32.Parse(Console.ReadLine());
                }
                else
                {
                    choice = (matches - 1) % 4;
                    if (choice == 0) //No winning strategy
                        choice = rnd.Next(1, Math.Min(matches, 3) + 1);

                    Console.WriteLine($"Computer took {choice} matches");
                }

                matches -= choice;

                if (matches == 1)
                {
                    Console.WriteLine($"1 match is left on the table {(userTurn ? "user" : "computer")} won");
                    Console.ReadLine();
                    break;
                }
                userTurn = !userTurn;
            }
        }


        static void Main2(string[] _)
        {
            var codec = new NbTools.Crypto.TripleDESStringEncryptor();
            var encd = codec.EncryptBase64("EA");
            var back = codec.DecryptBase64(encd);

            const string file = @"C:\Repo\Sync.svn\Temp\IpScan.csv";
            var coll = new CbKeyedCollection("EA collection");

            CsvParameters csvPar = new CsvParameters { FieldDelimiterN = ',', Trim = true };
            var ldr1 = new CbLoaderSaverCsv(coll);
            ldr1.AppendFile(file, csvPar);
            coll.SetKeyColumn("MAC address");

            var coll2 = new CbKeyedCollection("EA collection");
            var ldr2 = new CbLoaderSaverCsv(coll2);
            CsvParameters csvPar2 = new CsvParameters { FieldDelimiterN = '|', Trim = true };
            coll2.SetKeyColumn("MAC address");

            //const string file2 = @"C:\Repo\prg.git\CS\Aware\Client\IpScanExample.txt";
            //ldr2.AppendFile(file2, csvPar2);

            ldr2.AppendString(GetIpScanOutput(), csvPar2);

            coll2.DeleteColumn("User").DeleteColumn("MAC address");
            coll2.RenameColumn("Manufacturer", "User").RenameColumn("NetBIOS group", "MAC address").RenameColumn("NetBIOS name", "Manufacturer");
            coll2.RenameColumn("IP", "NetBIOS group").RenameColumn("Operating system", "NetBIOS name").RenameColumn("Type", "IP");
            var line = coll2.LineToCsv(1, csvPar2.FieldDelimiterN.Value);

            coll.OnValueChanged += Coll_OnValueChanged;
            coll.OnChanged += Coll_OnChanged;
            coll.SyncWith(coll2, i => coll2["Status"].GetText(i) == "alive", SyncMode.Append | SyncMode.Update);
            ldr1.SaveToFile();


            //Status | Name | Type | Operating system | IP          | NetBIOS name | NetBIOS group | Manufacturer | MAC address | User
            //               | IP  | NetBIOS name   | NetBIOS group | Manufacturer | MAC address    | User
        }

        //private static void Coll_OnChanged(CbCollection coll, CbCollection.CbCollChangedEventType eventType, int rowNum)
        private static void Coll_OnChanged(CbCollection coll, CbCollChangedEventType eventType, int rowNum)
        {
            Console.WriteLine($"{eventType}: '{coll.Name}'[{rowNum}]:  {coll["MAC address"].GetText(rowNum)}"); //{coll.Fields["MAC address"].GetText(rowNum)} - doesn't work because the row is not complete at the time of the call
        }

        private static void Coll_OnValueChanged(CbCollection coll, ICbCollectionColumn field, int ind)
        {
            switch (field)
            {
                case CbString str:
                    Console.WriteLine($"Field Update: '{coll.Name}'.{field.Name}[{ind}]: '{str.GetValue()}' => '{str.GetText(ind)}'");
                    break;
                default:
                    throw new Exception($"Unsupporte type: {field.GetType().Name}");
            }
        }


        private static string GetIpScanOutput()
        {
            //const string IpScanLocation = @"%ProgramFiles(x86)%\Advanced IP Scanner\advanced_ip_scanner_console.exe";
            const string IpScanLocation = @"C:\!Work\Advanced IP Scanner\advanced_ip_scanner_console.exe";
            var fi = new FileInfo(Environment.ExpandEnvironmentVariables(IpScanLocation));

            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = fi.FullName,
                Arguments = "/r:192.168.0.1-192.168.0.254",
                WorkingDirectory = fi.DirectoryName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };

            string stdOut, stdErr;
            using (Process pc = Process.Start(psi))
            {
                stdOut = pc.StandardOutput.ReadToEnd();
                stdErr = pc.StandardError.ReadToEnd();
                int exitCode = pc.ExitCode;
                pc.WaitForExit();
            }
            return stdOut;
        }


        static void PCastEntities(string[] _)
        {
            const string Root = @"D:\__WORK__\Files&Discs\PCast";
            const string dstFile = @"D:\__WORK__\Files&Discs\LM\Entity.csv";
            CsvParameters ParamsUni = new CsvParameters { FieldDelimiterN = '\t', EncodingN = Encoding.Unicode };

            var rep = new DfRepository();
            var ext = new HashSet<string>(NbMedia.VideoExtensions, StringComparer.OrdinalIgnoreCase);

            GetEntitiesForDir(new DirectoryInfo(Root), ext).ToCsv(dstFile, ParamsUni);
        }

        private static IEnumerable<PocEntity> GetEntitiesForDir(DirectoryInfo dir, HashSet<string> ext, PocEntity parent = null)
        {
            if (!dir.Exists)
                throw new Exception($"Directory {dir.FullName} doesn't exist");

            var root = new PocEntity(dir, parent);
            yield return root;

            //try
            //{
            foreach (var s in dir.GetDirectories().SelectMany(subDir => GetEntitiesForDir(subDir, ext, root)))
                yield return s;
            /*}
            catch (UnauthorizedAccessException) { return Enumerable.Empty<PocEntity>(); }*/

            foreach (var fi in dir.GetFiles())
            {
                /*if (!ext.Contains(fi.Extension))
                    continue;*/

                yield return new PocEntity(fi, root);
            }

            /*try { return d.GetFiles(ptrn); }
catch (UnauthorizedAccessException) { return Enumerable.Empty<FileInfo>(); }*/

            //foreach (var poc in NbDir.ListFilesRecursively(dir, ext.Select(e => $"*.{e}")).Select(fi => new PocEntity(fi, root)))
            //yield return poc;
        }

        /* static void Main(string[] args)
         {
             DfDynamicCollection col = new DfDynamicCollection("Collection1");

             model mdl = model.MergeXmls(modelFile);
             var recSet = mdl.GetRecordset(tblName);
             var sql = $"select * from {tblName}";

             DfExportHtml exp = new DfExportHtml(col, recSet);
             foreach (var frm in DfExportFormat.Permutations())
             {
                 using (StreamWriter wrtr = new StreamWriter($"{resDir}{frm}.htm"))
                 {
                     exp.ExportHtml(wrtr, frm, "Title", frm.ToString());
                 }
             }
         }*/

        /*static void Main(string[] args)
        {
            var z = RemoveReFw("re: fw: RE:FW:FW; elkrjelkrj Re: dlfk");

            string newFileName;
            using (var messageStream = File.Open("Oyster.msg", FileMode.Open, FileAccess.Read))
            {
                try
                {
                    OutlookStorage.Message message = new OutlookStorage.Message(messageStream); //TODO: derive disposable properly
                    newFileName = $"{message.Sent.ToString("yyyyMMdd HHmmss")} {message.From} '{message.Subject}".LegalizeForFilename(248) + "'.msg";

                    //var x = message.PropertyStreamDictionary();
                    //var dict = OutlookStorage.NbLoadStream(messageStream);
                }
                finally
                {
                    messageStream.Close();
                }
            }


            var fullPath = $@"C:\Temp\{newFileName}";




            //string a = "0011100111";

            Zadachki.Knuth("", "");

            //foreach (int i in Zadachki.HammingBrute().Take(1000))
            //    Console.WriteLine(i);



            return;
            }
            */

        /*for (int i = 1; i < 1000; i++)
    {
        Console.WriteLine(Zadachki.Ts17(Rnd.Next(100000), Rnd.Next(100000)));
    }
    DirectoryInfo di = new DirectoryInfo("test2");
    var multi = new MultiCsv(di, LogToConsole);
    multi.FromCsv<Parent1>();
    multi.FromCsv<Child>();

    var a = multi.DictionaryOf<Parent1>();
    var b = multi.EnumerableOf<Child>().ToList();
    var pl = multi.GetById<Parent1>(23);*/


        /*var pList = NbExt.FromCsv<Parent1>(di, LogToConsole).ToList();
        var pChild = NbExt.FromCsv<Child>(di, LogToConsole).ToList();
        var p1 = new Parent1 { ParentName = "Parent one", Id = 23 };
        var p2 = new Parent1 { ParentName = "Parent two" };
        var c = new Child { Father = p1, Mother = p2 };
        NbExt.ToEnumerable(p1, p2).ToCsv(di, LogToConsole);
        c.ToEnumerable().ToCsv(di, LogToConsole);
        Console.ReadKey();*/





        /*public static string RemoveReFw(string src)
        {
            while (src.StartsWith("RE:", StringComparison.OrdinalIgnoreCase) || src.StartsWith("FW:", StringComparison.OrdinalIgnoreCase))
            {
                src = src.Substring(3).Trim();
            }
            return src;
        }*/
    }

    /*internal class Parent1 : IdHolder
    {
        public Parent1()
        {
            MaxId = 1;
        }
        [CsvIgnore]
        override protected int MaxId { get; set; }
        public string ParentName { get; set; }
        public override string ToString()
        {
            return String.Format("#{0} {1}", Id, ParentName);
        }
    }
    internal class Child : IdHolder
    {
        [CsvIgnore]
        override protected int MaxId { get; set; }
        public Child()
        {
            MaxId = 1;
        }

#pragma warning disable 649
        public Parent1 Father;
        public Parent1 Mother;
#pragma warning restore
        public override string ToString()
        {
            return String.Format("#{0} child: {1} {2}", Id, Father, Mother);
        }
    }

    internal class Testl
    {
        public DateTime DateTime { get; set; }
        public string StringWithComma { get; set; }
#pragma warning disable 649
        public readonly TimeSpan Time;
        public readonly DateTime Date;
        public readonly string QuotesAround;
        public readonly string QuotesMiddle;
        public readonly decimal DecimalField;
        public readonly int IntField;
        public readonly string StringField;
#pragma warning restore

    }*/
}
