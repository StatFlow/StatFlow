﻿using NbTools;
using NbTools.Dgml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Exec
{
    static class ExpressionParser
    {
        public static decimal x;

        public static void T2_9()
        {
            try
            {
                x = 2;
                string expr = "10*-5 + 40*x";
                using (TextReader rdr = new StringReader(expr))
                {
                    decimal res = Sum(rdr);
                    Console.WriteLine("{0} = {1}", expr, res);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static decimal Sum(TextReader rdr)
        {
            decimal sum = 0;
            int r;
            bool first = true;
            while ((r = rdr.Peek()) != -1)
            {
                char sign = (char)r;
                if (sign == ' ')
                {
                    rdr.Read(); //Consume space
                    continue;
                }

                if (sign == '-' || sign == '+')
                    rdr.Read(); //Consume the sign
                else if (first)
                    sign = '+'; //If sing is not provided - assume plus
                else
                    throw new NbException($"Unexpected symbol: {sign}");

                decimal res = Product(rdr);

                if (sign == '+')
                    sum += res;
                else
                    sum -= res;
                first = false;
            }
            return sum;
        }

        public static decimal Product(TextReader rdr)
        {
            decimal prod = 1;
            int r;
            bool first = true;
            while ((r = rdr.Peek()) != -1)
            {
                char sign = (char)r;
                if (sign == ' ')
                {
                    rdr.Read(); //Consume space
                    continue;
                }

                if (first)
                    sign = '*';
                else
                {
                    if (sign == '/' || sign == '*')
                        rdr.Read(); //Consume the sign
                    else
                        return prod; //Unrecognized symbol - return
                }

                decimal res = Number(rdr);
                if (sign == '*')
                    prod *= res;
                else
                    prod /= res;
                first = false;
            }
            return prod;
        }


        public static decimal Number(TextReader rdr)
        {
            StringBuilder bld = new StringBuilder();
            int r;
            char ch = ' ';
            bool first = true;
            while ((r = rdr.Peek()) != -1)
            {
                ch = (char)r;
                if (first && ch == '-') //Must save to flag negative
                {
                    bld.Append(ch);
                    rdr.Read();
                    continue;
                }

                if (bld.Length == 0 && ch == 'x' || ch == 'X')
                {
                    rdr.Read();
                    return x;
                }

                if (Char.IsDigit(ch) || ch == '.')
                {
                    bld.Append(ch);
                    rdr.Read();
                }
                else break;

                first = false;
            }
            if (bld.Length == 0)
                throw new NbException($"Can't find number, char: '{ch}'");
            return Decimal.Parse(bld.ToString());
        }
    }

    static class CommentParser
    {

        /* Comment to be removed */

        const string str1 = /*comment in front of literal*/"/* comments inside literal*/    /*"/*comment behind literal*/;
        /* Multiline 
        comment */


        enum State { Text, Literal, CommentStart, Comment, CommentEnd }

        public static void T2_8()
        {
            string fileName = @"../../Zadachki.cs";
            string fileNameOut = @"../../Zadachki.out.cs";
            State state = State.Text;


            using (StreamWriter wrtr = new StreamWriter(fileNameOut))
            using (StreamReader rdr = new StreamReader(fileName))
            {
                while (!rdr.EndOfStream)
                {
                    char ch = (char)rdr.Read();
                    switch (state)
                    {
                        case State.Text:
                            switch (ch)
                            {
                                case '"':
                                    state = State.Literal;
                                    wrtr.Write(ch);
                                    break;

                                case '/':
                                    state = State.CommentStart;
                                    break;

                                default:
                                    wrtr.Write(ch); break;
                            }
                            break;

                        case State.Literal:
                            if (ch == '"')
                                state = State.Text; //Back to normal text
                            wrtr.Write(ch);
                            break;

                        case State.CommentStart:
                            if (ch == '*')
                                state = State.Comment;
                            else //Is was not a comment start
                            {
                                state = State.Text;
                                wrtr.Write('/');
                                goto case State.Text; //Treat current symbol as text
                            }
                            break;

                        case State.Comment:
                            if (ch == '*')
                                state = State.CommentEnd;
                            break;

                        case State.CommentEnd:
                            if (ch == '/')
                                state = State.Text;
                            else
                                state = State.Comment;
                            break;

                        default:
                            throw new NbException($"Unsupported state: '{state}'");
                    }
                }
            }
        }
    }

}
