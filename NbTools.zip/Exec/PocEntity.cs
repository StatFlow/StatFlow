﻿using System;
using System.IO;

using NbTools;

namespace Exec
{
    public class PocEntity
    {
        static int counter = 1;

        public PocEntity(FileInfo fi, PocEntity parentDir)
        {
            Id = counter++.ToString();
            Name = NbDir.NameOnly(fi);
            Type = "Entity";
            Url = fi.FullName;

            Size = fi.Length;
            FileCreatedTime = fi.CreationTimeUtc;
            //Extension = fi.Extension.Substring(1); //Trim front dot
            Path = parentDir.Id;
            Launcher = "Video";
        }

        public PocEntity(DirectoryInfo dir, PocEntity parentDir)
        {
            Id = counter++.ToString();
            Name = parentDir == null ? dir.FullName : dir.Name; //Save full path for the root
            Type = "Folder";
            Url = dir.FullName;

            FileCreatedTime = dir.CreationTimeUtc;
            Parents = parentDir?.Id; //Only one is allowed, no danger of overwriting the column
        }

#pragma warning disable CS0649
        public string Id;
        public string Name;
        public string Type;
        public string Parents;
        public string Icon;
        public string Launcher;
        public string CopyToClipboard;
        public string ShortCut;
        public DateTime AccessTime;
        public DateTime ArchivedDate;
        public string Url;
        public string Path;

        public long Size;
        public DateTime FileCreatedTime;
        public string Extension;
#pragma warning restore CS0649
    }
}
