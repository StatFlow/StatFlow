using System;
using System.Text;
using System.Xml;
using System.Net;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Linq;
using System.Xml.Linq;
using NbTools;

namespace Nb.Library.Web
{
    public static class WebLib
    {
        private static readonly Regex imapEmail = new Regex("<(.*)>");

        public static string ImapGetEmailN(string aFromField)
        {
            Match m = imapEmail.Match(aFromField);
            if (m.Success)
                return m.Value;
            else
                return null;
        }

        public static string Node2String(XmlNode aNode)
        {
            StringBuilder str = new StringBuilder();
            str.AppendLine(aNode.Name);
            foreach (XmlNode nd in aNode.ChildNodes)
            {
                str.Append("- ");
                str.AppendLine(nd.Name);
            }
            return str.ToString();
        }

        public static void DownloadSeries(string aFilenameFormat, string aUriFormat, int aFrom, int aTo, int aThreads = 1)
        {
            if (aFrom > aTo) //Swap if descending
            {
                int tmp = aTo;
                aTo = aFrom;
                aFrom = tmp;
            }

            ParallelOptions opt = new ParallelOptions { MaxDegreeOfParallelism = aThreads };
            Parallel.For(aFrom, aTo + 1, (i) =>
            {
                string fileName = String.Format(aFilenameFormat, i);
                string uri = String.Format(aUriFormat, i);
                TryDownload(fileName, new Uri(uri));
            });
        }

        public static bool TryDownload(string aFilename, Uri aUri)
        {
            try
            {
                FileInfo fi = new FileInfo(NbDir.LegalizeFullPath(aFilename));
                if (fi.Exists)
                    return true;

                NbExt.DirCreateRecursive(fi.Directory);
                using (WebClient webClient = new WebClient())
                {
                    webClient.DownloadFile(aUri.ToString(), aFilename);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }


        public static IEnumerable<XElement> NbFindRecursiveValue(this XElement elem, string name, string value)
        {
            return elem.Descendants(elem.Name.Namespace + name) //Using namespace of the parent
                .Where(i => value.Equals(i.Value, StringComparison.OrdinalIgnoreCase));
        }


        public static List<List<string>> NbParseHtmlTable(this XElement elem)
        {
            List<List<string>> res = new List<List<string>>(20);
            List<string> headers = null;

            foreach (var tr in elem.Descendants("tr"))
            {
                var hdr = tr.Descendants("th").Select(t => t.Value.Trim()).ToList(); //Overwrite if two or more headers
                if (hdr.Count > 0)
                    headers = hdr;

                var row = tr.Descendants("td").Select(t => t.Value.Trim()).ToList();
                if (row.Count > 0)
                    res.Add(row);
            }
            if (headers != null)
                res.Insert(0, headers); //Only one instance of headers
            return res;
        }

        public static Tuple<byte[], string> DownloadFavIcon(Uri uri)
        {
            const string rel_icon_regex = @"<\s*link\s*rel\s*=\s*""icon"".+href\s*=\s*""(.+)""\s*\/\s*>";

            byte[] res;
            using (WebClient wb = new WebClient())
            {
                //TODO support formats other than ico - png
                //<link rel="icon" type="image/png" href="https://www.raspberrypi.org/app/themes/mind-control/images/favicon.png" />

                //Attempt to load favicon.ico
                string favUrl = "http://" + uri.Host + "/" + "favicon.ico";
                try
                {
                    res = wb.DownloadData(favUrl);
                    if (res != null && res.Length > 0)
                        return Tuple.Create(res, ".ico");
                }
                catch { }; //Ignore if there was no such file - try other method

                var page = wb.DownloadString(uri);
                var match = Regex.Match(page, rel_icon_regex);
                if (!match.Success)
                    throw new Exception($"Can't find <link rel=\"icon\" on the page '{uri.ToString()}'");

                string newUrl = match.Groups[1].Value;
                res = wb.DownloadData(newUrl);
                if (res == null)
                    throw new Exception($"Can't download icon '{newUrl}'");

                Uri newUri = new Uri(newUrl);
                string fileName = newUri.Segments[newUri.Segments.Length - 1];

                return Tuple.Create(res, Path.GetExtension(fileName));
            }
        }
    }

    public class NbWebException : Exception
    {
        public NbWebException(string aFormat, params object[] args)
            : base(String.Format(aFormat, args))
        { }

    }
}
