﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Xml.Linq;

using NbTools;

namespace Nb.Library.Web
{
    public class TFileInfo
    {
        //[CsvIgnore]
        public static int currId = 1;

        public int Id { get; internal set; }
        public string FileName { get; internal set; }
        public DateTime? Date { get; internal set; }
        public bool TableOfContext { get; set; } //
        public string Url { get; internal set; }
        public string Description { get; internal set; }
    }

    public class NbLoader : IDisposable, IEnumerable<TFileInfo>
    {
        public const string csvFile = "Files.csv";
        private readonly string DownloadDir;
        private readonly string fullCsvName;
        private readonly Uri baseAddress;
        private readonly object padlock = new object();
        private readonly WebClient webClient;

        private readonly Dictionary<string, TFileInfo> FilesDict;
        private int maxCounter;

        

        public NbLoader(string aDowloadDir, string aBaseAddressN = null)
        {
            DownloadDir = aDowloadDir;
            fullCsvName = Path.Combine(DownloadDir, csvFile);

            if (!String.IsNullOrWhiteSpace(aBaseAddressN)) //Get rid of trailing /
                baseAddress = new Uri(aBaseAddressN.EndsWith(@"/") ? aBaseAddressN.Substring(0, aBaseAddressN.Length - 1) : aBaseAddressN);
            webClient = new WebClient();

            if (File.Exists(fullCsvName))
            {   //Load existing dictionary
                FilesDict = NbExt.FromCsv<TFileInfo>(fullCsvName).ToDictionary(t => t.Url);
                maxCounter = FilesDict.Values.Max(t => t.Id);
            }
            else
            {
                NbExt.DirCreateRecursive(aDowloadDir);
                FilesDict = new Dictionary<string, TFileInfo>();
                maxCounter = 0;
            }
        }

        public IEnumerable<TFileInfo> FilesNotLoaded()
        {
            return FilesDict.Values.Where(t => !File.Exists(Path.Combine(DownloadDir, t.FileName)));
        }


        public async Task<TFileInfo> LoadUrl(string aUrl, string aDescription = null, DateTime? aDate = null)
        {
            Uri uri = baseAddress != null ? new Uri(baseAddress, aUrl) : new Uri(aUrl);
            if (!aDate.HasValue)
                aDate = DateTime.Now;

            if (!FilesDict.TryGetValue(uri.AbsoluteUri, out TFileInfo fi))  //File is not in the table to download
            {
                string extenstion = new FileInfo(uri.LocalPath).Extension;  //Get extension out of the Url
                string filename = maxCounter.ToString() + extenstion;
                maxCounter++;
                fi = new TFileInfo { Id = maxCounter, FileName = filename, Url = uri.AbsoluteUri, Description = aDescription, Date = aDate, TableOfContext = false };
                lock (padlock)
                {
                    FilesDict.Add(fi.Url, fi);
                }
            }

            string fullPathFile = Path.Combine(DownloadDir, fi.FileName);
            if (!File.Exists(fullPathFile))
            {
                await webClient.DownloadFileTaskAsync(uri, fullPathFile);
            }
            return fi;
        }

        public TFileInfo GetFileInfo(string aUrl)
        {
            Uri uri = baseAddress != null ? new Uri(baseAddress, aUrl) : new Uri(aUrl);
            if (!FilesDict.TryGetValue(uri.AbsoluteUri, out TFileInfo fi))  //File is not in the table to download
                throw new NbException($"Can't find TFileInfo for '{uri.AbsoluteUri}'");

            return fi;
        }


        public bool TryGetLocalUri(string aUri, out TFileInfo resolvedUri)
        {
            Uri uri = new Uri(baseAddress, aUri); //Make full uri, if it is relavite
            resolvedUri = FilesDict.Values.FirstOrDefault(fi => uri.AbsoluteUri.Equals(fi.Url, StringComparison.InvariantCultureIgnoreCase));
            return resolvedUri != null;
        }




        [Flags]
        public enum State
        {
            InsideP = 1
        }

        /// <summary>
        /// Converts html node into the Kindle html node
        /// </summary>
        public void ProcessNode(XElement aRoot, INbTag aTag, State aState)
        {
            string name = aRoot.Name.LocalName;
            string attr;

            switch (name)
            {
                case "code":
                    aTag.TAT("font", a => a.Attrib("face", "monospace"), //Create monospace font tag appropriate for kindle
                        t => ProcessChildren(aRoot.Nodes(), t, aState));
                    break;

                case "font":
                    if (aRoot.NbTryGetAttribute("face", out attr))
                    {
                        attr = attr.ToUpperInvariant();
                        if (attr.Contains("CONSOLE") || attr.Contains("COURIER"))  //Monospace font mentioned in the source html
                        {
                            aTag.TAT("font", a => a.Attrib("face", "monospace"), //Create monospace font tag appropriate for kindle
                                t => ProcessChildren(aRoot.Nodes(), t, aState));
                            break;
                        }
                    }
                    goto case "p";

                case "a":
                    if (aRoot.NbTryGetAttribute("href", out attr))
                    {
                        aTag.TAT(name, a => a.Attrib("href", attr),
                            t => ProcessChildren(aRoot.Nodes(), t, aState)); //Node contains text itself
                        break;
                    }
                    else
                        goto case "p"; //if a tag doesn't have href - treat it as p tag

                case "p":
                    if (aRoot.Nodes().Count() == 0) //<p></p> - means new line
                    {
                        aTag.Tag("br");
                        break;
                    }

                    if ((aState & State.InsideP) == 0)
                        aTag.TT("p", SubTags: t => ProcessChildren(aRoot.Nodes(), t, aState | State.InsideP)); //Node contains text itself
                    else
                        ProcessChildren(aRoot.Nodes(), aTag, aState); //Don't create additional P tags inside
                    break;


                case "h6":
                case "h5":
                case "h4":
                case "h3":
                case "h2":
                case "h1":

                case "ul":
                case "ol":
                case "li":
                case "b":
                case "i":
                case "u":
                    //if (AnyNonEmptyXText(aRoot))
                    aTag.TT(name, t => ProcessChildren(aRoot.Nodes(), t, aState)); //Node contains text itself
                    //else
                    //    ProcessChildren(aRoot.Nodes(), aTag); //Node contains other nodes that contain text, it can be skipped
                    break;

                case "pre":
                    aTag.TT(name, t => ProcessChildren(aRoot.Nodes(), t, aState)); //Node contains text itself
                    break;


                case "div":
                case "span":
                    ProcessChildren(aRoot.Nodes(), aTag, aState);
                    break;

                case "br":
                    aTag.Tag(aRoot.Name.LocalName);
                    break;

                case "img":
                    if (aRoot.Nodes().Any())
                        throw new NbException("img tag with child nodes!");
                    if (!aRoot.NbTryGetAttribute("src", out attr))
                        break;

                    aTag.Tag("img", a => a.Attrib("src", attr));
                    break;

                default:
                    ProcessChildren(aRoot.Nodes(), aTag, aState);
                    //Console.WriteLine("Unsupported tag:", aRoot.Name.LocalName);
                    break;
            }
        }


        private void ProcessChildren(IEnumerable<XNode> aChildren, INbTag aTag, State aState)
        {
            foreach (XNode node in aChildren)
            {
                if (node is XText)
                {
                    XText nTxt = node as XText;
                    if (!String.IsNullOrEmpty(nTxt.Value))
                        aTag.Value(nTxt.Value);
                }
                else if (node is XElement)
                {
                    XElement el = node as XElement;
                    //if (!String.IsNullOrWhiteSpace(el.Value))  //Only process the nodes that have some text
                    ProcessNode(el, aTag, aState);
                }
                else if (node is XComment)
                { } //Ignore
                else if (node is XProcessingInstruction)
                { } //Ignore
                else if (node is XDocumentType)
                { }
                else
                    throw new NbException($"Unsupported node type: {node.GetType().Name}");
            }
        }











        public void Dispose()
        {
            if (FilesDict.Count > 0)
            {
                FilesDict.Values.ToCsv<TFileInfo>(fullCsvName);
            }
            webClient.Dispose();
        }

        public IEnumerator<TFileInfo> GetEnumerator()
        {
            return FilesDict.Values.GetEnumerator();
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return FilesDict.Values.GetEnumerator();
        }
    }
}
