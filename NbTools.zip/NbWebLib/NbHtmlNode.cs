using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Nb.Library;
using System.IO;
using System.Net;
using NbTools;
using System.Text.RegularExpressions;

namespace Nb.Library.Web
{
    public class NbHtmlNode
    {
        public readonly XmlElement fElement; //TODO: consider hiding it
        private readonly NbHtmlNode fParent;
        private readonly List<NbHtmlNode> fChildren;
        private readonly int fStrucStart;
        private readonly int fStrucEnd;

        private NbHtmlNode(XmlElement aElem, StringBuilder aStructureString)
            : this(aElem, null, aStructureString)
        { }

        protected NbHtmlNode(XmlElement aElem, NbHtmlNode aParent, StringBuilder aStructureString)
        {
            fElement = aElem;
            fParent = aParent;
            fChildren = new List<NbHtmlNode>(aElem.ChildNodes.Count);

            fStrucStart = aStructureString.Length;
            if (aElem.ChildNodes.Count > 0)
                aStructureString.Append("<").Append(Name).Append(">");
            else
                aStructureString.Append("<").Append(Name).Append("/>");

            foreach (XmlNode nd in aElem.ChildNodes)
            {
                if (!(nd is XmlElement el))
                    continue;
                else if (el.Name.ToLowerInvariant() == "table")
                {
                    NbHtmlTableNode tbl = new NbHtmlTableNode(el, this, aStructureString);
                    fChildren.Add(tbl);
                }
                else
                    fChildren.Add(new NbHtmlNode(el, this, aStructureString));
            }
            if (aElem.ChildNodes.Count > 0)
                aStructureString.Append("</").Append(Name).Append(">");

            fStrucEnd = aStructureString.Length;
        }

        public static NbHtmlNode LoadHtmlDocument(string aMainFile)
        {
            LoadHtmlDocument(aMainFile, out NbHtmlNode node, null);
            return node;
        }

        public static XmlDocument LoadHtmlDocument(string aMainFile, out NbHtmlNode aHtmlNode, Encoding aEncoding = null)
        {
            if (aEncoding == null)
            {
                aEncoding = Encoding.UTF8;
                try
                {
                    using (StreamReader reader = new StreamReader(aMainFile, Encoding.UTF8))
                    {
                        LoadHtmlDocument(reader, out NbHtmlNode root);
                        NbHtmlNode head = root.GetFirstRecursive(new NodeSearchCondition("meta", "content", null));
                        if (head != null)
                        {
                            string[] content = head.GetAttribSafe("content").Split(new char[] { ';', ' ' });
                            foreach (string str in content)
                            {
                                if (str.Contains("charset"))
                                {
                                    string charset = str.Substring(str.LastIndexOf('=') + 1);
                                    aEncoding = Encoding.GetEncoding(charset);
                                    break;
                                }
                            }
                        }
                    }
                }
                catch { } //Ignore error during codepage detection
            }

            using (StreamReader reader = new StreamReader(aMainFile, aEncoding))
            {
                return LoadHtmlDocument(reader, out aHtmlNode);
            }
        }

        public static XmlDocument LoadHtmlDocument(TextReader aReader, out NbHtmlNode aHtmlNode)
        {
            StringBuilder bld = new StringBuilder();
            NbHtmlNode rootNode = new NbHtmlNode(SgmlReader.GetRootNode(aReader, out XmlDocument aDoc), bld)
            {
                fStructureString = bld.ToString()
            };
            aHtmlNode = (rootNode.Name == "html") ? rootNode : null;
            while (rootNode.TryGetChild("html", out rootNode)) //If not found, rootNode is set to null
            {
                aHtmlNode = rootNode;
            }

            if (aHtmlNode == null)
                throw new NbException("<html> node is not found in document");
            else
                return aDoc;
        }

        public static NbHtmlNode LoadFromUrl(string aUrl, Encoding enc)
        {
            NbWebRequest req = new NbWebRequest(NbWebRequest.Mode.GET, aUrl);
            return req.GetRootNode(enc);
        }

        public static NbHtmlNode LoadXmlDocument(string aMainFile)
        {
            using (TextReader rdr = new StreamReader(aMainFile, Encoding.GetEncoding(1251)))
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(rdr);
                StringBuilder bld = new StringBuilder();
                return new NbHtmlNode(doc.DocumentElement, bld);
            }
        }

        public bool TrySetAttrib(string aAttributeName, string aAttributeValue)
        {
            foreach (XmlAttribute attrib in fElement.Attributes)
            {
                if (attrib.Name.Equals(aAttributeName, StringComparison.OrdinalIgnoreCase))
                {
                    attrib.Value = aAttributeValue;
                    return true;
                }
            }
            return false;
        }

        public void SetAttrib(string aAttributeName, string aAttribValue)
        {
            if (!TrySetAttrib(aAttributeName, aAttribValue))
                throw new NbWebException("Can't find attribute '{0}' in the node {1}", aAttributeName, this.ToString());
        }
        public string Name
        { get { return fElement.Name; } }

        public int Size
        { get { return fElement.InnerXml.Length; } }

        public string Text
        { get { return fElement.InnerText; } }

        public string TextNonRecursive
        {
            get
            {
                if (fTextNonRecursive == null)
                {
                    fTextNonRecursive = fElement.InnerText;
                    foreach (NbHtmlNode nd in Children) //Get rid of the texts of all underlying children.
                    {
                        if (!String.IsNullOrEmpty(nd.Text))
                            fTextNonRecursive = fTextNonRecursive.Replace(nd.Text, String.Empty);
                    }
                }
                return fTextNonRecursive;
            }
        } private string fTextNonRecursive;

        public string Html
        { get { return fElement.OuterXml; } }

        public string InnerHtml
        { get { return fElement.InnerXml; } }

        public IEnumerable<string> GetTexts
        {
            get
            {
                using (XmlReader reader = XmlReader.Create(new StringReader(Html)))
                {
                    while (reader.Read())
                    {
                        switch (reader.NodeType)
                        {
                            case XmlNodeType.Text:
                                yield return reader.Value.Trim();
                                break;
                            default:
                                break; //Don't do anything
                        }
                    }
                }
            }
        }


        public NbHtmlNode Parent
        { get { return fParent; } }

        public NbHtmlNode Root
        {
            get
            {
                if (Parent != null)
                    return Parent.Root;
                else
                    return this;
            }
        }



        public NbHtmlTableNode ParentTable
        {
            get
            {
                NbHtmlNode par = this;
                do
                {
                    par = par.Parent;
                    if (par is NbHtmlTableNode)
                        return par as NbHtmlTableNode;
                } while (par.Parent != null);
                return null;
            }
        }

        /// <summary>
        /// Returns all inner texts, splitted by tags
        /// </summary>
        public List<string> TextArray
        {
            get
            {
                if (fTextArray == null)
                {
                    fTextArray = new List<string>(10);
                    string src = fElement.OuterXml; //Outer in order to support text at the tail

                    while (src.Length > 0)
                    {
                        int ind = src.IndexOf('<');
                        if (ind > 0)
                        {
                            string text = src.Substring(0, ind).Replace("\r\n", " ").Trim();
                            if (!String.IsNullOrEmpty(text))
                                fTextArray.Add(text);

                            src = src.Substring(ind);
                        }
                        else
                        {
                            int clInd = src.IndexOf('>');
                            if (clInd <= 0)
                                throw new NbException($"Can't find closing '>' for the first tag in '{src}'");
                            else
                                src = src.Substring(clInd + 1);
                        }
                    }
                }
                return fTextArray;
            }
        } private List<string> fTextArray;


        public NbHtmlNode GetNodeCausingExceptionN()
        {
            try
            {
                string a = fElement.InnerXml;
                return null; //didn't throw an exception;
            }
            catch
            {   //Exception was thrown, check who did it
                foreach (NbHtmlNode node in Children)
                {
                    NbHtmlNode problemNode = node.GetNodeCausingExceptionN();
                    if (problemNode != null)
                        return problemNode;
                }
                return this; //There are no children or none of the children throws exception, this node must be responsible
            }
        }


        //Collection section

        public IList<NbHtmlNode> Children
        {
            get { return fChildren.AsReadOnly(); }
        }

        public NbHtmlNode GetChild(string aChildName)
        {
            if (!TryGetChild(aChildName, out NbHtmlNode nd))
                throw new NbNodeNotFoundException(this, aChildName);
            else
                return nd;
        }

        public string GetChildTextSafe(string aChildName)
        {
            if (TryGetChild(aChildName, out NbHtmlNode nd))
                return nd.Text;
            else
                return "";
        }

        public bool TryGetChild(string aChildName, out NbHtmlNode aChildNode)
        {
            aChildNode = null;
            foreach (NbHtmlNode nd in fChildren)
            {
                if (nd.Name == aChildName)
                {
                    aChildNode = nd;
                    return true;
                }
            }
            return false;
        }

        public bool TryGetAttrib(string aAttributeName, out string aAttributeValue)
        {
            aAttributeValue = null;
            foreach (XmlAttribute attrib in fElement.Attributes)
            {
                if (attrib.Name == aAttributeName)
                {
                    aAttributeValue = attrib.Value;
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Returns an empty string if attrib was not found
        /// </summary>
        /// <param name="aAttributeName"></param>
        /// <returns></returns>
        public string GetAttribSafe(string aAttributeName)
        {
            TryGetAttrib(aAttributeName, out string val);
            return val;
        }

        public string this[string attrName] => GetAttribSafe(attrName);

        /// <summary>
        /// Throws exception if attrib was not found
        /// </summary>
        /// <param name="aAttributeName"></param>
        /// <returns></returns>
        public string GetAttrib(string aAttributeName)
        {
            if (!TryGetAttrib(aAttributeName, out string val))
                throw new NbWebException("Can't find attribute '{0}' in the node {1}", aAttributeName, this.ToString());
            else
                return val;
        }

        public NbHtmlNode GetBiggest(string aChildName)
        {
            NbHtmlNode found = null;
            foreach (NbHtmlNode nd in fChildren)
            {
                if (nd.Name == aChildName)
                {
                    if (found == null)
                        found = nd;
                    else if (found.Size < nd.Size)
                        found = nd;
                }
            }
            if (found == null)
                throw new NbNodeNotFoundException(this, aChildName);
            else
                return found;
        }

        public NbHtmlNode GetFirst(string aChildName)
        {
            NbHtmlNode found = null;
            foreach (NbHtmlNode nd in fChildren)
            {
                if (nd.Name == aChildName)
                {
                    found = nd;
                    break;
                }
            }
            if (found == null)
                throw new NbNodeNotFoundException(this, aChildName);
            else
                return found;
        }

        public NbHtmlNode GetFirstSafe(string aChildName, string aAttribute, string aAttribValue)
        {
            if (String.IsNullOrEmpty(aChildName) && String.IsNullOrEmpty(aAttribute))
                throw new NbException("Neither childname nor attribute is specified in GetFirstSafe");
            if (!String.IsNullOrEmpty(aAttribute) && String.IsNullOrEmpty(aAttribValue))
                throw new NbException("Attribute specified, but AttribValue is null in GetFirstSafe");

            NbHtmlNode found = null;
            foreach (NbHtmlNode nd in fChildren)
            {
                if (!String.IsNullOrEmpty(aChildName))
                { //tag name is important and equals
                    if (nd.Name == aChildName)
                    {
                        if (!String.IsNullOrEmpty(aAttribute))
                        {
                            string attVal = nd.GetAttribSafe(aAttribute);
                            if (attVal == aAttribValue)
                            {
                                found = nd;
                                break;
                            }
                        }
                        else
                        {
                            found = nd;
                            break;
                        }
                    }
                }
                else if (!String.IsNullOrEmpty(aAttribute))
                { //tag name is not important

                    string attVal = nd.GetAttribSafe(aAttribute);
                    if (attVal == aAttribValue)
                    {
                        found = nd;
                        break;
                    }
                }
                else
                {
                    found = nd;
                    break;
                }
            }
            if (found == null)
                throw new NbNodeNotFoundException(this, aChildName);
            else
                return found;
        }

        public NbHtmlNode GetLast(string aChildName)
        {
            NbHtmlNode found = null;
            for (int i = fChildren.Count - 1; i >= 0; --i) //Going backwards
            {
                NbHtmlNode nd = fChildren[i];
                if (nd.Name == aChildName)
                {
                    found = nd;
                    break;
                }
            }
            if (found == null)
                throw new NbNodeNotFoundException(this, aChildName);
            else
                return found;
        }

        public IEnumerable<NbHtmlNode> GetAll(string aChildName)
        {
            foreach (NbHtmlNode nd in fChildren)
            {
                if (nd.Name == aChildName)
                    yield return nd;
            }
        }

        public NbHtmlNode GetFirstRecursive(NodeSearchCondition aCondition)
        {
            foreach (NbHtmlNode nd in GetAllRecursive(aCondition))
            {
                return nd;
            }
            return null;
        }

        public IEnumerable<NbHtmlNode> GetFirstLevelSkipDivsRecursive()
        {
            foreach (NbHtmlNode nd in fChildren)
            {
                if (nd.Name.Equals("div", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (NbHtmlNode nnd in nd.GetFirstLevelSkipDivsRecursive())
                        yield return nnd;
                }
                else //Do not yield div itself
                    yield return nd;
            }
        }


        public IEnumerable<NbHtmlNode> GetAllRecursive()
        {
            foreach (NbHtmlNode nd in fChildren)
            {
                foreach (NbHtmlNode nnd in nd.GetAllRecursive())
                    yield return nnd;

                yield return nd;
            }
        }

        public IEnumerable<NbHtmlNode> GetAllRecursive(string aChildName)
        {
            foreach (NbHtmlNode nd in fChildren)
            {
                foreach (NbHtmlNode nnd in nd.GetAllRecursive(aChildName))
                    yield return nnd;

                if (nd.Name == aChildName)
                    yield return nd;
            }
        }

        public IEnumerable<NbHtmlNode> GetAllRecursive(NodeSearchCondition aCondition)
        {
            foreach (NbHtmlNode nd in fChildren)
            {
                foreach (NbHtmlNode nnd in nd.GetAllRecursive(aCondition))
                    yield return nnd;

                if (aCondition.Satisfies(nd))
                    yield return nd;
            }
        }


        public NbHtmlNode GetChildRecursiveOneOnly(string aChildName)
        {
            NbHtmlNode res = null;
            foreach (NbHtmlNode nd in GetAllRecursive(aChildName))
            {
                if (res == null)
                    res = nd;
                else
                    throw new NbWebException("Node '{0}' contains two recursive children '{1}': '{2}' and '{3}'",
                        this.ToString(), aChildName, res.ToString(), nd.ToString());
            }

            if (res == null)
                throw new NbWebException("Coudn't find any '{0}' children in the node '{1}'",
                    aChildName, this.ToString());
            return res;
        }

        public void GetExactNumberOfChildren(string aChildName, NbHtmlNode[] aArray)
        {
            if (aArray == null || aArray.Length == 0)
                throw new ArgumentNullException("The array should be created and non-empty");

            int cnt = 0;
            foreach (NbHtmlNode node in this.Children)
            {
                if (node.Name == aChildName)
                {
                    if (cnt >= aArray.Length)
                        throw new NbWebException("There are more than {0} '{1}' children in the node {2}", aArray.Length, aChildName, Name);

                    aArray[cnt++] = node;
                }
            }

            if (cnt < aArray.Length)
                throw new NbWebException("There are {0} '{1}' children in the node {2}, but {3} were requested.", cnt, aChildName, Name, aArray.Length);
        }


        public override string ToString()
        {
            string str = String.Format("{0} ({1},{2})", Name, fChildren.Count, Size);

            if (!String.IsNullOrEmpty(Text) && Text.Trim().Length < 128)
                str += " - " + Text.Trim();

            return str;
        }

        public string StructureString
        {
            get
            {
                if (fStructureString == null)
                    fStructureString = Root.fStructureString.Substring(fStrucStart, fStrucEnd - fStrucStart);
                return fStructureString;
            }

        } private String fStructureString;

    }

    public class NbHtmlTableNode : NbHtmlNode
    {
        public readonly NbHtmlNode Node;
        public readonly int RowCount;
        public readonly int ColumnsCountFirstRow;


        public NbHtmlTableNode(XmlElement aElem, NbHtmlNode aParent, StringBuilder aStructureString)
            : base(aElem, aParent, aStructureString)
        {
            if (this.Children != null)
            {
                RowCount = this.Children.Count;
                if (RowCount > 0)
                    ColumnsCountFirstRow = Children[0].Children.Count;
            }

        }

        public IEnumerable<NbHtmlNode> Cells
        {
            get
            {
                foreach (NbHtmlNode tr in Children)
                {
                    if (tr.Name != "tr")
                        throw new Exception("Non-tr child in the table");

                    foreach (NbHtmlNode td in tr.Children)
                    {
                        if (td.Name != "td")
                            throw new Exception("Non-td child in the tr");
                        yield return td;
                    }
                }
            }
        }

        public void DumpCellsToFiles(string aPrefix, string aExtension)
        {
            int counter = 0;
            foreach (NbHtmlNode node in Cells)
            {
                FileInfo fi = new FileInfo(String.Format("{0}{1:d4}.{2}", aPrefix, ++counter, aExtension));
                NbExt.DirCreateRecursive(fi.Directory);
                using (StreamWriter wrtr = new StreamWriter(fi.FullName))
                {
                    string text = node.Html.Replace(">", ">\r\n");
                    wrtr.Write(text);
                }
            }

        }
    }

    public class NodeSearchCondition
    {
        public readonly string Name;
        public readonly string Attribute;
        public readonly Regex AttributeRegex;

        public NodeSearchCondition(string aName, string aAttribute, string aAttributeRegex)
        {
            Name = aName;
            Attribute = aAttribute;
            if (String.IsNullOrEmpty(aAttributeRegex))
                AttributeRegex = null;
            else
                AttributeRegex = new Regex(aAttributeRegex);
        }

        public bool Satisfies(NbHtmlNode aNode)
        {
            return SatisfiesByName(aNode) && SatisfiesByAttribute(aNode);
        }

        public bool SatisfiesByName(NbHtmlNode aNode)
        {
            return (String.IsNullOrEmpty(Name) //Name not specified - any name
                || Name == aNode.Name); //Name is specified and equal

        }

        public bool SatisfiesByAttribute(NbHtmlNode aNode)
        {
            if (String.IsNullOrEmpty(Attribute)) //Attribute is not specified 
            {
                if (AttributeRegex == null)
                    return true; //Neither Attribute, nor value is specified - return all 
                else
                { //Value is specified - return by text
                    Match match = AttributeRegex.Match(aNode.Text);
                    if (!match.Success) //The text doesn't match - doesn't satisfy
                        return false;

                    match = AttributeRegex.Match(aNode.TextNonRecursive); //Match with pure text now
                    return match.Success; //Satisfy is matches
                }
            }

            string attVal = aNode.GetAttribSafe(Attribute);
            if (!String.IsNullOrEmpty(attVal)) //Such attribute exists
            {
                if (AttributeRegex == null)
                    return true; //Do not look at the value, the presence of attribute is enough
                else
                { //Value Regex is provided do the matching
                    Match match = AttributeRegex.Match(attVal);
                    if (match.Success)
                        return true;
                }
            }

            return false;
        }
    }


    public class NbNodeNotFoundException : Exception
    {
        public NbNodeNotFoundException(NbHtmlNode aCurrentNode, string aDesiredNode)
            : base(String.Format("Node '{0}' is not found in the node '{1}'", aDesiredNode, aCurrentNode.ToString()))
        { }

    }

}
