﻿using Nb.Library.Web;
using NbTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace Nb.Library.Linq
{
    public static class LinqToHtml
    {
        public enum ReadScript { Keep = 0, Remove }

        public static XDocument LoadUrl(string aUrl, ReadScript aReadMode = ReadScript.Keep)
        {
            using (WebClient wc = new WebClient())
                return LoadString(wc.DownloadString(aUrl), aReadMode);
        }

        public static XDocument LoadFile(string aFilename, ReadScript aReadMode = ReadScript.Keep)
        {
            if (!File.Exists(aFilename))
                throw new Exception($"File '{aFilename}' doesn't exist");
            else using (StreamReader rdr = new StreamReader(aFilename))
                    return LoadString(rdr.ReadToEnd(), aReadMode);
        }

        public static XDocument LoadUrlSec(string aUrl, out HttpWebResponse aResponce, ReadScript aReadMode = ReadScript.Keep)
        {
            NbWebRequest nbLoginReq = new NbWebRequest(NbWebRequest.Mode.GET, aUrl, null);

            aResponce = (HttpWebResponse)nbLoginReq.GetResponse();
            Stream respStream = NbWebRequest.GetStreamForResponse(aResponce);

            using (StreamReader rdr1 = new StreamReader(respStream, Encoding.GetEncoding(1251))) //TODO: How to define encoding from the response?
            {
                return LoadString(rdr1.ReadToEnd(), aReadMode);
            }
        }

        private const string scriptRemovePattern = (@"<script(?:(?!<\/script>).).*?<\/script>");

        public static XDocument LoadString(string aString, ReadScript aReadMode = ReadScript.Keep)
        {
            if (aReadMode == ReadScript.Remove)
                aString = Regex.Replace(aString, scriptRemovePattern, String.Empty, RegexOptions.Singleline).Trim(); //Allows multiline scripts removal

            if (!aString.StartsWith("<html>", StringComparison.OrdinalIgnoreCase))
                aString = String.Format("<html>{0}</html>", aString);

            using (XmlReader rdr = SgmlReader(new StringReader(aString)))
                return XDocument.Load(rdr);
        }

        public static IEnumerable<string> GetScripts(string aHmlt)
        {
            Regex reg = new Regex(scriptRemovePattern, RegexOptions.Singleline);
            foreach (Match mat in reg.Matches(aHmlt))
            {
                yield return mat.Value;
            }
        }



        private static XmlReader SgmlReader(TextReader aTextReader)
        {
            SgmlReader sgmlReader = new SgmlReader
            {
                DocType = "HTML",
                WhitespaceHandling = WhitespaceHandling.All,
                CaseFolding = CaseFolding.ToLower,
                InputStream = aTextReader
            };
            return sgmlReader;
        }


        public static IEnumerable<XElement> Flatten(this XElement aElem)
        {
            yield return aElem;

            foreach (var el in aElem.Elements().SelectMany(e => e.Flatten()))
                yield return el;
        }

        //TODO: search recursive by name, atribute and its value
        public static IEnumerable<XElement> SearchRecursive(this XElement aElem, XName aName)
        {
            if (aElem.Name.Equals(aName))
                yield return aElem;

            foreach (var el in aElem.Elements())
                foreach (var a in SearchRecursive(el, aName)) //TODO: select many?
                    yield return a;
        }



        public static string Legalize(this string aFileName)
        {
            // / ? < > \ : * | ”
            aFileName = Regex.Replace(aFileName, "\"", "''").Replace("/", "⁄").Replace(":", ";");
            aFileName = Regex.Replace(aFileName, @"/|\?|<|>|\\|:|\*|\|", "_");
            return aFileName;
        }

        public static XElement NbElement(this XElement aEl, string aElementName)
        {
            return NbElement(aEl.Elements(), aElementName);
        }

        public static XElement NbElement(this IEnumerable<XElement> aEl, string aElementName)
        {
            var res = NbElements(aEl, aElementName).SingleOrDefault();
            if (res == null)
                throw new Exception($"Can't find element '{aElementName}' within {aEl}");
            else
                return res;
        }

        public static IEnumerable<XElement> NbElements(this XElement aEl, string aElementName)
        {
            return NbElements(aEl.Elements(), aElementName);
        }

        public static IEnumerable<XElement> NbElements(this IEnumerable<XElement> aEl, string aElementName)
        {
            return aEl.Where(e => e.Name.LocalName.Equals(aElementName, StringComparison.OrdinalIgnoreCase));
        }

        public static string NbElementAttribute(this IEnumerable<XElement> aEl, string aElementName, string aAttributeName)
        {
            XElement el = NbElement(aEl, aElementName);

            var res = el.Attributes().Where(a => a.Name.LocalName.Equals(aAttributeName, StringComparison.OrdinalIgnoreCase)).SingleOrDefault();
            if (res == null)
                throw new Exception($"Can't find attribute '{aAttributeName}' within element '{aElementName}' in {aEl}");
            else
                return res.Value;
        }

        public static IEnumerable<XElement> WhereElement(this XElement aColl, string aElement) => WhereElement(aColl.Elements(), aElement);
        public static IEnumerable<XElement> WhereElement(this IEnumerable<XElement> aColl, string aElement) => aColl.Where(el => el.Name.LocalName.EqIC(aElement));

        public static IEnumerable<XElement> WhereElementAndAttribute(this XElement aColl, string aElement, string aAttribute, string aAttributeValue)
            => WhereElementAndAttribute(aColl.Elements(), aElement, aAttribute, aAttributeValue);

        public static IEnumerable<XElement> WhereElementAndAttribute(this IEnumerable<XElement> aColl, string aElement, string aAttribute, string aAttributeValue)
        {
            foreach (var el in aColl.Where(el => el.Name.LocalName.EqIC(aElement)))
            {
                if (el.Attributes(aAttribute).Where(a => a.Value.EqIC(aAttributeValue)).Any())
                    yield return el;
            }
        }


        public static IEnumerable<Tuple<XElement, string>> WhereElementAndAttributeRegex1(this XElement aColl, string aElement, string aAttribute, string aRegex)
        {
            return WhereAttributeRegex1(aColl.Elements(), aAttribute, aRegex);
        }

        public static IEnumerable<Tuple<XElement, string>> WhereElementAndAttributeRegex1(this IEnumerable<XElement> aColl, string aElement, string aAttribute, string aRegex)
        {
            Regex rx = new Regex(aRegex);
            foreach (var el in aColl.Where(el => el.Name.LocalName.Equals(aElement, StringComparison.OrdinalIgnoreCase)))
            {
                XAttribute att = el.Attributes().Where(a => a.Name.LocalName.Equals(aAttribute, StringComparison.OrdinalIgnoreCase)).SingleOrDefault();
                if (att == null)
                    continue;

                Match m = rx.Match(att.Value);
                if (m.Success)
                    yield return Tuple.Create(el, m.Groups[1].Value);
            }
        }



        public static IEnumerable<Tuple<XElement, string>> WhereAttributeRegex1(this XElement aColl, string aAttribute, string aRegex)
        {
            return WhereAttributeRegex1(aColl.Elements(), aAttribute, aRegex);
        }

        public static IEnumerable<Tuple<XElement, string>> WhereAttributeRegex1(this IEnumerable<XElement> aColl, string aAttribute, string aRegex)
        {
            Regex rx = new Regex(aRegex);
            foreach (var el in aColl)
            {
                XAttribute att = el.Attributes().Where(a => a.Name.LocalName.Equals(aAttribute, StringComparison.OrdinalIgnoreCase)).SingleOrDefault();
                if (att == null)
                    continue;

                Match m = rx.Match(att.Value);
                if (m.Success)
                    yield return Tuple.Create(el, m.Groups[1].Value);
            }
        }


        public static IEnumerable<XElement> WhereAttribute(this IEnumerable<XElement> aColl, XName aAttribute, Func<XAttribute, bool> aPredicate)
        {
            foreach (var el in aColl)
            {
                if (el.Attributes(aAttribute).Where(aPredicate).Any())
                    yield return el;
            }
        }

    }


    public class NbWebClient : IDisposable
    {
        public NbWebClient()
        {
        }

        public IWebProxy Proxy;


        public CookieContainer CookieContainer
        {
            get
            {
                if (fCookieContainer == null)
                    fCookieContainer = new CookieContainer();
                return fCookieContainer;
            }
        }
        private CookieContainer fCookieContainer;

        public string Referer;
        public string Host;
        public string CookieDomain;
        public string CookiePath = "/";

        public void AddCookie(string aName, string aValue)
        {
            CookieContainer.Add(new Cookie(aName, aValue, CookiePath, CookieDomain ?? String.Empty));
        }

        public NbWebResponse LoadUrlSec(string aUrl, LinqToHtml.ReadScript aReadScript = LinqToHtml.ReadScript.Keep, string aData = null)
        {
            NbWebRequest nbLoginReq = new NbWebRequest(String.IsNullOrEmpty(aData) ? NbWebRequest.Mode.GET : NbWebRequest.Mode.POST, aUrl, null);
            if (Proxy != null)
                nbLoginReq.fHttpWebRequest.Proxy = Proxy;
            if (CookieContainer != null)
                nbLoginReq.fHttpWebRequest.CookieContainer = this.CookieContainer;
            if (Referer != null)
                nbLoginReq.fHttpWebRequest.Referer = Referer;


            if (!String.IsNullOrEmpty(aData))
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(aData);
                nbLoginReq.fHttpWebRequest.ContentLength = byteArray.Length;
                using (Stream dataStream = nbLoginReq.fHttpWebRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);
                }
            }


            NbWebResponse nbResp = new NbWebResponse(nbLoginReq.GetResponse(), aReadScript);
            SetCookies(nbResp.HttpWebResponse.Cookies);
            return nbResp;
        }

        public HttpWebResponse SaveFile(Uri aUrl, string aFileName, string aData = null, LinqToHtml.ReadScript aReadScript = LinqToHtml.ReadScript.Keep)
        {
            NbWebRequest nbLoginReq = new NbWebRequest(String.IsNullOrEmpty(aData) ? NbWebRequest.Mode.GET : NbWebRequest.Mode.POST, aUrl, null);
            nbLoginReq.fHttpWebRequest.Host = aUrl.Host;

            if (Proxy != null)
                nbLoginReq.fHttpWebRequest.Proxy = Proxy;
            if (CookieContainer != null)
                nbLoginReq.fHttpWebRequest.CookieContainer = this.CookieContainer;
            if (Referer != null)
                nbLoginReq.fHttpWebRequest.Referer = Referer;

            if (!String.IsNullOrEmpty(aData))
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(aData);
                nbLoginReq.fHttpWebRequest.ContentLength = byteArray.Length;
                using (Stream dataStream = nbLoginReq.fHttpWebRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);
                }
            }

            HttpWebResponse aResponce = (HttpWebResponse)nbLoginReq.GetResponse();
            SetCookies(aResponce.Cookies);
            Stream respStream = NbWebRequest.GetStreamForResponse(aResponce);
            NbExt.DirCreateRecursive(new FileInfo(aFileName).Directory);

            using (FileStream fs = new FileStream(aFileName, FileMode.OpenOrCreate, FileAccess.Write))
            {
                byte[] buffer = new byte[2048]; //TODO: take in out
                int bytesRead;
                while ((bytesRead = respStream.Read(buffer, 0, buffer.Length)) > 0)
                    fs.Write(buffer, 0, bytesRead);
            }

            return aResponce;
        }

        public void AddFiddlerCookies(string aFiddlerCookies)
        {
            foreach (var pair in aFiddlerCookies.Split(';').Select(c => Tuple.Create(c.Substring(0, c.IndexOf('=')), c.Substring(c.IndexOf('=') + 1))))
                AddCookie(pair.Item1.Trim(), pair.Item2.Trim());
        }

        public void SetCookies(CookieCollection cookieCollection)
        {
            string dom = CookieDomain.StartsWith("http") ? CookieDomain : "http://" + CookieDomain;
            CookieContainer.Add(new Uri(dom), cookieCollection);
        }

        public void Dispose()
        {
        }
    }
}
