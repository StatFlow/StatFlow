﻿using Nb.Library.Linq;
using NbTools.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace Nb.Library.Web
{
    public class CbLoaderHtmlTable
    {
        public readonly CbCollection Collection;
        //private readonly string LastUsedFilename;

        public CbLoaderHtmlTable(CbCollection coll)
        {
            Collection = coll;
        }

        public void AppendTable(XElement el)
        {
            if (el.Name.LocalName != "table")
                throw new Exception("Elelment name is not a table");

            bool first = true;
            var columns = new List<ICbCollectionColumn>();
            foreach (var row in el.Flatten().WhereElement("tr"))
            {

                if (first)
                {
                    int cnt = 0;
                    foreach (var td in row.Elements())
                    {
                        cnt++;
                        string name = td.Value.Trim();
                        if (String.IsNullOrWhiteSpace(name))
                            name = $"Noname{cnt}";

                        columns.Add(Collection.GetOrCreateColumn(name));
                    }

                    first = false;
                    continue;
                }

                Collection.Reset();
                foreach (var pair in row.Elements().Zip(columns, (e, colm) => (e, colm)))
                {
                    var txt = pair.e.Value.Trim();
                    pair.colm.SetTextToBuffer(txt);

                }
                Collection.Append();
            }
        }
    }
}
