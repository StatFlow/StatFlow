using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Collections;
using System.IO;
using System.IO.Compression;
using System.Diagnostics;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using Nb.Library.Linq;
using NbTools;

namespace Nb.Library.Web
{
    public class NbWebRequest
    {
        public readonly HttpWebRequest fHttpWebRequest;

        public enum Mode { GET, POST };

        public NbWebRequest(Mode aMode, string aAddress)
            : this(aMode, new Uri(aAddress), String.Empty)
        { }

        public NbWebRequest(Mode aMode, Uri aAddress)
            : this(aMode, aAddress, String.Empty)
        { }

        public NbWebRequest(Mode aMode, string aAddress, string aData)
            : this(aMode, new Uri(aAddress), aData)
        { }

        public NbWebRequest(Mode aMode, Uri aAddress, string aData)
        {
            fHttpWebRequest = (HttpWebRequest)WebRequest.Create(aAddress);

            switch (aMode)
            {
                case Mode.GET: fHttpWebRequest.Method = "GET"; break;
                case Mode.POST: fHttpWebRequest.Method = "POST"; break;
                default: throw new Exception($"Request mode '{aMode.ToString()}' is not supported");
            }

            // Define properties of the web request
            fHttpWebRequest.Accept = "image/gif, image/jpeg, image/pjpeg, image/pjpeg, application/x-shockwave-flash, application/xaml+xml, application/vnd.ms-xpsdocument, application/x-ms-xbap, application/x-ms-application, application/x-silverlight, application/vnd.ms-excel, application/msword, */*";
            fHttpWebRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip, deflate");
            fHttpWebRequest.Headers.Add(HttpRequestHeader.AcceptLanguage, "en-gb,en");
            fHttpWebRequest.ContentType = "application/x-www-form-urlencoded";
            fHttpWebRequest.KeepAlive = true;
            fHttpWebRequest.UserAgent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.2.12) Gecko/20101026 Firefox/3.6.12 ( .NET CLR 3.5.30729)";
            fHttpWebRequest.SendChunked = false;

            NbCookieContainer.HandleCookiesWithDots();
            fHttpWebRequest.CookieContainer = NbCookieContainer.Instanse;

            if (!String.IsNullOrEmpty(aData))
            {
                byte[] byteArray = Encoding.ASCII.GetBytes(aData);
                fHttpWebRequest.ContentLength = byteArray.Length;
                using (Stream dataStream = fHttpWebRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);
                }
            }
        }

        /// <summary>
        /// Timeout in seconds 
        /// </summary>
        public int Timeout
        {
            get { return fHttpWebRequest.Timeout / 1000; }
            set { fHttpWebRequest.Timeout = value * 1000; }
        }

        public static string TryReplicateSiteStructure(Uri uri, DirectoryInfo rootDir)
        {
            var fileName = Path.Combine(rootDir.FullName, uri.Host) + uri.LocalPath.Replace('/', '\\');
            var subDir = Path.GetDirectoryName(fileName);
            NbExt.DirCreateRecursive(subDir);

            if (TryLoadFileIfDoesntExist(uri, fileName))
                return fileName;
            else
                return null;
        }


        public static bool TryLoadFileIfDoesntExist(Uri uri, string aFileName)
        {
            FileInfo fi = new FileInfo(aFileName);
            if (fi.Exists)
                return true;

            NbExt.DirCreateRecursive(fi.Directory);
            NbWebRequest req = new NbWebRequest(Mode.GET, uri);
            return req.SaveResponseIntoFileSafe(aFileName, out HttpWebResponse resp);
        }

        public void RequestCookieOnly()
        {
            HttpWebResponse pWebResponse = (HttpWebResponse)fHttpWebRequest.GetResponse();
            pWebResponse.Close();
        }

        public HttpWebResponse SaveResponseIntoFileL(string aFileName)
        {
            Console.WriteLine("Loading " + aFileName);
            //Debug.Write("Sending request...");
            HttpWebResponse response = (HttpWebResponse)fHttpWebRequest.GetResponse();
            //Debug.WriteLine("done!");

            using (StreamWriter wrtr = new StreamWriter(aFileName, false, Encoding.GetEncoding(1251))) //TODO: decide automatically on http header.
            {
                Stream respStream = GetStreamForResponse(response);

                using (StreamReader rdr = new StreamReader(respStream, Encoding.GetEncoding(1251))) //TODO: How to define encoding from the response?
                {
                    string ss = rdr.ReadToEnd();
                    wrtr.Write(ss);
                }
            }
            return response;
        }

        public NbHtmlNode GetRootNode(Encoding enc)
        {
            HttpWebResponse response = (HttpWebResponse)fHttpWebRequest.GetResponse();
            Stream respStream = GetStreamForResponse(response);

            using (StreamReader rdr = new StreamReader(respStream, enc)) //TODO: How to define encoding from the response?
            {
                XmlDocument doc = NbHtmlNode.LoadHtmlDocument(rdr, out NbHtmlNode aHtmlNode);
                return aHtmlNode;
            }
        }

        public bool SaveResponseIntoFileSafe(string aFileName, out HttpWebResponse response)
        {
            // Create a web response
            try
            {
                response = SaveResponseIntoFileL(aFileName);
                return true;
            }
            catch (WebException ex)
            {
                if (ex.Response is HttpWebResponse)
                    response = ex.Response as HttpWebResponse;
                else
                    response = null;
                return false;
            }
        }

        public static Stream GetStreamForResponse(HttpWebResponse aResp)
        {
            Stream stream;
            switch (aResp.ContentEncoding.ToUpperInvariant())
            {
                case "GZIP":
                    stream = new GZipStream(aResp.GetResponseStream(), CompressionMode.Decompress);
                    break;
                case "DEFLATE":
                    stream = new DeflateStream(aResp.GetResponseStream(), CompressionMode.Decompress);
                    break;

                default:
                    stream = aResp.GetResponseStream();
                    stream.ReadTimeout = 5 * 1000; //Value in milliseconds
                    break;
            }
            return stream;
        }


        internal HttpWebResponse GetResponse()
        {
            return (HttpWebResponse)fHttpWebRequest.GetResponse();
        }
    }

    public class NbWebResponse
    {
        public readonly XDocument Document;
        public readonly HttpWebResponse HttpWebResponse;
        public readonly Dictionary<string, string> Headers;

        public NbWebResponse(HttpWebResponse aHttpResponse, LinqToHtml.ReadScript aReadScript = LinqToHtml.ReadScript.Keep)
        {
            HttpWebResponse = aHttpResponse;
            Headers = aHttpResponse.Headers.AllKeys.ToDictionary(s => s, s => String.Join("�", aHttpResponse.Headers.GetValues(s)));

            Stream respStream = NbWebRequest.GetStreamForResponse(aHttpResponse);
            using (StreamReader rdr1 = new StreamReader(respStream, Encoding.GetEncoding(1251))) //TODO: How to define encoding from the response?
            {
                Document = LinqToHtml.LoadString(rdr1.ReadToEnd(), aReadScript);
            }
        }
    }

    public static class NbCookieContainer
    {
        public static CookieContainer Instanse
        {
            get
            {
                if (fCookieContainer == null)
                    fCookieContainer = new CookieContainer();
                return fCookieContainer;
            }
        } private static CookieContainer fCookieContainer;

        public static List<Cookie> GetAllCookies(CookieContainer cc)
        {
            List<Cookie> lstCookies = new List<Cookie>();

            Hashtable table = (Hashtable)cc.GetType().InvokeMember("m_domainTable", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.GetField | System.Reflection.BindingFlags.Instance, null, cc, new object[] { });

            foreach (object pathList in table.Values)
            {
                SortedList lstCookieCol = (SortedList)pathList.GetType().InvokeMember("m_list", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.GetField | System.Reflection.BindingFlags.Instance, null, pathList, new object[] { });
                foreach (CookieCollection colCookies in lstCookieCol.Values)
                    foreach (Cookie c in colCookies) lstCookies.Add(c);
            }

            return lstCookies;
        }

        public static List<Cookie> Collection
        {
            get { return GetAllCookies(Instanse); }
        }

        public static string Readable
        {
            get
            {
                StringBuilder sb = new StringBuilder();
                List<Cookie> lstCookies = GetAllCookies(Instanse);
                sb.AppendLine("=========================================================== ");
                sb.AppendLine(lstCookies.Count + " cookies found.");
                sb.AppendLine("=========================================================== ");
                int cpt = 1;
                foreach (Cookie c in lstCookies)
                    sb.AppendLine("#" + cpt++ + "> Name: " + c.Name + "\tValue: " + c.Value + "\tDomain: " + c.Domain + "\tPath: " + c.Path + "\tExp: " + c.Expires.ToString());

                return sb.ToString();
            }
        }

        public static void HandleCookiesWithDots()
        {
            List<Cookie> cookiesList = GetAllCookies(Instanse);
            foreach (Cookie ck in cookiesList)
            {
                if (ck.Domain.StartsWith("."))
                {
                    ck.Domain = ck.Domain.Substring(1);
                    Instanse.Add(ck);
                }
            }
        }


        public static void Add(Cookie aCookie)
        {
            Instanse.Add(aCookie);
        }
    }
}


//Hotmail login

/*CookieContainer cookies = new CookieContainer();
string strUrl = loginPage;
HttpStatusCode status;
int hops = 1;
bool bFoundDestination;
do
{
HttpWebRequest webReq = WebRequest.Create(strUrl) as HttpWebRequest;
webReq.CookieContainer = cookies;
webReq.AllowAutoRedirect = false;
Debug.WriteLine("Hope[" + hops.ToString() + "] - " + strUrl);
Console.WriteLine("Hope[{0}] - {1}", hops++, strUrl);
HttpWebResponse webResp = webReq.GetResponse() as HttpWebResponse;
webResp.Close();
if (webResp.StatusCode == HttpStatusCode.Found)
{
    strUrl = webResp.Headers["Location"] as String;
}
else
{
    status = webResp.StatusCode;
    bFoundDestination = (webResp.StatusCode == HttpStatusCode.OK);
    break;
}
} while (true);*/