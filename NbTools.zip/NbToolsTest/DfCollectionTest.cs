﻿using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbTools;
using System.IO;
using NbTools.Collections;
using System.Diagnostics;
using NbCollV1;

namespace NbToolsTest
{
    [TestClass]
    public class DfCollectionTest
    {
        public enum EntType { Entity, Folder }

        public class DfEntitiesColletion : DfCollection
        {
            public readonly DfColumnStringIndex Id;
            public readonly DfColumnString Name;
            public readonly DfColumnEnum<EntType> Type;
            public readonly DfColumnReference Parents;
            public readonly DfColumnString Icon;
            public readonly DfColumnString Launcher;
            public readonly DfColumnString CopyToClipboard;
            public readonly DfColumnString ShortCut;
            public readonly DfColumnString AccessTime;
            public readonly DfColumnString Url;

            public readonly DfColumnDateTime ArchivedDate;
            public readonly DfColumnReference Path;
            public readonly DfColumnInt32 QuickToolbar;

            //Post resolution
            public DfColumnBackReference Children;

            public DfEntitiesColletion(string name) : base(name)
            {
                Id = new DfColumnStringIndex("Id", this, false);
                Name = new DfColumnString("Name", this, false);
                Type = new DfColumnEnum<EntType>("Type", this, false);

                Parents = new DfColumnReference("Parents", Id, this);

                Icon = new DfColumnString("Icon", this, false);
                Launcher = new DfColumnString("Launcher", this, false);
                CopyToClipboard = new DfColumnString("CopyToClipboard", this, false);
                ShortCut = new DfColumnString("ShortCut", this, false);
                AccessTime = new DfColumnString("AccessTime", this, false);
                Url = new DfColumnString("Url", this, false);


                ArchivedDate = new DfColumnDateTime(nameof(ArchivedDate), this, isNull: true);
                Path = new DfColumnReference(nameof(Path), Id, this);
                QuickToolbar = new DfColumnInt32(nameof(QuickToolbar), this, isNullable: true);
            }

            public override IEnumerable<IDfColumnBase> GetColumns()
            {
                yield return Id;
                yield return Name;
                yield return Type;
                yield return Parents;
                yield return Icon;
                yield return Launcher;
                yield return CopyToClipboard;
                yield return ShortCut;
                yield return AccessTime;
                yield return Url;

                yield return ArchivedDate;
                yield return Path;
                yield return QuickToolbar;
            }
            public override IDfColumnBase PrimaryKeyColumn => Id;

            public override IEnumerable<int> SavingOrder => Id.InOrder;

            internal void Resolve() => Children = Parents.ResolveAndCreateBackeferenceColumn(nameof(Children), null /*TODO*/);

            protected override void ProcessCsvHeaders(IEnumerable<string> headers, DfTable recSetN) { }
        }

        /// <summary>
        /// The test loads the LinkManager model and in order for resolution to work, it need multiple csv files, such as for parent directories
        /// </summary>
        [TestMethod, Ignore] 
        public void DfCol_SimpleRead()
        {
            var par = new CsvParameters { FieldDelimiterN = '\t', HeadersN = "Id	Name	Type	Parents	Icon	Launcher	CopyToClipboard	ShortCut	AccessTime	Url	ArchivedDate	Path" };
            var entities = new DfEntitiesColletion("Entity");
            entities.LoadFromCsv(@"C:\Repo\Sync.svn\Data\LinkManager\Manual\Entity.csv", null, par);
            entities.Resolve();


            var orderedIds = entities.Id.InOrder.Select(i => entities.Id.GetText(i)).ToList();

            foreach (int withPar in entities.All.Wher(entities.Parents, s => !String.IsNullOrWhiteSpace(s)))
            {
                var parents = entities.Parents.GetReferences(withPar).ToList();
            }

            var rootInd = entities.Parents.Where(s => String.IsNullOrWhiteSpace(s), entities.Type.Where(EntType.Folder, entities.All)).ToList();
            //Standard LINQ
            var rootInd2 = entities.All.Where(i => entities.Type.Vals[i] == EntType.Folder).Where(i => String.IsNullOrWhiteSpace(entities.Parents.Vals[i])).ToList();
            var rootInd3 = entities.All.Wher(entities.Type, v => v == EntType.Folder).Wher(entities.Parents, v => String.IsNullOrWhiteSpace(v)).ToList();

            var children = String.Join(", ", entities.Children.GetReferences(rootInd.First()).Select(i => entities.Name.GetText(i)));

            string res = entities.GetDescr(4);
            //dynamic b = entities.GetDynamic(4);
        }
    }
}
