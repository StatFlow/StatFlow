﻿using NbTools;
using System;
using System.Text;
using NbTools.Collections;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;

namespace NbToolsTest
{
    public class CbCollectionTestSteps
    {
        private readonly CbKeyedCollection theColl = new CbKeyedCollection("CbCollectionTestSteps test collection");
        private static readonly CsvParameters csvPar = new CsvParameters { FieldDelimiterN = ',', HeadersAreInTheFile = true };
        private readonly List<TableEvent> tableEvents = new List<TableEvent>();
        private readonly List<CellEvent> cellEvents = new List<CellEvent>();

        public class TableEvent
        {
            public CbCollChangedEventType EventType;
            public int RowNum;
        }
        public class CellEvent
        {
            public string Field;
            public int RowNum;
            public string Old;
            public string New;
        }

        public CbCollectionTestSteps()
        {
            theColl.OnChanged += (collection, eventType, rowNum) => tableEvents.Add(new TableEvent { EventType = eventType, RowNum = rowNum });
            theColl.OnValueChanged += TheColl_OnValueChanged;
        }

        private void TheColl_OnValueChanged(CbCollection collection, ICbCollectionColumn field, int ind)
        {
            cellEvents.Add(new CellEvent { Field = field.Name, RowNum = ind, Old = field.GetTextFromBuffer(), New = field.GetText(ind) });
        }

        public void GivenCsvFile()
        {
            CbLoaderSaverCsv ldr = new CbLoaderSaverCsv(theColl);
            /*var a = table.ToCsvString();
            using (var suppr = theColl.SuppressEvents())
            {
                ldr.AppendString(a, csvPar);
            }
            theColl.SetKeyColumn("Key");*/
        }

        public void WhenItIsMergedWithCsvFileUsingAppendUpdateMode(SyncMode mode)
        {
            Assert.IsNotNull(theColl, "The test collection must be defined before merging");
            var coll = new CbKeyedCollection("Second Collection");

            //new CbLoaderSaverCsv(coll).AppendString(table.ToCsvString(), csvPar);
            coll.SetKeyColumn("Key");

            theColl.SyncWith(coll, syncMode: mode);
        }

        public void ThenTheResultingCsvIs()
        {
            //theColl.Compare(table);
        }

        public void ThenTableLevelEventsGenerated()
        {
            //tableEvents.Compare(table);
        }

        public void ThenRecordLevelEventsGenerated()
        {
            //cellEvents.Compare(table);
        }

        public void WhenCsvFileIsResolved()
        {
            //theColl.Resolve();
        }
    }

    public static class Helpers
    {
        /*public static string ToCsvString(string sep = ",")
        {
            StringBuilder bld = new StringBuilder();
            bld.AppendLine(String.Join(sep, tbl.Header));
            tbl.Rows.ForEachSafe(r => bld.AppendLine(String.Join(sep, r.Values)));
            return bld.ToString();
        }*/

        public static void Compare(this CbCollection coll)
        {
            /*Assert.IsTrue(coll.Columns.Keys.SequenceEqual(tbl.Header));
            Assert.AreEqual(tbl.RowCount, coll.Count);
            ICbCollectionColumn[] fields = tbl.Header.Select(h => coll[h]).ToArray();

            foreach(var ind in coll.All.Select((aColl, iTbl) => (aColl, iTbl)))
            {
                for (int columnNum = 0; columnNum < fields.Length; ++columnNum)
                {
                    var txt = fields[columnNum].GetText(ind.aColl);
                    Assert.AreEqual(tbl.Rows[ind.iTbl][columnNum], txt);
                }
            }*/
        }

        public static void Compare<T>(this List<T> tableEvents)
        {
            /*Assert.AreEqual(table.RowCount, tableEvents.Count);
            FieldInfo[] fieldTypes = null;
            for (int r = 0; r < table.RowCount; ++r)
            {
                if (r == 0) //First line - initialise field properties in the order of SpecFlow Headers
                {
                    var fields = typeof(T).GetFields();
                    fieldTypes = table.Header.Select(h => fields.SingleVerbose(f => f.Name.EqIC(h), () => $"Field '{h}' can't be found in the class '{typeof(T).Name}'", _ => null)).ToArray();
                }

                for (int c = 0; c < fieldTypes.Length; ++c)
                {
                    var val = fieldTypes[c].GetValue(tableEvents[r]).ToString();
                    Assert.AreEqual(table.Rows[r][c], val);
                }
            }*/
        }
    }
}
