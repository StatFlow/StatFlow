﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbTools.SqlGen.Xml;
using System;
using System.Collections.Generic;
using static NbTools.NbSqlBuilder;

namespace NbToolsTest
{
    [TestClass]
    public class SqlBuilderTest
    {
        [TestMethod]
        public void MinimumRequest()
        {
            var nbSqlXml = NbSqlXml.LoadFile(@"C:\Repo\NbTools\NbTools\Filter\NbSqlXmlExample.xml");

            var bldr = new NbTools.NbSqlBuilder(nbSqlXml, null);
            var _ = bldr.GetMsSqlString();
            //Assert.AreEqual("\r\n\r\nselect top 1000\r\n column1, column2, Id from table\r\n", res);
        }



        [TestMethod]
        public void FilesVideosJoin()
        {

            var t1 = new NbSqlTable
            {
                name = "Files",
                alias = "f",
                field = new[] { new NbSqlField { name = "Id" }, new NbSqlField { name = "Name", order_ind = 1 }, new NbSqlField { name = "Extension" }, new NbSqlField { name = "Size" }, new NbSqlField { name = "Hash" } }
            };
            var t2 = new NbSqlTable
            {
                name = "Videos",
                alias = "v",
                join = new NbSqlJoin { field = "Id", to_table = "Files", to_field = "Hash" },
                field = new[] { new NbSqlField { name = "Width" }, new NbSqlField { name = "Height" } }
            };

            var nbSqlXml = new NbSqlXml { table = new[] { t1, t2 } };
            nbSqlXml.Resolve();


            var bldr = new NbTools.NbSqlBuilder(nbSqlXml, null);
            var _ = bldr.GetMsSqlString();
            //Assert.AreEqual("\r\n\r\nselect top 1000\r\n column1, column2, Id from table\r\n", res);
        }


        private const string SqlXmlRootTag = @"<?xml version='1.0' encoding='utf-8'?>
<sql_xml xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' top='1000' xsi:schemaLocation='NbTools.SqlGen C:\Repo\NbTools\NbTools\Filter\NbSqlXml.xsd'>
{0}
</sql_xml>";

        private static readonly string RootWithTable = String.Format(SqlXmlRootTag,
@" <table name='VideoView' alias='vv'>
    <field name='Id' />
    <field name='Name' order_ind='1' />
    <field name='Extension' />
  </table>
 {0}");

        [TestMethod]
        public void SubTree()
        {
            string xml1 = String.Format(RootWithTable,
@"<filter>
    <subtree field='ParentDirId' table='VideoView' tree_table='Dirs' root_node_id='11003' root_node_type='Dir' />
  </filter>");

            var nbSqlXml1 = NbSqlXml.LoadFromString(xml1);
            var bldr = new NbTools.NbSqlBuilder(nbSqlXml1, null);
            var res1 = bldr.GetMsSqlString();
            Assert.IsTrue(res1.Contains("presel"));
            Assert.IsTrue(res1.Contains(" in "));


            string xml2 = String.Format(RootWithTable,
@"<filter>
    <subtree exclude='true' field='ParentDirId' table='VideoView' tree_table='Dirs' root_node_id='11003' root_node_type='Dir' />
  </filter>");

            var nbSqlXml2 = NbSqlXml.LoadFromString(xml2);
            var bldr2 = new NbTools.NbSqlBuilder(nbSqlXml2, null);
            var res2 = bldr2.GetMsSqlString();
            Assert.IsTrue(res2.Contains("presel"));
            Assert.IsTrue(res2.Contains(" not in "));

        }
    }
}
