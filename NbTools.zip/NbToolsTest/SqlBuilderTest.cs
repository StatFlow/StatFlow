﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbTools.SqlGen.Xml;
using System;
using System.Data.SqlTypes;

namespace NbToolsTest
{
    [TestClass]
    public class SqlBuilderTest
    {
        [TestMethod]
        public void MinimumRequest()
        {
            var nbSqlXml = NbSqlXml.LoadFile(@"C:\Repo\NbTools\NbTools\Filter\NbSqlXmlExample.xml");

            var bldr = new NbTools.NbSqlBuilder(nbSqlXml);
            var res = bldr.GetMsSqlString();
            //Assert.AreEqual("\r\n\r\nselect top 1000\r\n column1, column2, Id from table\r\n", res);
        }
    }
}
