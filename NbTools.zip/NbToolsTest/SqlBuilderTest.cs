﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbTools.SqlGen.Xml;

namespace NbToolsTest
{
    [TestClass]
    public class SqlBuilderTest
    {
        [TestMethod]
        public void MinimumRequest()
        {
            var nbSqlXml = NbSqlXml.LoadFile(@"C:\Repo\NbTools\NbTools\Filter\NbSqlXmlExample.xml");

            var bldr = new NbTools.NbSqlBuilder(nbSqlXml);
            var res = bldr.GetMsSqlString();
            //Assert.AreEqual("\r\n\r\nselect top 1000\r\n column1, column2, Id from table\r\n", res);
        }



        [TestMethod]
        public void FilesVideosJoin()
        {

            var t1 = new NbSqlTable
            {
                name = "Files",
                alias = "f",
                field = new[] { new NbSqlField { name = "Id" }, new NbSqlField { name = "Name", order_ind = 1 }, new NbSqlField { name = "Extension" }, new NbSqlField { name = "Size" }, new NbSqlField { name = "Hash" } }
            };
            var t2 = new NbSqlTable
            {
                name = "Videos",
                alias = "v",
                join = new NbSqlJoin { field = "Id", to_table = "Files", to_field = "Hash" },
                field = new[] { new NbSqlField { name = "Width" }, new NbSqlField { name = "Height" } }
            };

            var nbSqlXml = new NbSqlXml { table = new[] { t1, t2 } };
            nbSqlXml.Resolve();


            var bldr = new NbTools.NbSqlBuilder(nbSqlXml);
            var res = bldr.GetMsSqlString();
            //Assert.AreEqual("\r\n\r\nselect top 1000\r\n column1, column2, Id from table\r\n", res);
        }
    }
}
