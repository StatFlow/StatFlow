﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using NbTools;
using NbTools.Collections;

using NbCollV1;

namespace NbToolsTest
{
    [TestClass]
    public class DfDynamicCollectionTest
    {
        //TODO;
        //col1.LoadFromXml
        //col1.LoadFromDb

        [TestMethod]
        public void DfDynCol_EmptyColumn()
        {
            var par = new CsvParameters { FieldDelimiterN = '\t' };
            var coll1 = new DfDynamicCollection("Collection1");
            DfTable recSet = null;

            const string SimpleCsv1 =
            @"FieldInd,FieldString,EmptyColumn
1,One
2,Two
";
            using StringReader sr = new StringReader(SimpleCsv1);
            coll1.LoadFromCsv(sr, recSet);
            Check(coll1, new[] { "1", "2" }, new[] { "One", "Two" }, new string[] { "", "" });
        }

        [TestMethod]
        public void DfDynCol_SimpleRead()
        {
            var par = new CsvParameters { FieldDelimiterN = '\t' };
            var coll1 = new DfDynamicCollection("Collection1");
            DfTable recSet = null;

            const string SimpleCsv1 =
            @"FieldInd,FieldString
1,One
2,Two
";
            using (StringReader sr = new StringReader(SimpleCsv1))
            {
                coll1.LoadFromCsv(sr, recSet);
                Check(coll1, new[] { "1", "2" }, new[] { "One", "Two" });
            }

            var intCol = coll1.GetColumn("FieldInd");

            coll1.EditLine(1);
            intCol.SetText("123");
            coll1.ReleaseLine();
            Check(coll1, new[] { "1", "123" }, new[] { "One", "Two" });
        }

        [TestMethod]
        public void DfDynCol_WithReferencedField()
        {
            var colFldr = new DfDynamicCollection("Folders");
            var colEnt = new DfDynamicCollection("Entities");

            using var rdr = new StringReader(
@"Id,Name,ParentId
1,Root,
2,Subforder2,1
3,SubSubforder2,2
4,SubSubforder4,2
5,Subforder5,1
");
            var rc = new DfTable
            {
                name = "Folders",
                fields = new DfFields
                {
                    Items = new DfField[] {
                        new DfField { name= "Id", type = DfType.@int},
                        new DfField { name= "Name",  type = DfType.@string },
                        new DfField { name= "Root",type = DfType.@int,
                            link = new DfLink[] { new DfLink { } }
                        }
                    }
                }
            };

            colFldr.LoadFromCsv(rdr, rc);
            Assert.AreEqual(colFldr.Count, 5, $"{colFldr.CollectionName} collection should have 5 rows");
            Assert.AreEqual(colFldr.GetColumns().Count(), 3, $"{colFldr.CollectionName} collection should have 3 columns");
        }


        private void Check(DfDynamicCollection col, params string[][] dsts)
        {
            Assert.AreEqual(col.GetColumnsAndDesc().Count, dsts.Length, $"Collection ({col.GetColumnsAndDesc().Count}) and the expected values ({dsts.Length}) have different number or columns");

            //ValueTuple
            foreach ((IDfColumnBase dfCol, DfField xmlCol, string[] expected) in col.GetColumnsAndDesc().Zip(dsts, (a, b) => (a.Item1, a.Item2, b)))
                AssertSequece(dfCol.Rows, expected);
        }

        private void AssertSequece<T>(IEnumerable<T> received, IEnumerable<T> expected) =>
            Assert.IsTrue(expected.SequenceEqual(received), $"Expected: '{String.Join("', '", expected)}', received: '{String.Join("', '", received)}'");


    }
}
