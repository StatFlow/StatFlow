﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace NbToolsTest
{
#pragma warning disable IDE1006 // Naming Styles
    [DataContract]
    public class Disruption
    {
        [DataMember]
        public string type { get; set; }

        [DataMember]
        public string category { get; set; }

        [DataMember]
        public string categoryDescription { get; set; }

        [DataMember]
        public string description { get; set; }

        [DataMember]
        public string additionalInfo { get; set; }

        [DataMember]
        public string created { get; set; }

        [DataMember]
        public List<object> affectedRoutes { get; set; }

        [DataMember]
        public List<object> affectedStops { get; set; }

        [DataMember]
        public string closureText { get; set; }

        [DataMember]
        public bool? isWholeLine { get; set; }
    }

    [DataContract]
    public class LineStatus
    {
        [DataMember]
        public string type { get; set; }

        [DataMember]
        public int id { get; set; }

        [DataMember]
        public int statusSeverity { get; set; }

        [DataMember]
        public string statusSeverityDescription { get; set; }

        [DataMember]
        public string created { get; set; }

        [DataMember]
        public List<object> validityPeriods { get; set; }

        [DataMember]
        public string lineId { get; set; }

        [DataMember]
        public string reason { get; set; }

        [DataMember]
        public Disruption disruption { get; set; }
    }

    [DataContract]
    public class ServiceType
    {
        [DataMember]
        public string type { get; set; }

        [DataMember]
        public string name { get; set; }

        [DataMember]
        public string uri { get; set; }
    }

    [DataContract]
    public class Crowding
    {
        [DataMember]
        public string type { get; set; }
    }

    [DataContract]
    public class tubeStatusRootObject
    {
        [DataMember]
        public string type { get; set; }

        [DataMember]
        public string id { get; set; }

        [DataMember]
        public string name { get; set; }

        [DataMember]
        public string modeName { get; set; }

        [DataMember]
        public List<object> disruptions { get; set; }

        [DataMember]
        public string created { get; set; }

        [DataMember]
        public string modified { get; set; }

        [DataMember]
        public List<LineStatus> lineStatuses { get; set; }

        [DataMember]
        public List<object> routeSections { get; set; }

        [DataMember]
        public List<ServiceType> serviceTypes { get; set; }

        [DataMember]
        public Crowding crowding { get; set; }
    }

#pragma warning restore IDE1006 // Naming Styles

    [TestClass]
    public class JsonTest
    {

        /*[TestMethod]
        public void ParseTfl()
        {
            const string fileName = @"TestData\TflStatus.json";
            //JsonSerializer serializer = new JsonSerializer();
            //var dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(file);

            //var response = await http.GetAsync(url);
            //var json = await response.Content.ReadAsStringAsync(); //This is working

            var json = File.ReadAllText(fileName);
            var data = Newtonsoft.Json.JsonConvert.DeserializeObject<tubeStatusRootObject[]>(json);

        }*/


        /*[TestMethod]
        public void TextWriter1()
        {
            StringBuilder sb = new StringBuilder();
            StringWriter sw = new StringWriter(sb);

            using (JsonWriter writer = new JsonTextWriter(sw))
            {
                writer.Formatting = Formatting.Indented;

                writer.WriteStartObject();
                writer.WritePropertyName("CPU");
                writer.WriteValue("Intel");
                writer.WritePropertyName("PSU");
                writer.WriteValue("500W");
                writer.WritePropertyName("Drives");
                writer.WriteStartArray();
                writer.WriteValue("DVD read/writer");
                writer.WriteComment("(broken)");
                writer.WriteValue("500 gigabyte hard drive");
                writer.WriteValue("200 gigabyte hard drive");
                writer.WriteEnd();
                writer.WriteEndObject();
            }
            var res = sb.ToString();
        }*/


        [TestMethod]
        public void TextWriter()
        {
            //DirectoryInfo di = new DirectoryInfo(@"C:\Temp\Queen.lrc\1977.10.28 - News of the World");
            DirectoryInfo dir = new DirectoryInfo(@"C:\Temp\Queen.lrc");

            var root = new JArray(dir.GetDirectories().OrderBy(d => d.Name).Select(d => AlbDir2Json(d)));
            var res = root.ToString();
        }

        private static int cntr = 100000;

        private static readonly Regex DirRegExt = new Regex(@"^(\d|.+) - (.+)$");
        private static JObject AlbDir2Json(DirectoryInfo di)
        {
            var m = DirRegExt.Match(di.Name);
            if (!m.Success)
                throw new Exception($"Can't parse directory name: {di.FullName}");

            var albId = m.Groups[1].ToString();

            return new JObject(
                new JProperty("id", albId), //1977.10.28
                new JProperty("text", m.Groups[2].ToString()),
                new JProperty("children",
                    new JArray(di.GetFiles("*.lrc").OrderBy(f => f.Name).Select(f => File2Json(albId, f)))
                ));
        }

        private static readonly Regex LrcRegExt = new Regex(@"^(\d{2}) - (.+).(lrc|txt)$");
        private static JObject File2Json(string albId, FileInfo fi)
        {
            var m = LrcRegExt.Match(fi.Name);
            if (m.Success)
                return new JObject(
                    new JProperty("id", albId + '_' + m.Groups[1].ToString()),
                    new JProperty("text", m.Groups[2].ToString()));
            else
                return new JObject(
                    new JProperty("id", cntr++),
                    new JProperty("text", fi.FullName));
        }
        /*
    [
      {
        "id": 1,
        "text": "Root node",
        "children": [
          {
            "id": 2,
            "text": "Child node 1"
          },
          {
            "id": 3,
            "text": "Child node 2"
          }
        ]
      }
    ]
        */

    }
}
