﻿using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbTools;
using System.IO;
using static NbTools.NbExt;
using System.Text;

namespace NbToolsTest
{
    [TestClass]
    public partial class CsvToolsTest1
    {

        [TestMethod]
        public void DeCsv2_Test1()
        {
            StringBuilder bld = new StringBuilder();
            //TODO: implement negative tests

            TestDeCsv(bld, "\"RN\r\nInside\",\"Only R\rInside\",\"Only N\ninside\"", new[] { "RN\r\nInside", "Only R\rInside", "Only N\ninside" });
            TestDeCsv(bld, "Unopened quote\"\r\n\"Comma, inside\"", new[] { "Unopened quote\"" }, new[] { "Comma, inside" });
            TestDeCsv(bld, "\"Unclosed quote", new[] { "Unclosed quote" });

            TestDeCsv(bld, "", new[] { "" });
            TestDeCsv(bld, "\"In quotes\",\"Quote inside: \"\"\",\"Two quotes\"\"\"\" together\"", new[] { "In quotes", "Quote inside: \"", "Two quotes\"\" together" });
            TestDeCsv(bld, ",Один,Два\r\nТри,Четыре,", new[] { "", "Один", "Два" }, new[] { "Три", "Четыре", "" });
            TestDeCsv(bld, "\n,One,Two", new[] { "" }, new[] { "", "One", "Two" });
            TestDeCsv(bld, ",One,Two\r\n,Three,Four", new[] { "", "One", "Two" }, new[] { "", "Three", "Four" });
            TestDeCsv(bld, "One,,Two\r\nThree,Four,", new[] { "One", "", "Two" }, new[] { "Three", "Four", "" });
            TestDeCsv(bld, "One,Two\r\nThree,Four", new[] { "One", "Two" }, new[] { "Three", "Four" });

            //TestDeCsv("One,Two\rSomeOtherStuff", new[] { "One", "Two" }, bld); failing \r is not counted as a new line symbol
            TestDeCsv("One,Two\nSomeOtherStuff", new[] { "One", "Two" }, bld);
            TestDeCsv("One,Two,\r\nSomeOtherStuff", new[] { "One", "Two", "" }, bld);
            TestDeCsv("One,Two,", new[] { "One", "Two", "" }, bld);
            TestDeCsv("One,Two,Three", new[] { "One", "Two", "Three" }, bld);
        }

        private void TestDeCsv(string src, string[] dst, StringBuilder bld)
        {
            using StringReader sr = new StringReader(src);
            var res = NbExt.DeCsvLine2(sr, bld, ',', false).ToList();
            Assert.IsTrue(dst.SequenceEqual(res), $"Expected: '{String.Join("', '", dst)}', received: '{String.Join("', '", res)}'");
        }

        private void TestDeCsv(StringBuilder bld, string src, params string[][] dsts)
        {
            using StringReader sr = new StringReader(src);
            foreach (var dst in dsts)
            {
                var res = NbExt.DeCsvLine2(sr, bld, ',', false).ToList();
                Assert.IsTrue(dst.SequenceEqual(res), $"Expected: '{String.Join("', '", dst)}', received: '{String.Join("', '", res)}'");
            }
        }

















        private static readonly List<string> MessagesGlobal = new List<string>(10);
        private static readonly CsvParameters csvParGlobal = new CsvParameters { LoggerN = MessagesGlobal.Add };

        internal class JiraRss1
        {
            public string Title { get; set; }
            public string Link { get; set; }
            public string Key { get; set; }


            public string Rank { get; set; }
            //public DateTime Cerated { get; set; }

            public override string ToString() => Title;
        }

        [TestMethod]
        public void FromJiraRss()
        {
            CsvParameters prm = new CsvParameters { LoggerN = _ => { } };
            var a = FromJiraRss<JiraRss1>("JiraRss.xml", prm).ToList();
            /*Assert.AreEqual(new DateTime(1902, 12, 31), a.DateField);
            Assert.AreEqual("Some string", a.StringField);
            Assert.AreEqual(42, a.IntField);*/
        }


        [TestMethod]
        public void FromCsvTest1()
        {
            var a = FromCsv<PropertiesClass1>("test1.csv").Single();
            Assert.AreEqual(new DateTime(1902, 12, 31), a.DateField);
            Assert.AreEqual("Some string", a.StringField);
            Assert.AreEqual(42, a.IntField);
        }

        [TestMethod]
        public void FromCsv_TagsTest()
        {
            var messages = new List<string>(10);
            var p = new CsvParameters { LoggerN = messages.Add };

            var a = FromCsv<PropertiesClass3>("test1.csv", p).Single();
        }

        internal class PropertiesClass3
        {
            public string StringField { get; set; }
            public int IntField { get; set; }
            public DateTime DateField { get; set; }

            [CsvIgnore]
            public decimal PropertyToIgnore { get; set; }

            [CsvFileName]
            public string FileName { get; set; }

#pragma warning disable 649 //Names are set through the reflection
            [CsvFileLineNum]
            public readonly int FileLine;
#pragma warning restore
        }
    }

    internal class PropertiesClass1
    {
        public string StringField { get; set; }
        public int IntField { get; set; }
        public DateTime DateField { get; set; }
    }

    internal class PropertiesClass2
    {
        public string StringFieldModified { get; set; }
        public int IntField { get; set; }
        public DateTime DateField { get; set; }
    }



    public partial class CsvToolsTest1
    {
        [TestMethod]
        public void FromCsv_ResolverTest1()
        {
            var deps = FromCsv<Department1>(Yield("Id, Name", "D1,Dept1", "D2,Dept2")).ToDictionary(d => d.Id);
            //Experimental: Department1 depConverter(string i) => deps[i]; 
#pragma warning disable IDE0039
            Func<string, Department1> depConverter = i => deps[i]; //Function must be declared as  Func<string, Department1> to convey the type of
#pragma warning restore

            CsvParameters csvPar = new CsvParameters { ResolversN = Yield<Func<string, IdHolder>>(depConverter) };

            var emps = FromCsv<Employee1>(Yield("Name, Dept, AnotherDept", "John,D1,D2"), csvPar).ToList();
            Assert.AreSame(deps["D1"], emps[0].Dept);

            var emps2 = FromCsv<Employee2>(Yield("Name,MultiDept", "Paul,D1|D2"), csvPar).Single();
            Assert.AreEqual(2, emps2.MultiDept.Count);
            Assert.AreSame(deps["D1"], emps2.MultiDept[0]);
            Assert.AreSame(deps["D2"], emps2.MultiDept[1]);

            Assert.IsTrue(deps.Values.ToCsvLines().SequenceEqual(Yield("Name,Id", "Dept1,D1", "Dept2,D2")));
            Assert.IsTrue(emps.ToCsvLines().SequenceEqual(Yield("Name,Dept,AnotherDept", "John,D1,D2")));
            var csv = Yield(emps2).ToCsvLines().ToList();
            Assert.IsTrue(csv.SequenceEqual(Yield("Name,MultiDept", "Paul,D1|D2")));
        }


        [TestMethod]
        public void FromCsv_ListOfEnum()
        {
            var keys = FromCsv<ListOfKeys>(Yield("Name, Keys", "One,Ctrl|A")).ToList();
            Assert.IsTrue(keys.ToCsvLines().SequenceEqual(Yield("Name,Keys", "One,Ctrl|A")));
        }
    }

#pragma warning disable 649 //Names are set through the reflection
    internal class Department1 : IdHolder
    {
        public string Name;
        public override string ToString() => $"[{Id}] {Name}";

        protected override int MaxId
        {
            get { return _max; }
            set { _max = value; }
        }
        private static int _max = 1;
    }

    internal class Employee1
    {
        public override string ToString() => $"{Name} Dept:{Dept?.Name ?? "None"}";

        public string Name;
        public Department1 Dept;
        public Department1 AnotherDept;
    }

    internal class Employee2
    {
        public string Name;
        public List<Department1> MultiDept;
    }

    internal class ListOfKeys
    {
        public enum Key { Ctrl, Shift, A, B, C }

        public string Name;
        public List<Key> Keys;
    }

#pragma warning restore
}