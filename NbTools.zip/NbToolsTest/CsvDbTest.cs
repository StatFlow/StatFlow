﻿using System;
using System.IO;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbTools.Collections;

namespace NbToolsTest
{
    [TestClass, Ignore]
    //TODO: Bug in Visual Studio Deployment Item stops the test from running
    //[DeploymentItem("CsvDb")] //Copies DLLs folder from the BIN directory into the root of tests
    public class CsvDbTest
    {
        [TestMethod]
        public void CsvDbTest_SimpleLoad()
        {
            CbDatabase db = new CbDatabase("DbLayout.xml");
            db.LoadAndResolveTables();
            var main = db.GetKeyed("Main");

            //Updating once line to reference another field
            int ind = main.KeyN.IndexOf("1.1.1");
            main["Parent"].SetTextToBuffer("1.2");
            main["Parent"].UpdateFromBufferAt(ind);

            //Updating a key of 1.1 to  1.1a
            ind = main.KeyN.IndexOf("1.1");
            main["Key"].SetTextToBuffer("1.1a");
            main["Key"].UpdateFromBufferAt(ind);

            db.SaveTables("saved");
            FilesAreEqual("MainSaved.csv", @"saved\Main.csv");
        }

        private void FilesAreEqual(string file1, string file2)
        {
            var lines1 = File.ReadAllLines(file1);
            var lines2 = File.ReadAllLines(file2);
            if (lines1.Length != lines2.Length)
                throw new Exception($"Files '{file1}({lines1.Length})' and '{file2}({lines2.Length})' have differenct length");

            if (!lines1.SequenceEqual(lines2))
                throw new Exception($"Files '{file1}({lines1.Length})' and '{file2}({lines2.Length})' have differenct lines");
        }
    }
}
