﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NbTools;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace NbToolsTest
{
    [TestClass]
    public class ProcessTest
    {
        [TestMethod]
        public void Process_DiskPart1()
        {
            var tsc = new TaskCompletionSource<(int exitCode, string stdOut, string errOut)>();

            ProcessStartInfo psi = new ProcessStartInfo()
            {
                FileName = "ftp.exe",
                //Arguments = (arguments == null) ? null : String.Join(" ", arguments.Select(a => PutInQuotes(a))),
                //WorkingDirectory = workDir?.FullName,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                CreateNoWindow = true
            };

            StringBuilder outBld = new StringBuilder();
            StringBuilder errBld = new StringBuilder();

            Process pc = new Process
            {
                StartInfo = psi,
                EnableRaisingEvents = true
            };

            pc.OutputDataReceived += (s, e) =>
            {
                outBld.AppendLine(e.Data);
            };
            pc.ErrorDataReceived += (s, e) =>
            {
                errBld.AppendLine(e.Data);
            };

            pc.Exited += (s, e) =>
            {
                int exitCode = pc.ExitCode;
                tsc.SetResult((exitCode, outBld.ToString(), errBld.ToString()));
                pc.Dispose();
            };

            pc.Start();
            pc.BeginOutputReadLine();
            pc.BeginErrorReadLine();
            pc.StandardInput.WriteLine("open qnikbud.myftp.org");
            //pc.StandardInput.WriteLine("quit");

            pc.WaitForExit();

        }
    }
}
