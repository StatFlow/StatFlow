using System.Windows.Forms;

namespace DataWalker2
{
    public partial class DummyOutputWindow : ToolWindow
    {
        public DummyOutputWindow()
        {
            InitializeComponent();
        }
    }
}