using System.Windows.Forms;

namespace DataWalker2
{
    public partial class DummyTaskList : ToolWindow
    {
        public DummyTaskList()
        {
            InitializeComponent();
        }
    }
}