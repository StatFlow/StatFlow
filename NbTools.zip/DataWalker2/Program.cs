using DataWalker;
using NbTools;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

namespace DataWalker2
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
            MainForm = new MainForm(args);

            Application.Run(MainForm);
        }

        private static MainForm MainForm;

        private static void ShowDialog(string header, string exMessage)
        {
            MessageBox.Show(MainForm, exMessage, header, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
            => ShowDialog(sender.ToString(), NbException.Exception2String(e.Exception));

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
            => ShowDialog($"Unhandled Exception from {sender.ToString()}", e.ExceptionObject.ToString());
    }

    internal interface ICommandExecutor
    {
        void CmdSave();
        void ShowQueryResult(QueryResultRecordset qrr);
    }
}