using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;


using NbTools;
using NbOrm.Xml;
using NbCollV1;
using NbTools.Graphics;
using NbOrm.Nbq;
using NbTools.Collections;

using DataWalker.Xml;
using DataWalker;
using System.Threading.Tasks;
using System.ComponentModel;

namespace DataWalker2
{
    public partial class MainForm : Form, IUiCallback
    {
        private bool m_bSaveLayout = true;
        private readonly DeserializeDockContent m_deserializeDockContent;
        private DummySolutionExplorer m_solutionExplorer;
        private DummyPropertyWindow m_propertyWindow;
        private DummyToolbox m_toolbox;
        private DummyOutputWindow m_outputWindow;
        private DummyTaskList m_taskList;
        //private bool _showSplash;
        //private SplashScreen _splashScreen;

        private readonly string[] Args; //Only used to pass same args to the new window
        private readonly string ModelFilesMask;
        private readonly string ConfigDir;

        //Section for te DbBrowser
        private readonly config Conf;
        private readonly model Model;
        private readonly layout_info HtmlLayout;

        internal ComboBoxController fCbc;

        private readonly ImageDictionary Icons;
        private readonly QueryManager QueryMgr;


        public MainForm(string[] args)
        {
            Args = args;
            InitializeComponent();
            AutoScaleMode = AutoScaleMode.Dpi;

            if (args == null || args.Length == 0)
                throw new Exception("DataWalker need one command line parameter: the wildcarded path to the database model xmls files");
            
            ModelFilesMask = args[0];
            ConfigDir = Path.GetDirectoryName(ModelFilesMask);
            if (!Directory.Exists(ConfigDir))
            {
                MessageBox.Show($"Directory '{ConfigDir}' doesn't exist");
            }

            //SetSplashScreen();
            CreateStandardControls();


            try
            {
                Conf = config.Load(Path.Combine(Path.GetDirectoryName(ModelFilesMask), "DataWalker.Config.xml"));
                HtmlLayout = layout_info.LoadXml(Path.Combine(Path.GetDirectoryName(ModelFilesMask), "Layout.xml"));
                Conf.toolbar1.PropertyChanged += Toolbar1_PropertyChanged;
                Icons = new ImageDictionary(Conf.folders?.graphics);

                //Update controls from the config
                cbTableGroups.Text = Conf.toolbar1.LastTableGroup;
                cbTables.Text = Conf.toolbar1.LastTable;
                tbParameter.Text = Conf.toolbar1.LastFilter;

                foreach (var env in Conf.environments)
                {
                    ToolStripButton rb;
                    if (String.IsNullOrWhiteSpace(env.icon_file))
                        rb = new ToolStripButton { Name = env.name, Text = env.name, Checked = env.selected }; //ToolTip = env.name
                    else // Image = new Image { Source = Icons.GetN(env.icon_file), Stretch = Stretch.None }
                        rb = new ToolStripButton { Name = env.name, Checked = env.selected }; //ToolTip = env.name
                    //rb.CheckedChanged += Rb_CheckedChanged;
                    toolBar.Items.Add(rb);
                    if (env.selected)
                        Task.Run(() => env.OpenConnections(this)); //As UI callback
                }

                try
                {
                    //Schema would have to load from xml, because some databases will not allow to use the API to get the schema
                    Model = model.MergeXmls(ModelFilesMask);
                    QueryMgr = new QueryManager(Model, HtmlLayout);

                    fCbc = new ComboBoxController(cbTables, QueryMgr.OrderedNames);
                    foreach (var tblGroup in QueryMgr.TableGroups)
                        cbTableGroups.Items.Add(tblGroup);

                    /*cbTableGroups.SelectedIndex = 0;

                    foreach (var resForm in QueryTypeBase.All)
                        cbResultFormat.Items.Add(resForm.Name);*/
                }
                catch (Exception ex)
                { throw new Exception($"Error loading the database model '{ModelFilesMask}'", ex); }

                //Load toolbar with queries from config
                /*ToolbarMain.Items.Add(new Separator());
                foreach (var qDesc in Conf.toolbar2.Safe())
                {
                    var q = QueryMgr[qDesc.name]; //Throws exception if not found
                    Button bt = new Button { Name = qDesc.name, Content = new Image { Source = Icons.GetN(qDesc.icon_file), Stretch = Stretch.None }, ToolTip = qDesc.description ?? q.description };
                    bt.Click += Toolbar2_Click;
                    ToolbarMain.Items.Add(bt);
                }
                QueryBuilder.Show();*/
            }
            catch (Exception ex)
            {
                Task.Run(() => MessageBox.Show(NbException.Exception2String(ex)));
            }


            showRightToLeft.Checked = (RightToLeft == RightToLeft.Yes);
            RightToLeftLayout = showRightToLeft.Checked;
            m_solutionExplorer.RightToLeftLayout = RightToLeftLayout;
            m_deserializeDockContent = new DeserializeDockContent(GetContentFromPersistString);

            vsToolStripExtender1.DefaultRenderer = _toolStripProfessionalRenderer;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            try { HtmlLayout.SaveXml(); } catch { } //TODO: show a dialog
            try { Conf.Save(); } catch { } //TODO: show a dialog
        }

        private void Toolbar1_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (Model == null)
                return;

            switch (e.PropertyName)
            {
                case nameof(configToolbar1.LastTable):
                    var recSetName = Conf.toolbar1.LastTable;
                    if (String.IsNullOrEmpty(recSetName))
                    {
                        //QueryBuilder.QuerySnapshot = null;
                        return;
                    }

                    //var recSet = Model.GetRecordset(recSetName);
                    //var qSnap = QuerySnapshot.FromRecordset(recSet);
                    //QueryBuilder.QuerySnapshot = qSnap;
                    break;
            }
        }


        private async void BtBrowse_Click(object sender, System.EventArgs e)
        {
            try
            {
                var recSetName = cbTables.Text;
                if (String.IsNullOrEmpty(recSetName))
                {
                    //QueryBuilder.QuerySnapshot = null;
                    return;
                }

                var recSet = Model.GetRecordset(recSetName);
                var qs = QuerySnapshot.FromRecordset(recSet);
                //QueryBuilder.QuerySnapshot = qSnap;

                QueryTypeBase qBase = QueryTypeBase.ByName("Sql Data"); //cbResultFormat.SelectedItem as string
                //var qs = QueryBuilder.QuerySnapshot;
                var nbqPar = qs?.GetNbqParameters();
                /*Uri uri;
                if ((nbqPar?.Count ?? 0) > 0)
                    uri = NbqUriBuilder.Build(qs.name, nbqPar, qBase.NbqType);
                else
                {
                    uri = NbqUriBuilder.Build(Conf.toolbar1.LastTable, tbParameter.Text, qBase.NbqType);
                }*/

                string query;
                if ((nbqPar?.Count ?? 0) > 0)
                    query = NbqUriBuilder.BuildQuery(qs.name, nbqPar);
                else
                    query = NbqUriBuilder.BuildQuery(Conf.toolbar1.LastTable, tbParameter.Text);

                var qRes = Task.Run(() => QueryMgr.LoadDataForUri(qBase.NbqType, query, Conf.EnvSelected)); //Always save to history
                var br = FindDbBrowser(); //Creates if not found
                br.ShowQueryResult(await qRes);
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void BtCsv_Click(object sender, EventArgs e)
        {
            try
            {
                var recSetName = cbTables.Text;
                if (String.IsNullOrEmpty(recSetName))
                {
                    //QueryBuilder.QuerySnapshot = null;
                    return;
                }

                var recSet = Model.GetRecordset(recSetName);
                var qs = QuerySnapshot.FromRecordset(recSet);
                //QueryBuilder.QuerySnapshot = qSnap;

                QueryTypeBase qBase = QueryTypeBase.ByName("Csv"); //cbResultFormat.SelectedItem as string
                //var qs = QueryBuilder.QuerySnapshot;
                var nbqPar = qs?.GetNbqParameters();
                string query;
                if ((nbqPar?.Count ?? 0) > 0)
                    query = NbqUriBuilder.BuildQuery(qs.name, nbqPar);
                else
                    query = NbqUriBuilder.BuildQuery(Conf.toolbar1.LastTable, tbParameter.Text);

                var qRes = QueryMgr.LoadDataForUri(qBase.NbqType, query, Conf.EnvSelected); //Always save to history
                //var br = FindDbBrowser(); //Creates if not found
                //br.ShowQueryResult(await qRes);
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void BtSave_Click(object sender, EventArgs e)
        {
            //Find active tab
            ICommandExecutor cmdExec = null;
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
                cmdExec = ActiveMdiChild as ICommandExecutor;
            else if (dockPanel.ActiveDocument != null)
                cmdExec = dockPanel.ActiveDocument as ICommandExecutor;

            cmdExec?.CmdSave();
        }

        private async void BtOpenWithGrid_Click(object sender, EventArgs e)
        {
            try
            {
                var recSetName = cbTables.Text;
                if (String.IsNullOrEmpty(recSetName))
                {
                    //QueryBuilder.QuerySnapshot = null;
                    return;
                }

                var recSet = Model.GetRecordset(recSetName);
                var qs = QuerySnapshot.FromRecordset(recSet);

                QueryTypeBase qBase = QueryTypeBase.ByName("Sql Data"); //cbResultFormat.SelectedItem as string
                var nbqPar = qs?.GetNbqParameters();
                string query;
                if ((nbqPar?.Count ?? 0) > 0)
                    query = NbqUriBuilder.BuildQuery(qs.name, nbqPar);
                else
                    query = NbqUriBuilder.BuildQuery(Conf.toolbar1.LastTable, tbParameter.Text);

                var qRes = await Task.Run(() => QueryMgr.LoadDataForUri(qBase.NbqType, query, Conf.EnvSelected)); //Always save to history
                switch(qRes)
                {
                    case QueryResultRecordset rs:
                        var gr = FindDbGrid(); //Creates if not found
                        (gr as ICommandExecutor).ShowQueryResult(rs);
                        break;
                    case QueryResultFile fl:
                        var te = FindTextEditor(); //Creates if not found
                        //te.ShowQueryResult(fl);
                        break;
                    default: throw new NbExceptionInfo($"Unsupported type of QueryResult: {qRes.GetType().Name}");
                }
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private object FindTextEditor()
        {
            throw new NotImplementedException();
        }


        #region Methods
        /// <summary>
        /// Finds most suitable browser to use for Uri navigation, if now found creates one
        /// </summary>
        /// <returns></returns>
        private DbBrowser.DbBrowser FindDbBrowser()
        {
            //TODO: look for active window first

            DbBrowser.DbBrowser br = (dockPanel.DocumentStyle == DocumentStyle.SystemMdi) ?
                MdiChildren.OfType<DbBrowser.DbBrowser>().FirstOrDefault() :
                dockPanel.Documents.OfType<DbBrowser.DbBrowser>().FirstOrDefault();

            if (br == null)
            {
                br = new DbBrowser.DbBrowser(Conf, Icons, QueryMgr);
                RegisterNewDockContent(br);
            }

            return br;
        }

        private DbGrid.DbGrid FindDbGrid()
        {
            //TODO: look for active window first
            DbGrid.DbGrid gr = (dockPanel.DocumentStyle == DocumentStyle.SystemMdi) ?
                MdiChildren.OfType<DbGrid.DbGrid>().FirstOrDefault() :
                dockPanel.Documents.OfType<DbGrid.DbGrid>().FirstOrDefault();

            if (gr == null)
            {
                gr = new DbGrid.DbGrid();
                RegisterNewDockContent(gr);
            }
            return gr;
        }

        private void RegisterNewDockContent(DockContent dockCont)
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                dockCont.MdiParent = this;
                dockCont.Show();
            }
            else
                dockCont.Show(dockPanel);
        }

        private void DbBrowserToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dummyDoc = new DbBrowser.DbBrowser(Conf, Icons, QueryMgr);

            int count = 1;
            string text = $"Document{count}";
            while (FindDocument(text) != null)
            {
                count++;
                text = $"Document{count}";
            }

            dummyDoc.Text = text;
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                dummyDoc.MdiParent = this;
                dummyDoc.Show();
            }
            else
                dummyDoc.Show(dockPanel);
        }


        private IDockContent FindDocument(string text)
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                return MdiChildren.SingleOrDefault(f => f.Text == text) as IDockContent;
                /*foreach (Form form in MdiChildren)
                    if (form.Text == text)
                        return form as IDockContent;
                return null;*/
            }
            else
            {
                return dockPanel.Documents.SingleOrDefault(cnt => cnt.DockHandler.TabText == text);
                /*foreach (IDockContent content in dockPanel.Documents)
                    if (content.DockHandler.TabText == text)
                        return content;

                return null;*/
            }
        }

        private void CloseAllDocuments()
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                foreach (Form form in MdiChildren)
                    form.Close();
            }
            else
            {
                foreach (IDockContent document in dockPanel.DocumentsToArray())
                {
                    // IMPORANT: dispose all panes.
                    document.DockHandler.DockPanel = null;
                    document.DockHandler.Close();
                }
            }
        }

        private IDockContent GetContentFromPersistString(string persistString)
        {
            if (persistString == typeof(DummySolutionExplorer).ToString())
                return m_solutionExplorer;
            else if (persistString == typeof(DummyPropertyWindow).ToString())
                return m_propertyWindow;
            else if (persistString == typeof(DummyToolbox).ToString())
                return m_toolbox;
            else if (persistString == typeof(DummyOutputWindow).ToString())
                return m_outputWindow;
            else if (persistString == typeof(DummyTaskList).ToString())
                return m_taskList;
            else if (persistString == typeof(DbBrowser.DbBrowser).ToString())
                return null;//new DbBrowser.DbBrowser(ModelFilesMask);
            else
            {
                // DummyDoc overrides GetPersistString to add extra information into persistString.
                // Any DockContent may override this value to add any needed information for deserialization.

                string[] parsedStrings = persistString.Split(new char[] { ',' });
                if (parsedStrings.Length != 3)
                    return null;

                if (parsedStrings[0] != typeof(DummyDoc).ToString())
                    return null;

                DummyDoc dummyDoc = new DummyDoc();
                if (parsedStrings[1] != string.Empty)
                    dummyDoc.FileName = parsedStrings[1];
                if (parsedStrings[2] != string.Empty)
                    dummyDoc.Text = parsedStrings[2];

                return dummyDoc;
            }
        }

        private void CloseAllContents()
        {
            // we don't want to create another instance of tool window, set DockPanel to null
            m_solutionExplorer.DockPanel = null;
            m_propertyWindow.DockPanel = null;
            m_toolbox.DockPanel = null;
            m_outputWindow.DockPanel = null;
            m_taskList.DockPanel = null;

            // Close all other document windows
            CloseAllDocuments();

            // IMPORTANT: dispose all float windows.
            foreach (var window in dockPanel.FloatWindows.ToList())
                window.Dispose();

            System.Diagnostics.Debug.Assert(dockPanel.Panes.Count == 0);
            System.Diagnostics.Debug.Assert(dockPanel.Contents.Count == 0);
            System.Diagnostics.Debug.Assert(dockPanel.FloatWindows.Count == 0);
        }

        private readonly ToolStripRenderer _toolStripProfessionalRenderer = new ToolStripProfessionalRenderer();

        private void SetSchema(object sender, System.EventArgs e)
        {
            // Persist settings when rebuilding UI
            string configFile = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), "DockPanel.temp.config");

            dockPanel.SaveAsXml(configFile);
            CloseAllContents();

            if (sender == this.menuItemSchemaVS2005)
            {
                this.dockPanel.Theme = this.vS2005Theme1;
                this.EnableVSRenderer(VisualStudioToolStripExtender.VsVersion.Vs2005, vS2005Theme1);
            }
            else if (sender == this.menuItemSchemaVS2015Blue)
            {
                this.dockPanel.Theme = this.vS2015BlueTheme1;
                this.EnableVSRenderer(VisualStudioToolStripExtender.VsVersion.Vs2015, vS2015BlueTheme1);
            }
            else if (sender == this.menuItemSchemaVS2015Light)
            {
                this.dockPanel.Theme = this.vS2015LightTheme1;
                this.EnableVSRenderer(VisualStudioToolStripExtender.VsVersion.Vs2015, vS2015LightTheme1);
            }
            else if (sender == this.menuItemSchemaVS2015Dark)
            {
                this.dockPanel.Theme = this.vS2015DarkTheme1;
                this.EnableVSRenderer(VisualStudioToolStripExtender.VsVersion.Vs2015, vS2015DarkTheme1);
            }

            menuItemSchemaVS2005.Checked = (sender == menuItemSchemaVS2005);
            menuItemSchemaVS2003.Checked = (sender == menuItemSchemaVS2003);
            menuItemSchemaVS2012Light.Checked = (sender == menuItemSchemaVS2012Light);
            menuItemSchemaVS2012Blue.Checked = (sender == menuItemSchemaVS2012Blue);
            menuItemSchemaVS2012Dark.Checked = (sender == menuItemSchemaVS2012Dark);
            menuItemSchemaVS2013Light.Checked = (sender == menuItemSchemaVS2013Light);
            menuItemSchemaVS2013Blue.Checked = (sender == menuItemSchemaVS2013Blue);
            menuItemSchemaVS2013Dark.Checked = (sender == menuItemSchemaVS2013Dark);
            menuItemSchemaVS2015Light.Checked = (sender == menuItemSchemaVS2015Light);
            menuItemSchemaVS2015Blue.Checked = (sender == menuItemSchemaVS2015Blue);
            menuItemSchemaVS2015Dark.Checked = (sender == menuItemSchemaVS2015Dark);
            if (dockPanel.Theme.ColorPalette != null)
            {
                statusBar.BackColor = dockPanel.Theme.ColorPalette.MainWindowStatusBarDefault.Background;
            }

            if (File.Exists(configFile))
                dockPanel.LoadFromXml(configFile, m_deserializeDockContent);
        }

        private void EnableVSRenderer(VisualStudioToolStripExtender.VsVersion version, ThemeBase theme)
        {
            vsToolStripExtender1.SetStyle(mainMenu, version, theme);
            vsToolStripExtender1.SetStyle(toolBar, version, theme);
            vsToolStripExtender1.SetStyle(statusBar, version, theme);
        }

        private void SetDocumentStyle(object sender, System.EventArgs e)
        {
            DocumentStyle oldStyle = dockPanel.DocumentStyle;
            DocumentStyle newStyle;
            if (sender == menuItemDockingMdi)
                newStyle = DocumentStyle.DockingMdi;
            else if (sender == menuItemDockingWindow)
                newStyle = DocumentStyle.DockingWindow;
            else if (sender == menuItemDockingSdi)
                newStyle = DocumentStyle.DockingSdi;
            else
                newStyle = DocumentStyle.SystemMdi;

            if (oldStyle == newStyle)
                return;

            if (oldStyle == DocumentStyle.SystemMdi || newStyle == DocumentStyle.SystemMdi)
                CloseAllDocuments();

            dockPanel.DocumentStyle = newStyle;
            menuItemDockingMdi.Checked = (newStyle == DocumentStyle.DockingMdi);
            menuItemDockingWindow.Checked = (newStyle == DocumentStyle.DockingWindow);
            menuItemDockingSdi.Checked = (newStyle == DocumentStyle.DockingSdi);
            menuItemSystemMdi.Checked = (newStyle == DocumentStyle.SystemMdi);
            menuItemLayoutByCode.Enabled = (newStyle != DocumentStyle.SystemMdi);
            menuItemLayoutByXml.Enabled = (newStyle != DocumentStyle.SystemMdi);
            toolBarButtonLayoutByCode.Enabled = (newStyle != DocumentStyle.SystemMdi);
            btBrowse.Enabled = (newStyle != DocumentStyle.SystemMdi);
        }

        #endregion

        #region Event Handlers

        private void MenuItemExit_Click(object sender, System.EventArgs e) => Close();
        private void MenuItemSolutionExplorer_Click(object sender, System.EventArgs e) => m_solutionExplorer.Show(dockPanel);
        private void MenuItemPropertyWindow_Click(object sender, System.EventArgs e) => m_propertyWindow.Show(dockPanel);
        private void MenuItemToolbox_Click(object sender, System.EventArgs e) => m_toolbox.Show(dockPanel);
        private void MenuItemOutputWindow_Click(object sender, System.EventArgs e) => m_outputWindow.Show(dockPanel);
        private void MenuItemTaskList_Click(object sender, System.EventArgs e) => m_taskList.Show(dockPanel);
        private void MenuItemAbout_Click(object sender, System.EventArgs e) => new AboutDialog().ShowDialog(this);

        private DummyDoc CreateNewDocument()
        {
            DummyDoc dummyDoc = new DummyDoc();

            int count = 1;
            string text = $"Document{count}";
            while (FindDocument(text) != null)
            {
                count++;
                text = $"Document{count}";
            }

            dummyDoc.Text = text;
            return dummyDoc;
        }

        private void MenuItemNew_Click(object sender, System.EventArgs e)
        {
            DummyDoc dummyDoc = CreateNewDocument();
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                dummyDoc.MdiParent = this;
                dummyDoc.Show();
            }
            else
                dummyDoc.Show(dockPanel);
        }

        private void MenuItemOpen_Click(object sender, System.EventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog
            {
                InitialDirectory = Application.ExecutablePath,
                Filter = "rtf files (*.rtf)|*.rtf|txt files (*.txt)|*.txt|All files (*.*)|*.*",
                FilterIndex = 1,
                RestoreDirectory = true
            };

            if (openFile.ShowDialog() == DialogResult.OK)
            {
                string fullName = openFile.FileName;
                string fileName = Path.GetFileName(fullName);

                if (FindDocument(fileName) != null)
                {
                    MessageBox.Show("The document: " + fileName + " has already opened!");
                    return;
                }

                DummyDoc dummyDoc = new DummyDoc { Text = fileName };
                if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
                {
                    dummyDoc.MdiParent = this;
                    dummyDoc.Show();
                }
                else
                    dummyDoc.Show(dockPanel);
                try
                {
                    dummyDoc.FileName = fullName;
                }
                catch (Exception exception)
                {
                    dummyDoc.Close();
                    MessageBox.Show(exception.Message);
                }

            }
        }

        private void MenuItemFile_Popup(object sender, System.EventArgs e)
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                menuItemClose.Enabled =
                    menuItemCloseAll.Enabled =
                    menuItemCloseAllButThisOne.Enabled = (ActiveMdiChild != null);
            }
            else
            {
                menuItemClose.Enabled = (dockPanel.ActiveDocument != null);
                menuItemCloseAll.Enabled =
                    menuItemCloseAllButThisOne.Enabled = (dockPanel.DocumentsCount > 0);
            }
        }

        private void MenuItemClose_Click(object sender, System.EventArgs e)
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
                ActiveMdiChild.Close();
            else if (dockPanel.ActiveDocument != null)
                dockPanel.ActiveDocument.DockHandler.Close();
        }

        private void MenuItemCloseAll_Click(object sender, System.EventArgs e) => CloseAllDocuments();

        private void MainForm_Load(object sender, System.EventArgs e)
        {
            SetSchema(this.menuItemSchemaVS2013Blue, null);

            string configFile = Path.Combine(ConfigDir, "DockPanel.Config.xml");

            if (File.Exists(configFile))
                dockPanel.LoadFromXml(configFile, m_deserializeDockContent);
        }

        private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            string configFile = Path.Combine(ConfigDir, "DockPanel.Config.xml");
            if (m_bSaveLayout)
                dockPanel.SaveAsXml(configFile);
            else if (File.Exists(configFile))
                File.Delete(configFile);
        }

        private void MenuItemToolBar_Click(object sender, System.EventArgs e)
        {
            toolBar.Visible = menuItemToolBar.Checked = !menuItemToolBar.Checked;
        }

        private void MenuItemStatusBar_Click(object sender, System.EventArgs e)
        {
            statusBar.Visible = menuItemStatusBar.Checked = !menuItemStatusBar.Checked;
        }

        private void ToolBar_ButtonClick(object sender, System.Windows.Forms.ToolStripItemClickedEventArgs e)
        {
            if (e.ClickedItem == toolBarButtonNew)
                MenuItemNew_Click(null, null);
            else if (e.ClickedItem == toolBarButtonOpen)
                MenuItemOpen_Click(null, null);
            else if (e.ClickedItem == toolBarButtonSolutionExplorer)
                MenuItemSolutionExplorer_Click(null, null);
            else if (e.ClickedItem == toolBarButtonPropertyWindow)
                MenuItemPropertyWindow_Click(null, null);
            else if (e.ClickedItem == toolBarButtonToolbox)
                MenuItemToolbox_Click(null, null);
            else if (e.ClickedItem == toolBarButtonOutputWindow)
                MenuItemOutputWindow_Click(null, null);
            else if (e.ClickedItem == toolBarButtonTaskList)
                MenuItemTaskList_Click(null, null);
            /*else if (e.ClickedItem == toolBarButtonLayoutByCode)
                MenuItemLayoutByCode_Click(null, null);*/
            else if (e.ClickedItem == btBrowse)
                BtBrowse_Click(null, null);
        }

        private void MenuItemNewWindow_Click(object sender, System.EventArgs e)
        {
            MainForm newWindow = new MainForm(Args);
            newWindow.Text += " - New";
            newWindow.Show();
        }

        private void MenuItemTools_Popup(object sender, System.EventArgs e) => menuItemLockLayout.Checked = !this.dockPanel.AllowEndUserDocking;
        private void MenuItemLockLayout_Click(object sender, System.EventArgs e) => dockPanel.AllowEndUserDocking = !dockPanel.AllowEndUserDocking;

        /*private void MenuItemLayoutByCode_Click(object sender, System.EventArgs e)
        {
            dockPanel.SuspendLayout(true);

            CloseAllContents();

            CreateStandardControls();

            m_solutionExplorer.Show(dockPanel, DockState.DockRight);
            m_propertyWindow.Show(m_solutionExplorer.Pane, m_solutionExplorer);
            m_toolbox.Show(dockPanel, new Rectangle(98, 133, 200, 383));
            m_outputWindow.Show(m_solutionExplorer.Pane, DockAlignment.Bottom, 0.35);
            m_taskList.Show(m_toolbox.Pane, DockAlignment.Left, 0.4);

            DummyDoc doc1 = new DummyDoc { Text = "Document1" };
            DummyDoc doc2 = new DummyDoc { Text = "Document2" };
            DummyDoc doc3 = new DummyDoc { Text = "Document3" };
            DummyDoc doc4 = new DummyDoc { Text = "Document4" };
            doc1.Show(dockPanel, DockState.Document);
            doc2.Show(doc1.Pane, null);
            doc3.Show(doc1.Pane, DockAlignment.Bottom, 0.5);
            doc4.Show(doc3.Pane, DockAlignment.Right, 0.5);

            dockPanel.ResumeLayout(true, true);
        }

        private void SetSplashScreen()
        {
            
            _showSplash = true;
            _splashScreen = new SplashScreen();

            ResizeSplash();
            _splashScreen.Visible = true;
            _splashScreen.TopMost = true;

            Timer _timer = new Timer();
            _timer.Tick += (sender, e) =>
            {
                _splashScreen.Visible = false;
                _timer.Enabled = false;
                _showSplash = false;
            };
            _timer.Interval = 4000;
            _timer.Enabled = true;
        }

        private void ResizeSplash()
        {
            if (_showSplash) {
                
            var centerXMain = (this.Location.X + this.Width) / 2.0;
            var LocationXSplash = Math.Max(0, centerXMain - (_splashScreen.Width / 2.0));

            var centerYMain = (this.Location.Y + this.Height) / 2.0;
            var LocationYSplash = Math.Max(0, centerYMain - (_splashScreen.Height / 2.0));

            _splashScreen.Location = new Point((int)Math.Round(LocationXSplash), (int)Math.Round(LocationYSplash));
            }
        }*/

        private void CreateStandardControls()
        {
            m_solutionExplorer = new DummySolutionExplorer();
            m_propertyWindow = new DummyPropertyWindow();
            m_toolbox = new DummyToolbox();
            m_outputWindow = new DummyOutputWindow();
            m_taskList = new DummyTaskList();
        }

        private void MenuItemCloseAllButThisOne_Click(object sender, System.EventArgs e)
        {
            if (dockPanel.DocumentStyle == DocumentStyle.SystemMdi)
            {
                Form activeMdi = ActiveMdiChild;
                foreach (Form form in MdiChildren)
                {
                    if (form != activeMdi)
                        form.Close();
                }
            }
            else
            {
                foreach (IDockContent document in dockPanel.DocumentsToArray())
                {
                    if (!document.DockHandler.IsActivated)
                        document.DockHandler.Close();
                }
            }
        }

        private void MenuItemShowDocumentIcon_Click(object sender, System.EventArgs e)
        {
            dockPanel.ShowDocumentIcon = menuItemShowDocumentIcon.Checked = !menuItemShowDocumentIcon.Checked;
        }

        private void ShowRightToLeft_Click(object sender, EventArgs e)
        {
            CloseAllContents();
            if (showRightToLeft.Checked)
            {
                this.RightToLeft = RightToLeft.No;
                this.RightToLeftLayout = false;
            }
            else
            {
                this.RightToLeft = RightToLeft.Yes;
                this.RightToLeftLayout = true;
            }
            m_solutionExplorer.RightToLeftLayout = this.RightToLeftLayout;
            showRightToLeft.Checked = !showRightToLeft.Checked;
        }

        private void ExitWithoutSavingLayout_Click(object sender, EventArgs e)
        {
            m_bSaveLayout = false;
            Close();
            m_bSaveLayout = true;
        }

        #endregion

        private void MainForm_SizeChanged(object sender, EventArgs e)
        {
            //ResizeSplash();
        }

        public void ShowStatus(string message)
        {
            //throw new NotImplementedException();
        }

        //Update config from toolbar controls
        private void CbTableGroups_TextChanged(object sender, EventArgs e) => Conf.toolbar1.LastTableGroup = cbTableGroups.Text;
        private void CbTables_TextChanged(object sender, EventArgs e) => Conf.toolbar1.LastTable = cbTables.Text;
        private void TbParameter_TextChanged(object sender, EventArgs e) => Conf.toolbar1.LastFilter = tbParameter.Text;

        /*public bool IsVertical
        public bool IsMergeCells
        public bool IsRemoveNullLines 
        public bool IsMonitorClipboard
        public string ResultFormat */
    }
}