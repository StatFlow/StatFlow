﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Threading;

using NbTools;

namespace DataWalker
{
    internal static class Extensions
    {
        /*public static ImageSource ToImageSource(this string filename)
        {
            try
            {
                const int IconSize = 16;
                BitmapDecoder decoder = BitmapDecoder.Create(new Uri(filename, UriKind.Absolute), BitmapCreateOptions.None, BitmapCacheOption.OnDemand);
                return decoder.Frames.FirstOrDefault(f => f.Width == IconSize) ?? decoder.Frames.OrderBy(f => f.Width).First(); //Returns bitmap frame
            }
            catch (Exception ex)
            {
                throw new Exception($"Can't load an icon from the file: '{filename}'", ex);
            }
        }*/
    }

    interface IUiCallback
    {
        void ShowStatus(string message);
    }



    public class ComboBoxController
    {
        private readonly ToolStripComboBox fCb;
        private readonly List<string> fFullList;
        private readonly DispatcherTimer fTimer;
        private bool KeyDownPressed = false;

        public ComboBoxController(ToolStripComboBox cb, IEnumerable<string> items)
        {
            fCb = cb;
            /*fCb.IsTextSearchCaseSensitive = false;
            fCb.IsTextSearchEnabled = true;
            fCb.IsEditable = true;*/

            fCb.KeyUp += FCb_KeyUp;
            fCb.GotFocus += FCb_GotFocus;

            fFullList = new List<string>();
            foreach (var str in items)
            {
                fCb.Items.Add(str);
                fFullList.Add(str);
            }

            fTimer = new DispatcherTimer();
            fTimer.Tick += FTimer_Tick; ;
            fTimer.Interval = new TimeSpan(0, 0, 0, 0, 500);
        }

        private void FCb_GotFocus(object sender, EventArgs e)
        {
            KeyDownPressed = false;
            fCb.Items.Clear();
            foreach (var str in fFullList)
                fCb.Items.Add(str);
        }

        private void FTimer_Tick(object sender, EventArgs e)
        {
            var toSearch = fCb.Text.Trim();
            if (!String.IsNullOrEmpty(toSearch) && !KeyDownPressed)
            {
                fCb.Items.Clear();
                foreach (var str in String.IsNullOrEmpty(toSearch) ? fFullList : fFullList.Where(s => s.ContainsIC(toSearch)))
                    fCb.Items.Add(str);

                //fCb.IsDropDownOpen = true;
            }
            fTimer.Stop();
        }



        private void FCb_KeyUp(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.Down:
                    KeyDownPressed = true;
                    break;
                case Keys.Enter:
                    /*var element = e.OriginalSource as UIElement;
                    if (element != null)
                        element.MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));*/
                    break;
            }

            //Debug.WriteLine($"Text: {fCb.Text}, IsFocused: {fCb.IsFocused}, ISKeybFocused {fCb.IsKeyboardFocused}, IsKeyboardFocusWithin: {fCb.IsKeyboardFocusWithin}");
            fTimer.Start();
        }
    }
}
