﻿using DataWalker.Xml;
using NbCollV1;
using NbOrm.Nbq;
using NbOrm.Xml;
using NbTools;
using NbTools.Collections;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace DataWalker
{
    /// <summary>
    /// Represents the data received from the query supports two formats:
    /// Recodset - Contains DfDynamicCollection with the data read from the database
    /// File     - Text information read from the file (or blob text)
    /// </summary>
    internal abstract class QueryResult
    {
        public readonly string Query;
        public readonly QueryTypeBase QueryType;

        public QueryResult(string query, QueryTypeBase qType)
        {
            Query = query;
            QueryType = qType;
        }

        protected const string noRec = "The request returned no records";

        /// <summary>
        /// 
        /// </summary>
        /// <param name="qOutFormat"></param>
        /// <returns>The string with content or link to local file and the boolean val, if true - treat string as Uri</returns>
        internal abstract Tuple<string, string, bool> Format(DfExportFormat qOutFormat, DirectoryInfo iconDir);

        public static void WriteFullHtml(TextWriter wrtr, string title, Action<INbTag> tagsWithinBody)
        {
            wrtr.WriteLine("<!doctype html>");
            var myT = NbTag.Create(wrtr).TT("html", t => t
                .TT("head", t1 => t1
                     ["title", title]
                     .TA("meta", a => a["charset"] = "utf-8")
                     .TV("style", NbExt.GetEmbeddedResourceTextFile("NbTools.Css.css"), encode: false)
                    //.TAV("script", a1 => a1["type", "text/javascript"]["language"] = "javascript", FileInOneLine(@"Data\JavaScript.js"), encode: false)
                    )
                .TT("body", tagsWithinBody)
                );
        }
    }


    internal class QueryResultRecordset : QueryResult
    {
        public readonly DfDynamicCollection Data;
        public readonly DfTable Layout;
        public readonly recordset Recordset;

        public QueryResultRecordset(string query, QueryTypeBase qType, DfDynamicCollection data, recordset aRecSet, DfTable layout)
            : base(query, qType)
        {
            Data = data ?? throw new ArgumentException("DfDynamicCollection in QueryResultRecordset is not provided");
            Recordset = aRecSet ?? throw new ArgumentException("recordset in QueryResultRecordset is not provided");
            Layout = layout;
        }

        internal override Tuple<string, string, bool> Format(DfExportFormat qOutFormat, DirectoryInfo iconDir)
        {
            if (Data != null && Recordset != null)
            {
                var exp = new DfExportHtml(Data, Layout, iconDir);
                if (qOutFormat.isTableOnly)
                {
                    var (html, css) = exp.ExportTableOnly(qOutFormat);
                    return Tuple.Create(html, css, false);
                }
                else
                {
                    var htmlStr = exp.ExportHtml(qOutFormat, "Title", Query);
                    return Tuple.Create(htmlStr, String.Empty, false);
                }
            }
            else
            {
                using StringWriter wrtr = new StringWriter();
                WriteFullHtml(wrtr, noRec, t => t.TV("p", noRec).TV("p", noRec));
                var htmlStr = wrtr.ToString();
                return Tuple.Create(htmlStr, String.Empty, false);
            }
            
        }
    }

    internal class QueryResultFile : QueryResult
    {
        public readonly string StringN;

        public QueryResultFile(string query, QueryTypeBase qType, string str)
            : base(query, qType)
        {
            StringN = str;
        }

        internal override Tuple<string, string, bool> Format(DfExportFormat qOutFormat, DirectoryInfo iconDir)
        {
            using StringWriter wrtr = new StringWriter();
            switch (QueryType.NbqType)
            {
                case NbqQueryType.nbsql:
                    var sqlText = System.Net.WebUtility.HtmlEncode(StringN); //Encode before converting \r\n
                    sqlText = sqlText.Replace("\r\n", "</br>\r\n");
                    WriteFullHtml(wrtr, Query, t => t.TV("p", Query).TV("p", sqlText, encode: false));
                    return Tuple.Create(wrtr.ToString(), String.Empty, false);

                case NbqQueryType.nbblob:
                    const string properXmlHeader = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
                    const string tempFile = @"C:\Temp\DataWalker.xml";

                    if (StringN.StartsWith("<?xml"))
                    {
                        var s = Regex.Replace(StringN, @"\<\?xml.+encoding=\""(utf-16)\""\?\>", properXmlHeader); //IExplorer can't handle uft-16
                        File.WriteAllText(tempFile, s);
                        return Tuple.Create(tempFile, String.Empty, true); //Treat as Uri
                    }
                    else if (StringN.StartsWith("<event")) //Event xmls without xml header
                    {
                        File.WriteAllText(tempFile, properXmlHeader + Environment.NewLine + StringN);
                        return Tuple.Create(tempFile, String.Empty, true); //Treat as Uri
                    }
                    else
                        return Tuple.Create(StringN, String.Empty, false); //Html is returned

                default:
                    throw new NbExceptionInfo($"Unsupported query type {QueryType}");
            }
        }
    }

    /// <summary>
    /// Query Manager manages history of abstract queries QueryResult (QueryResultRecordset, QueryResultFile)
    /// It determines the QueryType by the given Uri's protocol (QueryTypeSqlData, QueryTypeSqlText, QueryTypeSqlBlob, QueryTypeSqlDgml, QueryTypeCsv_
    /// </summary>                                                                                                              
    internal class QueryManager
    {
        private readonly model fMod;
        private readonly layout_info fLayoutTables;
        internal readonly List<QueryResult> history = new List<QueryResult>();
        internal int CurrentPositionInHistory = -1;
        private readonly SortedList<string, List<recordset>> tableGroups;

        public IList<string> TableGroups => tableGroups.Keys;
        internal List<recordset> GetTableGroup(string tblGroupName) => tableGroups[tblGroupName];

        internal QueryManager(model mod, layout_info htmlLayout)
        {
            fMod = mod;
            fLayoutTables = htmlLayout;
            tableGroups = new SortedList<string, List<recordset>>(StringComparer.OrdinalIgnoreCase);
            foreach (var tables in fMod.tables.Safe())
            {
                var groupName = tables.group ?? tables.conn_name;
                if (!tableGroups.TryGetValue(groupName, out List<recordset> list))
                {
                    list = new List<recordset>();
                    tableGroups.Add(groupName, list);
                }

                foreach (var table in tables.Items.Safe())
                {
                    list.Add(table);
                }

                list.Sort((x, y) => String.Compare(x.name, y.name, true));
            }

            //Get custom Sql providers with reflection
            var customSqlProviders = new Dictionary<string, CustomSqlProvider>();
            var customCollectionProviders = new Dictionary<string, CustomCollectionProvider>();
            foreach (Type mytype in System.Reflection.Assembly.GetExecutingAssembly().GetTypes()
                .Where(mytype => mytype.GetInterfaces().Contains(typeof(ICustomSqlProviderList))))
            {
                var list = (ICustomSqlProviderList)Activator.CreateInstance(mytype);
                foreach (var pair in list.Items())
                    customSqlProviders.Add(pair.Item1, pair.Item2);
                foreach (var pair in list.CollectionProviders())
                    customCollectionProviders.Add(pair.Item1, pair.Item2);

            }

            foreach (var view in fMod.tables.SelectMany(ts => ts.Items.Safe()).OfType<view>())
            {
                view.fXmlSql = view.sql;
                if (view.fXmlSql == null) //If no SQL given - look for the C# function
                {
                    if (!customSqlProviders.TryGetValue(view.name, out view.fCustSql))
                        throw new Exception($"View '{view.name}' doesn't have sql in xml and the custom sql provider function was not found");
                }
            }

            foreach (var exp in fMod.tables.SelectMany(ts => ts.Items.Safe()).OfType<file_data>())
            {
                customCollectionProviders.TryGetValue(exp.name, out exp.fCustColl);
                //throw new Exception($"Export '{exp.name}' doesn't have sql in xml and the custom sql provider function was not found");
            }
        }

        internal IEnumerable<string> OrderedNames => fMod.tables.OrderBy(ts => ts.conn_name).SelectMany(ts => ts.Items.Safe().Select(t => t.name).OrderBy(t => t));

        internal recordset this[string aName]
        {
            get
            {
                var rec = fMod.tables.SelectMany(ts => ts.Items.Safe()).SingleOrDefault(q => q.name.Equals(aName, StringComparison.OrdinalIgnoreCase));
                if (rec == null)
                    throw new Exception($"Recordset '{aName}' is not found in collection"); //TODO: IMplement the code to handle complex requests
                else
                    return rec;
            }
        }

        /// <summary>
        /// Loads report from the database, keeps the table transposer or the string with sql or blob. Does not deal with text or html formatting. Call only when you need to reload from Db
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="env"></param>
        /// <param name="qOutFormat"></param>
        /// <param name="CreateHistoryRec"></param>
        /// <returns></returns>
        internal QueryResult LoadDataForUri(NbqQueryType qType, string query, configEnvironment env, int maxRows = 100)
        {
            if (query == null)
                throw new NbExceptionInfo("Query string was not provided");

            var qType2 = QueryTypeBase.ByQType(qType);
            QueryResult qr = qType2.GetQueryResult(query, env, fMod, fLayoutTables);
            return qr;
        }

        internal void PushToHistory(QueryResult fCurrentQueryResult)
        {
            if (CurrentPositionInHistory < history.Count - 1) //We are not on the last entry
                history.RemoveRange(CurrentPositionInHistory + 1, history.Count - CurrentPositionInHistory - 1);

            history.Add(fCurrentQueryResult);
            CurrentPositionInHistory = history.Count - 1;
        }

        internal enum NavDirection { Back, Forward, Refresh };
        internal bool Can(NavDirection dir) => true; //TODO: Implement

        internal QueryResult GetFromHistoryN(NavDirection dir, DfExportFormat runPar, configEnvironment env, bool reloadFromDb)
        {
            switch (dir)
            {
                case NavDirection.Back:
                    if (CurrentPositionInHistory - 1 >= 0 && CurrentPositionInHistory - 1 < history.Count)
                        return history[--CurrentPositionInHistory];
                    break;
                case NavDirection.Forward:
                    if (CurrentPositionInHistory + 1 >= 0 && CurrentPositionInHistory + 1 < history.Count)
                        return history[++CurrentPositionInHistory];
                    break;
                case NavDirection.Refresh:
                    if (CurrentPositionInHistory >= 0 && CurrentPositionInHistory < history.Count)
                    {
                        if (reloadFromDb)
                        {
                            QueryResult qRes = history[CurrentPositionInHistory];
                            return LoadDataForUri(qRes.QueryType.NbqType, qRes.Query, env);
                        }
                        else
                            return history[CurrentPositionInHistory];
                    }
                    break;
                default:
                    throw new NbExceptionInfo($"Unsupported navigation diretion: {dir}"); ;
            }
            return null;
        }
    }
}
