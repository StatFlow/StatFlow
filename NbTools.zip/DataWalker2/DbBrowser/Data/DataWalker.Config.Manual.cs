﻿using System;
using System.Linq;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Xml.Serialization;
using NbTools;
using NbOrm.Xml;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using NbOrm.Nbq;
using System.Collections.Generic;

namespace DataWalker.Xml
{
    public partial class config : INbConnGetter
    {
        private static readonly Lazy<XmlSerializer> ser = new Lazy<XmlSerializer>(() => new XmlSerializer(typeof(config)));
        public configEnvironment Env(string name) => environments.SingleVerbose(en => en.name == name, () => $"Can't find environment '{name}'", i => $"{i} environments with the name '{name}' found");
        public configEnvironment EnvSelected => environments.SingleVerbose(en => en.selected, () => $"There are no selected environments", i => $"{i} environments are selected");

        private static string cName;
        public static config Load(string configName)
        {
            cName = configName;
            try
            {
                using var rdr = new StreamReader(cName);
                var conf = (config)ser.Value.Deserialize(rdr);
                if (conf.toolbar1 == null)
                    conf.toolbar1 = new configToolbar1();
                return conf;
            }
            catch (Exception ex)
            { throw new Exception($"Error deserializing '{cName}'", ex); }
        }

        public void Save()
        {
            try
            {   //Save to temp to keep original file in case of exception while saving
                string tmpFile = cName + ".tmp";
                using (var wrtr = new StreamWriter(tmpFile))
                    ser.Value.Serialize(wrtr, this);

                File.Delete(cName);
                File.Move(tmpFile, cName);
            }
            catch (Exception ex)
            { throw new Exception($"Error serilizing config into '{cName}'", ex); }
        }

        public string QueryNameByShortcut(string shortCut) => toolbar2.Safe().SingleOrDefault(q => shortCut.Equals(q.shortcut, StringComparison.OrdinalIgnoreCase))?.name;

        internal void CloseConnections()
        {
            foreach (var env in environments.Safe())
                env.CloseConnections();
        }

        public INbConn GetConnection(string envName, string connName) => Env(envName).GetNbConnection(connName);
    }

    public partial class QuerySnapshot
    {
#pragma warning disable CS0414,IDE0052
        [XmlIgnore]
        private recordset fRecSet;
#pragma warning restore CS0414,IDE0052


        public static QuerySnapshot FromRecordset(recordset rc)
        {
            var parEnum = rc switch
            {
                view vw => vw.Parameters,
                _ => rc.Fields,
            };
            var ret = new QuerySnapshot() { fRecSet = rc, name = rc.name };
            ret.param = parEnum.Select(p => new QuerySnapshotParameter()
            {
                name = p.name,
                SearchType = model.CtypeToSearchType(p.GetCType())
            }).Where(p => p.SearchType != SearchTypes.none).ToArray();

            return ret;
        }

        public override string ToString() => $"{name}({param?.Length ?? 0})";

        internal List<NbqInParameter> GetNbqParameters() => this.param.Safe().Where(p => !String.IsNullOrEmpty(p.value)).Select(p => new NbqInParameter()
        {
            Name = p.name,
            Value = p.value,
            searchType = p.SearchType,
            //TODO; determine order here
        }).ToList();

    }

    public partial class QuerySnapshotParameter
    {
        [XmlIgnore]
        public SearchTypes SearchType { get; internal set; }

        public override string ToString() => $"{name}='{value}'";
    }

    public partial class configEnvironment
    {
        internal void OpenConnections(IUiCallback ui) => Parallel.ForEach(connection, c => c.Open(this, ui));
        internal void CloseConnections() => Parallel.ForEach(connection, c => c.Close(this));
        internal INbConn GetNbConnection(string name) => connection.Single(c => c.name.EqIC(name)).NbConnection;
    }

    public partial class configToolbar1 : INotifyPropertyChanged
    {
        [XmlIgnore]
        public bool IsVertical { get { return vertical; } set { vertical = value; NotifyPropertyChanged(); } }
        [XmlIgnore]
        public bool IsMergeCells { get { return merge_cells; } set { merge_cells = value; NotifyPropertyChanged(); } }
        [XmlIgnore]
        public bool IsRemoveNullLines { get { return remove_null_lines; } set { remove_null_lines = value; NotifyPropertyChanged(); } }
        [XmlIgnore]
        public bool IsMonitorClipboard { get; set; } = false; //Do not save monitor clipboard in the config - it's irritating
        [XmlIgnore]
        public string LastFilter { get { return last_filter; } set { last_filter = value; NotifyPropertyChanged(); } }
        [XmlIgnore]
        public string LastTableGroup { get { return last_table_group; } set { last_table_group = value; NotifyPropertyChanged(); } }
        [XmlIgnore]
        public string LastTable { get { return last_table; } set { last_table = value; NotifyPropertyChanged(); } }
        [XmlIgnore]
        public string ResultFormat { get { return result_format; } set { result_format = value; NotifyPropertyChanged(); } }

        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged([CallerMemberName] string propertyName = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public partial class Connection
    {
        private INbConn nbConn;
        private readonly object lck = new object();

        public INbConn NbConnection
        {
            get { lock (lck) { return nbConn; } }
        }

        internal void Open(configEnvironment env, IUiCallback ui)
        {
            var conStr = conn_string;
            if (String.IsNullOrEmpty(conStr))
            {
                if (String.IsNullOrEmpty(conn_file))
                    throw new Exception($"Neither conn_string nor conn_file specified for connection {name}, environment {env.name}");

                if (!File.Exists(conn_file))
                    throw new Exception($"Connection file {conn_file} doesn't exist. Connection {name}, environment {env.name}");

                conStr = File.ReadAllText(conn_file);
            }

            try
            {
                lock (lck)
                {
                    //App.Log.Info($"Connecting to {type} Connection {name}, environment {env.name}");
                    ui.ShowStatus($"Connecting to {type} Connection {name}, environment {env.name}");

                    INbConn cn;
                    switch (type)
                    {
                        case ConnectionType.oracle: cn = new NbOrm.Ora.NbOraConn(conStr); break;
                        case ConnectionType.mssql: cn = new NbOrm.Ms.NbMsConn(conStr); break;
                        default:
                            throw new Exception($"Unsupported connection type: {type}");
                    }
                    nbConn = cn;
                }
                ui.ShowStatus($"Opened: {type} Connection {name}, environment {env.name}");
                //App.Log.Info($"Opened: {type} Connection {name}, environment {env.name}");
            }
            catch (Exception ex)
            {
                ui.ShowStatus($"Failed to connect: {ex.Message}");
                //App.Log.Exception($"Failed to connect to Oracle Connection {name}, environment {env.name}", ex);
                throw new Exception($"Error opening connection {name}, environment {env.name}", ex);
            }
        }

        internal void Close(configEnvironment env)
        {
            lock (lck)
            {
                if (nbConn != null)
                {
                    nbConn.Dispose();
                    nbConn = null;
                    Debug.WriteLine($"Closed: Oracle Connection {name}, environment {env.name}");
                }
            }
        }
    }
}
