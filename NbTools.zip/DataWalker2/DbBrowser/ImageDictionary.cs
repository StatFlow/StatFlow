﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace NbTools.Graphics
{
    public class ImageDictionary
    {
        private const int IconSize = 16;
        public readonly DirectoryInfo Dir;
        /*private readonly Dictionary<string, ImageSource> _dict;
        private readonly ImageSource _defaultImg;

        private static readonly string[] graphicalExtesions = new string[] { ".ico", ".png", ".gif", ".bmp" };*/

        public ImageDictionary(string path)
        {
            Dir = new DirectoryInfo(path);
            if (!Dir.Exists)
                throw new NbException($"Can't find image directory '{Dir.FullName}'");

            //_dict = new Dictionary<string, ImageSource>(StringComparer.OrdinalIgnoreCase);
            //defaultImg = Base2BitmapFrame(defaultIconBase64);
        }


        /*public ImageSource this[string str]
        {
            get
            {
                if (String.IsNullOrWhiteSpace(str))
                    return _defaultImg;

                if (!_dict.TryGetValue(str, out ImageSource img))
                {
                    FileInfo fi = Dir.GetFiles(str + ".*").Where(f => graphicalExtesions.Contains(f.Extension, StringComparer.OrdinalIgnoreCase)).FirstOrDefault();
                    if (fi != null)
                    {
                        //img = new BitmapImage(new Uri(fi.FullName, UriKind.Absolute));
                        BitmapDecoder decoder = BitmapDecoder.Create(new Uri(fi.FullName, UriKind.Absolute), BitmapCreateOptions.None, BitmapCacheOption.OnDemand);
                        img = decoder.Frames.FirstOrDefault(f => f.Width == IconSize) ?? decoder.Frames.OrderBy(f => f.Width).First(); //Returns bitmap frame
                        _dict.Add(str, img);
                    }
                    else
                    {
                        img = _defaultImg;
                        _dict.Add(str, _defaultImg);
                    }
                }
                return img;
            }
        }

        public ImageSource GetN(string str)
        {
            if (String.IsNullOrWhiteSpace(str))
                return null;

            if (!_dict.TryGetValue(str, out ImageSource img))
            {
                FileInfo fi = Dir.GetFiles(str + ".*").Where(f => graphicalExtesions.Contains(f.Extension, StringComparer.OrdinalIgnoreCase)).FirstOrDefault();
                if (fi != null)
                {
                    //img = new BitmapImage(new Uri(fi.FullName, UriKind.Absolute));
                    BitmapDecoder decoder = BitmapDecoder.Create(new Uri(fi.FullName, UriKind.Absolute), BitmapCreateOptions.None, BitmapCacheOption.OnDemand);
                    img = decoder.Frames.FirstOrDefault(f => f.Width == IconSize) ?? decoder.Frames.OrderBy(f => f.Width).First(); //Returns bitmap frame
                    _dict.Add(str, img);
                }
                else
                    return null;
            }
            return img;
        }

        internal void AddBase64Image(string id, string base64) => _dict.Add(id, Base2BitmapFrame(base64));

        internal BitmapFrame Base2BitmapFrame(string base64) //: BitmapSource : ImageSource
        {
            byte[] data = Convert.FromBase64String(base64);
            using (MemoryStream stream = new MemoryStream(data))
            {
                BitmapDecoder decoder = BitmapDecoder.Create(stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
                return decoder.Frames.SingleOrDefault(f => f.Width == IconSize) ?? decoder.Frames.OrderBy(f => f.Width).First(); //Returns bitmap frame
            }
        }*/

        private const string defaultIconBase64 =
            @"iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhk
iAAAAAlwSFlzAAABuwAAAbsBOuzj4gAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3Nj
YXBlLm9yZ5vuPBoAAAEqSURBVHjalVO7ToRAFL0zPH7DxtpmP8RE+UwsqPkDtyFY
aGGhJTWZ5c3duweRcSaQeJKTO2FyHjeAYmZSSt0R0Yn+h1K0nyEtOLVt99L3nZhp
IQkVSLfpKMMwpCiKnuUIA6DrOjIXQ1oHFAQaYo8E4Lzi10BpJcJADPTCm0CmJcbc
M4BAhBYhxnNnHdz5DX4MglW8tcC00sFdA5u+GPPYQDkmfirgGxD2BbcGfu2DBsuF
I/QNmHm3gf3aPPE0TTQMA2Ycx+w32Fq4hKiua6qqCg2LojgT0btd6Um+RG6ahvu+
Z0nicRxZhKAxhsuyxMyy7IuIHoT4j7S9ggtJR4CY4Zzn+XeSJI9y9caCPw3GafKS
53nGbNt2TtP01U5euf7O97g8BHb+QLKFK96fqCUWf/oCAAAAAElFTkSuQmCC";
    }
}
