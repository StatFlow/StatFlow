﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

using NbTools;
using NbTools.Collections;
using NbOrm.Nbq;

using DataWalker.Xml;
using NbTools.Graphics;
using NbHtmlGen;

namespace DataWalker2.DbBrowser
{
    partial class DbBrowser : DockContent, ICommandExecutor
    {
        private readonly config Conf;
        private readonly ImageDictionary Icons;
        private readonly QueryManager QueryMgr;

        internal DbBrowser(config conf, ImageDictionary icons, QueryManager qMgr)
        {
            InitializeComponent();
            AutoScaleMode = AutoScaleMode.Dpi;
            Conf = conf;
            Icons = icons;
            QueryMgr = qMgr;

            //QueryBuilder = new QueryBuilder(); //Query builder in the dialog window
            //QueryBuilder.QuerySnapshotChanged += QueryBuilder_QuerySnapshotChanged;
        }

        //private model Model;
        //private layout_info HtmlLayout;

        internal QueryResult fCurrentQueryResult;
        //internal ComboBoxController fCbc;
        //private readonly QueryBuilder QueryBuilder;

        private void DbBrowser_Load(object sender, EventArgs e)
        {
        }
        
        private void Rb_CheckedChanged(object sender, EventArgs e)
        {
      
        }


        /*private void Conn_Checked(object sender)
        {
            var env = Conf.Env(sender.CastVerbose<RadioButton>().Name);
            env.selected = true;
            Task.Run(() => env.OpenConnections(this)); //As Ui callback
        }

        private void Conn_Unchecked(object sender)
        {
            var env = Conf.Env(sender.CastVerbose<RadioButton>().Name);
            env.selected = false;
            Task.Run(() => env.CloseConnections());
        }

        private void Toolbar1_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (Model == null)
                return;

            switch (e.PropertyName)
            {
                case nameof(configToolbar1.LastTable):
                    var recSetName = Conf.toolbar1.LastTable;
                    if (String.IsNullOrEmpty(recSetName))
                    {
                        //QueryBuilder.QuerySnapshot = null;
                        return;
                    }

                    var recSet = Model.GetRecordset(recSetName);
                    var qSnap = QuerySnapshot.FromRecordset(recSet);
                    //QueryBuilder.QuerySnapshot = qSnap;
                    break;
            }

        }*/

        private void QueryBuilder_QuerySnapshotChanged(QuerySnapshot qs)
        {
            try
            {
                List<NbqInParameter> nbqPar = qs.GetNbqParameters();
                var uri = NbqUriBuilder.Build(qs.name, nbqPar, NbqQueryType.nbquery);
                //LoadDataForUri(uri);
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void TbParameter_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                /*if (e.Key == Key.Enter)
                {
                    var tbl = cbTables.SelectedItem as string;
                    var uri = NbqUriBuilder.Build(tbl, tbParameter.Text, NbqQueryType.nbquery);
                    LoadDataForUri(uri);
                }*/
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void Window_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                //None = 0, Alt = 1, Control = 2 ,Shift = 4, Windows = 8
                /*if (e.KeyboardDevice.Modifiers != 0)
                {
                    var str = $"{e.KeyboardDevice.Modifiers.ToString()}, {e.Key.ToString()}";
                    var qName = Conf.QueryNameByShortcut(str);
                    if (qName == null)
                    {
                        ShowStatus($"Shortcut {str} is not mapped to anything");
                        return;
                    }

                    var uri = NbqUriBuilder.Build(qName, tbParameter.Text, NbqQueryType.nbquery);
                    LoadDataForUri(uri);
                }*/
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            statusTimer?.Stop();
            //QueryBuilder?.Close();
        }

        private void WebControl_Navigating(object _) //TODO: pass nbquery and nbsql as parameters when building URI
        {
            /*if (e.Uri != null)
            {
                if (e.Uri.Scheme.StartsWith("nbhttp"))
                {
                    Process.Start(@"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", '"' + e.Uri.ToString().Substring(2) + '"');
                    e.Cancel = true;
                }
                else if (NbqParser.IsSupportedQueryType(e.Uri))
                {
                    e.Cancel = true;
                    LoadDataForUri(e.Uri);
                }
            }*/
        }


        /// <summary>
        /// This is where the window receives the uri from the singleton manager in the main window
        /// Executes the sql request by given Uri asynchronosly and displays in on the web control, updating the status message in the process
        /// </summary>
        /// <param name="uri"></param>
        /// <param name="runPar"></param>
        /// <param name="saveToNavHistory"></param>
        /*internal async void LoadDataForUri(Uri uri)
        {
            ShowStatus($"Loading {uri.LocalPath.TrimStart('/')}");

            try
            {
                var qRes = await Task.Run(() => QueryMgr.LoadDataForUri(uri, Conf.EnvSelected)); //Always save to history
                if (qRes == null)
                    return;

                fCurrentQueryResult = qRes;
                QueryMgr.PushToHistory(fCurrentQueryResult);
                NavToQueryResult();
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }

            ShowStatus($"{uri.LocalPath.TrimStart('/')}");
        }*/

        public void ShowQueryResult(QueryResultRecordset qrr)
        {
            throw new NotImplementedException();
        }

        internal void ShowQueryResult(QueryResult qRes)
        {
            if (qRes == null)
                return;

            try
            {
                fCurrentQueryResult = qRes;
                QueryMgr.PushToHistory(fCurrentQueryResult);
                NavToQueryResult();
            }
            catch (Exception ex)
            { MessageBox.Show(NbException.Exception2String(ex)); }
        }

        private void CbTableGroups_SelectionChanged(object _/*, SelectionChangedEventArgs e*/)
        {
            /*if (cbTableGroups.SelectedIndex == -1)
                return;

            var list = QueryMgr.GetTableGroup(cbTableGroups.SelectedValue.ToString());
            cbTables.Items.Clear();
            foreach (var rc in list)
                cbTables.Items.Add(rc.name);
            cbTables.SelectedIndex = 0;*/
        }

        private void Navigate(QueryManager.NavDirection navDir, bool reloadFromDb = false)
        {
            if (QueryMgr == null) //If on Window_loaded fails
                return;

            fCurrentQueryResult = QueryMgr.GetFromHistoryN(navDir, Conf, Conf.EnvSelected.name, reloadFromDb);
            if (fCurrentQueryResult == null)
                return;
            NavToQueryResult();
        }

        private void NavToQueryResult()
        {
            var (html, _, treatAsUri) = fCurrentQueryResult.Format(CurrentQueryFormat, Icons.Dir);
            if (treatAsUri) //Treat as Uri
                webControl.Navigate(new Uri(html));
            else
            {
                //webControl.Navigate(pair.Item1);  //NavigateToString

                //https://stackoverflow.com/questions/5362591/how-to-display-the-string-html-contents-into-webbrowser-control
                webControl.DocumentText = "0";
                webControl.Document.OpenNew(true);
                webControl.Document.Write(html);
                webControl.Refresh();
            }
        }

        private void NavigateBack_Exec(object _) => Navigate(QueryManager.NavDirection.Back);
        //private void NavigateBack_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Back) ?? false;

        //private void NavigateForward_Exec(object sender, ExecutedRoutedEventArgs e) => Navigate(QueryManager.NavDirection.Forward);
        //private void NavigateForward_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Forward) ?? false;

        //private void NavigateRefresh_Exec(object sender, ExecutedRoutedEventArgs e) => Navigate(QueryManager.NavDirection.Refresh, reloadFromDb: true); //Only reload from db by command
        //private void NavigateRefresh_Exec(object sender, ExecutedRoutedEventArgs e) => BtQueryUrl_Click(null, null); //Only reload from db by command

        //private void NavigateRefresh_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Refresh) ?? false;

        //private void NavigateRefresh(object sender, RoutedEventArgs e) { Navigate(QueryManager.NavDirection.Refresh); } //Quick refresh, without reloading from DB

        private DfExportFormat CurrentQueryFormat => new DfExportFormat //Think about simplifying
        {
            Format = DfExportFormat.Formats.Html,
            isMergeCells = true, //btMergeCells.IsChecked ?? false,
            isVertical = true, //btVertical.IsChecked ?? false,
            isRemoveNullColumns = true, //btNullLines.IsChecked ?? false
        };

        public void CmdSave()
        {
            if (fCurrentQueryResult == null)
                return;

            var dlg = new SaveFileDialog
            {
                Filter = "Html file (*.html)|*.html|Text file (*.txt)|*.txt",
                FileName = NbExt.LegalizeForFilename(fCurrentQueryResult.Query, 248) + ".html"
            };
            //TODO: save current dir
            if (dlg.ShowDialog() == DialogResult.OK)
            {   //TODO: support the saving of BLOBs
                File.WriteAllText(dlg.FileName, fCurrentQueryResult.Format(CurrentQueryFormat, Icons.Dir).Item1); //Reformat for saving
            }
        }

        //private void CommandSave_Can(object sender, CanExecuteRoutedEventArgs e) => e.CanExecute = QueryMgr?.Can(QueryManager.NavDirection.Refresh) ?? false;



        // Status message


        private Timer statusTimer = null;

        delegate void StatusInvoker(string mess);
        public void ShowStatus(string message)
        {
            if (InvokeRequired) // CheckAccess returns true if you're on the dispatcher thread
            {
                Invoke(new StatusInvoker(ShowStatus), message);
                return;
            }

            if (statusTimer == null)
            {
                statusTimer = new Timer();
                statusTimer.Tick += StatusTimer_Tick;
                statusTimer.Interval = 5;
            }

            statusTimer.Stop(); //If previous timer is still going
            //tbStatus.Text = message;
            statusTimer.Start();
        }

        private void StatusTimer_Tick(object sender, EventArgs e)
        {
            //tbStatus.Text = String.Empty;
            statusTimer.Stop();
        }


        private Timer clipboardTimer = null;
        private string clipboardText;

        private void BtMonitorClipboard_Checked(object _)
        {
            bool turnOn = /*sender.CastVerbose<CheckBox>().IsChecked ??*/ false;
            if (turnOn)
            {
                if (clipboardTimer == null)
                {
                    clipboardTimer = new Timer();
                    clipboardTimer.Tick += ClipboardTimer_Tick;
                    clipboardTimer.Interval = 1;
                }

                clipboardText = ClipText(); //Don't jump on the value already in the clipboard
                clipboardTimer.Start();
            }
            else
            {
                clipboardTimer.Stop();
            }
        }

        private void ClipboardTimer_Tick(object sender, EventArgs e)
        {
            var newText = ClipText();
            if (newText.Equals(clipboardText))
                return;

            clipboardText = newText;
            if (String.IsNullOrWhiteSpace(newText)) //Don't use empty text as a new value
                return;

            /*tbParameter.Text = clipboardText;
            var tbl = cbTables.SelectedItem as string;
            var uri = NbqUriBuilder.Build(tbl, tbParameter.Text, NbqQueryType.nbquery);*/
            //LoadDataForUri(null/*uri*/);

        }

        private static string ClipText()
        {
            var str = Clipboard.GetText();
            int ind = str.IndexOf('\r');
            if (ind > 0)
                str = str.Substring(0, ind);
            return str.Trim();
        }
    }
}
