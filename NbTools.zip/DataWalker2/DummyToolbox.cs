namespace DataWalker2
{
    public partial class DummyToolbox : ToolWindow
    {
        public DummyToolbox()
        {
            InitializeComponent();
        }
    }
}