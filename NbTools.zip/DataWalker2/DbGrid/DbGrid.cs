﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using WeifenLuo.WinFormsUI.Docking;
using NbTools;
using DataWalker;
using System.Reflection;
using NbCollV1;
using NbTools.Collections;

namespace DataWalker2.DbGrid
{
    public partial class DbGrid : DockContent, ICommandExecutor
    {
        private List<Tuple<IDfColumnBase, DfField>> OrderedColsN;
        private QueryResultRecordset QueryResultN;

        public DbGrid()
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            InitializeComponent();
            SetDoubleBuffering();
        }


        /// <summary>
        /// Doesnt' take the base class for QueryResult base, because it can only show the data grid 
        /// </summary>
        /// <param name="qrr"></param>
        void ICommandExecutor.ShowQueryResult(QueryResultRecordset qrr)
        {
            QueryResultN = qrr;
            grid1.Columns.Clear();
            grid1.Rows.Clear();

            if (qrr?.Layout?.fields?.Items == null)
                throw new Exception($"Layout for {qrr.Query} is empty");

            OrderedColsN = qrr.Data.ColumnsOrdererByLayout().ToList();
            foreach(var pair in OrderedColsN)
            {
                //Has to be exact type of the column
                DataGridViewColumn dgC = new DataGridViewTextBoxColumn
                {
                    Name = pair.Item2.name,
                    HeaderText = pair.Item2.disp_name ?? pair.Item2.name,
                    Visible = !pair.Item2.IsHidden,
                    Tag = pair
                };
                if (pair.Item2.col_width > 0)
                    dgC.Width = pair.Item2.col_width;

                grid1.Columns.Add(dgC);
            }

            //OrderedColsN.ForEachSafe(f => grid1.Columns.Add(f.Item2.name, f.Item2.disp_name ?? f.Item2.name));
            for(int i = 0; i < qrr.Data.Count; ++i)
            {
                var line = OrderedColsN.Select(c => c.Item1.GetObject(i)).ToArray();
                grid1.Rows.Add(line);
            }
        }

        private void SetDoubleBuffering()
        {
            bool value = true;
            if (!System.Windows.Forms.SystemInformation.TerminalServerSession)
            {
                Type dgvType = grid1.GetType();
                PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
                pi.SetValue(grid1, value, null);
            }
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            foreach(DataGridViewColumn col in grid1.Columns)
            {
                var pair = col.Tag as Tuple<IDfColumnBase, DfField> ?? throw new Exception("DataGridView column's tag is not set");
                pair.Item2.col_position = col.Visible ? col.DisplayIndex : DfField.HiddenPos;
                pair.Item2.col_width = col.Width;
            }
        }

        public void CmdSave()
        {
            if (QueryResultN == null)
                return;

            var suggName = QueryResultN.Query.LegalizeForFilename(100);
            var dlg = new SaveFileDialog
            {
                Filter = "Csv file (*.csv)|*.csv",
                FileName = suggName.Substring(0, 1).ToUpperInvariant() + suggName.Substring(1) + ".csv"
            };

            var targetFileName = (dlg.ShowDialog() == DialogResult.OK) ? dlg.FileName : null;

            QueryResultN.Data.SaveToFile(targetFileName, null);
        }
    }
}
