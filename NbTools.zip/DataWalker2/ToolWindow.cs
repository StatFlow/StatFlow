using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace DataWalker2
{
    public partial class ToolWindow : DockContent
    {
        public ToolWindow()
        {
            InitializeComponent();
            AutoScaleMode = AutoScaleMode.Dpi;
        }
    }
}