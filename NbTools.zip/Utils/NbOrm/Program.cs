﻿using System;
using System.IO;

using NbOrm.Xml;
using NbTools;
using System.Threading;
using NbOrm.Ora;
using System.Linq;

namespace NbOrm.Ms
{
    class Program
    {
        //private const string fileName = @"..\..\Xml\OracleSchema.xml";
        //string connString = System.Configuration.ConfigurationManager.AppSettings["connString"];

        static int Main(string[] args)
        {
            try
            {
                if (args.Length == 4)
                {
                    if (args[0].ToLowerInvariant() == "ora2xml" || args[0].ToLowerInvariant() == "sql2xml")
                    {
                        //Parameteters:
                        //Db connection string that can also be a local file containing connection string
                        //output xml filename
                        //conn_name that goes into <tables conn_name="XXX"> tag
                        return Schema2Db(args[0], args[1], args[2], args[3]);
                    }
                    else
                    {
                        var modelFile = args[1];
                        model mdl = modelFile.Contains("*") ? model.MergeXmls(modelFile) : model.LoadXml(modelFile);

                        switch (args[0].ToLowerInvariant())
                        {
                            case "sqlora":
                                XmlDesc2SqlScript(mdl, args[2], CsCode.Style.Oracle);
                                break;

                            case "sqlms":
                                XmlDesc2SqlScript(mdl, args[2], CsCode.Style.MsSql);
                                break;

                            case "c#ms":
                                var csMs = new SqlCsMs();
                                csMs.XmlDesc2CsFile(mdl, args[2]);
                                break;

                            case "c#ora":
                                var csOra = new SqlCsOracle();
                                csOra.XmlDesc2CsFile(mdl, args[2]);
                                break;
                            
                            default:
                                throw new Exception($"Unsupported parameter {args[0]}. Supported parameters are (sqlc, sqld, c#ms, c#ora, ora2xml, sql2xml)");
                        }

                        Console.WriteLine($"{args[0]} finished");
                        return 0;
                    }
                }
                throw new NbException("ORM tool expects three parameters: (sqlc, sqld, c#ms, c#ora) xml_file result_file\r\n" +
                    "or ora2xml|sql2xml connection_string result_xml_file  table-connection_Name");
            }
            catch (Exception ex)
            {
                Console.WriteLine(NbException.Exception2String(ex));
                Thread.Sleep(5000);
                return 1;
            }
        }

        public static int Schema2Db(string command, string connString, string xmlFilename, string table_conn_name)
        {
            if (File.Exists(connString))
                connString = File.ReadAllText(connString);
            var isOracle = command switch
            {
                "ora2xml" => true,
                "sql2xml" => false,
                _ => throw new Exception($"Unsupported command: '{command}'"),
            };
            Console.Write("Connecting...");
            using INbConn conn = isOracle ? new NbOraConn(connString) : (INbConn)new NbMsConn(connString);
            Console.Write(" building...");

            var tbls = SchemaToDb.GetTables(conn, out var tps);

            model mdl = new model
            {
                //config = new modelConfig(),
                types = tps.Values.OrderBy(t => t.name).ToArray(),
                tables = new modelTables[] { new modelTables { Items = tbls.OrderBy(t => t.name).ToArray(), conn_name = table_conn_name } },
                name = new FileInfo(xmlFilename).NameWithoutExtension()
            };
            Console.Write(" saving...");
            mdl.WriteXml(xmlFilename);
            Console.Write(" done!");
            return 0;
        }


        private static void XmlDesc2SqlScript(model mdl, string scriptFile, CsCode.Style style)
        {
            FileInfo fi = new FileInfo(scriptFile);
            string dropScript = Path.Combine(fi.Directory.FullName, fi.Name.Substring(0, fi.Name.Length - fi.Extension.Length) + ".Drop" + fi.Extension);
            string createScript = Path.Combine(fi.Directory.FullName, fi.Name.Substring(0, fi.Name.Length - fi.Extension.Length) + ".Create" + fi.Extension);
            SqlScript scriptGenerator = style switch
            {
                CsCode.Style.MsSql => new SqlScriptMs(),
                CsCode.Style.Oracle => new SqlScriptOracle(),
                _ => throw new NbExceptionEnum<CsCode.Style>(style),
            };
            File.WriteAllLines(createScript, scriptGenerator.CreateScript(mdl));
            File.WriteAllLines(dropScript, scriptGenerator.DropScript(mdl));

        }
    }
}
