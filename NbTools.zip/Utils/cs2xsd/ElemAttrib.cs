﻿using System;
using System.Collections.Generic;

using NbTools;

namespace cs2xsd
{
    public abstract class BaseTag
    {
        public readonly string Name;

        public BaseTag(string name)
        {
            Name = name;
        }

        internal abstract void RegisterTypeRecur(List<XsType> types);
    }

    public class Elem : BaseTag
    {
        public readonly XsType Type;
        public readonly int Min;
        public readonly int Max;

        public Elem(string name, XsType type, int min = -2, int max = -2) : base(name)
        {
            Type = type;
            Min = min;
            Max = max;
        }

        internal override void RegisterTypeRecur(List<XsType> types)
        {
            Type.RegisterSelfAndChildrenTypes(types);
        }

        internal void WriteTo(INbTag root)
        {
            root.TA("element", a =>
            {
                a.Attrib("name", Name);
                a.Attrib("type", Type.Name);

                if (Min != -2)
                    a.Attrib("minOccurs", Min == -1 ? "unbounded" : Min.ToString());
                if (Max != -2)
                    a.Attrib("maxOccurs", Max == -1 ? "unbounded" : Max.ToString());
            });
        }
    }

    public enum Uses { None, Optional, Required, Prohibited };

    public class Attr : BaseTag
    {
        private readonly XsType Type;
        private readonly Uses Use;
        private readonly string Deflt;

        public Attr(string name) : base(name)
        { }

        public Attr(string name, XsType type, Uses use = Uses.None, string deflt = null) : this(name)
        {
            Type = type;
            Use = use;
            Deflt = deflt;
        }

        internal override void RegisterTypeRecur(List<XsType> types) => Type.RegisterSelfAndChildrenTypes(types);

        internal void WriteTo(INbTag root)
        {
            root.TA("attribute", a =>
            {
                a.Attrib("name", Name);
                a.Attrib("type", Type.Name);
                if (Use != Uses.None)
                    a.Attrib("use", Use.ToString().ToLower());
                if (Deflt != null)
                    a.Attrib("default", Deflt);
            });
        }
    }
}
