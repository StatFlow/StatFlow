﻿using System;
using System.Collections.Generic;
using System.IO;

using NbTools;

//TODO: Unique keys in collection of elements
//TODO: Doc strings everywhere
//TODO: Unnecessary extra empty lines in the produced XSD

namespace cs2xsd
{
    public class Cs2Xsd
    {
        private static readonly string XsdTool = Environment.ExpandEnvironmentVariables(@"%ProgramFiles(x86)%\Microsoft SDKs\Windows\v10.0A\bin\NETFX 4.8 Tools\xsd.exe");

        public static void Generate(Elem elem, string xsdNameSpace, string dstFile) //string[] args
        {
            string beyond = @"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe";

            try
            {
                if (!File.Exists(XsdTool))
                    throw new Exception($"XSD tool is not found at this location: '{XsdTool}'");
                if (!File.Exists(beyond))
                    throw new Exception($"Beyond compare tool is not found at this location: '{beyond}'");

                var oldName = dstFile + ".old";
                File.Delete(oldName);
                if (File.Exists(dstFile))
                    File.Move(dstFile, oldName);

                using (StreamWriter wrtr = new StreamWriter(dstFile))
                {
                    wrtr.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
                    var nt = new NbTag(wrtr, indent: "  ", nameSpace: "xs");
                    nt.TAT("schema",
                        a => a["id", xsdNameSpace]["xmlns:mstns", $"http://tempuri.org/{xsdNameSpace}.xsd"]["xmlns:xs"] = "http://www.w3.org/2001/XMLSchema",
                        t => Schema(nt, elem)
                        );
                }

                NbProcess.RunSync(beyond, null, oldName, dstFile);
            }
            catch (Exception ex)
            {
                Console.WriteLine(NbException.Exception2String(ex));
            }
        }

        /*private static void CreateCsFile(string dstFile)
        {
            string tempTile = Path.Combine(Directory.GetCurrentDirectory(), "tmp.txt");
            var res1 = NbProcess.RunSync(XsdTool, null, tempTile, "/classes", "/fields", "/n:MusicStruct.Xml");


            var res2 = NbProcess.RunSync("findstr", null, "/V", "DebuggerStepThroughAttribute", tempTile, @$">{dstFile}.cs");
        }*/

        private static void Schema(INbTag root, Elem rootElement)
        {
            var types = new List<XsType>(); //Will be populated with with AddUnique() extension function
            rootElement.RegisterTypeRecur(types);
            rootElement.WriteTo(root);
            root.Value("\r\n", encode: false);

            foreach (var t in types) 
            {
                t.WriteTo(root);
                root.Value("\r\n", encode: false);
            }
        }
    }
}
