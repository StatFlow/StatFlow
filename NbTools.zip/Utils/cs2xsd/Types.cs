﻿using System;
using System.Collections.Generic;
using System.Linq;
using NbTools;

namespace cs2xsd
{
    public abstract class XsType
    {
        protected readonly BaseTag[] Tags;

        public readonly string Name;
        public XsType(string name, BaseTag[] tags)
        {
            //name[0].ToString().ToUpper() + name.Substring(1); //Ensure first letter is capital for types - make Xs: out of xs: for build-in types
            Name = name;
            Tags = tags;
        }

        internal abstract void WriteTo(INbTag root);

        public static TypeBuiltIn Int = new TypeBuiltIn("xs:int");
        public static TypeBuiltIn Long = new TypeBuiltIn("xs:long");
        public static TypeBuiltIn String = new TypeBuiltIn("xs:string");
        public static TypeBuiltIn Bool = new TypeBuiltIn("xs:boolean");
        public static TypeBuiltIn Token = new TypeBuiltIn("xs:token");
        public static TypeBuiltIn NCName = new TypeBuiltIn("xs:NCName");

        internal virtual void RegisterSelfAndChildrenTypes(List<XsType> types)
        {
            types.AddUnique(this);
            Tags.ForEachSafe(t => t.RegisterTypeRecur(types));
        }
    }

    public class TypeBuiltIn : XsType
    {
        public TypeBuiltIn(string name) : base(name, null) { }

        internal override void WriteTo(INbTag root) { } //Do not write for built-in types
    }

    public class TypeName : XsType
    {
        public TypeName(string name) : base(name, null) {}

        internal override void WriteTo(INbTag root) { }
    }

    public class TypeSequence : XsType
    {
        public TypeSequence(string name, params BaseTag[] tag)
            : base(name, tag) { }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
            {
                t1.TT("sequence", t2 =>
                {
                    foreach (Elem el in Tags.SafeOfType<Elem>())
                        el.WriteTo(t2);
                });
                foreach (Attr att in Tags.SafeOfType<Attr>())
                    att.WriteTo(t1);
            });
        }
    }

    public class TypeChoice : XsType
    {
        public readonly int Min;
        public readonly int Max;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">Name of the type should star with capital letter, becuase it will appear in C# code</param>
        /// <param name="min">-1 means unbounded, -2 means do not include the tag minOccurs</param>
        /// <param name="max">-1 means unbounded, -2 means do not include the tag maxOccurs. If 1 is provided it mean only one choice is allowed (radiobuttons)</param>
        /// <param name="tag">Array of element and attributes</param>
        public TypeChoice(string name, int min = -2, int max = -2, params BaseTag[] tag)
            : base(name, tag)
        {
            Min = min;
            Max = max;
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
                {
                    t1.TAT("choice",
                        a =>
                        {
                            if (Min != -2)
                                a["minOccurs"] = Min == -1 ? "unbounded" : Min.ToString();
                            if (Max != -2)
                                a["maxOccurs"] = Max == -1 ? "unbounded" : Max.ToString();
                        },
                        t2 =>
                        {
                            foreach (Elem el in Tags.SafeOfType<Elem>())
                                el.WriteTo(t2);
                        }
                    );
                    foreach (Attr att in Tags.SafeOfType<Attr>())
                        att.WriteTo(t1);
                }
            );
        }
    }


    public class TypeAttrOnly : XsType
    {
        public TypeAttrOnly(string name, params BaseTag[] tag)
            : base(name, tag)
        {
            if (tag.SafeOfType<Elem>().Any())
                throw new Exception($"{nameof(TypeAttrOnly)} '{name}' doesn't suport elements");
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
            {
                foreach (Attr att in Tags.SafeOfType<Attr>())
                    att.WriteTo(t1);
            });
        }
    }

    public class TypeDerived : XsType
    {
        private readonly XsType BaseType;

        public TypeDerived(string name, XsType baseType, params BaseTag[] tag)
            : base(name, tag)
        {
            BaseType = baseType;
            if (tag.SafeOfType<Elem>().Any())
                throw new Exception($"{nameof(TypeDerived)} '{name}' doesn't suport elements");
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
            {
                t1.TT("complexContent", t2 =>
                {
                    t2.TAT("extension", a => a["base"] = BaseType.Name, t3 =>
                    {
                        foreach (Attr att in Tags.SafeOfType<Attr>())
                            att.WriteTo(t3);
                    });
                });
            });
        }

        internal override void RegisterSelfAndChildrenTypes(List<XsType> types)
        {
            BaseType.RegisterSelfAndChildrenTypes(types);
            base.RegisterSelfAndChildrenTypes(types);
        }
    }


    /// <summary>
    /// List of build-in values such as xs:int, devided by spaces
    /// </summary>
    public class TypeList : XsType
    {
        private readonly TypeBuiltIn ListOfType;
        private readonly int MinLength;

        public TypeList(string name, TypeBuiltIn listOf, int minLength = -1)
            : base(name, null)
        {
            ListOfType = listOf;
            MinLength = minLength;
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("simpleType", a => a["name"] = Name, t1 =>
            {
                t1.TT("restriction", t2 =>
                {
                    t2.TT("simpleType",
                        t3 => t3.TA("list", a => a["itemType"] = ListOfType.Name));
                    if (MinLength != -1)
                        t2.TA("minLength", a => a["value"] = MinLength.ToString());
                });
            });
        }
    }

    public class TypeEnum : XsType
    {
        private readonly TypeBuiltIn ListOfType;
        private readonly Dictionary<string, string> Values;

        public TypeEnum(string name, TypeBuiltIn listOf, Dictionary<string, string> values)
            : base(name, null)
        {
            ListOfType = listOf;
            Values = values;
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("simpleType", a => a["name"] = Name, t1 =>
            {
                t1.TAT("restriction", a => a["base"] = ListOfType.Name, t2 =>
                    {
                        foreach (var pair in Values)
                        {
                            t2.TA("enumeration", a => a["value"] = pair.Key);
                        }
                    });
            });
        }
    }
}
