﻿using System;
using System.Collections.Generic;
using System.Linq;
using NbTools;

namespace cs2xsd
{
    public abstract class XsType
    {
        public readonly string Name;
        public XsType(string name)
        {
            Name = name;
        }

        internal abstract void WriteTo(INbTag root);

        public static TypeBuiltIn Int = new TypeBuiltIn("xs:int");
        public static TypeBuiltIn String = new TypeBuiltIn("xs:string");
        public static TypeBuiltIn NCName = new TypeBuiltIn("xs:NCName");
    }

    public class TypeSequence : XsType
    {
        private readonly IEnumerable<Elem> Elems;
        private readonly IEnumerable<Attrib> Attribs;

        public TypeSequence(string name, IEnumerable<Elem> elems = null, IEnumerable<Attrib> attribs = null)
            : base(name)
        {
            Elems = elems;
            Attribs = attribs;
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
            {
                t1.TT("sequence", t2 =>
                {
                    foreach (Elem el in Elems ?? Enumerable.Empty<Elem>())
                        el.WriteTo(t2);
                });
                //Attribs?.ForEachSafe(at => at.WriteTo(t1))
                foreach (Attrib att in Attribs ?? Enumerable.Empty<Attrib>())
                    att.WriteTo(t1);
            });
        }
    }

    public class TypeBuiltIn : XsType
    {
        public TypeBuiltIn(string name) : base(name)
        { }

        internal override void WriteTo(INbTag root)
        {
            throw new NotImplementedException();
        }
    }



    public class SimpleType : XsType
    {
        public SimpleType(string name) : base(name)
        { }

        internal override void WriteTo(INbTag root)
        {
            throw new NotImplementedException();
        }
    }
}
