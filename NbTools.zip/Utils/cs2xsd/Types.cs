﻿using System;
using System.Collections.Generic;
using System.Linq;
using NbTools;

namespace NbXsdV1.Xml
{
    public partial class NbXsd
    {
        void Resolve() { }
    }

    public abstract partial class XsType
    {
        public XsType() { } //For serialization

        public XsType(string name, BaseTag[] tags)
        {
            //name[0].ToString().ToUpper() + name.Substring(1); //Ensure first letter is capital for types - make Xs: out of xs: for build-in types
            Name = name;
            Tags = tags;
        }

        internal abstract void WriteTo(INbTag root);

        public static TypeBuiltIn Int = new TypeBuiltIn("xs:int");
        public static TypeBuiltIn Long = new TypeBuiltIn("xs:long");
        public static TypeBuiltIn Float = new TypeBuiltIn("xs:float");
        public static TypeBuiltIn Double = new TypeBuiltIn("xs:double");
        public static TypeBuiltIn Decimal = new TypeBuiltIn("xs:decimal");

        public static TypeBuiltIn String = new TypeBuiltIn("xs:string");
        public static TypeBuiltIn Bool = new TypeBuiltIn("xs:boolean");
        public static TypeBuiltIn HexBinary = new TypeBuiltIn("xs:hexBinary");
        public static TypeBuiltIn Base64Binary = new TypeBuiltIn("xs:base64Binary");
        public static TypeBuiltIn AnyURI = new TypeBuiltIn("xs:anyURI");

        public static TypeBuiltIn Token = new TypeBuiltIn("xs:token");
        public static TypeBuiltIn NCName = new TypeBuiltIn("xs:NCName");

        public static TypeBuiltIn DateTime = new TypeBuiltIn("xs:dateTime");
        public static TypeBuiltIn Date = new TypeBuiltIn("xs:date");
        public static TypeBuiltIn Time = new TypeBuiltIn("xs:time");
        public static TypeBuiltIn Duration = new TypeBuiltIn("xs:duration");

        /*
         * byte 	A signed 8-bit integer
decimal 	A decimal value
int 	A signed 32-bit integer
integer 	An integer value
long 	A signed 64-bit integer
negativeInteger 	An integer containing only negative values (..,-2,-1)
nonNegativeInteger 	An integer containing only non-negative values (0,1,2,..)
nonPositiveInteger 	An integer containing only non-positive values (..,-2,-1,0)
positiveInteger 	An integer containing only positive values (1,2,..)
short 	A signed 16-bit integer
unsignedLong 	An unsigned 64-bit integer
unsignedInt 	An unsigned 32-bit integer
unsignedShort 	An unsigned 16-bit integer
unsignedByte 	An unsigned 8-bit integer
        */


        /*
        anyURI 	 
        base64Binary 	 
        boolean 	 
        double 	 
        float 	 
        hexBinary 	 
        NOTATION 	 
        QName
         * */


        internal virtual void RegisterSelfAndChildrenTypes(NbDictionary<string, XsType> types)
        {
            if (!types.ContainsKey(Name))
                types.Add(Name, this);
            Tags.ForEachSafe(t => t.RegisterTypeRecur(types));
        }
    }

    public partial class TypeBuiltIn : XsType
    {
        public TypeBuiltIn(string name) : base(name, null) { }

        internal override void WriteTo(INbTag root) { } //Do not write for built-in types
    }

    public partial class TypeName : XsType
    {
        public TypeName(string name) : base(name, null) { }

        internal override void WriteTo(INbTag root) { }
    }

    public partial class TypeSequence : XsType
    {
        public TypeSequence(string name, params BaseTag[] tag)
            : base(name, tag) { }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
            {
                t1.TT("sequence", t2 =>
                {
                    foreach (Elem el in Tags.SafeOfType<Elem>())
                        el.WriteTo(t2);
                });
                foreach (Attr att in Tags.SafeOfType<Attr>())
                    att.WriteTo(t1);
            });
        }
    }

    public partial class TypeChoice : XsType
    {
        public readonly int Min;
        public readonly int Max;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">Name of the type should star with capital letter, becuase it will appear in C# code</param>
        /// <param name="min">-1 means unbounded, -2 means do not include the tag minOccurs</param>
        /// <param name="max">-1 means unbounded, -2 means do not include the tag maxOccurs. If 1 is provided it mean only one choice is allowed (radiobuttons)</param>
        /// <param name="tag">Array of element and attributes</param>
        public TypeChoice(string name, int min = Elem.None, int max = Elem.None, params BaseTag[] tag)
            : base(name, tag)
        {
            Min = min;
            Max = max;
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
                {
                    t1.TAT("choice",
                        a =>
                        {
                            if (Min != Elem.None)
                                a["minOccurs"] = Min == Elem.Unbounded ? "unbounded" : Min.ToString();
                            if (Max != Elem.None)
                                a["maxOccurs"] = Max == Elem.Unbounded ? "unbounded" : Max.ToString();
                        },
                        t2 =>
                        {
                            foreach (Elem el in Tags.SafeOfType<Elem>())
                                el.WriteTo(t2);
                        }
                    );
                    foreach (Attr att in Tags.SafeOfType<Attr>())
                        att.WriteTo(t1);
                }
            );
        }
    }

    /// <summary>
    /// complexType that only has attributes
    /// </summary>
    public partial class TypeAttrOnly : XsType
    {
        public TypeAttrOnly(string name, params BaseTag[] tag)
            : base(name, tag)
        {
            if (tag.SafeOfType<Elem>().Any())
                throw new Exception($"{nameof(TypeAttrOnly)} '{name}' doesn't support elements");
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
            {
                foreach (Attr att in Tags.SafeOfType<Attr>())
                    att.WriteTo(t1);
            });
        }
    }

    public partial class TypeDerived : XsType
    {
        public TypeDerived(string name, XsType baseType, params BaseTag[] tag)
            : base(name, tag)
        {
            BaseType = baseType;
            //if (tag.SafeOfType<Elem>().Any())
            //    throw new Exception($"{nameof(TypeDerived)} '{name}' doesn't support elements");
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("complexType", a => a["name"] = Name, t1 =>
            {
                t1.TT("complexContent", t2 =>
                {
                    t2.TAT("extension", a => a["base"] = BaseType.Name, t3 =>
                    {
                        var elems = Tags.SafeOfType<Elem>().ToList();
                        if (elems.Count > 0)
                        {
                            t3.TT("sequence", t4 =>
                            {
                                foreach (Elem el in Tags.SafeOfType<Elem>())
                                    el.WriteTo(t4);
                            });
                        }

                        foreach (Attr att in Tags.SafeOfType<Attr>())
                            att.WriteTo(t3);
                    });
                });
            });
        }

        internal override void RegisterSelfAndChildrenTypes(NbDictionary<string, XsType> types)
        {
            BaseType.RegisterSelfAndChildrenTypes(types);
            base.RegisterSelfAndChildrenTypes(types);
        }
    }


    /// <summary>
    /// List of build-in values such as xs:int, divided by spaces
    /// </summary>
    public partial class TypeList : XsType
    {
        public TypeList(string name, TypeBuiltIn listOf, int minLength = -1)
            : base(name, null)
        {
            ListOfType = listOf;
            MinLength = minLength;
        }

        internal override void WriteTo(INbTag root)
        {
            root.TAT("simpleType", a => a["name"] = Name, t1 =>
            {
                t1.TT("restriction", t2 =>
                {
                    t2.TT("simpleType",
                        t3 => t3.TA("list", a => a["itemType"] = ListOfType.Name));
                    if (MinLength != -1)
                        t2.TA("minLength", a => a["value"] = MinLength.ToString());
                });
            });
        }
    }


    public partial class TypeEnum : XsType
    {
        //Don't really need to resolve type name, becuase during export there is the first step with registration in the dictionary, so the type will be available to lookup by name
        private NbDictionary<string, string> Values;

        /*[Obsolete("Pass EnumItem[] as items to be compatible with xml variant")]
        public TypeEnum(string name, TypeBuiltIn listOf, NbDictionary<string, string> values)
            : base(name, null)
        {
            ListOfType = listOf;
            Values = values;
        }*/

        public TypeEnum(string name, TypeBuiltIn listOf, params (string key, string val)[] items)
            : base(name, null)
        {
            ListOfType = listOf;
            this.items = items.Select(p => new EnumItem() { key = p.key, value = p.val }).ToArray();
        }

        /*public TypeEnum(string name, TypeBuiltIn listOf, (string key, string val)[] items)
            : base(name, null)
        {
            ListOfType = listOf;
            this.items = items.Select(p => new EnumItem() {  key = p.key, value = p.val }).ToArray();
        }*/

        public TypeEnum(string name, TypeBuiltIn listOf, EnumItem[] items)
            : base(name, null)
        {
            ListOfType = listOf;
            this.items = items;
        }

        internal override void WriteTo(INbTag root)
        {
            if (Values == null)
            {
                if (items == null)
                    throw new Exception($"Both values parameter and items Xml tag were empty for TypeEnum: '{Name}'");
                Values = items.ToNbDictionary(i => i.key, i => i.value);
            }

            root.TAT("simpleType", a => a["name"] = Name, t1 =>
            {
                t1.TAT("restriction", a => a["base"] = ListOfType.Name, t2 =>
                    {
                        foreach (var pair in Values)
                        {
                            t2.TA("enumeration", a => a["value"] = pair.Key);
                        }
                    });
            });
        }
    }
}
