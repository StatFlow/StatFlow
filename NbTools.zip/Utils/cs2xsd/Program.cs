﻿using NbTools;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2xsd
{
    class Program
    {
        static void Main() //string[] args
        {
            string beyond = @"C:\Program Files (x86)\Beyond Compare 3\BCompare.exe";
            string oldFile = "MusicStruct.xsd";
            string newFile = "MusicStructNew.xsd";

            try
            {
                using (StreamWriter wrtr = new StreamWriter(newFile))
                {
                    wrtr.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
                    var nt = new NbTag(wrtr, indent: "  ", nameSpace: "xs");
                    nt.TAT("schema",
                        a => a["id", "MusicStruct"]["xmlns:mstns", "http://tempuri.org/MusicStruct.xsd"]["xmlns:xs"] = "http://www.w3.org/2001/XMLSchema",
                        t => Schema(nt, BuildStructure())
                        );
                }

                NbProcess.RunSync(beyond, NbExt.Yield(oldFile, newFile));
            }
            catch (Exception ex)
            {
                Console.WriteLine(NbException.Exception2String(ex));
            }
        }

        private static void Schema(INbTag root, Elem rootElement)
        {
            var types = new HashSet<XsType>();
            rootElement.RegisterTypeRecur(types);
            rootElement.WriteElementsRecur(root);

            foreach (var t in types.OrderBy(tg => tg.Name))
                t.WriteTo(root);
        }

        private static Elem BuildStructure()
        {
            var typ = new TypeSequence("Music", null, NbExt.Yield(new Attrib("BeatsPerMinute", XsType.Int, Attrib.Uses.Optional, "70")));

            return new Elem("music", typ);

        }
    }
}
