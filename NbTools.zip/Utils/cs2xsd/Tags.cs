﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NbTools;

namespace cs2xsd
{
    public abstract class BaseTag
    {
        public abstract string RootTag { get; }
        public readonly string Name;

        public BaseTag(string name)
        {
            Name = name;
        }

        internal virtual void WriteTo(INbTag root)
        {
            root.TA(RootTag, a => a["name"] = Name);
        }
    }

    public class Elem : BaseTag
    {
        public override string RootTag => "element";

        public readonly XsType Type;

        public Elem(string name, XsType type) : base(name)
        {
            Type = type;
        }

        internal void RegisterTypeRecur(HashSet<XsType> types)
        {
            types.Add(Type);
            //TODO: add types for children elements
        }

        internal void WriteElementsRecur(INbTag root)
        {
            root.TA(RootTag, a => a["name", Name]["type"] = Type.Name);
            //Write children element
        }
    }

    public class Attrib : BaseTag
    {
        public enum Uses { None, Optional, Required, Prohibited };

        private XsType Type;
        private Uses Use;
        private string Deflt;

        public Attrib(string name) : base(name)
        { }

        public Attrib(string name, XsType type, Uses use = Uses.None, string deflt = null) : this(name)
        {
            Type = type;
            Use = use;
            Deflt = deflt;
        }

        public override string RootTag => "attribute";

        internal override void WriteTo(INbTag root)
        {
            root.TA("attribute", a => {
                a.Attrib("name", Name);
                a.Attrib("type", Type.Name);
                if (Use != Uses.None)
                    a.Attrib("use", Use.ToString().ToLower());
                if (Deflt != null)
                    a.Attrib("default", Deflt);
            });
        }
    }
}
