﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Csv2XsdV1
{
    partial class csv2xsd
    {
        public static Lazy<XmlSerializer> modelXmlSerializer = new Lazy<XmlSerializer>(() => new XmlSerializer(typeof(csv2xsd)), false);
        public static csv2xsd LoadXml(string xmlFileName)
        {
            try
            {
                csv2xsd res;
                var fl = new FileInfo(xmlFileName);
                if (!fl.Exists)
                    throw new Exception($"Layout file does not exist: '{fl.FullName}'");

                using (FileStream str = new FileStream(fl.FullName, FileMode.Open))
                using (StreamReader rdr = new StreamReader(str))
                {
                    res = (csv2xsd)modelXmlSerializer.Value.Deserialize(rdr);
                    //res.FileName = fl.FullName;
                }
                return res;
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deserializing '{xmlFileName}'", ex);
            }
        }
    }
}
