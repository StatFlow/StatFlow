﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using static Csv2xsd.XsdTypeLine;

using NbTools;

namespace Csv2xsd
{
    class Model
    {
        public readonly Csv2XsdV1.csv2xsd conf;
        public readonly NbDictionary<string, XsdEnum> xsdEnums;
        public readonly NbDictionary<string, XsdType> xsdTypes;
        public readonly XsdType rootType;

        public readonly string name_space;

        public Model(Csv2XsdV1.csv2xsd conf)
        {
            this.conf = conf;
            name_space = conf.name_space + "V" + conf.version;

            //Read csv lines and enum csv lines into lists 
            var lines = (Path.GetExtension(conf.infile).ToLowerInvariant()) switch
            {
                ".csv" => NbExt.FromCsv<XsdTypeLine>(conf.infile).Where(l => !l.TypeName.StartsWith("#")).ToList(),//Ignore lines commented with #
                //".xlsx" => ReadExcel(conf.infile).ToList(),
                _ => throw new Exception($"Unsupported file type: {conf.infile}"),
            };
            string inEnumFile = Path.Combine(Path.GetDirectoryName(conf.infile), Path.GetFileNameWithoutExtension(conf.infile) + ".enum" + Path.GetExtension(conf.infile));
            var enumLines = NbExt.FromCsv<XsdEnumLine>(inEnumFile).ToList();

            //Combine enum  lines into groups by the Enum Name
            xsdEnums = enumLines.GroupBy(l => l.EnumName, StringComparer.OrdinalIgnoreCase)
                .Select(g => new XsdEnum { EnumName = g.Key, Lines = g.ToList() }).ToNbDictionary(e => e.EnumName, e => e, description: "Csv2Xsd enums");

            //Combine xsdLines into groups by Type Name - i.e all attributes under the same tag into the same group
            //TODO: does not preserve the order - use list instead or export in the order of dependencies?
            xsdTypes = lines.GroupBy(l => l.TypeName, StringComparer.OrdinalIgnoreCase)
                .Select(g => new XsdType { TypeName = g.Key, Lines = g.ToList() }).ToNbDictionary(t => t.TypeName, t => t, description: "Csv2Xsd types");

            xsdTypes.Values.ForEachSafe(t => t.Resolve(xsdTypes, xsdEnums));
            xsdEnums.Values.ForEachSafe(e => e.Resolve());

            rootType = xsdTypes.Values.SingleVerbose(t => !t.ReferredTo, () => "All types are referred to, there must be a cyclic dependency",
                i => $"{i} types are not referred to: {String.Join(", ", xsdTypes.Values.Where(t2 => !t2.ReferredTo).Select(t2 => t2.TypeName))}. Only one root is expected");
        }

        private enum ExcelXsdColumns { TypeName = 1, TypeType, Entry, EntryName, EntryType, Nullable, Default, Count, Comment };

        internal void Generate()
        {
            string name_space = conf.name_space + "V" + conf.version;
            string namespace_uri = $"http://tempuri.org/{name_space}.xsd";
            using StreamWriter wrtr = new StreamWriter(conf.outfile);
            wrtr.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            var root = NbTag.Create(wrtr, "  ");
            root.TAT("xs:schema", t => t["id", name_space]
                    ["xmlns:mstns", namespace_uri]
                    ["xmlns:xs"] = "http://www.w3.org/2001/XMLSchema",
                tag =>
                {
                    tag.TAT("xs:element", a => a["name"] = rootType.TypeName, tg => rootType.CreateXsd(tg));
                    tag.Value("\r\n", encode: false);

                    foreach (var xsdType in xsdTypes.Values.Where(tp => tp != rootType))
                    {
                        xsdType.CreateXsd(tag);
                        tag.Value("\r\n", encode: false);
                    }

                    foreach (var xsdEnum in xsdEnums.Values)
                    {
                        xsdEnum.CreateXsd(tag);
                        tag.Value("\r\n", encode: false);
                    }

                    Footer(tag, xsdTypes);
                });
        }

        //Predetermined special types
        public const string IntList = "IntList";


        private static void Footer(INbTag tag, IDictionary<string, XsdType> xsdTypes)
        {
            if (xsdTypes.Values.SelectMany(t => t.Lines.Select(l => l.EntryType)).Any(et => et.Equals(IntList, StringComparison.OrdinalIgnoreCase)))
            {
                tag.TAT("xs:simpleType", a => a["name"] = IntList,
                    t => t.Tag("xs:list", a1 => a1["itemType"] = "xs:integer")
                );
            }
        }
    }
}


/*private static IEnumerable<XsdTypeLine> ReadExcel(string fileName)
{
    // SpreadsheetLight works on the idea of a currently selected worksheet.
    // If no worksheet name is provided on opening an existing spreadsheet,
    // the first available worksheet is selected.
    using SLDocument sl = new SLDocument(fileName);
    var wsList = sl.GetWorksheetNames();
    if (wsList.Count == 0)
        throw new Exception($"{fileName} doesn't have worksheets");
    else
        sl.SelectWorksheet(wsList[0]);

    var rows = sl.GetCells();
    if (!rows.ContainsKey(1))
        throw new Exception($"No header found");
    var colLocations = GetColumnLocations(rows[1], sl);

    foreach (var row in rows.OrderBy(k => k.Key).Skip(1))
    {
        var line = new XsdTypeLine();

        foreach (var col in row.Value)
        {
            var cellText = sl.GetCellValueAsString(row.Key, col.Key);
            switch (colLocations[col.Key])
            {
                case ExcelXsdColumns.TypeName:
                    line.TypeName = cellText;
                    break;
                case ExcelXsdColumns.TypeType:
                    line.TypeType = (TypeTypes)Enum.Parse(typeof(TypeTypes), cellText);
                    break;
                case ExcelXsdColumns.Entry:
                    line.Entry = (Entries)Enum.Parse(typeof(Entries), cellText); ;
                    break;
                case ExcelXsdColumns.EntryName:
                    line.EntryName = cellText;
                    break;
                case ExcelXsdColumns.EntryType:
                    line.EntryType = cellText;
                    break;
                case ExcelXsdColumns.Nullable:
                    line.Nullable = cellText.EqIC("TRUE");
                    break;
                case ExcelXsdColumns.Default:
                    line.Default = cellText;
                    break;
                case ExcelXsdColumns.Count:
                    line.Count = cellText;
                    break;
                case ExcelXsdColumns.Comment:
                    line.Comment = cellText;
                    break;
                default:
                    break;
            }
        }
        yield return line;
    }
}

private static NbDictionary<int, ExcelXsdColumns> GetColumnLocations(Dictionary<int, SLCell> dictionary, SLDocument sl)
{
    var columnLocations = new NbDictionary<int, ExcelXsdColumns>(dictionary.Count, description: "Excel column locations");

    foreach (var pair in dictionary)
    {
        var cellText = sl.GetCellValueAsString(1, pair.Key);
        if (!Enum.TryParse(cellText, out ExcelXsdColumns enumInd))
            throw new Exception($"Unsupported column: {cellText}");
        columnLocations.Add(pair.Key, enumInd);

        //if (pair.Key != (int)enumInd)
        //    throw new Exception($"Column {cellText} not in the right place");
    }
    return columnLocations;
}*/
