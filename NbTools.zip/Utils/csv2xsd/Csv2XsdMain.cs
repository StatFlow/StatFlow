﻿using NbTools;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace Csv2xsd
{
    class Program
    {
        //Run with params to regenerate self ..\..\Config\csv2xsd.xml

        internal static int Main(string[] args)
        {
            try
            {
                string confFileName;
                if (args.Length > 0 && args[0] != null)
                {
                    confFileName = args[0];
                    if (!File.Exists(confFileName))
                        throw new NbExceptionCmdLine($"Csv2xsd expects XML configuration of conversion job as first command line parameter. '{confFileName}' doesn't exist.");
                }
                else
                {
                    confFileName = "csv2xsd.xml";
                    if (!File.Exists(confFileName))
                        throw new NbExceptionCmdLine($"Default XML configuration of conversion job '{confFileName}' doesn't exist.");
                }

                var conf = Csv2XsdV1.csv2xsd.LoadXml(confFileName);
                string workDir = new FileInfo(confFileName).Directory.FullName;

                /*if (args.Length != 2)
                    throw new NbExceptionCmdLine($"csv2xsd utility expects two parameters: source.csv and destination.xsd");*/

                CheckParams(conf, workDir);
                return Run(conf);
            }
            catch (NbExceptionCmdLine ex)
            {
                Console.WriteLine(ex.Message);
                return 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Fatal exception: {NbException.Exception2String(ex)}");
                return 2;
            }
        }

        private static void CheckParams(Csv2XsdV1.csv2xsd conf, string workDir)
        {
            string name_space = conf.name_space + "V" + conf.version;
            //string namespace_uri = $"http://tempuri.org/{name_space}.xsd";
            if (String.IsNullOrWhiteSpace(conf.infile))
                conf.infile = name_space + ".csv";
            if (!Path.IsPathRooted(conf.infile))
                conf.infile = Path.Combine(workDir, conf.infile);
            if (!File.Exists(conf.infile))
                throw new Exception($"Source file '{conf.infile}' is not found");

            if (String.IsNullOrWhiteSpace(conf.outfile))
                conf.outfile = name_space + ".xsd";
            if (!Path.IsPathRooted(conf.outfile))
                conf.outfile = Path.Combine(workDir, conf.outfile);

            if (conf.compare != null && !Path.IsPathRooted(conf.compare.baseline))
                conf.compare.baseline = Path.Combine(workDir, conf.compare.baseline);

            if (!String.IsNullOrEmpty(conf.xsd_tool))
            {
                conf.xsd_tool = Environment.ExpandEnvironmentVariables(conf.xsd_tool);
                if (!File.Exists(conf.xsd_tool))
                    throw new Exception($"Microsoft XSD tool can't be found at this location: '{conf.xsd_tool}'");
            }
        }


        public static int Run(Csv2XsdV1.csv2xsd conf)
        {
            Model mdl = new Model(conf); //Loading from file
            mdl.Generate();

            if (conf.compare != null)
                NbProcess.RunSync(conf.compare.compare_util, NbExt.Yield(conf.compare.baseline, conf.outfile), null); //Not sure if it works with NULL
                //Process.Start(conf.compare.compare_util, $"\"{conf.compare.baseline}\" \"{conf.outfile}\"");

            if (!String.IsNullOrEmpty(conf.xsd_tool))
            {
                //namespace - namespace of the generated class
                string outDir = new FileInfo(conf.outfile).Directory.FullName;
                //string par = $"\"{conf.outfile}\" /nologo /classes /fields /enableDataBinding /enableLinqDataSet /namespace:{mdl.name_space} /outputdir:\"{outDir}\"";
                var par = NbExt.Yield(conf.outfile, "/nologo", "/classes", "/fields", "/enableDataBinding", "/enableLinqDataSet", $"/namespace:{mdl.name_space}", $"/outputdir:\"{outDir}\"");

                var (code, stdOut, stdErr) = NbProcess.RunSync(conf.xsd_tool, par, outDir);
                if (code != 0)
                    throw new Exception($"MS XSD tool returned: {code}{Environment.NewLine}{stdOut}{Environment.NewLine}{stdErr}");
                else
                    Console.WriteLine(stdOut);


                //Файл создаётся без точек в имени: Doer_Config.cs
                //Из него нужно убрать строчки с     [System.Diagnostics.DebuggerStepThroughAttribute()]
                //Неплохо бы добавить базовый код для сериализации (загрузка и сохранение)

                /*var tmpFileName = Path.Combine(outDir, "Doer_Config.cs");
                var csFileName = Path.Combine(Path.GetDirectoryName(conf.outfile), Path.GetFileNameWithoutExtension(conf.outfile) + ".cs");
                par = $"/V \"DebuggerStepThroughAttribute\" \"{tmpFileName}\" >\"{csFileName}\"";
                Process.Start("findstr", par);
                prc.WaitForExit();
                if (prc.ExitCode != 0)
                    throw new Exception($"findstr returned: {prc.ExitCode}");*/
            }

            /// TRY: dataset              Generate sub-classed DataSet for this schema.Short form is '/d'.

            return 0;
        }

        /*private static void Footer(INbTag tag, IDictionary<string, XsdType> xsdTypes)
        {
            if (xsdTypes.Values.SelectMany(t => t.Lines.Select(l => l.EntryType)).Any(et => et.Equals(IntList, StringComparison.OrdinalIgnoreCase)))
            {
                tag.TAT("xs:simpleType", a => a["name"] = IntList,
                    t => t.Tag("xs:list", a1 => a1["itemType"] = "xs:integer")
                );
            }
        }*/
    }


    //TODO: think about deriving XsdType and XsdEnum from the same base class
    public class XsdType
    {
        public override string ToString() => $"{TypeName}({TypeType}): {String.Join(", ", Lines.Select(l => l.ToString()))}";

        internal string TypeName;
        internal XsdTypeLine.TypeTypes TypeType;

        internal List<XsdTypeLine> Lines;
        internal bool ReferredTo = false;

        internal void CreateXsd(INbTag t)
        {
            t.TAT("xs:complexType", ct => { if (ReferredTo) ct["name"] = TypeName; },
                ct =>
                {
                    var lines = Lines.Where(l => l.Entry == XsdTypeLine.Entries.Element).ToList();
                    if (lines.Count > 0) //Children elements do exist
                    {
                        if (TypeType == XsdTypeLine.TypeTypes.none)
                            TypeType = XsdTypeLine.TypeTypes.sequence;
                        //throw new Exception($"Type {TypeName}: Children elements in colection type None are not supported. Guess mechanism is not implemented");

                        ct.TT($"xs:{TypeType.ToString().ToLowerInvariant()}",
                        sq =>
                        {
                            foreach (var ln in Lines.Where(l => l.Entry == XsdTypeLine.Entries.Element))
                                ln.CreateXsd(sq);
                        });
                    }

                    foreach (var ln in Lines.Where(l => l.Entry == XsdTypeLine.Entries.Attribute))
                        ln.CreateXsd(ct);
                }
            );
        }

        internal void Resolve(NbDictionary<string, XsdType> xsdTypes, NbDictionary<string, XsdEnum> xsdEnums)
        {
            var tpTp = Lines.Select(l => l.TypeType).Distinct().ToList(); //Ignore nones
            if (tpTp.Count > 1)
                tpTp.Remove(XsdTypeLine.TypeTypes.none); //If empty lines together with type - ignore empty lines

            TypeType = tpTp.Count switch
            {
                0 => throw new Exception($"Type {TypeName} has no TypeType specified"),
                1 => tpTp[0],
                _ => throw new Exception($"Type {TypeName} must have one TypeType, several values specified: {String.Join(", ", tpTp)}"),
            };
            foreach (var ln in Lines)
                ln.Resolve(xsdTypes, xsdEnums);
        }
    }

    public class XsdEnum
    {
        public string EnumName;
        public string EnumType;
        internal List<XsdEnumLine> Lines;
        internal bool ReferredTo = false;

        internal void CreateXsd(INbTag t)
        {
            t.TAT("xs:simpleType", ct => ct["name"] = EnumName,
                ct => ct.TAT($"xs:restriction", rs => rs["base"] = $"xs:{EnumType}",
                    rs =>
                    {
                        foreach (var ln in Lines)
                            ln.CreateXsd(rs);
                    }));
        }

        /// <summary>
        /// Checks that all enums in the list refer to the same EnumType. Lines with empty EnumType are ignored
        /// </summary>
        internal void Resolve()
        {
            var tpTp = Lines.Select(l => l.EnumType).Distinct().ToList(); //Ignore nones
            if (tpTp.Count > 1)
                tpTp.Remove(""); //If empty lines together with type - ignore empty lines
            EnumType = tpTp.Count switch
            {
                0 => throw new Exception($"Enum {EnumName} has no EnumType specified"),
                1 => tpTp[0],
                _ => throw new Exception($"Enum {EnumName} must have one TypeType, several values specified: {String.Join(", ", tpTp)}"),
            };
        }
    }


    public class XsdEnumLine
    {
        public override string ToString() => $"{EnumName}({EnumType}): {Value}";

        internal void CreateXsd(INbTag rs)
        {
            if (String.IsNullOrWhiteSpace(Comment))
                rs.Tag("xs:enumeration", a => a["value"] = Value);
            else
            {
                rs.TAT("xs:enumeration", a => a["value"] = Value,
                    el => el.TT("xs:annotation",
                        an => an.TV("xs:documentation", Comment))
                );
            }
        }

#pragma warning disable CS0649 //The fields are accessed by CsvSerializer through Reflection
        public string EnumName;
        public string EnumType;
        public string Value;
        public string Comment;
#pragma warning restore CS0649 //The fields are accessed by CsvSerializer through Reflection
    }

    public class XsdTypeLine
    {
        public override string ToString() => $"{EntryName}[{EntryType}]";

#pragma warning disable CS0649 //The fields are accessed by CsvSerializer through Reflection
        public string TypeName;
        public TypeTypes TypeType;
        public Entries Entry;
        public string EntryName;
        public string EntryType;
        public bool Nullable;
        public string Default;
        public string Count;
        public string Comment;
#pragma warning restore CS0649 //The fields are accessed by CsvSerializer through Reflection

        [CsvIgnore]
        private XsdType ResolvedEntryTypeN;

        [CsvIgnore]
        private XsdEnum ResolvedEnumTypeN;

        internal void CreateXsd(INbTag sq)
        {
            if (String.IsNullOrWhiteSpace(Comment))
                sq.Tag(TagName, el => CreateAttrib(el));
            else
            {
                sq.TAT(TagName, el => CreateAttrib(el),
                    el => el.TT("xs:annotation",
                        an => an.TV("xs:documentation", Comment))
                );
            }
        }

        public enum TypeTypes { none = 0, sequence = 1, choice, all }
        public enum Entries { Element = 1, Attribute }

        internal string TagName => Entry switch
        {
            Entries.Element => "xs:element",
            Entries.Attribute => "xs:attribute",
            _ => throw new Exception($"Unsupported Entry: {Entry}"),
        };

        internal string GetTypeStr
        {
            get
            {
                if (ResolvedEntryTypeN != null)
                    return ResolvedEntryTypeN.TypeName;
                else if (ResolvedEnumTypeN != null)
                    return ResolvedEnumTypeN.EnumName;

                return (EntryType.ToLowerInvariant()) switch
                {
                    "intlist" => Model.IntList,
                    _ => $"xs:{EntryType}",
                };
            }
        }

        private void CreateAttrib(INbAtrrib el)
        {
            el["name", EntryName]["type"] = GetTypeStr;
            switch (Entry)
            {
                case Entries.Element:
                    el["minOccurs"] = Nullable ? "0" : "1";
                    el["maxOccurs"] = Count.EqIC("Many") ? "unbounded" : Count;
                    break;

                case Entries.Attribute:
                    el["use"] = Nullable ? "optional" : "required";
                    if (!String.IsNullOrWhiteSpace(Default))
                        el["default"] = Default;
                    break;

                default: throw new Exception($"Unsupported Element type: {Entry}");
            }
        }

        internal void Resolve(NbDictionary<string, XsdType> xsdTypes, NbDictionary<string, XsdEnum> xsdEnums)
        {
            if (xsdTypes.TryGetValue(EntryType, out ResolvedEntryTypeN))
            {
                ResolvedEntryTypeN.ReferredTo = true;
                return;
            }
            else if (xsdEnums.TryGetValue(EntryType, out ResolvedEnumTypeN))
            {
                ResolvedEnumTypeN.ReferredTo = true;
                return;
            }
            else
            {
                if (EntryType.EqIC("boolean") && !String.IsNullOrEmpty(Default))
                    Default = Default.ToLowerInvariant(); //Excel forces "FALSE" instead of false
            }
        }
    }
}
