﻿using cs2xsd;

namespace Schemas
{
    class Program
    {
        static void Main()
        {
            Cs2Xsd.Generate(LinkManagerSettings.Root(), "LinkManSettV1", @"..\..\..\..\LinkManager\Data\LinkManSettV1.xsd", createCs: true);
        }
    }
}
