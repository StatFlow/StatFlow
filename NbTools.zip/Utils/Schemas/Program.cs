﻿using NbXsdV1.Xml;

namespace Schemas
{
    class Program
    {
        static void Main()
        {
            //Cs2Xsd.Generate(LinkManagerSettings.Root(), "LinkManSettV1", @"..\..\..\..\LinkManager\Data\LinkManSettV1.xsd", createCs: true);

            Cs2Xsd.Generate(NbXsdSchema.Root(), "NbXsdV1", @"..\..\..\cs2xsd\NbXsdV1.xsd", createCs: true);
        }
    }
}
