﻿using NbXsdV1.Xml;
using System;

namespace Schemas
{
    static class LinkManagerSettings
    {
        static TypeSequence Proxy()
        {
            return new TypeSequence(nameof(Proxy)
                , new Attr("url", XsType.String, Uses.Required)
                , new Attr("port", XsType.Int, Uses.Optional, deflt: "80")
                , new Attr("pass_variable", XsType.String, Uses.Optional)
                );
        }

        static TypeSequence Paths()
        {
            return new TypeSequence(nameof(Paths)
                , new Elem("icons", XsType.String, 1, 1)
                , new Elem("video_player", XsType.String, 0, 1)
                , new Elem("video_repository", XsType.String, 0, 1)
                );
        }

        static TypeAttrOnly Variable()
        {
            return new TypeAttrOnly(nameof(Variable)
                , new Attr("name", XsType.NCName, Uses.Required)
                , new Attr("value", XsType.String, Uses.Optional, deflt: String.Empty)
                , new Attr("encoded_val", XsType.String, Uses.Optional, deflt: String.Empty)
                );
        }


        static TypeAttrOnly ListColumn()
        {
            return new TypeAttrOnly(nameof(ListColumn)
                , new Attr("name", XsType.String, Uses.Required)
                , new Attr("label", XsType.String, Uses.Optional, deflt: String.Empty)
                , new Attr("width", XsType.Int, Uses.Optional, deflt: "100")
                );
        }

        static TypeAttrOnly Entity()
        {
            return new TypeAttrOnly(nameof(Entity)
                , new Attr("name", XsType.String, Uses.Required)
                , new Attr("show_in_tree", XsType.Bool, Uses.Required)
                );
        }

        static TypeAttrOnly Launcher()
        {
            return new TypeAttrOnly(nameof(Launcher)
                , new Attr("id", XsType.String, Uses.Required)
                , new Attr("path", XsType.String, Uses.Required)
                , new Attr("cl_params", XsType.String, Uses.Optional,deflt: String.Empty)
                , new Attr("extension", XsType.String, Uses.Optional, deflt: String.Empty)
                );
        }

        internal static Elem Root()
        {
            var Root = new TypeSequence("LinkManSett"
                , new Attr("title", XsType.String, Uses.Optional, deflt: "LinkManager")
                , new Elem("proxy", Proxy(), 0, 1)
                , new Elem("paths", Paths(), 0, 1)
                , new ListSingle("variable", Variable())
                , new ListSingle("quick_link", XsType.String)
                , new ListSingle("list_column", ListColumn())
                , new ListSingle("entity", Entity())
                , new ListSingle("launcher", Launcher())
                );

            return new Elem("link_man_sett", Root);
        }
    }
}
