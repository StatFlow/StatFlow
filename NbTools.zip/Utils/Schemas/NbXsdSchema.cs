﻿using NbXsdV1.Xml;
using System;

namespace Schemas
{
    static class NbXsdSchema
    {
        static TypeAttrOnly XBaseTag => new TypeAttrOnly(nameof(BaseTag) //Base for all tags (elem, attrib)
            , new Attr("Name", XsType.String)
            , new Attr("Doc", XsType.String)  //TODO: This should be inner value perhaps???
            );
        static TypeDerived XElem => new TypeDerived(nameof(Elem), XBaseTag);
        static TypeDerived XAttr => new TypeDerived(nameof(Attr), XBaseTag);
        static TypeDerived XListSingle => new TypeDerived(nameof(ListSingle), XBaseTag);

        static TypeSequence XXsType => new TypeSequence(nameof(XsType) //Base for all types
            , new Attr("Name", XsType.String)
            , new Elem("Tags", XBaseTag, 0, Elem.Unbounded)
            );
        static TypeDerived XTypeBuiltIn => new TypeDerived(nameof(TypeBuiltIn), XXsType);
        static TypeDerived XTypeName => new TypeDerived(nameof(TypeName), XXsType);
        static TypeDerived XTypeSequence => new TypeDerived(nameof(TypeSequence), XXsType);
        static TypeDerived XTypeChoice => new TypeDerived(nameof(TypeChoice), XXsType);
        static TypeDerived XTypeAttrOnly => new TypeDerived(nameof(TypeAttrOnly), XXsType);

        static TypeDerived XTypeDerived => new TypeDerived(nameof(TypeDerived), XXsType
            , new Elem("BaseType", XXsType, 1, 1)
            );
        static TypeDerived XTypeList => new TypeDerived(nameof(TypeList), XXsType
            , new Attr("MinLength", XsType.Int, Uses.Optional, "-1")
            , new Elem("ListOfType", XTypeBuiltIn, 1, 1)
            );

        static TypeDerived XTypeEnum => new TypeDerived(nameof(TypeEnum), XXsType
            , new Attr("type", XsType.String, Uses.Required)
            , new Elem("ListOfType", XTypeBuiltIn, 1, 1) //TODO: remove
            , new Elem("items", EnumItem, 1, Elem.Unbounded)
            );

        static TypeAttrOnly EnumItem => new TypeAttrOnly("EnumItem" //Base for all tags (elem, attrib)
            , new Attr("key", XsType.String, Uses.Required)
            , new Attr("value", XsType.String, Uses.Required)  //TODO: This should be inner value perhaps???
            );

        static TypeAttrOnly TypeRef => new TypeAttrOnly("type_ref", new Attr("type", XsType.String, Uses.Required)); //Base for all types

        internal static Elem Root()
        {
            var XTypes = new TypeChoice("types", min: 1, max: -1
                , new Elem("XTypeBuiltIn", XTypeBuiltIn, 0, 1)
                , new Elem("XTypeName", XTypeName, 0, 1)

                , new Elem("XTypeSequence", XTypeSequence, 0, 1)
                , new Elem("XTypeChoice", XTypeChoice, 0, 1)
                , new Elem("XTypeList", XTypeList, 0, 1)
                , new Elem("XTypeEnum", XTypeEnum, 0, 1)
                , new Elem("XTypeAttrOnly", XTypeAttrOnly, 0, 1)
                , new Elem("XTypeDerived", XTypeDerived, 0, 1)
            //, new Attr("deleted", XsType.Bool, Uses.Optional, deflt: "false")
            );

            var Root = new TypeSequence("NbXsd"
                , new Elem("type", XTypes, 1)
                , new Elem("root", TypeRef, 1, 1)
                );

            return new Elem("nbxsd", Root);
        }
    }
}
