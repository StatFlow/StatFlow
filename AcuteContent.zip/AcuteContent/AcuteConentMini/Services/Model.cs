﻿using AcuteContent.Xml;

namespace AcuteConentMini;

public class Model
{
    private readonly AcuteContentXml Xml;
    internal readonly List<NBox> FlatBoxes;
    internal readonly List<string> Alltags;

    public Model(string xmlFilename)
    {
        Xml = AcuteContentXml.LoadFile(xmlFilename);
        FlatBoxes = Xml.boxes.Flatten.ToList();
        Alltags = Xml.tags.Items.OfType<NPic>().Select(p => p.title).ToList();
    }

    public bool IsUserValid(string username, string password)
    {
        return username.ToLowerInvariant() switch
        {
            "nb" => password == "8797",
            _ => false,
        };
    }
}

/*public class NbUser
{
    string Name;
    string Pass;
}*/