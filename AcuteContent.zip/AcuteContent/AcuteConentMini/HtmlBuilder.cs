﻿using AcuteContent.Xml;
using NbCore;

namespace AcuteConentMini;

public static class HtmlBuilder
{
    //const string srcDir = @"C:\Users\budan\Videos\Egypt 23\DCIM\101NIKON";
    //using FilerModel fm = new(srcDir, srcDir + ".filer");
    //fm.Load();

    const string contTypeHtml = "text/html; charset=UTF-8";
    const NBox.LinkType LinkType = NBox.LinkType.RootPath;

    internal static IResult FilesByTag(this Model mdl, string ids, HttpContext ctx, string? userName)
    {
        List<string> selTags = ids?.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList() ?? throw new Exception("ids parameter was not provided");
        List<NBox> filtered = mdl.FlatBoxes.Where(b => b.TagsRecursive.ContainsAllIc(selTags)).ToList();

        HtmlParam htmlPars = new(Title: "Filtered", CssText: Css.Text);
        return Results.Stream(strm => HtmlTag.CreateHtmlPage(strm, htmlPars, t =>
        {
            t.div(t1 => t1.GenerateTagButtons(selTags, mdl.Alltags)).div(t1 => t1.GenerateTiles(filtered)).div(t1 => t1.ListFiles(mdl.FlatBoxes));
        }), contTypeHtml);
    }

    static NbTag ListFiles(this NbTag t, List<NBox> all)
    {
        foreach (NBox box in all) //If tag is in URL, hitting it removes in from the list, if not in URL - adds to URL
        {
            switch (box)
            {
                case NVid vid:
                    t.p(vid.thumb.src);
                    break;
                default:
                    t.p(box.ToString());
                    break;
            }
        }
        return t;
    }

    static NbTag GenerateTagButtons(this NbTag t, List<string> selTags, List<string> allTags)
    {
        foreach (var tag in allTags) //If tag is in URL, hitting it removes in from the list, if not in URL - adds to URL
        {
            IEnumerable<string> newTags = selTags.Contains(tag) ? selTags.Where(t => t != tag) : selTags.Append(tag); //Remove or apped tags depending on selection
            var tagList = String.Join(',', newTags);
            if (!String.IsNullOrEmpty(tagList))
                t.a($"/tags?ids={tagList}", tag);
            else
                t.a($"/", tag);
        }
        return t;
    }

    static NbTag GenerateTiles(this NbTag t, List<NBox> filtered)
    {
        foreach (NBox box in filtered) //.Where(b => b is not NDir)
        {
            switch (box)
            {
                case NVid vid:
                    string? vidPath = vid.Parent?.Path(LinkType);
                    t.span("tile", t => GenerateTile(t, vidPath + vid.thumb.src, vidPath + vid.src));
                    break;
                case NPic pic:
                    string picSrc = pic.Parent?.Path(LinkType) + pic.src;
                    t.span("tile", t => GenerateTile(t, picSrc, picSrc));
                    break;
                default:
                    break;
            }
        }
        return t;
    }

    static void GenerateTile(NbTag t, string thumbUrl, string linkUrl)
    {
        t.a(linkUrl, t2 =>
            t2.TA("img", a2 => a2["height", "100"]["src"] = thumbUrl).Text(thumbUrl ?? "No Thumb file found"));
    }

}
