using AcuteConentMini;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.FileProviders;
using System.Security.Claims;

//const string cssFile = @"C:\Repo\Cs\AcuteContent\AcuteContentBuilder\Data\nb.css"; //TODO: copy to dst folder or embed

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<Model>(new Model(@"C:\Sync\AcuteContent\TestSrc.xml"));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddAuthentication(BasicAuthenticationHandler.Name).AddScheme<AuthenticationSchemeOptions, BasicAuthenticationHandler>(BasicAuthenticationHandler.Name, null);
builder.Services.AddAuthorization();

var app = builder.Build();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
}
//app.UseAuthentication();
app.UseAuthorization();
app.UseHttpsRedirection();




//app.MapGet("/", [AllowAnonymous] () => "Hello World!");
/*app.MapGet("/auth", [Authorize] () =>
{
    return FilesByTag("MarK");
}).WithName("GetWeatherForecast");*/

app.MapGet("/tags", [Authorize] (string ids, HttpContext ctx, ClaimsPrincipal user, Model mdl) => mdl.FilesByTag(ids, ctx, user.Identity?.Name));

//https://stackoverflow.com/questions/38005913/fileservermiddleware-with-credentials
app.UseFileServer(new FileServerOptions
{
    FileProvider = new PhysicalFileProvider(@"C:\Sync\AcuteContent\TestSrc"),
    RequestPath = "",
    EnableDefaultFiles = true,
    EnableDirectoryBrowsing = true,

});

app.Run();



//https://learn.microsoft.com/en-us/aspnet/core/fundamentals/minimal-apis/responses?view=aspnetcore-7.0  Minimap API return types

//builder.Services.AddDbContext<TodoDb>(opt => opt.UseInMemoryDatabase("TodoList"));
//builder.Services.AddDatabaseDeveloperPageExceptionFilter();

/*app.MapGet("/todoitems", async (TodoDb db) =>
    await db.Todos.ToListAsync());

app.MapGet("/todoitems/complete", async (TodoDb db) =>
    await db.Todos.Where(t => t.IsComplete).ToListAsync());

app.MapGet("/todoitems/{id}", async (int id, TodoDb db) =>
    await db.Todos.FindAsync(id)
        is Todo todo
            ? Results.Ok(todo)
            : Results.NotFound());

app.MapPost("/todoitems", async (Todo todo, TodoDb db) =>
{
    db.Todos.Add(todo);
    await db.SaveChangesAsync();

    return Results.Created($"/todoitems/{todo.Id}", todo);
});

app.MapPut("/todoitems/{id}", async (int id, Todo inputTodo, TodoDb db) =>
{
    var todo = await db.Todos.FindAsync(id);

    if (todo is null) return Results.NotFound();

    todo.Name = inputTodo.Name;
    todo.IsComplete = inputTodo.IsComplete;

    await db.SaveChangesAsync();

    return Results.NoContent();
});

app.MapDelete("/todoitems/{id}", async (int id, TodoDb db) =>
{
    if (await db.Todos.FindAsync(id) is Todo todo)
    {
        db.Todos.Remove(todo);
        await db.SaveChangesAsync();
        return Results.NoContent();
    }

    return Results.NotFound();
});*/
