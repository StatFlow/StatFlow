﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text;

namespace AcuteConentMini;

public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
{
    public const string Name = "BasicAuthentication";

    private const string Realm = "Basic realm=\"aws.mytfp.org\"";
    private readonly Model Users;

    public BasicAuthenticationHandler(IOptionsMonitor<AuthenticationSchemeOptions> options, ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock, Model users)
        : base(options, logger, encoder, clock)
    {
        Users = users;
    }

    protected override Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        var authHeader = Request.Headers["Authorization"].ToString();
        if (authHeader != null && authHeader.StartsWith("basic", StringComparison.OrdinalIgnoreCase))
        {
            var credentialstring = Encoding.UTF8.GetString(Convert.FromBase64String(authHeader[6..].Trim()));
            var credentials = credentialstring.Split(':');
            string name = credentials[0], pass = credentials[1];

            if (Users.IsUserValid(name, pass))
            {
                var claims = new[] { new Claim(ClaimTypes.Name, name), new Claim(ClaimTypes.Role, "user") };
                var identity = new ClaimsIdentity(claims, "Basic");
                var claimsPrincipal = new ClaimsPrincipal(identity); //TODO cash values in UserService
                return Task.FromResult(AuthenticateResult.Success(new AuthenticationTicket(claimsPrincipal, Scheme.Name)));
            }
        }

        Response.StatusCode = 401;
        Response.Headers.Add("WWW-Authenticate", Realm);
        return Task.FromResult(AuthenticateResult.Fail("Invalid Authorization Header"));
    }
}
