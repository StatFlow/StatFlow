﻿public static class Css
{
    public const string Text = @"
:root {
    --pal1: #06283d;
    --pal2: #256d85;
    --pal3: #47b5ff;
    --pal4: #dff6ff;
}

@media only screen and (-webkit-min-device-pixel-ratio: 1) {
    body {
        font-family: Roboto, Arial, sans-serif;
        color: var(--pal4);
        font-size: 14px;
        font-weight: bolder;
        margin: 4px;
        background-color: var(--pal1);
    }

    video {
        width: 600px;
        float: left;
        margin: 5px;
        border-radius: 5px;
    }

    .vid_tile {
        float: left;
        margin: 5px;
        background-color: var(--pal2);
    }
}

@media only screen and (-webkit-min-device-pixel-ratio: 2) {
    body {
        font-family: Roboto, Arial, sans-serif;
        color: var(--pal4);
        font-size: 20px;
        font-weight: 400;
        margin: 0;
        padding: 0;
        background-color: var(--pal1);
    }

    video {
        width: 100%;
        margin: 0;
        border-radius: 5px;
    }

    .vid_tile {
        float: left;
        margin: 0;
        background-color: var(--pal2);
    }
}

img {
    float: left;
    margin: 0 5px 0 0;
    border-radius: 5px;
}

.tile {
    float: left;
    width: 370px;
    height: 100px;
    padding: 0px;
    margin: 5px;
    background-color: #e0e0e0;
    border-radius: 5px;
}
";

}
