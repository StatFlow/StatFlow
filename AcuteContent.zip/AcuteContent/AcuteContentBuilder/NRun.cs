﻿using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using Drw = DocumentFormat.OpenXml.Drawing;

internal class NRun
{
    internal static NRun ParseRun(Run run, NbDictionary<string, Uri> extRel)
    {
        Drawing? drw = run.ChildElements.OfType<Drawing>().SingleOrDefaultVerbose(who: "Run", whats: "Drawing children");
        if (drw != null)
            return new NRunDrawing(drw, extRel);

        Text? txt = run.ChildElements.OfType<Text>().SingleOrDefaultVerbose(who: "Run", whats: "Text children");
        if (txt != null)
            return new NRunText(txt);

        throw new Exception("Run contains neither Drawing, nor Text");
    }

}

internal class NRunText : NRun
{
    private readonly Text Txt;

    public NRunText(Text txt) => Txt = txt;
}

internal class NRunDrawing : NRun
{
    internal readonly string Id;
    internal readonly Uri Uri;

    public NRunDrawing(Drawing drw, NbDictionary<string, Uri> extRel)
    {
        Drw.GraphicData grD = drw.Inline?.Graphic?.GraphicData ?? throw new Exception("GraphicData can't be found");
        Drw.Pictures.Picture pic = grD.GetChild<Drw.Pictures.Picture>();
        string? link = (pic.BlipFill?.Blip?.Link?.Value) ?? throw new Exception("There is no link = maybe support imbedded images");
        Id = link;
        Uri = extRel[link];
    }
}

internal static class Ext
{
    public static T GetChild<T>(this OpenXmlElement elem) => elem.ChildElements.OfType<T>().SingleOrDefault()
        ?? throw new Exception($"element {elem} doesn't have a child of type {typeof(T).Name}");
}
