﻿using System.Text.RegularExpressions;

internal static partial class Regexs
{
    [GeneratedRegex(@"^\d+\.*\s*(.+)$", RegexOptions.Compiled)]
    private static partial Regex LeadingNumber();

    [GeneratedRegex(@"^(.+)_snapshot_(.+)(\.jpg)$")]
    internal static partial Regex MediaPlayerSnapshotFile();


    internal static string DropLeadingNumber(FileInfo file)
    {
        string res = Path.GetFileNameWithoutExtension(file.Name);
        var match = LeadingNumber().Match(res);
        if (match.Success)
            return match.Groups[1].Value;

        return res;
    }

    internal static string TitleFromFileName(FileInfo file)
    {
        string res = Path.GetFileNameWithoutExtension(file.Name);
        var match = LeadingNumber().Match(res);
        if (match.Success)
            return match.Groups[1].Value;

        return res;
    }

    [GeneratedRegex(@"^(.*)(\[.+\])\.\S+$")]  //Tags must exist!
    private static partial Regex TitleAndTags(); //Use*? to make the* non-greedy.

    internal static (string title, string[] tags) TitleAndTags(string fileName)
    {
        Match match = TitleAndTags().Match(fileName);
        if (!match.Success)
        {
            throw new ArgumentException($"File '{fileName}' doesn't match the pattern: 'Some name [tags].ext'");
        }

        return (match.Groups[1].Value, match.Groups[2].Value.Trim('[', ']', ' ').Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries));
    }


    [GeneratedRegex(@"^(.*)(\[.+\])$")]  //Tags must exist!
    private static partial Regex TitleAndTagsFolder(); //Use*? to make the* non-greedy.

    internal static (string title, string[] tags) TitleAndTagsFolder(string folderName)
    {
        Match match = TitleAndTagsFolder().Match(folderName);
        if (!match.Success)
        {
            throw new ArgumentException($"Folder '{folderName}' doesn't match the pattern: 'Some name [tags]'");
        }

        return (match.Groups[1].Value, match.Groups[2].Value.Trim('[', ']', ' ').Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries));
    }
}
