﻿using AcuteContent.Xml;
using AcuteContentBuilder.Xml;

internal record ProcInPlaceContext(DirectoryInfo SrcFolder, bool EnsureThumbs, string MediaPlayer, Dictionary<string, SiteTag> Tags, HashSet<string> MissingTags);


internal static class ContentRecursive
{
    public static AcuteContentXml BuildAcuteContentXml(AcuteContentBuilderConfig conf)
    {
        List<SiteTagGroup> siteStruct = null!;
        HashSet<string> missingTags = new(comparer: StringComparer.OrdinalIgnoreCase);

        Dictionary<string, SiteTag> tagDict = new(comparer: StringComparer.OrdinalIgnoreCase);
        NDir tags = ProcessInplaceTagsFolderRecc(tagDict);

        ProcInPlaceContext cont = new(conf.SourceDir, conf.ensure_thumbs, conf.media_player, tagDict, missingTags);

        List<NBox> boxes = DirectoryToBoxes(siteStruct, cont);
        NDir root = new() { Items = boxes.ToArray() }; //url = conf.SourceDir.FullName

        if (missingTags.Count > 0)
            throw new Exception($"Tags: {String.Join(", ", missingTags)} are missing");

        AcuteContentXml xml = new() { title = cont.SrcFolder.Name, boxes = root, tags = tags };
        xml.Resolve();
        return xml;
    }

    private static NDir ProcessInplaceTagsFolderRecc(IDictionary<string, SiteTag> tagDict)
    {
        string[] tagNames = new[] { "NikB", "prikol", "dogfish1", "MarK", "dmil", "freedive" };

        NDir root = new() { Items = tagNames.Select(n => new NPic() { title = n }).ToArray(), url = "false" };
        foreach (NPic tag in root.Items.OfType<NPic>())
        {
            if (tagDict.ContainsKey(tag.title))
                throw new Exception($"Tag {tag.title} is found twice in tags directory");
            else
                tagDict.Add(tag.title, null!);
        }
        return root;
    }

    private static List<NBox> DirectoryToBoxes(List<SiteTagGroup> siteStruct, ProcInPlaceContext cont)
    {
        List<NBox> boxes = new();

        //Process dirs
        var dirs = cont.SrcFolder.GetDirsSafe();
        foreach (DirectoryInfo dir in dirs)
        {
            NBox? nbox = ProcessContForDir(siteStruct, cont with { SrcFolder = dir });
            if (nbox != null)
                boxes.Add(nbox);
        }

        //Process Files
        Dictionary<string, VidEntry> vidEntries = new(StringComparer.OrdinalIgnoreCase);
        List<FileInfo> picEntries = new();

        foreach (FileInfo fi in cont.SrcFolder.GetFilesSafe().OrderBy(fi => fi.Name))
        {
            if (fi.Name == "desktop.ini")
                continue;

            switch (NbMedia.GetFileMediaType(fi))
            {
                case NbMedia.FileMediaTypes.Video:
                    vidEntries.Add(fi.Name, new VidEntry(fi));
                    break;

                case NbMedia.FileMediaTypes.Photo:
                    if (fi.NameWithoutExtension().EqIC("folder")) //Special file, used at the level above
                        continue;

                    string? key = vidEntries.Keys.FirstOrDefault(k => fi.Name.StartsWith(k, StringComparison.OrdinalIgnoreCase));
                    if (key != null) //File is tag file for video
                    {
                        (string _, string[] tags) = Regexs.TitleAndTags(fi.Name);

                        if (!vidEntries.TryGetValue(key, out var rec))
                            throw new Exception($"Can't find video '{key}' for tag file '{fi.FullName}'");

                        if (rec.ThumbFile != null)
                            throw new Exception($"Video '{rec.VidFile.FullName}' has two thumbnails: '{rec.ThumbFile.FullName}' and '{fi.FullName}'");

                        rec.ThumbFile = fi;  //Attach thumbnail to a video file
                    }
                    else //File is a photo
                    {
                        picEntries.Add(fi);
                    }
                    break;

                /*tring? key = vidEntries.Keys.SingleOrDefaultVerbose(k => fi.Name.StartsWith(k, StringComparison.OrdinalIgnoreCase));
                if (key != null) //Attach thumbnail to a video file
                {
                var rec = vidEntries[key];
                if (rec.ThumbFile != null)
                    throw new Exception($"Video '{rec.VidFile.FullName}' has two thumbnails: '{rec.ThumbFile.FullName}' and '{fi.FullName}'");
                rec.ThumbFile = fi;
                }*/
                default: break; //Ignore other types of files
            }
        }

        if (cont.EnsureThumbs)
            EnsureThumbs(vidEntries, cont.SrcFolder, cont.MediaPlayer);

        foreach (VidEntry vidEntry in vidEntries.Values.OrderBy(ve => ve.VidFile.Name)) //Pictures
        {
            try
            {
                NBox? nbox = ProcessContVid(vidEntry, cont);
                if (nbox != null)
                    boxes.Add(nbox);
            }
            catch
            {
                //if (vidEntry.ThumbFile != null)
                //    Task.Run(() => NbProcess.Explorer(vidEntry.ThumbFile));
                throw; //Continue loop
            }
        }

        foreach (FileInfo file in picEntries)
        {
            boxes.Add(new NPic() { src = file.Name, title = file.NameWithoutExtension() });
        }
        return boxes;
    }

    private static NBox? ProcessContForDir(List<SiteTagGroup> siteStruct, ProcInPlaceContext cont)
    {
        FileInfo folderThumbFi = cont.SrcFolder.GetFiles("folder.*").FirstOrDefault() ?? throw new FileNotFoundException($"Folder '{cont.SrcFolder.FullName}' doesn't have a folder.* file inside of it to be used as a folder picture");

        List<NBox> boxes = DirectoryToBoxes(siteStruct, cont);
        boxes.Add(new NThumb() { title = cont.SrcFolder.Name, src = folderThumbFi.Name });

        var (_, tags) = Regexs.TitleAndTagsFolder(cont.SrcFolder.Name); //Title is unused
        return new NDir() { Items = boxes.ToArray(), url = cont.SrcFolder.Name, tags = tags };
    }

    private static NVid? ProcessContVid(VidEntry vid, ProcInPlaceContext cont)
    {
        if (vid.ThumbFile == null)
            return null;

        try
        {
            var (title, tags) = vid.TitleAndTags();  //Title and Tags for a single video
            if (tags.ContainsAnyIC(ProcessAndMoveFlat.SkipTags))  //Skipping by tag
                return null;

            if (String.IsNullOrWhiteSpace(title))
                title = String.Join(", ", tags);

            Console.Write($"Processing '{vid.VidFile.Name}'...");
            NThumb nthumb = new() { src = vid.ThumbFile.Name, title = title, };

            NVid nvid = new() { src = vid.VidFile.Name, src_small = vid.VidFile.Name, thumb = nthumb, tags = tags };  //Video files itself
            Console.WriteLine("done!");

            //Add the box to the Tag object's collection of boxes
            foreach (string tag in tags)
            {
                if (cont.Tags.TryGetValue(tag, out var t))
                { } //t.Vids.Add(nvid);
                else
                    cont.MissingTags.Add(tag);
            }
            return nvid;
        }
        catch (Exception ex)
        {
            Console.WriteLine(NbException.Exception2String(ex));
            //Task.Run(() => NbProcess.Explorer(vid.ThumbFile));
            throw;
        }
    }

    private static void EnsureThumbs(Dictionary<string, VidEntry> vids, DirectoryInfo workDir, string mpc)
    {
        foreach (var ent in vids.Values.Where(e => e.ThumbFile == null))
        {
            NbProcess.RunSync(mpc, workDir, ent.VidFile.FullName);
        }
    }

    /*internal static void ProcessRecur(DirectoryInfo di)
    {
        var (vids, _) = ScanDir(di);
        EnsureThumbs(vids, di);

        foreach (DirectoryInfo subDir in di.GetDirectories().OrderBy(d => d.Name))
            ProcessRecur(subDir);
    }

    private static void EnsureThumbs(Dictionary<string, VidEntry> vids, DirectoryInfo workDir)
    {
        foreach (var ent in vids.Values.Where(e => e.ThumbFile == null))
        {
            NbProcess.RunSync(Mpc, workDir, ent.VidFile.FullName);
        }
    }

    //Scan directory, attach thumbnails to video entries and collect standalone pictures
    internal static (Dictionary<string, VidEntry> Vids, List<FileInfo> Pics) ScanDir(DirectoryInfo di)
    {
        Dictionary<string, VidEntry> vidEntries = new();
        List<FileInfo> picEntries = new();

        foreach (FileInfo fi in di.GetFiles().OrderBy(fi => fi.Name))
        {
            switch (NbMedia.GetFileMediaType(fi))
            {
                case NbMedia.FileMediaTypes.Video:
                    vidEntries.Add(fi.Name, new VidEntry(fi));
                    break;

                case NbMedia.FileMediaTypes.Photo:
                    string? key = vidEntries.Keys.SingleOrDefaultVerbose(k => fi.Name.StartsWith(k, StringComparison.OrdinalIgnoreCase));
                    if (key != null) //Attach thumbnail to a video file
                    {
                        var rec = vidEntries[key];
                        if (rec.ThumbFile != null)
                            throw new Exception($"Video '{rec.VidFile.FullName}' has two thumbnails: '{rec.ThumbFile.FullName}' and '{fi.FullName}'");
                        rec.ThumbFile = fi;
                    }
                    else //Or save as standalone picture
                        picEntries.Add(fi);
                    break;

                default: break; //Ignore other types of files
            }
        }
        return (vidEntries, picEntries);
    }*/
}


