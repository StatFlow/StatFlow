﻿using DocumentFormat.OpenXml.Wordprocessing;
using System.Xml.Serialization;

namespace AcuteContent.Xml;

public abstract partial class NBox
{
    public enum LinkType
    {
        /// <summary>
        /// Local means no path is included in the link and the html file will be stored together with files
        /// </summary>
        Local,
        /// <summary>
        /// The links will include the path to the root of the site (i.e. all subdirectories
        /// </summary>
        RootPath,
        //DiskPath  disabled for now
    }

    internal static NBox? ParseParagraph(Paragraph par, AcuteContentParams runPar, NbDictionary<string, Uri> extRel)
    {
        var runs = par.ChildElements.OfType<Run>().ToList();

        var parsetRuns = runs.Select(r => NRun.ParseRun(r, extRel)).ToList();
        int textCount = parsetRuns.OfType<NRunText>().Count();
        int drwCount = parsetRuns.OfType<NRunDrawing>().Count();

        if (textCount == 0 && drwCount == 0)
            return null;
        else if (textCount == 0 && drwCount == 1)
            return new NPic(parsetRuns.OfType<NRunDrawing>().Single(), runPar);
        else if (textCount == 0 && drwCount > 1)
            return new NPics(parsetRuns.OfType<NRunDrawing>().ToArray(), runPar);
        else if (textCount > 0 && drwCount == 0)
            return new NText(par, runPar);
        else
            return null;
    }

    [XmlIgnore]
    public NDir? Parent;
    public abstract void WriteHtml(NbTag t, NDir? parent, LinkType linkType);

    public virtual IEnumerable<NBox> Flatten
    {
        get { yield return this; }
    }
    public IEnumerable<string> TagsRecursive
    {
        get
        {
            var one = new List<string>(Parent?.TagsRecursive ?? Enumerable.Empty<string>());
            return one.Concat(tags.Safe());
            //(Parent?.TagsRecursive ?? Enumerable.Empty<string>()).Concat(tags.Safe());
        }
    }
}

public partial class NText : NBox
{
    //public string text;
    public NText() { } //For Serialization

    internal NText(Paragraph par, AcuteContentParams _)
    {
        text = par.InnerText;
    }

    public override void WriteHtml(NbTag t, NDir? parent, LinkType linkType)
    {
        t.TV("p", text);
    }
}

public partial class NPic : NBox
{
    //public string src;
    public NPic() { } //For Serialization

    internal NPic(NRunDrawing nboxRunDrawing, AcuteContentParams htmlPar)
    {
        src = CopyImageFile(nboxRunDrawing, htmlPar);
    }

    public override void WriteHtml(NbTag t, NDir? parent, LinkType linkType) => t.img(src);

    internal static string CopyImageFile(NRunDrawing drw, AcuteContentParams contPar)
    {
        string srcFilePath = drw.Uri.LocalPath;
        string dstFileName = $"{contPar.Id}_{drw.Id}{Path.GetExtension(srcFilePath).ToLowerInvariant()}";
        string dstFile = Path.Combine(contPar.Directory, dstFileName);

        if (!File.Exists(dstFile))
            File.Copy(srcFilePath, dstFile);
        return dstFileName;
    }

    public override string ToString() => src;
}


public partial class NThumb : NBox
{
    public NThumb() { }

    internal NThumb(NRunDrawing nboxRunDrawing, AcuteContentParams htmlPar)
    {
        src = NPic.CopyImageFile(nboxRunDrawing, htmlPar);
    }

    public override void WriteHtml(NbTag t, NDir? parent, LinkType linkType) => t.img(parent?.Path(linkType) + src);

    public override string ToString() => src;
}


public partial class NVid : NBox
{
    /*
       <figure>
                <video controls width="640" poster="http://qnikbud.myftp.org:8800/dada/Lidl1/Lidl.jpg" preload="none">
                    <source src="http://qnikbud.myftp.org:8800/dada/Lidl1/Lidl.mp4"  type="video/mp4">
                    Sorry, your browser doesn't support embedded videos.
                </video>
                <figcaption>Caption</figcaption>
        <figure>
     */


    public override void WriteHtml(NbTag t, NDir? parent, LinkType linkType)
    {
        string path = parent.Path(linkType);

        //["preload", "none"]["controls", "true"]["width", "600"]
        t.TAT("video", at => at["preload", "none"]["controls", "true"]["poster"] = path + thumb.src,
            t1 => t1.TAV("source", a1 => a1["type", "video/mp4"]["src"] = path + src_small, "Sorry, your browser doesn't support embedded videos")
            );

        if (String.IsNullOrEmpty(thumb.title))
            return;

        string dwnFile = $"{thumb.title}{src[src.LastIndexOf('.')..].ToLowerInvariant()}";
        t.p(t1 => t1
            .a(path + src, thumb.title)
            .a(href: path + src, cls: "tooltip", download: dwnFile, t1 => t1
                .span("tooltiptext", "Download Source")
                .img(cls: "ac_btn_down")));
        //.TA("img", at => at["class"] = )));
    }

    public override string ToString() => src;
}

public partial class NDir : NBox
{
    public NThumb? Thumb => Items.OfType<NThumb>().SingleOrDefault();

    public NDir() { }

    public NDir(string url, NThumb thumb)
    {
        this.url = url;
        Items = new[] { thumb };
    }

    public void Resolve()
    {
        foreach (NBox item in Items.Safe())
        {
            item.Parent = this;
            if (item is NDir ndir)
                ndir.Resolve();
        }
    }

    //public string FullPath => Parent != null ? Parent.FullPath + '\\' + url : url;
    //public string FullUrl => Parent?.FullPath ?? "file:///" + url;

    /// <summary>
    /// Path depending on the link type requested. For Local the empty string is returned. Non-empty paths end with /
    /// </summary>
    /// <param name="linkType"></param>
    public string Path(LinkType linkType)
    {
        return linkType switch
        {
            LinkType.Local => String.Empty,
            LinkType.RootPath => Parent?.Path(linkType) + this.url + '/',
            _ => throw new NbExceptionEnum<LinkType>(linkType),
        };
    }

    public override IEnumerable<NBox> Flatten => Items.Safe().SelectMany(i => i.Flatten).Prepend(this);

    public override void WriteHtml(NbTag t, NDir? parent, LinkType linkType)
    {
        t.TAT("a", t1 => t1["href"] = $"{url}/index.html",
            t2 => t2.TA("img", a2 => a2["width", "200"]["src"] = $"{url}/{Thumb?.src}").Text(Thumb?.title ?? "No Thumb file found")
            );
    }

    public override string ToString() => $"{url} [{Items?.Length ?? 0}]";
}

public partial class NPics : NBox
{
    public NPics() { } //For Serialization
                       //public NPic[] pic;

    //private readonly NRunDrawing[] Drawings;
    internal NPics(NRunDrawing[] nboxRunDrawings, AcuteContentParams runPar)
    {
        //Drawings = nboxRunDrawings;
        List<NPic> pics = new(nboxRunDrawings.Length);
        foreach (NRunDrawing drawing in nboxRunDrawings)
        {
            var npic = new NPic(drawing, runPar);
            pics.Add(npic);
        }
        pic = pics.ToArray();
    }

    public override void WriteHtml(NbTag t, NDir? parent, LinkType linkType)
    {
        foreach (NPic p in pic)
            t.img(p.src);
    }
}

public partial class AcuteContentXml
{
    public void Resolve()
    {
        boxes.Resolve();
        tags?.Resolve();
    }
}

public record AcuteContentParams(string Directory, string Id)
{
    internal string HtmlFileName => $"{Directory}\\{Id}.html";
}
