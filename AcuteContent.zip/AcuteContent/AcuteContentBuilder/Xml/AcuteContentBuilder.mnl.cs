﻿using System.Xml.Serialization;

namespace AcuteContentBuilder.Xml;

public partial class AcuteContentBuilderConfig
{
    private void Resolve()
    {
        SourceDir = new DirectoryInfo(source_dir);
        if (!SourceDir.Exists)
            throw new Exception($"Source directory '{source_dir}' doesn't exist");

        DestDir = new DirectoryInfo(destination_dir);
        if (!DestDir.Exists)
            throw new Exception($"Destination directory '{destination_dir}' doesn't exist");

        TagstDir = new DirectoryInfo(tags_dir);
        if (!TagstDir.Exists)
            throw new Exception($"Tags directory '{tags_dir}' doesn't exist");

        TagsHelperDir = new DirectoryInfo(tag_helper_dir);
        if (!TagsHelperDir.Exists)
            throw new Exception($"Tags directory '{tag_helper_dir}' doesn't exist");
    }

    [XmlIgnore]
    public DirectoryInfo SourceDir { get; private set; } = default!;
    [XmlIgnore]
    public DirectoryInfo DestDir { get; private set; } = default!;
    [XmlIgnore]
    public DirectoryInfo TagstDir { get; private set; } = default!;
    [XmlIgnore]
    public DirectoryInfo TagsHelperDir { get; private set; } = default!;

}
