﻿using AcuteContent.Xml;
using AcuteContentBuilder.Xml;

//const string nikon = @"C:\Users\budan\Videos\Egypt 23\DCIM\101NIKON";
//const string tagsDir = @"C:\Sync\AcuteContent\Tags";
//const string prikol = @"C:\Users\budan\Videos\Prikol";
//string srcFolder = @"C:\Temp\AcuteContent\Vids";
//string srcFolder = nikon;
//string dstFolder = @"C:\Repo\AcuteAlert\AcuteContentWeb\wwwroot";
//string dstFolder = @"C:\AutoDelete\Vids";
//string dstFolder = @"M:\AcuteContent";

//if (Directory.Exists(dstFolder))
//    Directory.Delete(dstFolder, true);



if (args.Length != 1)
    throw new Exception("Config XML name should be provided");


//Process and move FlatDir - current content creator
var conf = AcuteContentBuilderConfig.LoadFile(@"Xml\" + args[0] + (args[0].EndsWith(".xml") ? "" : ".xml"));
AcuteContentXml cont = ContentRecursive.BuildAcuteContentXml(conf);
cont.Save(@"C:\Sync\AcuteContent\TestSrc2.xml"); 

//var htmPage = HtmlInPlace.CreateXmlForDirsReccur(cont.boxes);
//await NbProcess.Browser(htmPage);



/*ProcessAndMoveFlat.ProcessSimpleDir(conf);
await NbProcess.Browser(conf.browser_url);*/


//ProcessWord();
/*static Task ProcessWord()
{
    //string otherFile = @"C:\Temp\AcuteContent\Page1.docx";
    string fileName = @"C:\Temp\AcuteContent\2009.09.16 MSDOS\MsDos.docx";
    ParseWordDoc.OpenWordprocessingDocumentReadonly(fileName);
    return Task.CompletedTask;
}*/


// Content xml must be created in the destination folder, together with the thumbnails and the files with short names (MD5)
// 
// Then compilation is happening:
// 1. Long files names are replaced with MD5.
// 2. Big pictures / videos are processed to reduce in size.
// 3. Files are copied into a new folder representing servers
//Console.WriteLine("Hello, World!");
