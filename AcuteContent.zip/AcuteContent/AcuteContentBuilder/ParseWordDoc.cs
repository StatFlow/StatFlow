﻿using AcuteContent.Xml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Diagnostics;
using System.IO.Packaging;

internal static class ParseWordDoc
{
    public static void OpenWordprocessingDocumentReadonly(string filepath)
    {
        var linkType = NBox.LinkType.Local;
        NDir? ndir = null;

        using WordprocessingDocument wordDocument = WordprocessingDocument.Open(filepath, isEditable: false); // Open a WordprocessingDocument based on a filepath.
        MainDocumentPart mdp = wordDocument.MainDocumentPart ?? throw new Exception($"There is no {nameof(MainDocumentPart)} in the document"); ;
        NbDictionary<string, Uri> extRel = mdp.ExternalRelationships.ToNbDictionary(r => r.Id, r => r.Uri, description: nameof(MainDocumentPart.ExternalRelationships));


        //ImagePart imagePart = mdp.AddImagePart(ImagePartType.Jpeg);
        /*using (FileStream stream = new FileStream(@"C:\Temp\AcuteContent\aN173Z3_700b.jpg", FileMode.Open))
        {
            imagePart.FeedData(stream);
        }
        AddImageToBody(wordDocument, mdp.GetIdOfPart(imagePart));*/

        //MainDocumentPart mdp = wordDocument.Parts.Select(p => p.OpenXmlPart).OfType<MainDocumentPart>().FirstOrDefault() ?? throw new Exception($"There is no {nameof(MainDocumentPart)} in the document");
        //var parts = mdp.Parts.ToDictionary(p => p.RelationshipId, p => p.OpenXmlPart);

        //PrintParts(wordDocument.Parts, 0);
        //PrintParts(wordDocument.MainDocumentPart?.Parts, 0);


        string nbCss = File.ReadAllText("nb.css");

        Body body = wordDocument?.MainDocumentPart?.Document.Body ?? throw new Exception("Body is not found"); // Assign a reference to the existing document body.  

        PrintRecur(body, 0);

        AcuteContentParams contPars = new(@"C:\Temp\AcuteContent\Rendered2", "MsDos2");
        NbFs.CreateDirRecursive(contPars.Directory);
        var acuteContentXml = CreateAcuteContentXml(mdp, contPars);
        acuteContentXml.title = "MsDos";
        //acuteContentXml.Save(Path.Combine(contPars.Directory, contPars.Id, "AcuteContent.xml"));

        HtmlParam htmlPars = new(acuteContentXml.title, nbCss);
        HtmlFileName htmlFile = new(contPars.Directory, contPars.Id, DateTime.UtcNow);
        HtmlTag.CreateHtmlPage(htmlFile.HtmlFileFullName, htmlPars, t => ForAllBoxes(t, ndir, linkType, acuteContentXml));

        /*foreach (Paragraph par in body.ChildElements.OfType<Paragraph>())
        {
            Run? run = par.ChildElements.OfType<Run>().SingleOrDefault();
            if (run != null)
                ProcessRun(null, run);
            else
            {
                Debug.WriteLine($"Paragraph '{par}' doesn't contain any runs");
                continue;
            }
        }*/
        // Attempt to add some text.
        //Paragraph para = body.AppendChild(new Paragraph());
        //Run run = para.AppendChild(new Run());
        //run.AppendChild(new Text("Append text in body, but text is not saved - OpenWordprocessingDocumentReadonly"));

        // Call Save to generate an exception and show that access is read-only.
        // wordDocument.MainDocumentPart.Document.Save();
    }

    internal static void ForAllBoxes(NbTag t, NDir? ndir, NBox.LinkType linkType, AcuteContentXml cont)
    {
        foreach (NBox box in cont.boxes.Items.Safe())
            box.WriteHtml(t, ndir, linkType);
    }

    private static AcuteContentXml CreateAcuteContentXml(MainDocumentPart mdp, AcuteContentParams htmlPar)
    {
        Body body = mdp.Document.Body ?? throw new Exception("Body is not found"); // Assign a reference to the existing document body.  
        NbDictionary<string, Uri> extRel = mdp.ExternalRelationships.ToNbDictionary(r => r.Id, r => r.Uri, description: nameof(MainDocumentPart.ExternalRelationships));

        List<NBox> boxes = new(body.ChildElements.Count);
        foreach (Paragraph par in body.ChildElements.OfType<Paragraph>())
        {
            NBox? parsedPar = NBox.ParseParagraph(par, htmlPar, extRel);
            if (parsedPar == null)
                continue;

            boxes.Add(parsedPar);
        }

        AcuteContentXml acuteContentXml = new() { boxes = new NDir() { Items = boxes.ToArray() } };
        return acuteContentXml;
    }


    /*public static void ProcessParagraph(INbTag t, NbDictionary<string, Uri> extRel, Paragraph par)
    {
        foreach (OpenXmlElement run in par.ChildElements.OfType<Run>())
        {
        }
    }

    internal static void ProcessDrawing(INbTag t, NbDictionary<string, Uri> extRel, Drawing drw)
    {
        Drw.GraphicData grD = drw.Inline?.Graphic?.GraphicData ?? throw new Exception("GraphicData can't be found");
        Drw.Picture pic = grD.GetChild<Drw.Picture>();
        string? link = pic.BlipFill?.Blip?.Link?.Value;
        if (link == null) //There is no link = maybe support imbedded images
            return;
        Uri uri = extRel[link];

        t.TA("img", a => a["src"] = uri.ToString());
    }*/

    //DocumentFormat.OpenXml.Drawing.Pictures.Picture



    /// <summary>
    /// Prints the contents for OpenXmlElement for debugging, recurcive
    /// </summary>
    /// <param name="elem"></param>
    /// <param name="level"></param>
    public static void PrintRecur(OpenXmlElement elem, int level)
    {
        var children = elem.ChildElements.ToArray(); //For debugging
        foreach (OpenXmlElement el in children)
        {
            Debug.Write(new String(' ', level) + el.GetType().Name);
            if (!String.IsNullOrEmpty(el.InnerText))
                Debug.WriteLine($"'{el.InnerText}'");
            else
                Debug.WriteLine(String.Empty);

            PrintRecur(el, level + 1);
        }
    }


    /// <summary>
    /// Prints a collection of OpenXML IdPartPair objects for debugging, Recursive
    /// </summary>
    /// <param name="pairs"></param>
    /// <param name="level"></param>
    public static void PrintParts(IEnumerable<IdPartPair>? pairs, int level)
    {
        foreach (var pair in pairs ?? Enumerable.Empty<IdPartPair>())
        {
            Debug.WriteLine(new String(' ', level) + pair.RelationshipId + " " + pair.OpenXmlPart.GetType().Name);
            PrintParts(pair.OpenXmlPart.Parts, level + 2);
        }
    }



    public static void OpenWordprocessingPackageReadonly(string filepath)
    {
        // Open System.IO.Packaging.Package.
        Package wordPackage = Package.Open(filepath, FileMode.Open, FileAccess.Read);

        using (WordprocessingDocument wordDocument = WordprocessingDocument.Open(wordPackage))         // Open a WordprocessingDocument based on a package.
        {
            // Assign a reference to the existing document body. 
            Body body = wordDocument?.MainDocumentPart?.Document.Body ?? throw new Exception("Body is not found");

            // Attempt to add some text.
            Paragraph para = body.AppendChild(new Paragraph());
            Run run = para.AppendChild(new Run());
            run.AppendChild(new Text("Append text in body, but text is not saved - OpenWordprocessingPackageReadonly"));

            // Call Save to generate an exception and show that access is read-only.
            // wordDocument.MainDocumentPart.Document.Save();
        }

        // Close the package.
        wordPackage.Close();
    }


    /*private static void AddImageToBody(WordprocessingDocument wordDoc, string relationshipId)
    {
        // Define the reference of the image.
        var element =
             new Drawing(
                 new DW.Inline(
                     new DW.Extent() { Cx = 990000L, Cy = 792000L },
                     new DW.EffectExtent()
                     {
                         LeftEdge = 0L,
                         TopEdge = 0L,
                         RightEdge = 0L,
                         BottomEdge = 0L
                     },
                     new DW.DocProperties()
                     {
                         Id = (UInt32Value)1U,
                         Name = "Picture 1"
                     },
                     new DW.NonVisualGraphicFrameDrawingProperties(
                         new A.GraphicFrameLocks() { NoChangeAspect = true }),
                     new A.Graphic(
                         new A.GraphicData(
                             new PIC.Picture(
                                 new PIC.NonVisualPictureProperties(
                                     new PIC.NonVisualDrawingProperties()
                                     {
                                         Id = (UInt32Value)0U,
                                         Name = "New Bitmap Image.jpg"
                                     },
                                     new PIC.NonVisualPictureDrawingProperties()),
                                 new PIC.BlipFill(
                                     new A.Blip(
                                         new A.BlipExtensionList(
                                             new A.BlipExtension()
                                             {
                                                 Uri =
                                                    "{28A0092B-C50C-407E-A947-70E740481C1C}"
                                             })
                                     )
                                     {
                                         Embed = relationshipId,
                                         CompressionState =
                                         A.BlipCompressionValues.Print
                                     },
                                     new A.Stretch(
                                         new A.FillRectangle())),
                                 new PIC.ShapeProperties(
                                     new A.Transform2D(
                                         new A.Offset() { X = 0L, Y = 0L },
                                         new A.Extents() { Cx = 990000L, Cy = 792000L }),
                                     new A.PresetGeometry(
                                         new A.AdjustValueList()
                                     )
                                     { Preset = A.ShapeTypeValues.Rectangle }))
                         )
                         { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
                 )
                 {
                     DistanceFromTop = (UInt32Value)0U,
                     DistanceFromBottom = (UInt32Value)0U,
                     DistanceFromLeft = (UInt32Value)0U,
                     DistanceFromRight = (UInt32Value)0U,
                     EditId = "50D07946"
                 });

        // Append the reference to body, the element should be in a Run.
        wordDoc.MainDocumentPart.Document.Body.AppendChild(new Paragraph(new Run(element)));
    }*/

}
