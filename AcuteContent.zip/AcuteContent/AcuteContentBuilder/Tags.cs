﻿using AcuteContent.Xml;
using NbCore.Crypto;

internal record SiteTag(string Slug, string Title, string ImgFileName)
{
    internal List<NBox> Vids { get; } = new List<NBox>();
    internal string? Href { get; set; }

    internal void WriteHtml(NbTag t) => t.a(Href ?? String.Empty, "tile", t => t.img(ImgFileName, "tag_thumb").Text($"{Title} ({Vids.Count})")); //TODO; think about array of lines
    internal void WriteTagHelperHtml(NbTag t) => t.a($"nbcp://{Slug}", "tile", t => t.img(ImgFileName, "tag_thumb").Text(Title));
}

internal record SiteTagGroup(string Slug, string Title, string ImgFileName, NbDictionary<string, SiteTag> Tags)
{
    internal string? Href { get; set; }

    internal void WriteHtml(NbTag t) => t.a(Href ?? String.Empty, "tile", t => t.img(ImgFileName, "tag_thumb").Text(Title));
}

internal static class Tags
{
    internal static List<SiteTagGroup> Load(DirectoryInfo tagsFolder, DirectoryInfo dstFolder)
    {
        List<SiteTagGroup> siteStruct2 = new();
        //Scanning the files first, and finding correcponding folder later
        foreach (FileInfo tagGrpFile in tagsFolder.GetFilesSafe().Where(f => NbMedia.GetFileMediaType(f) == NbMedia.FileMediaTypes.Photo))
        {
            var (title1, tags1) = Regexs.TitleAndTags(tagGrpFile.Name);
            if (tags1.Length != 1)
                throw new Exception($"Tag Group file '{tagGrpFile.FullName}' should have one tag in [] to act as a slug");

            DirectoryInfo tagGrpDir = new(Path.Combine(tagGrpFile.DirSafe().FullName, tagGrpFile.NameWithoutExtension())); //Directory name is file name without extension
            if (!tagGrpDir.Exists)
                throw new Exception($"Can't find directory '{tagGrpDir.FullName}' for file '{tagGrpFile.FullName}'");

            NbDictionary<string, SiteTag> tagDict = new(keyGetter: t => t.Slug, comparer: StringComparer.OrdinalIgnoreCase);
            foreach (FileInfo tagFile in tagGrpDir.GetFilesSafe().Where(f => NbMedia.GetFileMediaType(f) == NbMedia.FileMediaTypes.Photo))
            {
                var (title2, tags2) = Regexs.TitleAndTags(tagFile.Name);
                string obfTagFile = NbFs.ObfuscateFileToDst(tagFile, dstFolder, String.Empty, NbCrypto.Md5Safe64(tagFile.FullName));  //The tag thumbs are small, no need to cache MD5
                foreach (string tag in tags2)
                {
                    if (title2.Contains('!'))
                        title2 = title2[..title2.IndexOf('!')].Trim();
                        //title2 = String.Join("<br/>", title2.Split('!', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries));
                    tagDict.Add(new SiteTag(tag, title2, obfTagFile));
                }
            }

            string obfFile = NbFs.ObfuscateFileToDst(tagGrpFile, dstFolder, String.Empty, NbCrypto.Md5Safe64(tagGrpFile.FullName));  //The tag thumbs are small, no need to cache MD5
            SiteTagGroup stg = new(tags1[0], title1, obfFile, tagDict); //TODO AddPictures
            siteStruct2.Add(stg);
        }
        return siteStruct2;
    }
}
