﻿internal class MediaPacker
{
    public static string FfmpegRepackFileToDst(FileInfo file, DirectoryInfo dstFolder, string subFolder, string md5)
    {
        string fileName = Path.Combine(subFolder, md5 + ".small.mp4");
        string md5Repacked = Path.Combine(dstFolder.FullName, fileName);
        if (!File.Exists(md5Repacked))  //Repackage to destination
        {
            int ret = NbProcess.RunDosWindowSync(@"C:\App\ffmpeg\bin\ffmpeg.exe", workDir: null,
                @"-i",
                file.FullName,
                "-filter:v", "scale=-1:360",
                "-c:v", "libx264",
                "-preset", "slow",
                "-crf", "25",
                "-c:a", "copy",
                md5Repacked
               );

            if (ret != 0)
            {
                Console.WriteLine("ffmpeg.exe failed");
                Console.Write("Press Any key...");
                Console.ReadKey();
                Console.WriteLine();
                if (File.Exists(md5Repacked))
                    File.Delete(md5Repacked);
            }
        }

        return fileName;
    }

    //C:\App\ffmpeg\bin\ffmpeg -i C:\Temp\Gul.mp4 -i C:\Temp\poker.m4a -filter:v scale = -1:360 -c:v libx264 -preset slow -crf 25 -filter_complex amix = inputs = 2:duration=first:weights="1 0.25" C:\Temp\!res1.mp4

    public static string FfmpegRepackFileToDst(FileInfo file, DirectoryInfo dstFolder, string subFolder, string audioMixin, string md5)
    {
        string fileName = Path.Combine(subFolder, md5 + ".small.mp4");
        string md5Repacked = Path.Combine(dstFolder.FullName, fileName);
        if (!File.Exists(md5Repacked))  //Repackage to destination
        {
            // var (ret, std, err) = NbProcess.RunSync
            int ret = NbProcess.RunDosWindowSync(@"C:\App\ffmpeg\bin\ffmpeg.exe", workDir: null,
                "-i", file.FullName,
                "-i", audioMixin,
                "-filter:v", "scale=-1:360",
                "-c:v", "libx264",
                "-preset", "slow",
                "-crf", "25",
                @"-filter_complex", @"amix=inputs=2:duration=first:weights=""0.75 0.35""",
                md5Repacked
               );

            if (ret != 0)
            {
                Console.WriteLine("ffmpeg.exe failed");
                Console.Write("Press Any key...");
                Console.ReadKey();
                Console.WriteLine();
                if (File.Exists(md5Repacked))
                    File.Delete(md5Repacked);
            }
        }

        return fileName;
    }
}
