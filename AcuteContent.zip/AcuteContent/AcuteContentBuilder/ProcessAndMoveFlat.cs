﻿using AcuteContent.Xml;
using AcuteContentBuilder.Xml;
using NbFiler;

//TODO: salt for index.html files to avoid local caching
//Как указывать время кэширования в html документе

//TODO:  p не может быть внутри span,  нужно иметь возможность поместить текст ии img внутри a-тэга
//TODO: вытасткивать дату создание из файла и покзывать его на страничке?

//TODO: Удаление старых файлов

internal record ProcAndMoveContext(DirectoryInfo SrcFolder, DirectoryInfo DstFolder, string SubFolder, string NbCssFile, DateTime TimeStamp,
    bool EnsureThumbs, bool RepackVideo, string MediaPlayer, List<string>? MixInAudioFiles,
    Dictionary<string, SiteTag> Tags, FilerModel Filer, HashSet<string> MissingTags)
{ }

internal static class ProcessAndMoveFlat
{
    private static readonly Random Rnd = new();
    internal static readonly string[] SkipTags = new[] { "Skip", "LarSkip" };

    public static void ProcessSimpleDir(AcuteContentBuilderConfig conf)
    {
        using FilerModel fm = new(conf.source_dir, conf.source_dir + ".filer");
        fm.Load();
        fm.Sync(DateTime.UtcNow);
        NbProcess.RunDosCommandSync("del", conf.DestDir, "/S", "*.html", "*.css", "folder.*");

        string nbCssFile = NbFs.ObfuscateFileToDst(new FileInfo(@"Data/nb.css"), conf.DestDir, subFolder: String.Empty, md5: null);
        string nbTagHlpCssFile = NbFs.ObfuscateFileToDst(new FileInfo(@"Data/nb.css"), conf.TagsHelperDir, subFolder: String.Empty, md5: null);

        HashSet<string> missingTags = ProcessAndMoveFlat.ProcessAll(conf, nbCssFile, fm);
        foreach (string tag in missingTags)
            Console.WriteLine(tag);
    }

    /// <summary>
    /// Parses the folder and creates "content.xml" file bases on folder contents if xml file is not found
    /// </summary>
    /// <param name="srcFolder"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private static HashSet<string> ProcessAll(AcuteContentBuilderConfig conf, string nbCssFile, FilerModel fm)
    {
        List<SiteTagGroup> siteStruct2 = Tags.Load(conf.TagstDir, conf.DestDir);
        HashSet<string> missingTags = new();

        Dictionary<string, SiteTag> tags = new(siteStruct2.SelectMany(g => g.Tags), StringComparer.OrdinalIgnoreCase);

        List<string>? audioMixIn = null;
        if (conf.music_mixin_dir != null && Directory.Exists(conf.music_mixin_dir))
        {
            audioMixIn = new List<string>();
            foreach (FileInfo file in NbFs.FlattenDir(new DirectoryInfo(conf.music_mixin_dir)).SelectMany(d => d.GetFiles()))
            {
                if (NbMedia.GetFileMediaType(file) != NbMedia.FileMediaTypes.Audio)
                    continue;
                audioMixIn.Add(file.FullName);
            }
        }

        ProcAndMoveContext cont = new(conf.SourceDir, conf.DestDir, String.Empty, nbCssFile, DateTime.UtcNow, conf.ensure_thumbs, RepackVideo: false,
            conf.media_player, audioMixIn, tags, fm, missingTags);
        ProcessContentFolderRecc(siteStruct2, cont);


        ProcAndMoveContext helperCont = cont with { DstFolder = new DirectoryInfo(@"C:\AutoDelete\LocalTags") };
        List<SiteTagGroup> siteStruct3 = Tags.Load(conf.TagstDir, helperCont.DstFolder); //Changed Dst folder
        GenTagsHelperHtml("TagHelper", siteStruct3, helperCont);

        return missingTags;
    }

    /// <summary>
    /// Parses the folder and creates "content.xml" file bases on folder contents if xml file is not found
    /// </summary>
    /// <param name="srcFolder"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    private static void ProcessContentFolderRecc(List<SiteTagGroup> siteStruct, ProcAndMoveContext cont)
    {
        if (!cont.SrcFolder.Exists)
            throw new Exception($"Folder '{cont.SrcFolder.FullName}' doesn't exist");
        if (!cont.DstFolder.Exists)
            NbFs.CreateDirRecursive(cont.DstFolder);

        //Generate content XML and create destination files
        List<NBox> boxes = DirectoryToBoxes(siteStruct, cont);

        AcuteContentXml xml = new() { title = cont.SrcFolder.Name, boxes = new NDir() { Items = boxes.ToArray() } };
        string contFile = Path.Combine(cont.DstFolder.FullName, cont.SubFolder, "content.xml");
        xml.Save(contFile);

        GenTagsHtml(xml.title, siteStruct, cont);
    }

    private static void GenTagsHelperHtml(string title, List<SiteTagGroup> siteStruct, ProcAndMoveContext cont)
    {
        //Generate HTML from Content.xml
        HtmlParam htmlPars = new(title, CssFile: cont.NbCssFile);
        HtmlFileName htmlFile = new(Directory: cont.DstFolder.FullName, Id: "index", cont.TimeStamp);
        foreach (SiteTagGroup tagGroup in siteStruct)
        {
            foreach (SiteTag tagItem in tagGroup.Tags.Values.Where(t => t.Vids.Any()).OrderBy(t => t.Title))
            {
                //File for each tag
                /*HtmlParam lvl2file = htmlPars with { Id = tagItem.Slug, Title = tagItem.Title };
                tagItem.Href = lvl2file.HtmlFileJustName;
                HtmlTag.CreateHtmlPage(lvl2file, t =>
                {
                    foreach (NBox box in tagItem.Vids)
                    {
                        if (tagGroup.Tags.Keys.ContainsAnyIC(box.tags))
                            t.span("vid_tile", box.WriteHtml);
                    }
                });*/
            }

            //File for each tag group
            HtmlParam lvl1file = htmlPars with { Title = tagGroup.Title };
            HtmlFileName lvl1fileName = htmlFile with { Id = tagGroup.Slug };
            tagGroup.Href = lvl1fileName.HtmlFileJustName;
            HtmlTag.CreateHtmlPage(lvl1fileName.HtmlFileJustName, lvl1file, t =>
            {
                foreach (SiteTag st in tagGroup.Tags.Values)
                    st.WriteTagHelperHtml(t);
            });
        }

        //Root file listing all tag groups
        htmlPars = htmlPars with { DisableCache = true }; // Don't timestamp index.html
        htmlFile = htmlFile with { TimeStamp = default };
        HtmlTag.CreateHtmlPage(htmlFile.HtmlFileFullName, htmlPars, t =>
        {
            foreach (SiteTagGroup stg in siteStruct.Where(st => st.Href != null))
                stg.WriteHtml(t);
        });
    }

    private static void GenTagsHtml(string title, List<SiteTagGroup> siteStruct, ProcAndMoveContext cont)
    {
        var linkType = NBox.LinkType.Local;
        //Generate HTML from Content.xml
        HtmlParam htmlPars = new(title, CssFile: cont.NbCssFile);
        HtmlFileName htmlFile = new(Directory: cont.DstFolder.FullName, Id: "index", cont.TimeStamp);
        foreach (SiteTagGroup tagGroup in siteStruct)
        {
            foreach (SiteTag tagItem in tagGroup.Tags.Values.Where(t => t.Vids.Any()).OrderBy(t => t.Title))
            {
                //File for each tag
                HtmlParam lvl2file = htmlPars with { Title = tagItem.Title };
                HtmlFileName lvl2fileName = htmlFile with { Id = tagItem.Slug, };
                tagItem.Href = lvl2fileName.HtmlFileJustName;
                HtmlTag.CreateHtmlPage(lvl2fileName.HtmlFileJustName, lvl2file, t =>
                {
                    foreach (NBox box in tagItem.Vids)
                    {
                        if (tagGroup.Tags.Keys.ContainsAnyIC(box.tags))
                            t.span("vid_tile", t=> box.WriteHtml(t, null, linkType));
                    }
                });
            }

            //File for each tag group
            HtmlParam lvl1file = htmlPars with { Title = tagGroup.Title };
            HtmlFileName lvl1fileName = htmlFile with { Id = tagGroup.Slug };
            tagGroup.Href = lvl1fileName.HtmlFileJustName;
            HtmlTag.CreateHtmlPage(lvl1fileName.HtmlFileJustName, lvl1file, t =>
            {
                foreach (SiteTag st in tagGroup.Tags.Values.Where(st => st.Href != null))
                    st.WriteHtml(t);
            });
        }

        //Root file listing all tag groups
        htmlPars = htmlPars with { DisableCache = true }; // Don't timestamp index.html
        htmlFile = htmlFile with { TimeStamp = default };
        HtmlTag.CreateHtmlPage(htmlFile.HtmlFileFullName, htmlPars, t =>
        {
            foreach (SiteTagGroup stg in siteStruct.Where(st => st.Href != null))
                stg.WriteHtml(t);
        });
    }

    private static List<NBox> DirectoryToBoxes(List<SiteTagGroup> siteStruct, ProcAndMoveContext cont)
    {
        List<NBox> boxes = new();

        //Process dirs
        var dirs = cont.SrcFolder.GetDirsSafe();
        foreach (DirectoryInfo dir in dirs)
        {
            var (title, tags) = Regexs.TitleAndTagsFolder(dir.Name);
            var isRepack = tags.Contains("repack", StringComparer.OrdinalIgnoreCase);

            NBox? nbox = ProcessContForDir(siteStruct, cont with { SrcFolder = dir, RepackVideo = isRepack });
            if (nbox != null)
                boxes.Add(nbox);
        }

        //Process Files
        Dictionary<string, VidEntry> vidEntries = new();
        List<FileInfo> picEntries = new();

        foreach (FileInfo fi in cont.SrcFolder.GetFilesSafe().OrderBy(fi => fi.Name))
        {
            switch (NbMedia.GetFileMediaType(fi))
            {
                case NbMedia.FileMediaTypes.Video:
                    vidEntries.Add(fi.Name, new VidEntry(fi));
                    break;

                case NbMedia.FileMediaTypes.Photo:
                    if (fi.NameWithoutExtension().EqIC("folder")) //Special file, used at the level above
                        continue;

                    string? key = vidEntries.Keys.SingleOrDefaultVerbose(k => fi.Name.StartsWith(k, StringComparison.OrdinalIgnoreCase));
                    if (key != null) //Attach thumbnail to a video file
                    {
                        var rec = vidEntries[key];
                        if (rec.ThumbFile != null)
                            throw new Exception($"Video '{rec.VidFile.FullName}' has two thumbnails: '{rec.ThumbFile.FullName}' and '{fi.FullName}'");
                        rec.ThumbFile = fi;
                    }
                    else //Or save as standalone picture
                        picEntries.Add(fi);
                    break;

                default: break; //Ignore other types of files
            }
        }

        if (cont.EnsureThumbs)
            EnsureThumbs(vidEntries, cont.SrcFolder, cont.MediaPlayer);

        foreach (VidEntry vidEntry in vidEntries.Values.OrderBy(ve => ve.VidFile.Name)) //Pictures
        {
            try
            {
                NBox? nbox = ProcessContVid(vidEntry, cont);
                if (nbox != null)
                    boxes.Add(nbox);
            }
            catch
            {
                if (vidEntry.ThumbFile != null)
                    Task.Run(() => NbProcess.Explorer(vidEntry.ThumbFile));
                //throw; //Continue loop
            }
        }

        foreach (FileInfo file in picEntries) //Pictures
        {
            NBox? nbox = ProcessContPic(file, cont);
            if (nbox != null)
                boxes.Add(nbox);
        }
        return boxes;
    }

    private static void EnsureThumbs(Dictionary<string, VidEntry> vids, DirectoryInfo workDir, string mpc)
    {
        foreach (var ent in vids.Values.Where(e => e.ThumbFile == null))
        {
            NbProcess.RunSync(mpc, workDir, ent.VidFile.FullName);
        }
    }

    /// <summary>
    /// MD5 for directory is calculated using the folder.jpg file MD5
    /// </summary>
    /// <param name="cont"></param>
    /// <returns></returns>
    /// <exception cref="FileNotFoundException"></exception>
    private static NBox? ProcessContForDir(List<SiteTagGroup> siteStruct, ProcAndMoveContext cont)
    {
        //var (fldTitle, fldTags) = Regexs.TitleAndTagsFolder(cont.SrcFolder.Name);

        //Find the folder.ext file
        FileInfo folderThumbFi = cont.SrcFolder.GetFiles("folder.*").FirstOrDefault() ?? throw new FileNotFoundException($"Folder '{cont.SrcFolder.FullName}' doesn't have a folder.* file inside of it to be used as a folder picture");
        string md5 = cont.Filer.Md5ForFileFail(folderThumbFi.FullName);

        string md5DirPath = Path.Combine(cont.DstFolder.FullName, cont.SubFolder, md5);
        NbFs.CreateDirRecursive(md5DirPath);
        folderThumbFi.CopyTo(Path.Combine(md5DirPath, folderThumbFi.Name.ToLowerInvariant()));

        ProcessContentFolderRecc(siteStruct, cont with { SubFolder = Path.Combine(cont.SubFolder, md5) }); //Recursive call, DstFolder stays the name, subfolder receives another md5
        return new NDir(md5, new NThumb() { title = cont.SrcFolder.Name, src = folderThumbFi.Name });
    }

    private static NVid? ProcessContVid(VidEntry vid, ProcAndMoveContext cont)
    {
        if (vid.ThumbFile == null)
            return null;

        try
        {
            string md5 = cont.Filer.Md5ForFileFail(vid.VidFile.FullName);
            var (title, tags) = vid.TitleAndTags();  //Title and Tags for a single video
            if (tags.ContainsAnyIC(SkipTags))  //Skipping by tag
                return null;

            if (String.IsNullOrWhiteSpace(title))
                title = String.Join(", ", tags.Select(t => cont.Tags[t].Title.Trim()));

            Console.Write($"Obfuscating '{vid.VidFile.Name}'...");
            NThumb nthumb = new()
            {
                src = NbFs.ObfuscateFileToDst(vid.ThumbFile, cont.DstFolder, cont.SubFolder, md5), //Video picture
                title = title,
            };

            string? repackedVid = null;
            if (cont.RepackVideo)
            {
                if (cont.MixInAudioFiles != null)
                {
                    string randAudio = Rnd.OneOf(cont.MixInAudioFiles);
                    repackedVid = MediaPacker.FfmpegRepackFileToDst(vid.VidFile, cont.DstFolder, cont.SubFolder, randAudio, md5);
                }
                else
                    repackedVid = MediaPacker.FfmpegRepackFileToDst(vid.VidFile, cont.DstFolder, cont.SubFolder, md5);
            }

            string origVid = NbFs.ObfuscateFileToDst(vid.VidFile, cont.DstFolder, cont.SubFolder, md5);
            NVid nvid = new() { src = origVid, src_small = repackedVid ?? origVid, thumb = nthumb, tags = tags };  //Video files itself
            Console.WriteLine("done!");

            //Add the box to the Tag object's collection of boxes
            foreach (string tag in tags)
            {
                if (cont.Tags.TryGetValue(tag, out var t))
                    t.Vids.Add(nvid);
                else
                    cont.MissingTags.Add(tag);
            }
            return nvid;
        }
        catch (Exception ex)
        {
            Console.WriteLine(NbException.Exception2String(ex));
            Task.Run(() => NbProcess.Explorer(vid.ThumbFile));
            throw;
        }
    }

    private static NPic? ProcessContPic(FileInfo file, ProcAndMoveContext cont)
    {
        string md5 = cont.Filer.Md5ForFileFail(file.FullName);
        var npic = new NPic() { src = NbFs.ObfuscateFileToDst(file, cont.DstFolder, cont.SubFolder, md5) }; //TODO: support tags
        return npic;
    }
}

/// <summary>
/// VidEntry represents a couple of FileInfos - one for video, another is for associated thumbnail. This has nothing to do with HTML generation.
/// In the future the vidoe might have several thumbs, so ThumbFile might become a List<FileInfo>
/// </summary>
/// <param name="VidFile"></param>
internal record VidEntry(FileInfo VidFile)
{
    public FileInfo? ThumbFile { get; set; }

    //private static readonly Regex TitleAndTagsRegex = new(@"^(.+?)\s*(\[.+\])\.\S+$");  //Use*? to make the* non-greedy.
    internal (string title, string[] tags) TitleAndTags()
    {
        if (ThumbFile == null)
            throw new ArgumentException("ThumbFile was no set");
        if (!ThumbFile.Name.StartsWith(VidFile.Name, StringComparison.OrdinalIgnoreCase))
            throw new Exception($"Thumb filename '{ThumbFile?.FullName}' is not continuation of vidfile name: '{VidFile}'");

        try
        {
            string remainder = ThumbFile.Name[VidFile.Name.Length..].TrimStart('_', ' ', '.');
            return Regexs.TitleAndTags(remainder);
        }
        catch
        {
            Task.Run(() => NbProcess.Explorer(ThumbFile));
            throw;
        }
    }
}