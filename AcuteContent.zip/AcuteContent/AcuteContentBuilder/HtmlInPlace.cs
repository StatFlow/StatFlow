﻿using AcuteContent.Xml;

internal static class HtmlInPlace
{
    const string cssFile = @"C:\Repo\Cs\AcuteContent\AcuteContentBuilder\Data\nb.css"; //TODO: copy to dst folder or embed
    private static readonly NBox.LinkType LinkTypeLocal = NBox.LinkType.Local;

    internal static string CreateXmlForDirsReccur(NDir ndir)
    {
        string dirPath = ndir.Path(NBox.LinkType.RootPath); //Check if it still works
        if (!Directory.Exists(dirPath))
            throw new Exception($"Directory '{dirPath}' doesn't exist");
        

        HtmlParam htmlPars = new(Title: ndir.url, CssFile: cssFile);
        HtmlFileName htmlFile = new(Directory: dirPath, Id: "index", default);

        HtmlTag.CreateHtmlPage(htmlFile.HtmlFileFullName, htmlPars, t =>
        {
            foreach (var box in ndir.Items.Safe())
            {
                switch (box)
                {
                    case NDir subDir: CreateXmlForDirsReccur(subDir); break; 


                    default: box.WriteHtml(t, ndir, LinkTypeLocal); break;
                }
            }
        });

        return htmlFile.HtmlFileFullName;
    }

    internal static string CreateXmlForDir(NDir ndir, NBox.LinkType linkType)
    {
        string dirPath = ndir.Path(linkType); //Check if it still works
        if (!Directory.Exists(dirPath))
            throw new Exception($"Directory '{dirPath}' doesn't exist");

        HtmlParam htmlPars = new(Title: ndir.url, CssFile: cssFile);
        HtmlFileName htmlFile = new(Directory: dirPath, Id: "index", default);
        HtmlTag.CreateHtmlPage(htmlFile.HtmlFileFullName, htmlPars, t =>
        {
            foreach (var box in ndir.Items.Safe())
            {
                //if (box is NDir)
                //    continue;
                
                box.WriteHtml(t, ndir, linkType);
            }
        });

        return htmlFile.HtmlFileFullName;
    }

}
