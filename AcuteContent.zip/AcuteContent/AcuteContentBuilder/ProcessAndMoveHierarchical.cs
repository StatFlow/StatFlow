﻿using AcuteContent.Xml;
using NbCore.Crypto;
using static AcuteContent.Xml.NBox;

internal class ProcessAndMoveHierarchical
{
    /// <summary>
    /// Parses the folder and creates "content.xml" file bases on folder contents if xml file is not found
    /// </summary>
    /// <param name="srcFolder"></param>
    /// <returns></returns>
    /// <exception cref="Exception"></exception>
    public static void AcuteContentFolderToXml(DirectoryInfo srcFolder, DirectoryInfo dstFolder, string nbCss)
    {
        if (!srcFolder.Exists)
            throw new Exception($"Folder '{srcFolder.FullName}' doesn't exist");
        if (!dstFolder.Exists)
            NbFs.CreateDirRecursive(dstFolder);

        string contFile = Path.Combine(dstFolder.FullName, "content.xml");
        /*if (File.Exists(contFile))
            return AcuteContentXml.LoadFile(contFile); //Do we need to return it?*/

        AcuteContentXml xml = new() { title = srcFolder.Name };
        List<NBox> boxes = new();

        var dirs = srcFolder.GetDirsSafe();
        foreach (DirectoryInfo dir in dirs)
        {
            NBox? nbox = ProcessContForDir(dir, dstFolder, nbCss);
            if (nbox != null)
                boxes.Add(nbox);
        }

        //Process Files
        FileInfo[] files = srcFolder.GetFilesSafe();
        foreach (FileInfo file in files)
        {
            if (file.NameWithoutExtension().EqIC("folder")) //Special file, used at the level above
                continue;

            NBox? nbox = ProcessContForFile(file, dstFolder);
            if (nbox != null)
                boxes.Add(nbox);
        }

        xml.boxes = new NDir() { Items = boxes.ToArray() };
        xml.Save(contFile);

        HtmlParam htmlPars = new(xml.title, nbCss);
        HtmlFileName htmlFile = new(dstFolder.FullName, "index", DateTime.UtcNow);
        HtmlTag.CreateHtmlPage(htmlFile.HtmlFileFullName, htmlPars, t => AcuteContentXml2Html(t, null, LinkType.Local, xml));
    }

    internal static void AcuteContentXml2Html(NbTag t, NDir? ndir, LinkType linkType,  AcuteContentXml cont)
    {
        foreach (NBox box in cont.boxes.Items.Safe())
        {
            t.TAT("span", a => a["class"] = "tile", t => box.WriteHtml(t, ndir, linkType));
        }
    }

    private static NBox? ProcessContForDir(DirectoryInfo dir, DirectoryInfo dstFolder, string nbCss)
    {
        //Find the folder.ext file
        var fi = dir.GetFiles("folder.*").FirstOrDefault() ?? throw new FileNotFoundException($"Folder '{dir.FullName}' doesn't have a folder.* file inside of it to be used as a folder picture");
        var md5 = NbCrypto.Md5Safe64(fi.FullName);
        string md5DirPath = Path.Combine(dstFolder.FullName, md5);
        NbFs.CreateDirRecursive(md5DirPath);
        fi.CopyTo(Path.Combine(md5DirPath, fi.Name.ToLowerInvariant()));

        AcuteContentFolderToXml(dir, new DirectoryInfo(md5DirPath), nbCss); //Recursive call

        return new NDir(md5, new NThumb() { title = dir.Name, src = fi.Name });
    }

    public static NBox? ProcessContForFile(FileInfo file, DirectoryInfo dstFolder)
    {
        string dir = file.DirSafe().FullName;

        if (NbMedia.GetFileMediaType(file) == NbMedia.FileMediaTypes.Photo)
        {
            var md5 = NbCrypto.Md5Safe64(file.FullName);
            var nthumb = new NThumb() { src = CopyFileToDst(file, dstFolder, md5) };

            var match = Regexs.MediaPlayerSnapshotFile().Match(file.Name);
            if (!match.Success) //This is just a picture file
            {
                nthumb.title = Regexs.TitleFromFileName(file); //Simple filename - get the title
                return nthumb;
            }

            ///// This is a snapshot for a video file, that should be there /////
            var vidFile = new FileInfo(Path.Combine(dir, match.Groups[1].Value));
            if (!vidFile.Exists)
                throw new Exception($"Can't find video '{vidFile.FullName}' for snapshot file '{file.FullName}'");

            var vidName = CopyFileToDst(vidFile, dstFolder, md5);

            nthumb.title = Regexs.TitleFromFileName(vidFile); //Snapshot filename, use simple videofile name for the title
            return new NVid() { src = vidName, thumb = nthumb };
        }
        return null;
    }

    private static string CopyFileToDst(FileInfo file, DirectoryInfo dstFolder, string md5)
    {
        string fileName = md5 + file.Extension;
        string md5FilePic = Path.Combine(dstFolder.FullName, md5 + file.Extension);
        if (!File.Exists(md5FilePic))
            File.Copy(file.FullName, md5FilePic);
        return fileName;
    }
}