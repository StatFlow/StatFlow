using Microsoft.Web.WebView2.Core;
using NbCore;
using System.Diagnostics;

namespace AcuteBrowser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            webView.CoreWebView2InitializationCompleted += WebView21_CoreWebView2InitializationCompleted;
        }

        private void WebView21_CoreWebView2InitializationCompleted(object? sender, CoreWebView2InitializationCompletedEventArgs e) => Debug.WriteLine("CoreWebView2InitializationCompleted");

        private async void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                await webView.EnsureCoreWebView2Async(null);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(NbException.Exception2String(ex));
            }
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            //webView.NavigateToString($"""<html><body><h1>Some Text</h1><a href="nbmpc://C:\Users\budan\Videos\retra.mp4">nbmpc link</a><a href="nbcb://MarK">copy to clipboard</a></body></html>""");

            //webView.Source = new Uri("http://qnikbud.myftp.org:8800/acct/");
            webView.Source = new Uri("file:///C:/AutoDelete/LocalTags/index.html");

        }

        const string Mpc = @"C:\Program Files (x86)\K-Lite Codec Pack\MPC-HC64\mpc-hc64.exe";

        private async void WebView_NavigationStarting(object sender, CoreWebView2NavigationStartingEventArgs e)
        {
            try
            {
                var uri = new Uri(e.Uri);
                switch (uri.Scheme)
                {
                    case "nbmpc":
                        var file = new FileInfo(uri.AbsolutePath);
                        if (!file.Exists)
                            throw new Exception($"File '{file.FullName}' doens't exist");

                        await NbProcess.RunAsync(Mpc, file.DirSafe(), file.FullName).ConfigureAwait(false);

                        e.Cancel = true;
                        break;

                    case "nbcb":
                    case "nbcp":
                        Clipboard.SetText(e.Uri[7..]); //Skip nbcb://
                        break;
                }

            }
            catch (Exception ex)
            {
                //TODO: thread safe Dialog
                //MessageBox.Show(NbException.Exception2String(ex), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Debug.WriteLine(NbException.Exception2String(ex));
            }
        }
    }
}